from pathlib import Path
import sys

path=Path('duck-quest/js/game-v96.js')
if not path.exists():
    raise SystemExit('ERROR: duck-quest/js/game-v96.js not found')
text=path.read_text()

MARKER="window.DUCKIE_DASH_CORE='24.208-driver-safe-coins';"
if MARKER in text:
    print('v24.208 Dash core patch already present.')
    raise SystemExit(0)

def require_once(needle, label):
    count=text.count(needle)
    if count != 1:
        raise SystemExit(f'ERROR: expected exactly one {label}, found {count}')

def replace_between(source, start, end, replacement, label):
    a=source.find(start)
    if a < 0:
        raise SystemExit(f'ERROR: start marker missing for {label}')
    b=source.find(end, a+len(start))
    if b < 0:
        raise SystemExit(f'ERROR: end marker missing for {label}')
    return source[:a] + replacement + source[b:]

# 1) Mark the patched Dash core inside the original Duckie Dash closure.
needle="// v24.166 — Duckie Dash, Buddy Eggs, Mysterious Merchant, and Sibling Spat\n(function(){\n  const DASH_COST=3;"
require_once(needle,'Duckie Dash v24.166 opening')
text=text.replace(needle, needle+"\n  "+MARKER, 1)

# 2) Add reliable, wrapper-relative driver/cart styling. The OC layer is not tied
#    to viewport percentages, so it stays seated with the duck on tall phone screens.
needle="  document.head.appendChild(extraCss);\n\n  function injectFeatureMarkup(){"
require_once(needle,'extraCss append point')
style_block="""  document.head.appendChild(extraCss);

  const dashV208Style=document.createElement('style');
  dashV208Style.id='duckieDashCoreV208Style';
  dashV208Style.textContent=`
    #dashRunner.dash-runner-v208{
      position:absolute!important;
      width:20%!important;
      max-width:92px!important;
      aspect-ratio:1 / 1!important;
      height:auto!important;
      left:12%!important;
      bottom:10%!important;
      z-index:5!important;
      overflow:visible!important;
      pointer-events:none!important;
      image-rendering:pixelated!important;
      will-change:transform;
    }
    #dashRunner.dash-runner-v208 .dash-cart-v208,
    #dashRunner.dash-runner-v208 .dash-driver-v208{
      position:absolute!important;
      display:block!important;
      object-fit:contain!important;
      image-rendering:pixelated!important;
      pointer-events:none!important;
      user-select:none!important;
      -webkit-user-drag:none!important;
    }
    #dashRunner.dash-runner-v208 .dash-cart-v208{
      inset:0!important;
      width:100%!important;
      height:100%!important;
      z-index:5!important;
    }
    /* Show the upper body clearly above the duck while hiding the legs so the OC reads as riding. */
    #dashRunner.dash-runner-v208 .dash-driver-v208{
      width:70%!important;
      height:112%!important;
      left:2%!important;
      top:-31%!important;
      z-index:6!important;
      object-position:center top!important;
      clip-path:inset(0 0 29% 0);
      filter:drop-shadow(0 1px 0 rgba(0,0,0,.12));
    }
    #dashRunner.dash-runner-v208.hit .dash-driver-v208{
      filter:brightness(1.15) saturate(1.08) drop-shadow(0 1px 0 rgba(0,0,0,.12));
    }
  `;
  document.head.appendChild(dashV208Style);

  function injectFeatureMarkup(){"""
text=text.replace(needle,style_block,1)

# 3) Replace the single cart image with one runner wrapper containing the OC and cart.
old_track='<div id="dashTrack" class="dash-track"><img id="dashBg" class="dash-bg" src="${AREA_CONFIG.meadow.backgrounds[0]}" alt=""><img id="dashRunner" class="dash-runner" src="${DASH_CARTS[0].image}" alt="Duck cart"><div id="dashOverlay" class="dash-overlay"><div class="dash-overlay-card"><strong>Ready?</strong><small>Use 3 Jump Tokens to run. A rare Free Run is used first if you have one.</small><button id="dashStart" class="pixel-button primary" type="button">Start Duckie Dash</button></div></div></div>'
new_track='<div id="dashTrack" class="dash-track"><img id="dashBg" class="dash-bg" src="${AREA_CONFIG.meadow.backgrounds[0]}" alt=""><div id="dashRunner" class="dash-runner dash-runner-v208" aria-label="OC riding a duck cart"><img id="dashRunnerDriverV208" class="dash-driver-v208" src="assets/characters/peep/base/idle-1.webp" alt=""><img id="dashRunnerCartV208" class="dash-cart-v208" src="${DASH_CARTS[0].image}" alt="Duck cart"></div><div id="dashOverlay" class="dash-overlay"><div class="dash-overlay-card"><strong>Ready?</strong><small>Use 3 Jump Tokens to run. A rare Free Run is used first if you have one.</small><button id="dashStart" class="pixel-button primary" type="button">Start Duckie Dash</button></div></div></div>'
require_once(old_track,'Dash track markup')
text=text.replace(old_track,new_track,1)

# 4) Add driver source/sync helpers before the feature badge refresh.
refresh_marker='  function refreshFeatureBadges(){'
require_once(refresh_marker,'refreshFeatureBadges')
helpers="""  function dashDriverIdleSrcV208(){
    try{const frames=heroIdleFrames();return Array.isArray(frames)&&frames[0]?frames[0]:'assets/characters/peep/base/idle-1.webp';}
    catch(error){return 'assets/characters/peep/base/idle-1.webp';}
  }
  function dashDriverHurtSrcV208(){
    try{return heroHurtFrame()||dashDriverIdleSrcV208();}
    catch(error){return dashDriverIdleSrcV208();}
  }
  function syncDashDriverV208(hurt=false){
    const driver=document.querySelector('#dashRunnerDriverV208');
    const cart=document.querySelector('#dashRunnerCartV208');
    if(cart){const selected=selectedCart();if(selected?.image&&cart.getAttribute('src')!==selected.image)cart.src=selected.image;}
    if(driver){
      const src=hurt?dashDriverHurtSrcV208():dashDriverIdleSrcV208();
      if(driver.getAttribute('src')!==src)driver.src=src;
      driver.onerror=()=>{driver.onerror=null;driver.src='assets/characters/peep/base/idle-1.webp';};
    }
  }

"""
text=text.replace(refresh_marker,helpers+refresh_marker,1)

# 5) Refresh the real child cart/driver rather than assigning src to the wrapper DIV.
start='  function refreshFeatureBadges(){'
end='\n\n  function renderDashSelectors(){'
new_refresh="""  function refreshFeatureBadges(){
    ensureExpansionSave();
    const token=specialQty('jump-token'),free=questSave.dash.freeRuns,ready=readyEggs(),cart=selectedCart();
    const map=[['#dashTokenHome',token],['#dashTokenCount',token],['#dashFreeHome',free],['#dashFreeCount',free],['#dashHighHome',questSave.dash.highScore],['#commonEggQty',specialQty('common-egg')],['#rareEggQty',specialQty('rare-egg')],['#hatchReadyQty',ready]];
    map.forEach(([sel,v])=>{const el=document.querySelector(sel);if(el)el.textContent=String(v);});
    const badge=document.querySelector('#hatchReadyBadge');if(badge)badge.textContent=ready?`(${ready} Ready!)`:'';
    const cartLabel=document.querySelector('#dashCartLabel');if(cartLabel)cartLabel.textContent=cart.name;
    const cartImage=document.querySelector('#dashRunnerCartV208');if(cartImage)cartImage.src=cart.image;
    else {const runner=document.querySelector('#dashRunner');if(runner&&runner.tagName==='IMG')runner.src=cart.image;}
    syncDashDriverV208(false);
  }"""
text=replace_between(text,start,end,new_refresh,'refreshFeatureBadges body')

# 6) Preview always restores both rider and cart.
start='  function resetDashPreview(){'
end='\n  function renderDashReadyOverlay(){'
new_reset="""  function resetDashPreview(){ensureExpansionSave();const cfg=DASH_STAGE[questSave.dash.selectedStage];const bg=document.querySelector('#dashBg');if(bg)bg.src=cfg.backgrounds[0];const runner=document.querySelector('#dashRunner');if(runner)runner.style.transform='translateY(0px)';syncDashDriverV208(false);dashHud();}"""
text=replace_between(text,start,end,new_reset,'resetDashPreview body')

# 7) Replace spawning with enforced horizontal safety. The only coins allowed to share
#    a mushroom/obstacle X-position are the intentional high vertical double-jump pair.
start='  function spawnDashThing(kind){'
end='\n  function recordTinyDuck(){'
new_spawn="""  function spawnDashThing(kind){
    const track=dashTrack();if(!track)return;
    const cfg=DASH_STAGE[questSave.dash.selectedStage];
    const W=track.clientWidth,spawnX=W+40,groundRaise=4;
    const safeObstacleGap=Math.max(112,Math.min(140,W*.28));
    const pickupGap=Math.max(52,Math.min(66,W*.14));
    const obstacleNear=(x,gap=safeObstacleGap)=>dash.obstacles.some(o=>Math.abs(o.x-x)<gap);
    const pickupNear=(x,gap=pickupGap)=>dash.pickups.some(o=>Math.abs(o.x-x)<gap);
    const add=(thing,x,raise,extra={})=>{
      const el=document.createElement('img');
      el.className=`dash-thing ${thing==='obstacle'?'dash-obstacle':thing==='tiny'?'dash-tiny-duck':'dash-coin'}`;
      el.src=thing==='obstacle'?cfg.obstacle:thing==='tiny'?'../assets/ducks/Tiny-duck.webp':'../assets/ui/pink-coin.webp';
      el.alt='';track.appendChild(el);
      const obj={kind:thing,x,raise,el,hit:false,...extra};
      (thing==='obstacle'?dash.obstacles:dash.pickups).push(obj);
      return obj;
    };

    if(kind==='obstacle'){
      let x=spawnX,tries=0;
      // Never introduce a mushroom/obstacle beside an existing coin lane.
      while((obstacleNear(x,96)||dash.pickups.some(o=>o.kind==='coin'&&!o.overObstacleStack&&Math.abs(o.x-x)<safeObstacleGap))&&tries<10){x+=70;tries++;}
      add('obstacle',x,groundRaise);
      return;
    }

    if(kind==='tiny'){
      let x=spawnX,tries=0;
      while((obstacleNear(x,94)||pickupNear(x,48))&&tries<8){x+=54;tries++;}
      add('tiny',x,groundRaise);
      return;
    }

    if(kind==='coin'){
      // Sometimes reward a double-jump with two coins stacked safely above an obstacle.
      const support=dash.obstacles
        .filter(o=>o.x>W-105&&o.x<W+190)
        .sort((a,b)=>Math.abs(a.x-spawnX)-Math.abs(b.x-spawnX))[0]||null;
      if(support&&Math.random()<0.46){
        const obstacleW=Math.min(W*.155,74),coinW=Math.min(W*.098,42);
        const stackX=support.x+Math.max(7,(obstacleW-coinW)/2);
        // Lower coin clears the obstacle on a normal jump; upper coin rewards the second jump.
        add('coin',stackX,96,{overObstacleStack:true});
        add('coin',stackX,148,{overObstacleStack:true});
        return;
      }

      // All ordinary coins must stay well away from every obstacle horizontally.
      let x=spawnX+Math.floor(Math.random()*68),tries=0;
      while((obstacleNear(x,safeObstacleGap)||pickupNear(x,pickupGap))&&tries<12){x+=48;tries++;}
      // One final hard guarantee in case a crowded spawn lane exhausted the normal tries.
      while(obstacleNear(x,safeObstacleGap)){x+=safeObstacleGap;}
      const heights=[28,52,76,102,128];
      const raise=heights[Math.floor(Math.random()*heights.length)];
      add('coin',x,raise);
    }
  }"""
text=replace_between(text,start,end,new_spawn,'spawnDashThing body')

# 8) Keep the rider attached to the cart and flash the hurt sprite on collision.
start='  function dashFrame(ts){'
end='\n  function startDash(){'
new_frame="""  function dashFrame(ts){if(!dash.running)return;if(!dash.last)dash.last=ts;const dt=Math.min(.04,(ts-dash.last)/1000);dash.last=ts;dash.elapsed+=dt;dash.invuln=Math.max(0,dash.invuln-dt);dash.obstacleClock+=dt;dash.coinClock+=dt;changeDashSegment();if(dash.elapsed>=30){finishDash(true);return;}if(dash.obstacleClock>1.75){dash.obstacleClock=0;spawnDashThing('obstacle')}if(dash.coinClock>.9){dash.coinClock=0;spawnDashThing('coin')}
    dash.jumpV-=1380*dt;dash.jumpY=Math.max(0,dash.jumpY+dash.jumpV*dt);if(dash.jumpY<=0&&dash.jumpV<0){dash.jumpY=0;dash.jumpV=0;dash.jumpCount=0}const runner=document.querySelector('#dashRunner');if(runner)runner.style.transform=`translateY(${-dash.jumpY}px)`;const track=dashTrack();if(!track){finishDash(false);return;}const W=track.clientWidth,H=track.clientHeight,playerX=W*.12,playerW=Math.min(W*.20,92),playerH=playerW*.75,ground=H*.10,playerY=H-ground-playerH-dash.jumpY;const speed=W*.43;
    dash.obstacles=dash.obstacles.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const ow=Math.min(W*.155,74),oh=ow,hitW=ow*.44,hitH=oh*.27,hitX=o.x+ow*.28,hitY=H-ground-hitH-o.raise;if(!o.hit&&dash.invuln<=0&&overlap(playerX,playerY,playerW*.72,playerH*.75,hitX,hitY,hitW,hitH)){o.hit=true;dash.hearts--;dash.invuln=1.0;runner?.classList.add('hit');syncDashDriverV208(true);setTimeout(()=>{runner?.classList.remove('hit');syncDashDriverV208(false)},420);dashHud();if(dash.hearts<=0){finishDash(false);return false}}if(o.x<-80){o.el.remove();return false}return true});
    dash.pickups=dash.pickups.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const iw=o.kind==='tiny'?Math.min(W*.108,48):Math.min(W*.098,42),ih=iw,pickW=iw*.74,pickH=ih*.74,pickX=o.x+iw*.13,pickY=H-ground-pickH-o.raise;if(overlap(playerX,playerY,playerW*.72,playerH*.75,pickX,pickY,pickW,pickH)){if(o.kind==='tiny'){dash.tiny++;recordTinyDuck()}else dash.coins++;o.el.remove();dashHud();return false}if(o.x<-60){o.el.remove();return false}return true});dashHud();dash.raf=requestAnimationFrame(dashFrame)}"""
text=replace_between(text,start,end,new_frame,'dashFrame body')

path.write_text(text)
print('Patched Duckie Dash core to v24.208.')

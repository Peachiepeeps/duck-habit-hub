from pathlib import Path

# This installer intentionally patches the already-live v24.208 tree rather than
# replacing game-v96.js, preserving the working chest and Dash-core changes.

version=Path('version.json')
if not version.exists():
    raise SystemExit('ERROR: version.json missing')
version.write_text('{\n  "version": "24.209"\n}\n')

root=Path('index.html')
text=root.read_text()
if 'duck-habit-build" content="24.208"' not in text and 'duck-habit-build" content="24.209"' not in text:
    raise SystemExit('ERROR: expected v24.208/v24.209 root build marker missing')
text=text.replace('duck-habit-build" content="24.208"','duck-habit-build" content="24.209"')
text=text.replace('sw-v24-208.js?v=24-208','sw-v24-209.js?v=24-209')
root.write_text(text)

quest=Path('duck-quest/index.html')
q=quest.read_text()
q=q.replace('?v=24-208','?v=24-209')
loader='<script src="js/quest-fixes-v209.js?v=24-209"></script>'
if loader not in q:
    anchor='  <script src="js/quest-fixes-v207.js?v=24-209"></script>'
    if anchor not in q:
        raise SystemExit('ERROR: v207 loader anchor missing from Duck Quest index')
    q=q.replace(anchor,anchor+'\n  '+loader,1)
quest.write_text(q)

old_sw=Path('sw-v24-208.js')
new_sw=Path('sw-v24-209.js')
if new_sw.exists():
    sw=new_sw.read_text()
elif old_sw.exists():
    sw=old_sw.read_text()
else:
    raise SystemExit('ERROR: sw-v24-208.js missing')
sw=sw.replace('v24-208','v24-209').replace('24-208','24-209').replace('./sw-v24-208.js','./sw-v24-209.js')
entry="'./duck-quest/js/quest-fixes-v209.js?v=24-209'"
if entry not in sw:
    anchor="'./duck-quest/js/quest-fixes-v207.js?v=24-209'"
    if anchor not in sw:
        raise SystemExit('ERROR: v207 service-worker entry missing')
    sw=sw.replace(anchor,anchor+','+entry,1)
new_sw.write_text(sw)
Path('sw.js').write_text("importScripts('./sw-v24-209.js');\n")

print('Patched Duckie Days metadata/loaders to v24.209.')

from pathlib import Path

# Duckie Days v24.210 — universal between-encounter HP refill.
# This patches the already-working v24.209 tree in-place so the chest, event,
# hatchery, and Duckie Dash fixes remain untouched.

GAME = Path('duck-quest/js/game-v96.js')
V207 = Path('duck-quest/js/quest-fixes-v207.js')
V209 = Path('duck-quest/js/quest-fixes-v209.js')

for p in (GAME, V207, V209):
    if not p.exists():
        raise SystemExit(f'ERROR: required file missing: {p}')

# ---------------------------------------------------------------------------
# 1) Core guarantee: every transition to the next encounter recalculates the
# active OC's current max HP and begins the new encounter at full HP.
# This covers Peep, Miko, Io, Miho, and Annika because peepStats() already uses
# activeHeroProgress().level and the active character's equipped Vitality charm.
# ---------------------------------------------------------------------------
game = GAME.read_text()
marker = "window.DUCKIE_HP_REFILL_CORE='24.210-all-oc-between-encounters';"
if marker not in game:
    old = "function nextEncounter() {\n  resetDoubleBattleUi();"
    if game.count(old) != 1:
        raise SystemExit(f'ERROR: expected exactly one nextEncounter anchor, found {game.count(old)}')
    new = """function refillActiveHeroHpV210(){
  if(!currentRun) return;
  const stats=peepStats(activeHeroProgress().level);
  const maxHp=Math.max(1,Math.round(Number(stats?.maxHp)||Number(currentRun.maxHp)||1));
  currentRun.maxHp=maxHp;
  currentRun.hp=maxHp;
  renderPeepHp();
}
%s

function nextEncounter() {
  refillActiveHeroHpV210();
  resetDoubleBattleUi();""" % marker
    game = game.replace(old, new, 1)

# Merchant/non-battle events should visibly refill immediately too, not only
# after the player presses Continue.
old_merchant = "if(currentRun){currentRun.hp=currentRun.maxHp;renderPeepHp();markEndlessFloorComplete();}"
new_merchant = "if(currentRun){refillActiveHeroHpV210();markEndlessFloorComplete();}"
if old_merchant in game:
    game = game.replace(old_merchant, new_merchant, 1)
elif new_merchant not in game:
    raise SystemExit('ERROR: merchant HP-refill anchor missing')

GAME.write_text(game)

# ---------------------------------------------------------------------------
# 2) v24.207 owns normal/Mimic chest buttons. It previously granted rewards
# without restoring HP before showing Continue. Restore immediately there too.
# ---------------------------------------------------------------------------
v207 = V207.read_text()
v207_marker = "window.DUCKIE_DAYS_V210_CHEST_HP='24.210-normal-chest-refill';"
if v207_marker not in v207:
    insert_after = "  window.DUCKIE_DAYS_V207_FIXES='24.207-direct-chest-handler';\n"
    if insert_after not in v207:
        raise SystemExit('ERROR: v207 marker missing')
    v207 = v207.replace(insert_after, insert_after + "  " + v207_marker + "\n", 1)

    old = """    const rewards=generateRewards(pendingChest);
    applyRewards(rewards);
    const parts=rewardParts(rewards);"""
    new = """    const rewards=generateRewards(pendingChest);
    applyRewards(rewards);
    if(currentRun){
      if(typeof refillActiveHeroHpV210==='function') refillActiveHeroHpV210();
      else { currentRun.hp=currentRun.maxHp; renderPeepHp(); }
    }
    const parts=rewardParts(rewards);"""
    if v207.count(old) != 1:
        raise SystemExit(f'ERROR: expected exactly one v207 reward anchor, found {v207.count(old)}')
    v207 = v207.replace(old, new, 1)

# A Mimic is an immediate surprise battle instead of a normal reward chest. It is
# still a new battle, so restore the active OC before that battlefield begins too.
for mimic_call in (
    "        startEnemy('mimic',{forceShiny:true,mimicChestStyle:'amethyst'});",
    "        startEnemy('mimic',{mimicChestStyle:id});",
):
    heal_line = "        if(typeof refillActiveHeroHpV210==='function') refillActiveHeroHpV210();"
    patched = heal_line + "\n" + mimic_call
    if patched in v207:
        continue
    if v207.count(mimic_call) != 1:
        raise SystemExit(f'ERROR: expected exactly one Mimic start anchor: {mimic_call}')
    v207 = v207.replace(mimic_call, patched, 1)
V207.write_text(v207)

# ---------------------------------------------------------------------------
# 3) v24.209 owns Picnic/Fountain completion. Make its visible refill use the
# same active-OC calculation (important if the reward itself caused a level-up).
# ---------------------------------------------------------------------------
v209 = V209.read_text()
v209_marker = "window.DUCKIE_DAYS_V210_EVENT_HP='24.210-choice-event-refill';"
if v209_marker not in v209:
    insert_after = "  window.DUCKIE_DAYS_V209_FIXES='24.209-event-recovery-dash-seat';\n"
    if insert_after not in v209:
        raise SystemExit('ERROR: v209 marker missing')
    v209 = v209.replace(insert_after, insert_after + "  " + v209_marker + "\n", 1)

    old = """    if(currentRun){
      currentRun.hp=currentRun.maxHp;
      renderPeepHp();
      markEndlessFloorComplete();
    }"""
    new = """    if(currentRun){
      if(typeof refillActiveHeroHpV210==='function') refillActiveHeroHpV210();
      else { currentRun.hp=currentRun.maxHp; renderPeepHp(); }
      markEndlessFloorComplete();
    }"""
    if v209.count(old) != 1:
        raise SystemExit(f'ERROR: expected exactly one v209 event HP anchor, found {v209.count(old)}')
    v209 = v209.replace(old, new, 1)
V209.write_text(v209)

# ---------------------------------------------------------------------------
# 4) Bump app metadata/loaders/cache-busters to v24.210.
# ---------------------------------------------------------------------------
version=Path('version.json')
if not version.exists():
    raise SystemExit('ERROR: version.json missing')
version.write_text('{\n  "version": "24.210"\n}\n')

root=Path('index.html')
root_text=root.read_text()
if 'duck-habit-build" content="24.209"' not in root_text and 'duck-habit-build" content="24.210"' not in root_text:
    raise SystemExit('ERROR: expected v24.209/v24.210 root build marker missing')
root_text=root_text.replace('duck-habit-build" content="24.209"','duck-habit-build" content="24.210"')
root_text=root_text.replace('sw-v24-209.js?v=24-209','sw-v24-210.js?v=24-210')
root.write_text(root_text)

quest=Path('duck-quest/index.html')
q=quest.read_text()
q=q.replace('?v=24-209','?v=24-210')
quest.write_text(q)

old_sw=Path('sw-v24-209.js')
new_sw=Path('sw-v24-210.js')
if new_sw.exists():
    sw=new_sw.read_text()
elif old_sw.exists():
    sw=old_sw.read_text()
else:
    raise SystemExit('ERROR: sw-v24-209.js missing')
sw=sw.replace('v24-209','v24-210').replace('24-209','24-210').replace('./sw-v24-209.js','./sw-v24-210.js')
new_sw.write_text(sw)
Path('sw.js').write_text("importScripts('./sw-v24-210.js');\n")

print('Patched Duckie Days to v24.210 universal OC HP refill.')

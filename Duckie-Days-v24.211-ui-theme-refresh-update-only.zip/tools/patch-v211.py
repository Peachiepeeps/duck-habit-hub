from pathlib import Path

GAME=Path('duck-quest/js/game-v96.js')
QUEST=Path('duck-quest/index.html')
ROOT=Path('index.html')
VERSION=Path('version.json')
THEME=Path('duck-quest/js/theme-refresh-v211.js')

for p in (GAME, QUEST, ROOT, VERSION, THEME):
    if not p.exists():
        raise SystemExit(f'ERROR: required file missing: {p}')

game=GAME.read_text()
marker="window.DUCKIE_UI_THEME_CORE='24.211-expanded-theme-catalog';"
if marker not in game:
    anchor='const QUEST_CHARACTER_NAMES = Object.freeze({peep:"Peep",miko:"Miko",io:"Io",miho:"Miho",annika:"Annika"});\n'
    if anchor not in game:
        raise SystemExit('ERROR: theme catalog anchor missing')
    game=game.replace(anchor,anchor+marker+'\n',1)

# Refresh Miko in-place so existing unlock/save IDs remain compatible.
old_miko='''  {\n    id:"miko-moonlight", name:"Miko Moonlight",\n    description:"Buttercream, charcoal, and a little warm gold.",\n    swatches:["#fff8df","#43423e","#d7b96f"], themeColor:"#ded5bd",\n    requirement:{stage:"meadow",level:10,character:"miko"}\n  },'''
new_miko='''  {\n    id:"miko-moonlight", name:"Miko Teal Moonlight",\n    description:"Deep teal, ink black, ivory cream, and warm gold.",\n    swatches:["#f8f3e3","#3f958e","#20292a","#d6bd72"], themeColor:"#4b9e97",\n    requirement:{stage:"meadow",level:10,character:"miko"}\n  },'''
if old_miko in game:
    game=game.replace(old_miko,new_miko,1)
elif 'id:"miko-moonlight", name:"Miko Teal Moonlight"' not in game:
    raise SystemExit('ERROR: Miko theme definition missing')

old_miho='''  {\n    id:"miho-tea-room", name:"Miho Silent Space",\n    description:"Dark charcoal, muted crimson, and a cold white glow.",\n    swatches:["#2b2027","#7b3c49","#f4ecef"], themeColor:"#5a2b34",\n    requirement:{stage:"meadow",level:10,character:"miho"}\n  },'''
new_miho='''  {\n    id:"miho-tea-room", name:"Miho Silent Space",\n    description:"Charcoal, wine red, dusty rose, and moonlit cream.",\n    swatches:["#20191e","#99495d","#f7eef0","#d7c0c7"], themeColor:"#6f3948",\n    requirement:{stage:"meadow",level:10,character:"miho"}\n  },'''
if old_miho in game:
    game=game.replace(old_miho,new_miho,1)
elif 'id:"miho-tea-room", name:"Miho Silent Space"' not in game:
    raise SystemExit('ERROR: Miho theme definition missing')

# Add four stage-milestone themes before the existing Endless reward themes.
new_themes='''  {\n    id:"matcha-cream", name:"Matcha Cream",\n    description:"Soft sage, matcha green, warm cream, and a touch of gold.",\n    swatches:["#fbf7e8","#88aa78","#465044","#c9dbae"], themeColor:"#a8c59c",\n    requirement:{stage:"meadow",level:30}\n  },\n  {\n    id:"seafoam-pearl", name:"Seafoam Pearl",\n    description:"Seafoam teal, pearl white, and a tiny champagne-gold accent.",\n    swatches:["#f8fffc","#61b5ad","#385653","#eadbb1"], themeColor:"#a9d8d1",\n    requirement:{stage:"ocean",level:60}\n  },\n  {\n    id:"strawberry-milk", name:"Strawberry Milk",\n    description:"Strawberry pink, milk cream, and a soft berry outline.",\n    swatches:["#fff8f4","#df788d","#cc6279","#f3c2ca"], themeColor:"#efb0bc",\n    requirement:{stage:"candy",level:90}\n  },\n  {\n    id:"lavender-starlight", name:"Lavender Starlight",\n    description:"Dreamy lavender, soft plum, moon cream, and pale starlight gold.",\n    swatches:["#fbf9ff","#a38bd3","#504862","#ead7a9"], themeColor:"#cdbce8",\n    requirement:{stage:"cloud",level:140}\n  },\n'''
anchor='''  {\n    id:"rose-arcade", name:"Rose Arcade",'''
if 'id:"matcha-cream", name:"Matcha Cream"' not in game:
    if anchor not in game:
        raise SystemExit('ERROR: Endless theme insertion anchor missing')
    game=game.replace(anchor,new_themes+anchor,1)

GAME.write_text(game)

# Bump all loaders/cache busters from v24.210 to v24.211 and load the theme refresh last.
q=QUEST.read_text()
q=q.replace('?v=24-210','?v=24-211')
theme_tag='  <script src="js/theme-refresh-v211.js?v=24-211"></script>\n'
if 'theme-refresh-v211.js' not in q:
    anchor='  <script src="js/quest-fixes-v209.js?v=24-211"></script>\n'
    if anchor not in q:
        raise SystemExit('ERROR: quest-fixes-v209 loader anchor missing')
    q=q.replace(anchor,anchor+theme_tag,1)
QUEST.write_text(q)

VERSION.write_text('{\n  "version": "24.211"\n}\n')

root=ROOT.read_text()
if 'duck-habit-build" content="24.210"' not in root and 'duck-habit-build" content="24.211"' not in root:
    raise SystemExit('ERROR: root v24.210/v24.211 build marker missing')
root=root.replace('duck-habit-build" content="24.210"','duck-habit-build" content="24.211"')
root=root.replace('sw-v24-210.js?v=24-210','sw-v24-211.js?v=24-211')
ROOT.write_text(root)

old_sw=Path('sw-v24-210.js')
new_sw=Path('sw-v24-211.js')
if new_sw.exists():
    sw=new_sw.read_text()
elif old_sw.exists():
    sw=old_sw.read_text()
else:
    raise SystemExit('ERROR: sw-v24-210.js missing')
sw=sw.replace('v24-210','v24-211').replace('24-210','24-211').replace('./sw-v24-210.js','./sw-v24-211.js')
entry="'./duck-quest/js/quest-fixes-v209.js?v=24-211'"
theme_entry="'./duck-quest/js/theme-refresh-v211.js?v=24-211'"
if theme_entry not in sw:
    if entry not in sw:
        raise SystemExit('ERROR: SW quest-fixes-v209 cache anchor missing')
    sw=sw.replace(entry,entry+','+theme_entry,1)
new_sw.write_text(sw)
Path('sw.js').write_text("importScripts('./sw-v24-211.js');\n")

print('Patched Duckie Days to v24.211 unified themes + expanded theme catalog.')

from pathlib import Path

QUEST=Path('duck-quest/index.html')
ROOT=Path('index.html')
VERSION=Path('version.json')
FIX=Path('duck-quest/js/theme-fixes-v212.js')
for p in (QUEST,ROOT,VERSION,FIX):
    if not p.exists():
        raise SystemExit(f'ERROR: required file missing: {p}')

q=QUEST.read_text()
# Allow a rerun without duplicating the loader.
q=q.replace('?v=24-211','?v=24-212')
tag='  <script src="js/theme-fixes-v212.js?v=24-212"></script>\n'
if 'theme-fixes-v212.js' not in q:
    anchor='  <script src="js/theme-refresh-v211.js?v=24-212"></script>\n'
    if anchor not in q:
        raise SystemExit('ERROR: v24.211 theme refresh loader anchor missing')
    q=q.replace(anchor,anchor+tag,1)
QUEST.write_text(q)

VERSION.write_text('{\n  "version": "24.212"\n}\n')

root=ROOT.read_text()
if 'duck-habit-build" content="24.211"' not in root and 'duck-habit-build" content="24.212"' not in root:
    raise SystemExit('ERROR: root v24.211/v24.212 build marker missing')
root=root.replace('duck-habit-build" content="24.211"','duck-habit-build" content="24.212"')
root=root.replace('sw-v24-211.js?v=24-211','sw-v24-212.js?v=24-212')
ROOT.write_text(root)

old_sw=Path('sw-v24-211.js')
new_sw=Path('sw-v24-212.js')
if new_sw.exists():
    sw=new_sw.read_text()
elif old_sw.exists():
    sw=old_sw.read_text()
else:
    raise SystemExit('ERROR: sw-v24-211.js missing')
sw=sw.replace('v24-211','v24-212').replace('24-211','24-212').replace('./sw-v24-211.js','./sw-v24-212.js')
anchor="'./duck-quest/js/theme-refresh-v211.js?v=24-212'"
entry="'./duck-quest/js/theme-fixes-v212.js?v=24-212'"
if entry not in sw:
    if anchor not in sw:
        raise SystemExit('ERROR: SW v24.211 theme cache anchor missing')
    sw=sw.replace(anchor,anchor+','+entry,1)
new_sw.write_text(sw)
Path('sw.js').write_text("importScripts('./sw-v24-212.js');\n")

print('Patched Duckie Days to v24.212 tool-button themes + Stage label contrast.')

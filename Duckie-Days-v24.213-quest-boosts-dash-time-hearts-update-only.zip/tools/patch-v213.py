from pathlib import Path

GAME=Path('duck-quest/js/game-v96.js')
QUEST=Path('duck-quest/index.html')
ROOT=Path('index.html')
VERSION=Path('version.json')
HUB=Path('hub-shop-boosts-v213.js')
BOOST=Path('duck-quest/js/boost-items-v213.js')
ASSETS=[
    Path('assets/items/quest-boosts/Exp-candy-small.png'),
    Path('assets/items/quest-boosts/Exp-candy-large.png'),
    Path('assets/items/quest-boosts/Warm-blanket.png'),
]
for p in (GAME,QUEST,ROOT,VERSION,HUB,BOOST,*ASSETS):
    if not p.exists():
        raise SystemExit(f'ERROR: required file missing: {p}')

def replace_between(source,start,end,replacement,label):
    a=source.find(start)
    if a<0: raise SystemExit(f'ERROR: start marker missing for {label}')
    b=source.find(end,a+len(start))
    if b<0: raise SystemExit(f'ERROR: end marker missing for {label}')
    return source[:a]+replacement+source[b:]

# ---------------------------------------------------------------------------
# Duck Quest core: Warm Blanket + Duckie Dash time-heart pickups.
# ---------------------------------------------------------------------------
game=GAME.read_text()
marker="window.DUCKIE_BOOST_CORE='24.213-candy-blanket-time-hearts';"
if marker not in game:
    anchor="  window.DUCKIE_DASH_CORE='24.208-driver-safe-coins';\n"
    if anchor not in game: raise SystemExit('ERROR: v24.208 Dash marker missing')
    game=game.replace(anchor,anchor+'  '+marker+'\n',1)

    # Warm Blanket helper + hatch detail action. Rebuild only this one small function.
    start='  function openHatchDetail(index){'
    end='\n  async function hatchSlot(index){'
    new_hatch='''  function warmBlanketQtyV213(){return Math.max(0,Math.floor(Number(hubSave?.inventory?.['warm-blanket'])||0));}\n  function applyWarmBlanketV213(index){\n    const slot=questSave?.eggs?.incubators?.[index];\n    if(!slot || Date.now()>=slot.endAt) return;\n    if(!useInventory('warm-blanket',1)){setMessage('You do not have a Warm Blanket.');return;}\n    const now=Date.now(),remaining=Math.max(0,slot.endAt-now);\n    slot.endAt=now+Math.max(1000,Math.ceil(remaining*.50));\n    persistAll();refreshFeatureBadges();renderHatchery();openHatchDetail(index);\n  }\n  function openHatchDetail(index){\n    ensureExpansionSave();const slot=questSave.eggs.incubators[index];if(!slot)return;selectedHatchSlot=index;hatchAnimating=false;\n    const d=eggDefinition(slot.type),ready=Date.now()>=slot.endAt;const modal=document.querySelector('#hatchDetailModal');\n    modal?.classList.remove('hidden');modal?.setAttribute('aria-hidden','false');\n    const result=document.querySelector('#hatchResult');if(result){result.className='hatch-result hidden';result.innerHTML='';}\n    const glow=document.querySelector('#hatchGlow');glow?.classList.remove('active');\n    const egg=document.querySelector('#hatchDetailEgg');if(egg){egg.src=d.image;egg.alt=d.name;egg.className='hatch-window-egg';egg.classList.remove('hidden');}\n    const title=document.querySelector('#hatchDetailTitle');if(title)title.textContent=d.name;\n    const kicker=document.querySelector('#hatchDetailKicker');if(kicker)kicker.textContent=`NEST ${index+1}`;\n    const sub=document.querySelector('#hatchDetailSubtitle');if(sub)sub.textContent=ready?'It is wiggling... it wants out!':slot.type==='rare'?'A rare little surprise is warming up.':'Warm and cozy.';\n    const status=document.querySelector('#hatchDetailStatus');if(status)status.textContent=ready?'Oh?':`${fmtRemaining(slot.endAt-Date.now())} until hatch`;\n    const actions=document.querySelector('#hatchDetailActions');if(actions){\n      actions.innerHTML='';\n      if(ready){\n        const hatch=document.createElement('button');hatch.id='hatchNowButton';hatch.type='button';hatch.className='pixel-button primary';hatch.textContent='Hatch!';hatch.addEventListener('click',()=>hatchSlot(index));actions.appendChild(hatch);\n      }else{\n        const swap=document.createElement('button');swap.type='button';swap.className='pixel-button';swap.textContent='Switch Egg';swap.addEventListener('click',()=>{closeHatchDetail();openEggInventory(index,true)});actions.appendChild(swap);\n        const blankets=warmBlanketQtyV213();\n        if(blankets>0){\n          const blanket=document.createElement('button');blanket.type='button';blanket.className='pixel-button warm-blanket-use-v213';blanket.innerHTML=`<img src="../assets/items/quest-boosts/Warm-blanket.png" alt="">Warm Blanket ×${blankets}`;blanket.addEventListener('click',()=>applyWarmBlanketV213(index));actions.appendChild(blanket);\n        }\n      }\n      const close=document.createElement('button');close.type='button';close.className='pixel-button';close.textContent=ready?'Not Yet':'Close';close.addEventListener('click',closeHatchDetail);actions.appendChild(close);\n    }\n  }'''
    game=replace_between(game,start,end,new_hatch,'v24.213 hatch detail')

    # Dash state gets a flexible duration so time pickups truly extend the run.
    old_dash="  const dash={running:false,raf:0,last:0,elapsed:0,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacles:[],pickups:[],obstacleClock:0,coinClock:0,segment:-1,invuln:0};"
    new_dash="  const dash={running:false,raf:0,last:0,elapsed:0,duration:30,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacles:[],pickups:[],obstacleClock:0,coinClock:0,segment:-1,invuln:0};"
    if game.count(old_dash)!=1: raise SystemExit(f'ERROR: Dash state anchor count {game.count(old_dash)}')
    game=game.replace(old_dash,new_dash,1)

    old_hud="  function dashHud(){const set=(id,v)=>{const e=document.querySelector(id);if(e)e.textContent=String(v)};set('#dashHearts',dash.hearts);set('#dashCoins',dash.coins);set('#dashTiny',dash.tiny);set('#dashTime',Math.max(0,30-dash.elapsed).toFixed(1));}"
    new_hud="  function dashHud(){const set=(id,v)=>{const e=document.querySelector(id);if(e)e.textContent=String(v)};set('#dashHearts',dash.hearts);set('#dashCoins',dash.coins);set('#dashTiny',dash.tiny);set('#dashTime',Math.max(0,(Number(dash.duration)||30)-dash.elapsed).toFixed(1));}"
    if game.count(old_hud)!=1: raise SystemExit(f'ERROR: Dash HUD anchor count {game.count(old_hud)}')
    game=game.replace(old_hud,new_hud,1)

    # Replace spawning while preserving the v24.208 obstacle safety and two-coin mushroom reward.
    start='  function spawnDashThing(kind){'
    end='\n  function recordTinyDuck(){'
    new_spawn='''  function spawnDashThing(kind){\n    const track=dashTrack();if(!track)return;\n    const cfg=DASH_STAGE[questSave.dash.selectedStage];\n    const W=track.clientWidth,spawnX=W+40,groundRaise=4;\n    const safeObstacleGap=Math.max(112,Math.min(140,W*.28));\n    const pickupGap=Math.max(52,Math.min(66,W*.14));\n    const obstacleNear=(x,gap=safeObstacleGap)=>dash.obstacles.some(o=>Math.abs(o.x-x)<gap);\n    const pickupNear=(x,gap=pickupGap)=>dash.pickups.some(o=>Math.abs(o.x-x)<gap);\n    const add=(thing,x,raise,extra={})=>{\n      const el=document.createElement('img');\n      const timeHeart=thing==='time-pink'||thing==='time-gold';\n      el.className=`dash-thing ${thing==='obstacle'?'dash-obstacle':thing==='tiny'?'dash-tiny-duck':timeHeart?'dash-time-heart-v213':'dash-coin'}`;\n      el.src=thing==='obstacle'?cfg.obstacle:thing==='tiny'?'../assets/ducks/Tiny-duck.webp':thing==='time-pink'?'../assets/bakery/drops/Pink-heart-refill.webp':thing==='time-gold'?'../assets/bakery/drops/Gold-heart-refill.webp':'../assets/ui/pink-coin.webp';\n      el.alt='';track.appendChild(el);\n      const obj={kind:thing,x,raise,el,hit:false,...extra};\n      (thing==='obstacle'?dash.obstacles:dash.pickups).push(obj);\n      return obj;\n    };\n\n    if(kind==='obstacle'){\n      let x=spawnX,tries=0;\n      // Do not let a new obstacle appear beside an ordinary coin OR a time-heart pickup.\n      while((obstacleNear(x,96)||dash.pickups.some(o=>o.kind!=='tiny'&&!o.overObstacleStack&&Math.abs(o.x-x)<safeObstacleGap))&&tries<10){x+=70;tries++;}\n      add('obstacle',x,groundRaise);return;\n    }\n    if(kind==='tiny'){\n      let x=spawnX,tries=0;while((obstacleNear(x,94)||pickupNear(x,48))&&tries<8){x+=54;tries++;}add('tiny',x,groundRaise);return;\n    }\n    if(kind==='coin'){\n      // Keep the fun two-coin vertical reward over mushrooms for double-jumps.\n      const support=dash.obstacles.filter(o=>o.x>W-105&&o.x<W+190).sort((a,b)=>Math.abs(a.x-spawnX)-Math.abs(b.x-spawnX))[0]||null;\n      if(support&&Math.random()<0.46){\n        const obstacleW=Math.min(W*.155,74),coinW=Math.min(W*.098,42);\n        const stackX=support.x+Math.max(7,(obstacleW-coinW)/2);\n        add('coin',stackX,96,{overObstacleStack:true});add('coin',stackX,148,{overObstacleStack:true});return;\n      }\n\n      // Rare time extensions use the existing Merge Game Heart Refill art.\n      const heartRoll=Math.random();\n      const specialKind=heartRoll<0.006?'time-gold':heartRoll<0.036?'time-pink':null;\n      let x=spawnX+Math.floor(Math.random()*68),tries=0;\n      while((obstacleNear(x,safeObstacleGap)||pickupNear(x,pickupGap))&&tries<12){x+=48;tries++;}\n      while(obstacleNear(x,safeObstacleGap)){x+=safeObstacleGap;}\n      if(specialKind){\n        const raise=[54,78,102][Math.floor(Math.random()*3)];\n        add(specialKind,x,raise,{timeBonus:specialKind==='time-gold'?30:10});\n        return;\n      }\n      const heights=[28,52,76,102,128];const raise=heights[Math.floor(Math.random()*heights.length)];add('coin',x,raise);\n    }\n  }'''
    game=replace_between(game,start,end,new_spawn,'v24.213 Dash spawning')

    start='  function dashFrame(ts){'
    end='\n  function startDash(){'
    new_frame='''  function dashFrame(ts){if(!dash.running)return;if(!dash.last)dash.last=ts;const dt=Math.min(.04,(ts-dash.last)/1000);dash.last=ts;dash.elapsed+=dt;dash.invuln=Math.max(0,dash.invuln-dt);dash.obstacleClock+=dt;dash.coinClock+=dt;changeDashSegment();if(dash.elapsed>=(Number(dash.duration)||30)){finishDash(true);return;}if(dash.obstacleClock>1.75){dash.obstacleClock=0;spawnDashThing('obstacle')}if(dash.coinClock>.9){dash.coinClock=0;spawnDashThing('coin')}\n    dash.jumpV-=1380*dt;dash.jumpY=Math.max(0,dash.jumpY+dash.jumpV*dt);if(dash.jumpY<=0&&dash.jumpV<0){dash.jumpY=0;dash.jumpV=0;dash.jumpCount=0}const runner=document.querySelector('#dashRunner');if(runner)runner.style.transform=`translateY(${-dash.jumpY}px)`;const track=dashTrack();if(!track){finishDash(false);return;}const W=track.clientWidth,H=track.clientHeight,playerX=W*.12,playerW=Math.min(W*.20,92),playerH=playerW*.75,ground=H*.10,playerY=H-ground-playerH-dash.jumpY;const speed=W*.43;\n    dash.obstacles=dash.obstacles.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const ow=Math.min(W*.155,74),oh=ow,hitW=ow*.44,hitH=oh*.27,hitX=o.x+ow*.28,hitY=H-ground-hitH-o.raise;if(!o.hit&&dash.invuln<=0&&overlap(playerX,playerY,playerW*.72,playerH*.75,hitX,hitY,hitW,hitH)){o.hit=true;dash.hearts--;dash.invuln=1.0;runner?.classList.add('hit');syncDashDriverV208(true);setTimeout(()=>{runner?.classList.remove('hit');syncDashDriverV208(false)},420);dashHud();if(dash.hearts<=0){finishDash(false);return false}}if(o.x<-80){o.el.remove();return false}return true});\n    dash.pickups=dash.pickups.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const isTime=o.kind==='time-pink'||o.kind==='time-gold';const iw=o.kind==='tiny'?Math.min(W*.108,48):isTime?Math.min(W*.108,46):Math.min(W*.098,42),ih=iw,pickW=iw*.74,pickH=ih*.74,pickX=o.x+iw*.13,pickY=H-ground-pickH-o.raise;if(overlap(playerX,playerY,playerW*.72,playerH*.75,pickX,pickY,pickW,pickH)){if(o.kind==='tiny'){dash.tiny++;recordTinyDuck()}else if(isTime){const bonus=Math.max(0,Number(o.timeBonus)||0);dash.duration=(Number(dash.duration)||30)+bonus;const pop=document.createElement('div');pop.className='dash-time-pop-v213';pop.textContent=`+${bonus}s`;track.appendChild(pop);setTimeout(()=>pop.remove(),950)}else dash.coins++;o.el.remove();dashHud();return false}if(o.x<-60){o.el.remove();return false}return true});dashHud();dash.raf=requestAnimationFrame(dashFrame)}'''
    game=replace_between(game,start,end,new_frame,'v24.213 Dash frame')

    old_start="Object.assign(dash,{running:true,last:0,elapsed:0,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,coinClock:0,segment:-1,invuln:0});"
    new_start="Object.assign(dash,{running:true,last:0,elapsed:0,duration:30,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,coinClock:0,segment:-1,invuln:0});"
    if game.count(old_start)!=1: raise SystemExit(f'ERROR: Dash reset anchor count {game.count(old_start)}')
    game=game.replace(old_start,new_start,1)

GAME.write_text(game)

# ---------------------------------------------------------------------------
# Load the new Hub shop extension and Duck Quest boost UI.
# ---------------------------------------------------------------------------
root=ROOT.read_text()
if 'duck-habit-build" content="24.212"' not in root and 'duck-habit-build" content="24.213"' not in root:
    raise SystemExit('ERROR: root v24.212/v24.213 build marker missing')
root=root.replace('duck-habit-build" content="24.212"','duck-habit-build" content="24.213"')
root=root.replace('sw-v24-212.js?v=24-212','sw-v24-213.js?v=24-213')
hub_tag='  <script src="hub-shop-boosts-v213.js?v=24-213"></script>\n'
if 'hub-shop-boosts-v213.js' not in root:
    anchor='  <script src="script-v24-201.js?v=24-201"></script>\n'
    if anchor not in root: raise SystemExit('ERROR: Hub core script anchor missing')
    root=root.replace(anchor,anchor+hub_tag,1)
ROOT.write_text(root)

q=QUEST.read_text().replace('?v=24-212','?v=24-213')
boost_tag='  <script src="js/boost-items-v213.js?v=24-213"></script>\n'
if 'boost-items-v213.js' not in q:
    anchor='  <script src="js/theme-fixes-v212.js?v=24-213"></script>\n'
    if anchor not in q: raise SystemExit('ERROR: v24.212 theme-fix loader anchor missing')
    q=q.replace(anchor,anchor+boost_tag,1)
QUEST.write_text(q)

VERSION.write_text('{\n  "version": "24.213"\n}\n')

old_sw=Path('sw-v24-212.js');new_sw=Path('sw-v24-213.js')
if new_sw.exists(): sw=new_sw.read_text()
elif old_sw.exists(): sw=old_sw.read_text()
else: raise SystemExit('ERROR: sw-v24-212.js missing')
sw=sw.replace('v24-212','v24-213').replace('24-212','24-213').replace('./sw-v24-212.js','./sw-v24-213.js')
entries=[
    "'./hub-shop-boosts-v213.js?v=24-213'",
    "'./assets/items/quest-boosts/Exp-candy-small.png'",
    "'./assets/items/quest-boosts/Exp-candy-large.png'",
    "'./assets/items/quest-boosts/Warm-blanket.png'",
    "'./assets/bakery/drops/Pink-heart-refill.webp'",
    "'./assets/bakery/drops/Gold-heart-refill.webp'",
    "'./duck-quest/js/boost-items-v213.js?v=24-213'",
]
anchor="'./duck-quest/js/theme-fixes-v212.js?v=24-213'"
if anchor not in sw: raise SystemExit('ERROR: SW v24.212 theme-fix cache anchor missing')
for entry in entries:
    if entry not in sw:
        sw=sw.replace(anchor,anchor+','+entry,1)
new_sw.write_text(sw)
Path('sw.js').write_text("importScripts('./sw-v24-213.js');\n")

print('Patched Duckie Days to v24.213 Quest Boost Shop + Duckie Dash time hearts.')

from pathlib import Path
import json, shutil, sys, re

root=Path.cwd()
stage=Path(sys.argv[1]).resolve()

def must(path):
    p=root/path
    if not p.exists(): raise SystemExit(f'Missing required repo file: {path}')
    return p

def write(path,text):
    p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8')

# Require the v24.213 boost-item base this focused fix extends.
version=json.loads(must('version.json').read_text(encoding='utf-8')).get('version')
if str(version)!='24.213':
    raise SystemExit(f'Expected installed v24.213 before v24.214, found {version!r}')
for req in ['hub-shop-boosts-v213.js','duck-quest/js/boost-items-v213.js','sw-v24-213.js']:
    must(req)

shutil.copy2(stage/'hub-exp-candy-use-v214.js', root/'hub-exp-candy-use-v214.js')
shutil.copy2(stage/'duck-quest/js/boost-labels-v214.js', root/'duck-quest/js/boost-labels-v214.js')
shutil.copy2(stage/'V24.214-NOTES.txt', root/'V24.214-NOTES.txt')

# Root Hub: load the new Inventory action after the v213 item catalog/shop extension.
p=must('index.html'); text=p.read_text(encoding='utf-8')
text=re.sub(r'(<meta name="duck-habit-build" content=")24\.213("\s*/>)',r'\g<1>24.214\2',text,count=1)
text=text.replace('hub-shop-boosts-v213.js?v=24-213','hub-shop-boosts-v213.js?v=24-214')
needle='  <script src="hub-shop-boosts-v213.js?v=24-214"></script>'
insert=needle+'\n  <script src="hub-exp-candy-use-v214.js?v=24-214"></script>'
if 'hub-exp-candy-use-v214.js' not in text:
    if needle not in text: raise SystemExit('Could not locate v213 Hub boost script tag')
    text=text.replace(needle,insert,1)
text=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";', 'const DUCK_HUB_BUILD = "24.214";', text, count=1)
text=text.replace('./sw-v24-213.js?v=24-213','./sw-v24-214.js?v=24-214')
p.write_text(text,encoding='utf-8')

# Duck Quest: cache-bust the current bundle and add clearer Token Shop labels.
p=must('duck-quest/index.html'); text=p.read_text(encoding='utf-8')
text=text.replace('?v=24-213','?v=24-214')
needle='  <script src="js/boost-items-v213.js?v=24-214"></script>'
insert=needle+'\n  <script src="js/boost-labels-v214.js?v=24-214"></script>'
if 'boost-labels-v214.js' not in text:
    if needle not in text: raise SystemExit('Could not locate v213 Duck Quest boost script tag')
    text=text.replace(needle,insert,1)
p.write_text(text,encoding='utf-8')

# New SW version from the proven v213 worker.
old=must('sw-v24-213.js').read_text(encoding='utf-8')
sw=old.replace('v24-213','v24-214').replace('24-213','24-214')
# Add the two v214 scripts to the app shell.
hub_entry="'./hub-shop-boosts-v213.js?v=24-214'"
if "'./hub-exp-candy-use-v214.js?v=24-214'" not in sw:
    sw=sw.replace(hub_entry,hub_entry+",'./hub-exp-candy-use-v214.js?v=24-214'",1)
quest_entry="'./duck-quest/js/boost-items-v213.js?v=24-214'"
if "'./duck-quest/js/boost-labels-v214.js?v=24-214'" not in sw:
    sw=sw.replace(quest_entry,quest_entry+",'./duck-quest/js/boost-labels-v214.js?v=24-214'",1)
write('sw-v24-214.js',sw)
write('sw.js',"importScripts('./sw-v24-214.js');\n")
write('version.json',json.dumps({'version':'24.214'},indent=2)+'\n')

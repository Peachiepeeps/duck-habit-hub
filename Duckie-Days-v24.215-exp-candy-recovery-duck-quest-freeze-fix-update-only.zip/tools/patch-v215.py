from pathlib import Path
import json, shutil, sys, re

root=Path.cwd()
stage=Path(sys.argv[1]).resolve()

def must(path):
    p=root/path
    if not p.exists(): raise SystemExit(f'Missing required repo file: {path}')
    return p

def write(path,text):
    p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8')

version=json.loads(must('version.json').read_text(encoding='utf-8')).get('version')
if str(version)!='24.214':
    raise SystemExit(f'Expected installed v24.214 before v24.215, found {version!r}')
for req in ['hub-shop-boosts-v213.js','duck-quest/js/boost-items-v213.js','sw-v24-214.js']:
    must(req)

shutil.copy2(stage/'hub-exp-candy-use-v215.js', root/'hub-exp-candy-use-v215.js')
shutil.copy2(stage/'duck-quest/js/boost-labels-v215.js', root/'duck-quest/js/boost-labels-v215.js')
shutil.copy2(stage/'V24.215-NOTES.txt', root/'V24.215-NOTES.txt')

# Root Hub: stop loading the v214 inventory patch and load the safer v215 one.
p=must('index.html'); text=p.read_text(encoding='utf-8')
text=re.sub(r'(<meta name="duck-habit-build" content=")24\.214("\s*/>)',r'\g<1>24.215\2',text,count=1)
text=text.replace('hub-shop-boosts-v213.js?v=24-214','hub-shop-boosts-v213.js?v=24-215')
text=re.sub(r'\n?\s*<script src="hub-exp-candy-use-v214\.js\?v=24-214"></script>','',text)
needle='  <script src="hub-shop-boosts-v213.js?v=24-215"></script>'
insert=needle+'\n  <script src="hub-exp-candy-use-v215.js?v=24-215"></script>'
if 'hub-exp-candy-use-v215.js' not in text:
    if needle not in text: raise SystemExit('Could not locate Hub boost script tag')
    text=text.replace(needle,insert,1)
text=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";', 'const DUCK_HUB_BUILD = "24.215";', text, count=1)
text=text.replace('./sw-v24-214.js?v=24-214','./sw-v24-215.js?v=24-215')
p.write_text(text,encoding='utf-8')

# Duck Quest: remove the recursive v214 label helper and load v215 safe labels.
p=must('duck-quest/index.html'); text=p.read_text(encoding='utf-8')
text=text.replace('?v=24-214','?v=24-215')
text=re.sub(r'\n?\s*<script src="js/boost-labels-v214\.js\?v=24-215"></script>','',text)
needle='  <script src="js/boost-items-v213.js?v=24-215"></script>'
insert=needle+'\n  <script src="js/boost-labels-v215.js?v=24-215"></script>'
if 'boost-labels-v215.js' not in text:
    if needle not in text: raise SystemExit('Could not locate v213 Duck Quest boost script tag')
    text=text.replace(needle,insert,1)
p.write_text(text,encoding='utf-8')

# New service worker from v214, but do NOT cache/load the broken v214 label helper.
old=must('sw-v24-214.js').read_text(encoding='utf-8')
sw=old.replace('v24-214','v24-215').replace('24-214','24-215')
sw=sw.replace(",'./hub-exp-candy-use-v214.js?v=24-215'",'')
sw=sw.replace(",'./duck-quest/js/boost-labels-v214.js?v=24-215'",'')
hub_entry="'./hub-shop-boosts-v213.js?v=24-215'"
if "'./hub-exp-candy-use-v215.js?v=24-215'" not in sw:
    sw=sw.replace(hub_entry,hub_entry+",'./hub-exp-candy-use-v215.js?v=24-215'",1)
quest_entry="'./duck-quest/js/boost-items-v213.js?v=24-215'"
if "'./duck-quest/js/boost-labels-v215.js?v=24-215'" not in sw:
    sw=sw.replace(quest_entry,quest_entry+",'./duck-quest/js/boost-labels-v215.js?v=24-215'",1)
write('sw-v24-215.js',sw)
write('sw.js',"importScripts('./sw-v24-215.js');\n")
write('version.json',json.dumps({'version':'24.215'},indent=2)+'\n')

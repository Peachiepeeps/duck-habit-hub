from pathlib import Path
import json, sys, re

root=Path.cwd()
stage=Path(sys.argv[1]).resolve()

def must(path):
    p=root/path
    if not p.exists(): raise SystemExit(f'Missing required repo file: {path}')
    return p

def write(path,text):
    p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8')

version=json.loads(must('version.json').read_text(encoding='utf-8')).get('version')
if str(version)!='24.215':
    raise SystemExit(f'Expected installed v24.215 before v24.216, found {version!r}')
for req in ['duck-quest/js/game-v96.js','duck-quest/index.html','index.html','sw-v24-215.js']:
    must(req)

# ---- Duckie Dash core: safe obstacle patterns ----
p=must('duck-quest/js/game-v96.js')
text=p.read_text(encoding='utf-8')
text=text.replace("window.DUCKIE_DASH_CORE='24.208-driver-safe-coins';",
                  "window.DUCKIE_DASH_CORE='24.216-safe-mushroom-patterns';",1)

old_dash="const dash={running:false,raf:0,last:0,elapsed:0,duration:30,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacles:[],pickups:[],obstacleClock:0,coinClock:0,segment:-1,invuln:0};"
new_dash="const dash={running:false,raf:0,last:0,elapsed:0,duration:30,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacles:[],pickups:[],obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0};"
if old_dash not in text: raise SystemExit('Could not locate Dash state object for v24.216')
text=text.replace(old_dash,new_dash,1)

old_obstacle="""    if(kind==='obstacle'){
      let x=spawnX,tries=0;
      // Do not let a new obstacle appear beside an ordinary coin OR a time-heart pickup.
      while((obstacleNear(x,96)||dash.pickups.some(o=>o.kind!=='tiny'&&!o.overObstacleStack&&Math.abs(o.x-x)<safeObstacleGap))&&tries<10){x+=70;tries++;}
      add('obstacle',x,groundRaise);return;
    }"""
new_obstacle="""    if(kind==='obstacle'){
      // v24.216: Mushrooms use only two intentionally safe patterns:
      // 1) a single obstacle with enough time to land and jump again, or
      // 2) a tight two-mushroom cluster that behaves like one wider obstacle.
      // This avoids the awkward middle-distance pair that could be impossible to clear.
      const cluster=Math.random()<0.20;
      const clusterGap=Math.max(64,Math.min(78,W*.18));
      const conflictsPickup=px=>dash.pickups.some(o=>o.kind!=='tiny'&&!o.overObstacleStack&&Math.abs(o.x-px)<safeObstacleGap);
      let x=spawnX,tries=0;
      while((obstacleNear(x,96)||conflictsPickup(x)||(cluster&&(obstacleNear(x+clusterGap,96)||conflictsPickup(x+clusterGap))))&&tries<12){x+=70;tries++;}
      add('obstacle',x,groundRaise,{dashPattern:cluster?'cluster':'single'});
      if(cluster){
        add('obstacle',x+clusterGap,groundRaise,{dashPattern:'cluster'});
        // Give the player extra recovery room after the wider cluster.
        dash.nextObstacleDelay=2.55+Math.random()*.25;
      }else{
        // A normal single gets a larger landing/reaction window than the old 1.75s cadence.
        dash.nextObstacleDelay=2.05+Math.random()*.28;
      }
      return;
    }"""
if old_obstacle not in text: raise SystemExit('Could not locate Dash obstacle spawn block for v24.216')
text=text.replace(old_obstacle,new_obstacle,1)

old_frame="if(dash.obstacleClock>1.75){dash.obstacleClock=0;spawnDashThing('obstacle')}if(dash.coinClock>.9){dash.coinClock=0;spawnDashThing('coin')}"
new_frame="if(dash.obstacleClock>(Number(dash.nextObstacleDelay)||2.10)){dash.obstacleClock=0;spawnDashThing('obstacle')}if(dash.coinClock>.9){dash.coinClock=0;spawnDashThing('coin')}"
if old_frame not in text: raise SystemExit('Could not locate Dash obstacle timer for v24.216')
text=text.replace(old_frame,new_frame,1)

old_start="Object.assign(dash,{running:true,last:0,elapsed:0,duration:30,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,coinClock:0,segment:-1,invuln:0});"
new_start="Object.assign(dash,{running:true,last:0,elapsed:0,duration:30,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0});"
if old_start not in text: raise SystemExit('Could not locate Dash start reset for v24.216')
text=text.replace(old_start,new_start,1)
p.write_text(text,encoding='utf-8')

# ---- Cache-bust both app shells ----
p=must('duck-quest/index.html'); q=p.read_text(encoding='utf-8')
q=q.replace('?v=24-215','?v=24-216')
p.write_text(q,encoding='utf-8')

p=must('index.html'); h=p.read_text(encoding='utf-8')
h=re.sub(r'(<meta name="duck-habit-build" content=")24\.215("\s*/>)',r'\g<1>24.216\2',h,count=1)
h=h.replace('?v=24-215','?v=24-216')
h=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";', 'const DUCK_HUB_BUILD = "24.216";', h, count=1)
h=h.replace('./sw-v24-215.js?v=24-216','./sw-v24-216.js?v=24-216')
p.write_text(h,encoding='utf-8')

# ---- Service worker ----
old=must('sw-v24-215.js').read_text(encoding='utf-8')
sw=old.replace('v24-215','v24-216').replace('24-215','24-216')
write('sw-v24-216.js',sw)
write('sw.js',"importScripts('./sw-v24-216.js');\n")
write('version.json',json.dumps({'version':'24.216'},indent=2)+'\n')
write('V24.216-NOTES.txt',(stage/'V24.216-NOTES.txt').read_text(encoding='utf-8'))

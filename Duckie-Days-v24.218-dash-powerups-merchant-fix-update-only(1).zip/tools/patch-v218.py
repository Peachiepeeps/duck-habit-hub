#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path


VERSION = "24.218"
VERSION_SLUG = "24-218"


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        fail(f"expected one {label} anchor, found {count}")
    return text.replace(old, new, 1)


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


repo = Path.cwd().resolve()
payload = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else fail("payload directory was not provided")

required = [
    payload / "duck-quest/js/merchant-fix-v218.js",
    payload / "duck-quest/assets/dash/Angel-Wing.png",
    payload / "duck-quest/assets/dash/Bubble-icon.png",
    payload / "duck-quest/assets/dash/Bubble.png",
    payload / "duck-quest/assets/dash/backgrounds/DD-Meadow.png",
    payload / "duck-quest/assets/dash/backgrounds/DD-Ocean.png",
    payload / "duck-quest/assets/dash/backgrounds/DD-Candyland.png",
    payload / "duck-quest/assets/dash/backgrounds/DD-CloudGarden.png",
]
for path in required:
    if not path.is_file():
        fail(f"payload file is missing: {path.relative_to(payload)}")

version_path = repo / "version.json"
if not version_path.is_file():
    fail("run this installer from the repository root (version.json is missing)")

try:
    current_version = str(json.loads(version_path.read_text(encoding="utf-8")).get("version", ""))
except Exception as error:
    fail(f"could not read version.json: {error}")

if not re.fullmatch(r"24\.\d+", current_version):
    fail(f"unsupported starting version: {current_version!r}")
if int(current_version.split(".")[1]) > 218:
    fail(f"repository is newer than v{VERSION}; refusing to overwrite v{current_version}")

current_slug = current_version.replace(".", "-")

# Copy the seven Dash assets and the final, late-loading Merchant controller.
for source in required:
    relative = source.relative_to(payload)
    destination = repo / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

game_path = repo / "duck-quest/js/game-v96.js"
if not game_path.is_file():
    fail("duck-quest/js/game-v96.js is missing")
game = game_path.read_text(encoding="utf-8")

# If the earlier v24.217 Dash package is already present, preserve its implementation.
# Otherwise fold those agreed features directly into this one-step v24.218 installer.
dash_already_updated = (
    "DD-Meadow.png" in game
    and "Bubble-icon.png" in game
    and "Angel-Wing.png" in game
    and "dashBubble" in game
)

if not dash_already_updated:
    game = replace_once(
        game,
        "window.DUCKIE_DASH_CORE='24.216-safe-mushroom-patterns';",
        "window.DUCKIE_DASH_CORE='24.218-powerups-smooth-scroll';",
        "Dash build marker",
    )

    old_stage = """  const DASH_STAGE={
    meadow:{name:'Meadow',backgrounds:AREA_CONFIG.meadow.backgrounds,obstacle:'assets/dash/Obstacle-mushroom.png'},
    ocean:{name:'Ocean',backgrounds:AREA_CONFIG.ocean.backgrounds,obstacle:'assets/dash/Obstacle-rock.png'},
    candy:{name:'Candyland',backgrounds:AREA_CONFIG.candy.backgrounds,obstacle:'assets/dash/Obstacle-gumdrop.png'},
    cloud:{name:'Cloud Garden',backgrounds:AREA_CONFIG.cloud.backgrounds,obstacle:'assets/dash/Obstacle-cloud.png'}
  };"""
    new_stage = """  const DASH_STAGE={
    meadow:{name:'Meadow',dashBackground:'assets/dash/backgrounds/DD-Meadow.png',backgrounds:['assets/dash/backgrounds/DD-Meadow.png'],obstacle:'assets/dash/Obstacle-mushroom.png'},
    ocean:{name:'Ocean',dashBackground:'assets/dash/backgrounds/DD-Ocean.png',backgrounds:['assets/dash/backgrounds/DD-Ocean.png'],obstacle:'assets/dash/Obstacle-rock.png'},
    candy:{name:'Candyland',dashBackground:'assets/dash/backgrounds/DD-Candyland.png',backgrounds:['assets/dash/backgrounds/DD-Candyland.png'],obstacle:'assets/dash/Obstacle-gumdrop.png'},
    cloud:{name:'Cloud Garden',dashBackground:'assets/dash/backgrounds/DD-CloudGarden.png',backgrounds:['assets/dash/backgrounds/DD-CloudGarden.png'],obstacle:'assets/dash/Obstacle-cloud.png'}
  };"""
    game = replace_once(game, old_stage, new_stage, "Dash stage configuration")

    css_anchor = ".dash-tiny-duck{width:10.8%;max-width:48px}"
    css_replacement = css_anchor + ".dash-powerup-v217{width:10.8%;max-width:48px;filter:drop-shadow(0 2px 0 rgba(255,255,255,.7))}.dash-bg-scroll-v217{position:absolute;inset:0;z-index:0;display:flex;width:max-content;height:100%;will-change:transform;pointer-events:none}.dash-bg-scroll-v217 .dash-bg{position:relative!important;inset:auto!important;flex:0 0 auto!important;width:auto!important;max-width:none!important;height:100%!important;object-fit:fill!important}.dash-bubble-v217{position:absolute!important;z-index:9!important;width:142%!important;height:142%!important;left:-21%!important;top:-21%!important;object-fit:contain!important;pointer-events:none!important;opacity:0!important;transform:scale(.82)!important;transition:opacity .14s ease,transform .14s ease!important;filter:drop-shadow(0 0 8px rgba(180,239,255,.8))!important}.dash-bubble-v217.active{opacity:1!important;transform:scale(1)!important}.dash-power-pop-v217{position:absolute;left:17%;bottom:36%;z-index:12;padding:5px 8px;border:2px solid #fff;border-radius:999px;background:rgba(255,248,224,.95);color:#8b5a6d;font-size:.65rem;font-weight:900;animation:dashPowerPopV217 .9s ease-out forwards;pointer-events:none}@keyframes dashPowerPopV217{to{opacity:0;transform:translateY(-28px)}}"
    game = replace_once(game, css_anchor, css_replacement, "Dash power-up CSS")

    old_markup = """              <div class="dash-hud"><span>♥ <strong id="dashHearts">3</strong></span><span>Time <strong id="dashTime">30.0</strong></span><span>Coins <strong id="dashCoins">0</strong></span><span>Tiny Ducks <strong id="dashTiny">0</strong></span></div>
              <div id="dashTrack" class="dash-track"><img id="dashBg" class="dash-bg" src="${AREA_CONFIG.meadow.backgrounds[0]}" alt=""><div id="dashRunner" class="dash-runner dash-runner-v208" aria-label="OC riding a duck cart"><img id="dashRunnerDriverV208" class="dash-driver-v208" src="assets/characters/peep/base/idle-1.webp" alt=""><img id="dashRunnerCartV208" class="dash-cart-v208" src="${DASH_CARTS[0].image}" alt="Duck cart"></div><div id="dashOverlay" class="dash-overlay"><div class="dash-overlay-card"><strong>Ready?</strong><small>Use 3 Jump Tokens to run. A rare Free Run is used first if you have one.</small><button id="dashStart" class="pixel-button primary" type="button">Start Duckie Dash</button></div></div></div>"""
    new_markup = """              <div class="dash-hud"><span>Power <strong id="dashPower">—</strong></span><span>Time <strong id="dashTime">30.0</strong></span><span>Coins <strong id="dashCoins">0</strong></span><span>Tiny Ducks <strong id="dashTiny">0</strong></span></div>
              <div id="dashTrack" class="dash-track"><div id="dashBgScrollV217" class="dash-bg-scroll-v217"><img id="dashBg" class="dash-bg" src="assets/dash/backgrounds/DD-Meadow.png" alt=""><img id="dashBgCloneV217" class="dash-bg" src="assets/dash/backgrounds/DD-Meadow.png" alt=""></div><div id="dashRunner" class="dash-runner dash-runner-v208" aria-label="OC riding a duck cart"><img id="dashRunnerDriverV208" class="dash-driver-v208" src="assets/characters/peep/base/idle-1.webp" alt=""><img id="dashRunnerCartV208" class="dash-cart-v208" src="${DASH_CARTS[0].image}" alt="Duck cart"><img id="dashBubble" class="dash-bubble-v217" src="assets/dash/Bubble.png" alt=""></div><div id="dashOverlay" class="dash-overlay"><div class="dash-overlay-card"><strong>Ready?</strong><small>Use 3 Jump Tokens to run. A rare Free Run is used first if you have one.</small><button id="dashStart" class="pixel-button primary" type="button">Start Duckie Dash</button></div></div></div>"""
    game = replace_once(game, old_markup, new_markup, "Dash track markup")

    game = replace_once(
        game,
        "const dash={running:false,raf:0,last:0,elapsed:0,duration:30,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacles:[],pickups:[],obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0};",
        "const dash={running:false,raf:0,last:0,elapsed:0,duration:30,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacles:[],pickups:[],obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0,speedBoost:0,bubble:0,bgOffset:0};",
        "Dash state",
    )

    old_hud = "function dashHud(){const set=(id,v)=>{const e=document.querySelector(id);if(e)e.textContent=String(v)};set('#dashHearts',dash.hearts);set('#dashCoins',dash.coins);set('#dashTiny',dash.tiny);set('#dashTime',Math.max(0,(Number(dash.duration)||30)-dash.elapsed).toFixed(1));}"
    new_hud = "function dashHud(){const set=(id,v)=>{const e=document.querySelector(id);if(e)e.textContent=String(v)};set('#dashCoins',dash.coins);set('#dashTiny',dash.tiny);set('#dashTime',Math.max(0,(Number(dash.duration)||30)-dash.elapsed).toFixed(1));set('#dashPower',dash.bubble>0?`Bubble ${dash.bubble.toFixed(1)}s`:dash.speedBoost>0?`Wing ${dash.speedBoost.toFixed(1)}s`:'—');document.querySelector('#dashBubble')?.classList.toggle('active',dash.bubble>0);}"
    game = replace_once(game, old_hud, new_hud, "Dash HUD")

    old_preview = "function resetDashPreview(){ensureExpansionSave();const cfg=DASH_STAGE[questSave.dash.selectedStage];const bg=document.querySelector('#dashBg');if(bg)bg.src=cfg.backgrounds[0];const runner=document.querySelector('#dashRunner');if(runner)runner.style.transform='translateY(0px)';syncDashDriverV208(false);dashHud();}"
    new_preview = "function resetDashPreview(){ensureExpansionSave();const cfg=DASH_STAGE[questSave.dash.selectedStage];const bg=document.querySelector('#dashBg'),clone=document.querySelector('#dashBgCloneV217'),strip=document.querySelector('#dashBgScrollV217');if(bg)bg.src=cfg.dashBackground;if(clone)clone.src=cfg.dashBackground;if(strip)strip.style.transform='translateX(0px)';dash.bgOffset=0;const runner=document.querySelector('#dashRunner');if(runner)runner.style.transform='translateY(0px)';document.querySelector('#dashBubble')?.classList.remove('active');syncDashDriverV208(false);dashHud();}"
    game = replace_once(game, old_preview, new_preview, "Dash preview")

    old_add = """      const timeHeart=thing==='time-pink'||thing==='time-gold';
      el.className=`dash-thing ${thing==='obstacle'?'dash-obstacle':thing==='tiny'?'dash-tiny-duck':timeHeart?'dash-time-heart-v213':'dash-coin'}`;
      el.src=thing==='obstacle'?cfg.obstacle:thing==='tiny'?'../assets/ducks/Tiny-duck.webp':thing==='time-pink'?'../assets/bakery/drops/Pink-heart-refill.webp':thing==='time-gold'?'../assets/bakery/drops/Gold-heart-refill.webp':'../assets/ui/pink-coin.webp';"""
    new_add = """      const timeHeart=thing==='time-pink'||thing==='time-gold';
      const powerup=thing==='wing'||thing==='bubble';
      el.className=`dash-thing ${thing==='obstacle'?'dash-obstacle':thing==='tiny'?'dash-tiny-duck':timeHeart?'dash-time-heart-v213':powerup?'dash-powerup-v217':'dash-coin'}`;
      el.src=thing==='obstacle'?cfg.obstacle:thing==='tiny'?'../assets/ducks/Tiny-duck.webp':thing==='time-pink'?'../assets/bakery/drops/Pink-heart-refill.webp':thing==='time-gold'?'../assets/bakery/drops/Gold-heart-refill.webp':thing==='wing'?'assets/dash/Angel-Wing.png':thing==='bubble'?'assets/dash/Bubble-icon.png':'../assets/ui/pink-coin.webp';"""
    game = replace_once(game, old_add, new_add, "Dash pickup assets")

    old_special = """      // Rare time extensions use the existing Merge Game Heart Refill art.
      const heartRoll=Math.random();
      const specialKind=heartRoll<0.006?'time-gold':heartRoll<0.036?'time-pink':null;
      let x=spawnX+Math.floor(Math.random()*68),tries=0;
      while((obstacleNear(x,safeObstacleGap)||pickupNear(x,pickupGap))&&tries<12){x+=48;tries++;}
      while(obstacleNear(x,safeObstacleGap)){x+=safeObstacleGap;}
      if(specialKind){
        const raise=[54,78,102][Math.floor(Math.random()*3)];
        add(specialKind,x,raise,{timeBonus:specialKind==='time-gold'?30:10});
        return;
      }"""
    new_special = """      // Rare hearts extend the run; Angel Wing and Bubble are ten-second power-ups.
      const specialRoll=Math.random();
      const specialKind=specialRoll<0.006?'time-gold':specialRoll<0.036?'time-pink':specialRoll<0.054?'wing':specialRoll<0.072?'bubble':null;
      let x=spawnX+Math.floor(Math.random()*68),tries=0;
      while((obstacleNear(x,safeObstacleGap)||pickupNear(x,pickupGap))&&tries<12){x+=48;tries++;}
      while(obstacleNear(x,safeObstacleGap)){x+=safeObstacleGap;}
      if(specialKind){
        const raise=[54,78,102][Math.floor(Math.random()*3)];
        add(specialKind,x,raise,{timeBonus:specialKind==='time-gold'?30:specialKind==='time-pink'?10:0});
        return;
      }"""
    game = replace_once(game, old_special, new_special, "Dash special pickup roll")

    old_segment = "function changeDashSegment(){const cfg=DASH_STAGE[questSave.dash.selectedStage],bg=document.querySelector('#dashBg');if(!bg)return;const segment=Math.floor(dash.elapsed/5);if(segment===dash.segment)return;dash.segment=segment;if(segment>=5){bg.src=cfg.backgrounds[3];return;}let choices=[0,1,2];const current=Number(bg.dataset.segmentIndex);if(Number.isFinite(current)&&choices.length>1)choices=choices.filter(x=>x!==current);const idx=choices[Math.floor(Math.random()*choices.length)];bg.dataset.segmentIndex=String(idx);bg.src=cfg.backgrounds[idx];if(segment>0&&Math.random()<.25)setTimeout(()=>{if(dash.running)spawnDashThing('tiny')},900);}"
    new_segment = "function changeDashSegment(){const segment=Math.floor(dash.elapsed/5);if(segment===dash.segment)return;dash.segment=segment;if(segment>0&&Math.random()<.25)setTimeout(()=>{if(dash.running)spawnDashThing('tiny')},900);}"
    game = replace_once(game, old_segment, new_segment, "Dash background cycling")

    old_finish = "function finishDash(success){if(!dash.running)return;dash.running=false;cancelAnimationFrame(dash.raf);const base=success?20:5;const award=base+dash.coins;hubSave.coins=Math.max(0,Number(hubSave.coins)||0)+award;questSave.dash.runs=Math.max(0,Number(questSave.dash.runs)||0)+1;const score=Math.max(0,Math.floor(dash.elapsed*4+dash.coins*8+dash.tiny*60+(success?100:0)));questSave.dash.highScore=Math.max(questSave.dash.highScore,score);persistAll();refreshFeatureBadges();const ov=document.querySelector('#dashOverlay');if(ov){ov.classList.remove('hidden');ov.innerHTML=`<div class=\"dash-overlay-card\"><strong>${success?'Finish Line!':'Run Ended!'}</strong><small>${success?'You reached the boss-stage finish!':'Your cart ran out of hearts.'}<br>Pink Coins +${award}<br>Tiny Ducks ${dash.tiny}<br>Score ${score}</small><div class=\"dash-result-actions-v193\"><button id=\"dashAgain\" class=\"pixel-button primary\" type=\"button\">Run Again</button><button id=\"dashRunMenuV193\" class=\"pixel-button\" type=\"button\">Dash Menu</button></div></div>`;ov.querySelector('#dashAgain')?.addEventListener('click',startDash);ov.querySelector('#dashRunMenuV193')?.addEventListener('click',leaveDashRunStage);}}"
    new_finish = "function finishDash(success){if(!dash.running)return;dash.running=false;cancelAnimationFrame(dash.raf);document.querySelector('#dashBubble')?.classList.remove('active');const base=success?20:5;const award=base+dash.coins;hubSave.coins=Math.max(0,Number(hubSave.coins)||0)+award;questSave.dash.runs=Math.max(0,Number(questSave.dash.runs)||0)+1;const score=Math.max(0,Math.floor(dash.elapsed*4+dash.coins*8+dash.tiny*60+(success?100:0)));questSave.dash.highScore=Math.max(questSave.dash.highScore,score);persistAll();refreshFeatureBadges();const ov=document.querySelector('#dashOverlay');if(ov){ov.classList.remove('hidden');ov.innerHTML=`<div class=\"dash-overlay-card\"><strong>${success?'Finish Line!':'Run Ended!'}</strong><small>${success?'You reached the boss-stage finish!':'The run ended early.'}<br>Pink Coins +${award}<br>Tiny Ducks ${dash.tiny}<br>Score ${score}</small><div class=\"dash-result-actions-v193\"><button id=\"dashAgain\" class=\"pixel-button primary\" type=\"button\">Run Again</button><button id=\"dashRunMenuV193\" class=\"pixel-button\" type=\"button\">Dash Menu</button></div></div>`;ov.querySelector('#dashAgain')?.addEventListener('click',startDash);ov.querySelector('#dashRunMenuV193')?.addEventListener('click',leaveDashRunStage);}}"
    game = replace_once(game, old_finish, new_finish, "Dash result text")

    old_frame_start = "function dashFrame(ts){if(!dash.running)return;if(!dash.last)dash.last=ts;const dt=Math.min(.04,(ts-dash.last)/1000);dash.last=ts;dash.elapsed+=dt;dash.invuln=Math.max(0,dash.invuln-dt);dash.obstacleClock+=dt;dash.coinClock+=dt;changeDashSegment();if(dash.elapsed>=(Number(dash.duration)||30)){finishDash(true);return;}if(dash.obstacleClock>(Number(dash.nextObstacleDelay)||2.10)){dash.obstacleClock=0;spawnDashThing('obstacle')}if(dash.coinClock>.9){dash.coinClock=0;spawnDashThing('coin')}"
    new_frame_start = "function dashFrame(ts){if(!dash.running)return;if(!dash.last)dash.last=ts;const dt=Math.min(.04,(ts-dash.last)/1000);dash.last=ts;dash.elapsed+=dt*(dash.speedBoost>0?1.4:1);dash.invuln=Math.max(0,dash.invuln-dt);dash.speedBoost=Math.max(0,dash.speedBoost-dt);dash.bubble=Math.max(0,dash.bubble-dt);dash.obstacleClock+=dt;dash.coinClock+=dt;changeDashSegment();if(dash.elapsed>=(Number(dash.duration)||30)){finishDash(true);return;}if(dash.obstacleClock>(Number(dash.nextObstacleDelay)||2.10)){dash.obstacleClock=0;spawnDashThing('obstacle')}if(dash.coinClock>.9){dash.coinClock=0;spawnDashThing('coin')}"
    game = replace_once(game, old_frame_start, new_frame_start, "Dash frame timers")

    old_speed = "const speed=W*.43;"
    new_speed = "const speed=W*.43*(dash.speedBoost>0?1.4:1);const strip=document.querySelector('#dashBgScrollV217'),bg=document.querySelector('#dashBg');if(strip&&bg?.clientWidth){dash.bgOffset=(dash.bgOffset+speed*dt*.55)%bg.clientWidth;strip.style.transform=`translateX(${-dash.bgOffset}px)`;}"
    game = replace_once(game, old_speed, new_speed, "Dash speed and smooth background")

    old_collision = "dash.obstacles=dash.obstacles.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const ow=Math.min(W*.155,74),oh=ow,hitW=ow*.44,hitH=oh*.27,hitX=o.x+ow*.28,hitY=H-ground-hitH-o.raise;if(!o.hit&&dash.invuln<=0&&overlap(playerX,playerY,playerW*.72,playerH*.75,hitX,hitY,hitW,hitH)){o.hit=true;dash.hearts--;dash.invuln=1.0;runner?.classList.add('hit');syncDashDriverV208(true);setTimeout(()=>{runner?.classList.remove('hit');syncDashDriverV208(false)},420);dashHud();if(dash.hearts<=0){finishDash(false);return false}}if(o.x<-80){o.el.remove();return false}return true});"
    new_collision = "dash.obstacles=dash.obstacles.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const ow=Math.min(W*.155,74),oh=ow,hitW=ow*.44,hitH=oh*.27,hitX=o.x+ow*.28,hitY=H-ground-hitH-o.raise;if(!o.hit&&dash.invuln<=0&&overlap(playerX,playerY,playerW*.72,playerH*.75,hitX,hitY,hitW,hitH)){o.hit=true;dash.invuln=.85;if(dash.bubble>0){showDashPowerPopV217('Blocked!');}else{dash.duration=(Number(dash.duration)||30)+10;runner?.classList.add('hit');syncDashDriverV208(true);showDashPowerPopV217('+10s');setTimeout(()=>{runner?.classList.remove('hit');syncDashDriverV208(false)},420);}dashHud();}if(o.x<-80){o.el.remove();return false}return true});"
    game = replace_once(game, old_collision, new_collision, "Dash obstacle penalty")

    old_pickups = "dash.pickups=dash.pickups.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const isTime=o.kind==='time-pink'||o.kind==='time-gold';const iw=o.kind==='tiny'?Math.min(W*.108,48):isTime?Math.min(W*.108,46):Math.min(W*.098,42),ih=iw,pickW=iw*.74,pickH=ih*.74,pickX=o.x+iw*.13,pickY=H-ground-pickH-o.raise;if(overlap(playerX,playerY,playerW*.72,playerH*.75,pickX,pickY,pickW,pickH)){if(o.kind==='tiny'){dash.tiny++;recordTinyDuck()}else if(isTime){const bonus=Math.max(0,Number(o.timeBonus)||0);dash.duration=(Number(dash.duration)||30)+bonus;const pop=document.createElement('div');pop.className='dash-time-pop-v213';pop.textContent=`+${bonus}s`;track.appendChild(pop);setTimeout(()=>pop.remove(),950)}else dash.coins++;o.el.remove();dashHud();return false}if(o.x<-60){o.el.remove();return false}return true});dashHud();dash.raf=requestAnimationFrame(dashFrame)}"
    new_pickups = "dash.pickups=dash.pickups.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const isTime=o.kind==='time-pink'||o.kind==='time-gold',isPower=o.kind==='wing'||o.kind==='bubble';const iw=o.kind==='tiny'?Math.min(W*.108,48):(isTime||isPower)?Math.min(W*.108,46):Math.min(W*.098,42),ih=iw,pickW=iw*.74,pickH=ih*.74,pickX=o.x+iw*.13,pickY=H-ground-pickH-o.raise;if(overlap(playerX,playerY,playerW*.72,playerH*.75,pickX,pickY,pickW,pickH)){if(o.kind==='tiny'){dash.tiny++;recordTinyDuck()}else if(isTime){const bonus=Math.max(0,Number(o.timeBonus)||0);dash.duration=(Number(dash.duration)||30)+bonus;showDashPowerPopV217(`+${bonus}s`)}else if(o.kind==='wing'){dash.speedBoost=10;showDashPowerPopV217('Speed Up!')}else if(o.kind==='bubble'){dash.bubble=10;showDashPowerPopV217('Bubble Shield!')}else dash.coins++;o.el.remove();dashHud();return false}if(o.x<-60){o.el.remove();return false}return true});dashHud();dash.raf=requestAnimationFrame(dashFrame)}"
    game = replace_once(game, old_pickups, new_pickups, "Dash pickup effects")

    insert_before_frame = "  function dashFrame(ts){"
    pop_helper = "  function showDashPowerPopV217(text){const track=dashTrack();if(!track)return;const pop=document.createElement('div');pop.className='dash-power-pop-v217';pop.textContent=text;track.appendChild(pop);setTimeout(()=>pop.remove(),950);}\n"
    if insert_before_frame not in game:
        fail("Dash frame insertion anchor is missing")
    game = game.replace(insert_before_frame, pop_helper + insert_before_frame, 1)

    old_start = "Object.assign(dash,{running:true,last:0,elapsed:0,duration:30,hearts:3,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0});"
    new_start = "Object.assign(dash,{running:true,last:0,elapsed:0,duration:30,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0,speedBoost:0,bubble:0,bgOffset:0});"
    game = replace_once(game, old_start, new_start, "Dash run reset")
else:
    game = re.sub(
        r"window\.DUCKIE_DASH_CORE='24\.217[^']*';",
        "window.DUCKIE_DASH_CORE='24.218-powerups-smooth-scroll';",
        game,
        count=1,
    )

write_text(game_path, game)

# Load the Merchant fix last, after every existing Quest patch.
dq_index_path = repo / "duck-quest/index.html"
dq_index = dq_index_path.read_text(encoding="utf-8")
dq_index = re.sub(r"\s*<script\s+src=[\"']js/merchant-fix-v218\.js[^\"']*[\"']\s*></script>", "", dq_index)
dq_index = dq_index.replace(f"?v={current_slug}", f"?v={VERSION_SLUG}")
merchant_tag = f'  <script src="js/merchant-fix-v218.js?v={VERSION_SLUG}"></script>\n'
if "</body>" not in dq_index:
    fail("duck-quest/index.html has no closing body tag")
dq_index = dq_index.replace("</body>", merchant_tag + "</body>", 1)
write_text(dq_index_path, dq_index)

# Update app build metadata and force a clean service-worker refresh.
root_index_path = repo / "index.html"
root_index = root_index_path.read_text(encoding="utf-8")
root_index, meta_count = re.subn(
    r'(<meta\s+name="duck-habit-build"\s+content=")[^"]+("\s*/?>)',
    rf'\g<1>{VERSION}\g<2>',
    root_index,
    count=1,
)
if meta_count != 1:
    fail("root build meta tag was not found")
root_index, build_count = re.subn(
    r'const\s+DUCK_HUB_BUILD\s*=\s*"[^"]+";',
    f'const DUCK_HUB_BUILD = "{VERSION}";',
    root_index,
    count=1,
)
if build_count != 1:
    fail("DUCK_HUB_BUILD marker was not found")
root_index = root_index.replace(f"?v={current_slug}", f"?v={VERSION_SLUG}")
root_index, worker_count = re.subn(
    r'\./sw-v24-\d+\.js\?v=24-\d+',
    f'./sw-v{VERSION_SLUG}.js?v={VERSION_SLUG}',
    root_index,
    count=1,
)
if worker_count != 1:
    fail("service-worker registration was not found")
write_text(root_index_path, root_index)

write_text(version_path, json.dumps({"version": VERSION}, indent=2) + "\n")

source_worker = repo / f"sw-v{current_slug}.js"
if not source_worker.is_file():
    candidates = sorted(repo.glob("sw-v24-*.js"))
    if not candidates:
        fail("no versioned service worker was found")
    source_worker = candidates[-1]

worker = source_worker.read_text(encoding="utf-8")
worker = re.sub(r"duck-habit-hub-app-v24-\d+", f"duck-habit-hub-app-v{VERSION_SLUG}", worker)
worker = re.sub(r"duck-habit-hub-runtime-v24-\d+", f"duck-habit-hub-runtime-v{VERSION_SLUG}", worker)
worker = re.sub(r"\./sw-v24-\d+\.js", f"./sw-v{VERSION_SLUG}.js", worker)
worker = worker.replace(f"?v={current_slug}", f"?v={VERSION_SLUG}")

assets = [
    "./duck-quest/js/merchant-fix-v218.js?v=24-218",
    "./duck-quest/assets/dash/Angel-Wing.png",
    "./duck-quest/assets/dash/Bubble-icon.png",
    "./duck-quest/assets/dash/Bubble.png",
    "./duck-quest/assets/dash/backgrounds/DD-Meadow.png",
    "./duck-quest/assets/dash/backgrounds/DD-Ocean.png",
    "./duck-quest/assets/dash/backgrounds/DD-Candyland.png",
    "./duck-quest/assets/dash/backgrounds/DD-CloudGarden.png",
]
missing_entries = [entry for entry in assets if entry not in worker]
if missing_entries:
    anchor = "  './bakery/index.html'"
    if anchor not in worker:
        fail("service-worker app-shell insertion anchor was not found")
    addition = ",\n" + ",\n".join(f"  '{entry}'" for entry in missing_entries)
    worker = worker.replace(anchor, anchor + addition, 1)

write_text(repo / f"sw-v{VERSION_SLUG}.js", worker)
write_text(repo / "sw.js", f"importScripts('./sw-v{VERSION_SLUG}.js');\n")

notes = """Duckie Days v24.218 — Dash Power-Ups + Merchant Choices

- Keeps the v24.217 Duckie Dash additions in this single installer.
- Angel Wing grants about 1.4x speed for 10 seconds.
- Bubble grants 10 seconds of obstacle protection and displays over the rider/cart.
- Obstacles add 10 seconds to the run instead of removing hearts.
- Meadow, Ocean, Candyland, and Cloud Garden use their dedicated smooth-scrolling strips.
- Mysterious Merchant reliably shows exactly two purchase choices plus No Thanks.
- Buying deducts Pink Coins and grants the selected item/charm; No Thanks safely continues the run.
"""
write_text(repo / "V24.218-NOTES.txt", notes)

print(f"Installed Duckie Days v{VERSION} over v{current_version}.")

#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path


VERSION = "24.225"
VERSION_SLUG = "24-225"
START_VERSION = "24.224"
START_SLUG = "24-224"


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


repo = Path.cwd().resolve()
payload = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else fail("payload directory was not provided")

payload_files = [
    "duck-quest/js/game-v96.js",
    "duck-quest/js/merchant-fix-v218.js",
    "duck-quest/css/style-v82.css",
    "duck-quest/index.html",
]
for relative in payload_files:
    if not (payload / relative).is_file():
        fail(f"payload file is missing: {relative}")

version_path = repo / "version.json"
if not version_path.is_file():
    fail("run this installer from the repository root (version.json is missing)")

try:
    current_version = str(json.loads(version_path.read_text(encoding="utf-8")).get("version", ""))
except Exception as error:
    fail(f"could not read version.json: {error}")

if current_version != START_VERSION:
    fail(f"v{VERSION} must be installed over v{START_VERSION}; found v{current_version or 'unknown'}")

# Confirm that the expected v24.224 baseline is present before replacing the
# four Duck Quest files. This protects unrelated or newer local changes.
baseline_game = (repo / "duck-quest/js/game-v96.js").read_text(encoding="utf-8")
for marker in [
    "sibling-spat-hidden-v224",
    "window.DUCKIE_DASH_CORE='24.224-2x-fullscreen-endless-no-freeze';",
]:
    if marker not in baseline_game:
        fail(f"expected v24.224 game marker is missing: {marker}")

for relative in payload_files:
    source = payload / relative
    destination = repo / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

# Every Duck Quest resource receives a fresh cache key. The copied index is the
# exact v24.224 page plus the new controls, so this replacement is deliberate.
dq_index_path = repo / "duck-quest/index.html"
dq_index = dq_index_path.read_text(encoding="utf-8").replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
write_text(dq_index_path, dq_index)

# Update the hub build markers and service-worker registration.
root_index_path = repo / "index.html"
root_index = root_index_path.read_text(encoding="utf-8")
root_index, meta_count = re.subn(
    r'(<meta\s+name="duck-habit-build"\s+content=")[^"]+("\s*/?>)',
    rf'\g<1>{VERSION}\g<2>',
    root_index,
    count=1,
)
if meta_count != 1:
    fail("root build meta tag was not found")
root_index, build_count = re.subn(
    r'const\s+DUCK_HUB_BUILD\s*=\s*"[^"]+";',
    f'const DUCK_HUB_BUILD = "{VERSION}";',
    root_index,
    count=1,
)
if build_count != 1:
    fail("DUCK_HUB_BUILD marker was not found")
root_index = root_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
root_index, worker_count = re.subn(
    r'\./sw-v24-\d+\.js\?v=24-\d+',
    f'./sw-v{VERSION_SLUG}.js?v={VERSION_SLUG}',
    root_index,
    count=1,
)
if worker_count != 1:
    fail("service-worker registration was not found")
write_text(root_index_path, root_index)

write_text(version_path, json.dumps({"version": VERSION}, indent=2) + "\n")

source_worker = repo / f"sw-v{START_SLUG}.js"
if not source_worker.is_file():
    fail(f"{source_worker.name} is missing")
worker = source_worker.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-224", "duck-habit-hub-app-v24-225")
worker = worker.replace("duck-habit-hub-runtime-v24-224", "duck-habit-hub-runtime-v24-225")
worker = worker.replace("./sw-v24-224.js", "./sw-v24-225.js")
worker = worker.replace("?v=24-224", "?v=24-225")
write_text(repo / "sw-v24-225.js", worker)
write_text(repo / "sw.js", "importScripts('./sw-v24-225.js');\n")

notes = """Duckie Days v24.225 — Merchant Sale and Quest Flow

- Mysterious Merchant items are 20% cheaper than their normal prices.
- Merchant charms use their complete family colors and metal-tier coloring.
- Normal stage victories show a pink Run Next Level button first and remove Run Again.
- Endless Quest keeps its Continue Floor action.
- Stage routes replace Start from Beginning with Pick Starting Point.
- Pick Starting Point offers every unlocked level from 1 through the latest level.
- The starting-point chooser remembers the last-used level as its default.
- Preserves the v24.224 Sibling Spat scene repair.
- Preserves the fullscreen endless Duckie Dash backgrounds and no-freeze repair.
"""
write_text(repo / "V24.225-NOTES.txt", notes)

print(f"Installed Duckie Days v{VERSION} over v{current_version}.")

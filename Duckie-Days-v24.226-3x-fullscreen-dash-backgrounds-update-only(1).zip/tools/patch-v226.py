#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
import shutil
import struct
import sys
from pathlib import Path


VERSION = "24.226"
VERSION_SLUG = "24-226"
START_VERSION = "24.225"
START_SLUG = "24-225"

BACKGROUND_HASHES = {
    "DD-Meadow-3x.png": "70373033c26135fa63895b752d14b49522cb706c1da3aef75d0d4190e3be2b2c",
    "DD-Ocean-3x.png": "5477fbd2c3a05266e492fede380929c45e940e3121b5ccdbb77d2cba75bec264",
    "DD-Candyland-3x.png": "2caf90cd8e093fd55db18c83be2ff6a2557c755ef8107c8f77a627195c9baa4e",
    "DD-CloudGarden-3x.png": "d7cf67f36a50ac87e8878c3ec6fbedad7f4011c88f80c888ff0fcb9e507a2248",
}


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        fail(f"background is not a valid PNG: {path.name}")
    return struct.unpack(">II", header[16:24])


repo = Path.cwd().resolve()
payload = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else fail("payload directory was not provided")

required_payload = [
    "duck-quest/js/dash-background-fix-v226.js",
    *[f"duck-quest/assets/dash/backgrounds/{name}" for name in BACKGROUND_HASHES],
]
for relative in required_payload:
    if not (payload / relative).is_file():
        fail(f"payload file is missing: {relative}")

for name, expected_hash in BACKGROUND_HASHES.items():
    source = payload / "duck-quest/assets/dash/backgrounds" / name
    if png_dimensions(source) != (6600, 1500):
        fail(f"{name} must be exactly 6600 x 1500")
    actual_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    if actual_hash != expected_hash:
        fail(f"{name} does not match the approved background asset")

version_path = repo / "version.json"
if not version_path.is_file():
    fail("run this installer from the repository root (version.json is missing)")

try:
    current_version = str(json.loads(version_path.read_text(encoding="utf-8")).get("version", ""))
except Exception as error:
    fail(f"could not read version.json: {error}")

if current_version != START_VERSION:
    fail(f"v{VERSION} must be installed over v{START_VERSION}; found v{current_version or 'unknown'}")

game_path = repo / "duck-quest/js/game-v96.js"
dq_index_path = repo / "duck-quest/index.html"
baseline_game = game_path.read_text(encoding="utf-8")
for marker in [
    "window.DUCKIE_DASH_CORE='24.224-2x-fullscreen-endless-no-freeze';",
    "window.DUCKIE_DAYS_QUEST_FLOW='24.225-next-level-and-start-picker';",
    "Time’s Up!",
    "dashBgCloneV217",
]:
    if marker not in baseline_game:
        fail(f"expected v24.225 game marker is missing: {marker}")

for relative in required_payload:
    source = payload / relative
    destination = repo / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

game = baseline_game.replace(
    "window.DUCKIE_DASH_CORE='24.224-2x-fullscreen-endless-no-freeze';",
    "window.DUCKIE_DASH_CORE='24.226-3x-fullscreen-endless-no-freeze';",
    1,
)
background_names = ["Meadow", "Ocean", "Candyland", "CloudGarden"]
for name in background_names:
    game = game.replace(f"DD-{name}.png", f"DD-{name}-3x.png")
write_text(game_path, game)

dq_index = dq_index_path.read_text(encoding="utf-8")
old_dash_tag = '<script src="js/dash-background-fix-v224.js?v=24-225"></script>'
new_dash_tag = '<script src="js/dash-background-fix-v226.js?v=24-226"></script>'
if dq_index.count(old_dash_tag) != 1:
    fail("expected v24.224 Dash background script tag was not found exactly once")
dq_index = dq_index.replace(old_dash_tag, new_dash_tag, 1)
dq_index = dq_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
write_text(dq_index_path, dq_index)

old_fix = repo / "duck-quest/js/dash-background-fix-v224.js"
if old_fix.is_file():
    old_fix.unlink()

root_index_path = repo / "index.html"
root_index = root_index_path.read_text(encoding="utf-8")
root_index, meta_count = re.subn(
    r'(<meta\s+name="duck-habit-build"\s+content=")[^"]+("\s*/?>)',
    rf'\g<1>{VERSION}\g<2>',
    root_index,
    count=1,
)
if meta_count != 1:
    fail("root build meta tag was not found")
root_index, build_count = re.subn(
    r'const\s+DUCK_HUB_BUILD\s*=\s*"[^"]+";',
    f'const DUCK_HUB_BUILD = "{VERSION}";',
    root_index,
    count=1,
)
if build_count != 1:
    fail("DUCK_HUB_BUILD marker was not found")
root_index = root_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
root_index, worker_count = re.subn(
    r'\./sw-v24-\d+\.js\?v=24-\d+',
    f'./sw-v{VERSION_SLUG}.js?v={VERSION_SLUG}',
    root_index,
    count=1,
)
if worker_count != 1:
    fail("service-worker registration was not found")
write_text(root_index_path, root_index)

write_text(version_path, json.dumps({"version": VERSION}, indent=2) + "\n")

source_worker = repo / f"sw-v{START_SLUG}.js"
if not source_worker.is_file():
    fail(f"{source_worker.name} is missing")
worker = source_worker.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-225", "duck-habit-hub-app-v24-226")
worker = worker.replace("duck-habit-hub-runtime-v24-225", "duck-habit-hub-runtime-v24-226")
worker = worker.replace("./sw-v24-225.js", "./sw-v24-226.js")
worker = worker.replace("?v=24-225", "?v=24-226")
worker = worker.replace("dash-background-fix-v224.js", "dash-background-fix-v226.js")
for name in background_names:
    worker = worker.replace(f"DD-{name}.png", f"DD-{name}-3x.png")
write_text(repo / "sw-v24-226.js", worker)
write_text(repo / "sw.js", "importScripts('./sw-v24-226.js');\n")

notes = """Duckie Days v24.226 — New 3x Fullscreen Duckie Dash Backgrounds

- Replaces all four Duckie Dash stage strips with the supplied 6600 x 1500 artwork.
- Maps the Meadow and Cloud Garden artwork to their visually correct stages despite the swapped source filenames.
- Keeps every Duckie Dash background at 100% of the play-area height.
- Keeps two copies of each strip side by side for a smooth endless horizontal loop.
- Duckie Dash still ends only when its timer reaches zero; there is no background finish or boss stage.
- Preserves the no-freeze repair and avoids recursive overlay observation.
- Preserves v24.225 Mysterious Merchant pricing/color fixes and Quest result/start-point flow.
- Uses new -3x asset filenames so installed PWAs cannot reuse older cached background images.
"""
write_text(repo / "V24.226-NOTES.txt", notes)

print(f"Installed Duckie Days v{VERSION} over v{current_version}.")

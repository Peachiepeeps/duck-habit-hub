#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path


VERSION = "24.229"
VERSION_SLUG = "24-229"
START_VERSION = "24.228"
START_SLUG = "24-228"

BACKGROUND_HASHES = {
    "DD-Meadow-3x.png": "70373033c26135fa63895b752d14b49522cb706c1da3aef75d0d4190e3be2b2c",
    "DD-Ocean-3x.png": "5477fbd2c3a05266e492fede380929c45e940e3121b5ccdbb77d2cba75bec264",
    "DD-Candyland-3x.png": "2caf90cd8e093fd55db18c83be2ff6a2557c755ef8107c8f77a627195c9baa4e",
    "DD-CloudGarden-3x.png": "d7cf67f36a50ac87e8878c3ec6fbedad7f4011c88f80c888ff0fcb9e507a2248",
}


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        fail(f"expected exactly one {label}; found {count}")
    return text.replace(old, new, 1)


repo = Path.cwd().resolve()
payload = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else fail("payload directory was not provided")
if not (payload / "tools/patch-v229.py").is_file():
    fail("payload file is missing: tools/patch-v229.py")

version_path = repo / "version.json"
if not version_path.is_file():
    fail("run this installer from the repository root (version.json is missing)")
try:
    current_version = str(json.loads(version_path.read_text(encoding="utf-8")).get("version", ""))
except Exception as error:
    fail(f"could not read version.json: {error}")
if current_version != START_VERSION:
    fail(f"v{VERSION} must be installed over v{START_VERSION}; found v{current_version or 'unknown'}")

# This is a positioning-only update. Keep every approved background strip exact.
background_dir = repo / "duck-quest/assets/dash/backgrounds"
for name, expected_hash in BACKGROUND_HASHES.items():
    path = background_dir / name
    if not path.is_file():
        fail(f"required background is missing: {name}")
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected_hash:
        fail(f"background changed unexpectedly: {name}")

game_path = repo / "duck-quest/js/game-v96.js"
game = game_path.read_text(encoding="utf-8")
for marker in [
    "window.DUCKIE_DASH_CORE='24.228-extra-low-foreground';",
    "const DASH_GROUND_RATIO=.03;",
    "const DASH_BASE_SPEED=.48;",
    "bottom:10%!important;",
    "ground=H*DASH_GROUND_RATIO,playerY=H-ground-playerH-dash.jumpY",
    "const speed=W*DASH_BASE_SPEED*(dash.speedBoost>0?1.4:1)",
    "dash.bgOffset=(dash.bgOffset+speed*dt*.55)%bg.clientWidth",
]:
    if marker not in game:
        fail(f"expected v24.228 marker is missing: {marker}")

game = replace_once(
    game,
    "const DASH_GROUND_RATIO=.03;",
    "const DASH_GROUND_RATIO=.05;\n  const DASH_RUNNER_RAISE=4;",
    "shared ground ratio",
)
game = replace_once(
    game,
    "window.DUCKIE_DASH_CORE='24.228-extra-low-foreground';",
    "window.DUCKIE_DASH_CORE='24.229-aligned-foreground';",
    "Duckie Dash core marker",
)
game = replace_once(
    game,
    ".dash-runner{position:absolute;width:20%;max-width:92px;height:auto;left:12%;bottom:3%;",
    ".dash-runner{position:absolute;width:20%;max-width:92px;height:auto;left:12%;bottom:calc(5% + 4px);",
    "base runner ground position",
)
game = replace_once(
    game,
    "bottom:10%!important;",
    "bottom:calc(5% + 4px)!important;",
    "composite runner override",
)
game = replace_once(
    game,
    "ground=H*DASH_GROUND_RATIO,playerY=H-ground-playerH-dash.jumpY",
    "ground=H*DASH_GROUND_RATIO,playerY=H-ground-DASH_RUNNER_RAISE-playerH-dash.jumpY",
    "runner collision ground position",
)
write_text(game_path, game)

dq_index_path = repo / "duck-quest/index.html"
dq_index = dq_index_path.read_text(encoding="utf-8")
if f"?v={START_SLUG}" not in dq_index:
    fail("v24.228 Duck Quest cache keys were not found")
dq_index = dq_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
write_text(dq_index_path, dq_index)

root_index_path = repo / "index.html"
root_index = root_index_path.read_text(encoding="utf-8")
root_index, meta_count = re.subn(
    r'(<meta\s+name="duck-habit-build"\s+content=")[^"]+("\s*/?>)',
    rf'\g<1>{VERSION}\g<2>',
    root_index,
    count=1,
)
if meta_count != 1:
    fail("root build meta tag was not found")
root_index, build_count = re.subn(
    r'const\s+DUCK_HUB_BUILD\s*=\s*"[^"]+";',
    f'const DUCK_HUB_BUILD = "{VERSION}";',
    root_index,
    count=1,
)
if build_count != 1:
    fail("DUCK_HUB_BUILD marker was not found")
root_index = root_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
root_index, worker_count = re.subn(
    r'\./sw-v24-\d+\.js\?v=24-\d+',
    f'./sw-v{VERSION_SLUG}.js?v={VERSION_SLUG}',
    root_index,
    count=1,
)
if worker_count != 1:
    fail("service-worker registration was not found")
write_text(root_index_path, root_index)
write_text(version_path, json.dumps({"version": VERSION}, indent=2) + "\n")

source_worker = repo / f"sw-v{START_SLUG}.js"
if not source_worker.is_file():
    fail(f"{source_worker.name} is missing")
worker = source_worker.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-228", "duck-habit-hub-app-v24-229")
worker = worker.replace("duck-habit-hub-runtime-v24-228", "duck-habit-hub-runtime-v24-229")
worker = worker.replace("./sw-v24-228.js", "./sw-v24-229.js")
worker = worker.replace("?v=24-228", "?v=24-229")
write_text(repo / "sw-v24-229.js", worker)
write_text(repo / "sw.js", "importScripts('./sw-v24-229.js');\n")

notes = """Duckie Days v24.229 — Aligned Duckie Dash Foreground

- Raises the shared Duckie Dash object ground from 3% to 5%.
- Moves the visible OC and duck cart down from the old 10% override to the same 5% + 4px line used by ground-level obstacles and Tiny Ducks.
- Aligns the runner collision box to that exact visible line.
- Preserves the current 0.48 base speed and 1.4x Angel Wing boost.
- Leaves all four 6600 x 1500 fullscreen backgrounds byte-for-byte unchanged.
- Preserves endless looping, timer-only completion, object patterns, pickups, and earlier Merchant/Quest fixes.
"""
write_text(repo / "V24.229-NOTES.txt", notes)
print(f"Installed Duckie Days v{VERSION} over v{current_version}.")

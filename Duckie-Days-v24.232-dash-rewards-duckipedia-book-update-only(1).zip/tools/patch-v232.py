#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path


VERSION = "24.232"
VERSION_SLUG = "24-232"
START_VERSION = "24.229"
START_SLUG = "24-229"


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        fail(f"expected exactly one {label}; found {count}")
    return text.replace(old, new, 1)


repo = Path.cwd().resolve()
payload = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else fail("payload directory was not provided")
if not (payload / "tools/patch-v232.py").is_file():
    fail("payload file is missing: tools/patch-v232.py")

version_path = repo / "version.json"
if not version_path.is_file():
    fail("run this installer from the repository root (version.json is missing)")
try:
    current_version = str(json.loads(version_path.read_text(encoding="utf-8")).get("version", ""))
except Exception as error:
    fail(f"could not read version.json: {error}")
if current_version != START_VERSION:
    fail(f"v{VERSION} must be installed over v{START_VERSION}; found v{current_version or 'unknown'}")

game_path = repo / "duck-quest/js/game-v96.js"
game = game_path.read_text(encoding="utf-8")
for marker in [
    "window.DUCKIE_DASH_CORE='24.229-aligned-foreground';",
    "const DASH_GROUND_RATIO=.05;",
    "const DASH_RUNNER_RAISE=4;",
    "const DASH_BASE_SPEED=.48;",
    ".sibling-scene.sibling-spat-v224 .sibling-right-v224",
    "@keyframes siblingRightIdleV224",
    "const SIBLING_IDLE_FRAMES=",
    "function beginSiblingBattle(){",
    "refs.sprite?.classList.remove(\"boss-fighter\",\"gold-boss-fighter\",\"queen-bee-fighter\",\"strawberry-slime-fighter\",\"rainbow-flower-fighter\",\"ocean-elite-fighter\",\"ocean-boss-fighter\",\"cream-fox-fighter\");",
]:
    if marker not in game:
        fail(f"expected v24.229 marker is missing: {marker}")


def guarded_fragment(text: str, start: str, end: str, include_end: bool = False) -> str:
    start_at = text.find(start)
    end_at = text.find(end, start_at + len(start))
    if start_at < 0 or end_at < 0:
        fail(f"could not protect cutscene fragment: {start} ... {end}")
    if include_end:
        end_at += len(end)
    return text[start_at:end_at]


css_anchor = ".sibling-dialogue-actions{display:flex;justify-content:flex-end}.sibling-dialogue-actions .pixel-button{min-width:120px}"
cutscene_css_before = guarded_fragment(game, ".sibling-scene{", css_anchor, include_end=True)
cutscene_js_before = guarded_fragment(game, "function siblingSprite(", "function beginSiblingBattle()")

# Add battle-only rules. The existing Sibling Spat cutscene rules and functions
# remain untouched. The independent CSS scale keeps the inward flip active even
# while the normal attack/hurt animations animate the transform property.
battle_css = css_anchor + """
    /* v24.230 — Sibling Spat battle only: face the opponent inward and size by height. */
    .battlefield.sibling-battle-v230 .enemy-combatant .enemy-fighter.sibling-opponent-v230{width:auto!important;max-width:none!important;max-height:none!important;scale:-1 1;transform-origin:center bottom!important;object-fit:contain!important}
    .battlefield.sibling-battle-v230.miho-active .enemy-combatant .enemy-fighter.sibling-opponent-v230{height:40.2%!important;bottom:8%!important}
    .battlefield.sibling-battle-v230.miko-active .enemy-combatant .enemy-fighter.sibling-opponent-v230{height:53.3%!important;bottom:6%!important}
    @media(max-width:600px){.battlefield.sibling-battle-v230.miho-active .enemy-combatant .enemy-fighter.sibling-opponent-v230{height:44.5%!important;bottom:9%!important}.battlefield.sibling-battle-v230.miko-active .enemy-combatant .enemy-fighter.sibling-opponent-v230{height:54.2%!important;bottom:7%!important}}
"""
game = replace_once(game, css_anchor, battle_css, "Sibling Spat battle CSS anchor")

# Remove the battle-only class whenever an enemy slot is repopulated. This
# prevents its orientation/height rules from leaking into later encounters.
class_cleanup_old = 'refs.sprite?.classList.remove("boss-fighter","gold-boss-fighter","queen-bee-fighter","strawberry-slime-fighter","rainbow-flower-fighter","ocean-elite-fighter","ocean-boss-fighter","cream-fox-fighter");'
class_cleanup_new = 'refs.sprite?.classList.remove("boss-fighter","gold-boss-fighter","queen-bee-fighter","strawberry-slime-fighter","rainbow-flower-fighter","ocean-elite-fighter","ocean-boss-fighter","cream-fox-fighter");refs.sprite?.classList.toggle("sibling-opponent-v230",Boolean(enemy?.siblingCharacterId));ui.battlefield?.classList.toggle("sibling-battle-v230",Boolean(enemy?.siblingCharacterId));'
game = replace_once(game, class_cleanup_old, class_cleanup_new, "enemy sprite class cleanup")

# Activate the battle-only rules only after the cutscene closes and the real
# opponent has been created. Both directions use the same inward-facing class.
begin_old = "startEnemy(opponent,{suppressIntro:true});currentEnemy.uncatchable=true;"
begin_new = "startEnemy(opponent,{suppressIntro:true});ui.battlefield?.classList.add('sibling-battle-v230');ui.enemySprite?.classList.add('sibling-opponent-v230');currentEnemy.uncatchable=true;"
game = replace_once(game, begin_old, begin_new, "Sibling Spat battle activation")

marker_anchor = "  // ----- Sibling Spat dialogue + battle -----"
game = replace_once(
    game,
    marker_anchor,
    "  window.SIBLING_SPAT_BATTLE_FIX='24.230-inward-equal-height';\n" + marker_anchor,
    "Sibling Spat battle fix marker",
)

cutscene_css_after = guarded_fragment(game, ".sibling-scene{", css_anchor, include_end=True)
cutscene_js_after = guarded_fragment(game, "function siblingSprite(", "function beginSiblingBattle()")
if cutscene_css_after != cutscene_css_before or cutscene_js_after != cutscene_js_before:
    fail("the approved Sibling Spat cutscene changed unexpectedly")

# ----- Duckie Dash: persist both Pink Coins and real Tiny Duck quantities -----
game = replace_once(
    game,
    "window.DUCKIE_DASH_CORE='24.229-aligned-foreground';",
    "window.DUCKIE_DASH_CORE='24.229-aligned-foreground';\n  window.DUCKIE_DASH_REWARD_FIX='24.232-persist-coins-and-tiny-ducks';",
    "Duckie Dash reward fix marker",
)

record_tiny_old = "function recordTinyDuck(){hubSave.tinyDuckSightings=Math.max(0,Number(hubSave.tinyDuckSightings)||0)+1;if(!Array.isArray(hubSave.unlockedDucks))hubSave.unlockedDucks=[];const add=id=>{if(!hubSave.unlockedDucks.includes(id))hubSave.unlockedDucks.push(id)};add('tiny-duck');if(hubSave.tinyDuckSightings>=4)add('tiny-duck-stack');if(hubSave.tinyDuckSightings>=100)add('pile-of-tiny-ducks');}"
reward_helpers_new = """function addDashDuckCopyV232(saveData,duckId,amount=0){
    if(!saveData || !duckId)return 0;
    if(!Array.isArray(saveData.unlockedDucks))saveData.unlockedDucks=[];
    const wasUnlocked=saveData.unlockedDucks.includes(duckId);
    if(!wasUnlocked)saveData.unlockedDucks.push(duckId);
    if(!saveData.duckCollectionCounts||typeof saveData.duckCollectionCounts!=='object'||Array.isArray(saveData.duckCollectionCounts))saveData.duckCollectionCounts={};
    const before=Math.max(wasUnlocked?1:0,Math.floor(Number(saveData.duckCollectionCounts[duckId])||0));
    const after=amount>0?before+Math.max(0,Math.floor(Number(amount)||0)):Math.max(1,before);
    saveData.duckCollectionCounts[duckId]=after;
    return after;
  }
  function awardDashRewardsV232(collectedCoins,collectedTiny,success){
    const latest=loadHubSave();
    const pickupCoins=Math.max(0,Math.floor(Number(collectedCoins)||0));
    const tinyDucks=Math.max(0,Math.floor(Number(collectedTiny)||0));
    const coinAward=(success?20:5)+pickupCoins;
    latest.coins=Math.max(0,Number(latest.coins)||0)+coinAward;
    latest.stats=latest.stats&&typeof latest.stats==='object'?latest.stats:{};
    latest.stats.coinsEarnedTotal=Math.max(0,Number(latest.stats.coinsEarnedTotal)||0)+coinAward;
    if(tinyDucks>0){
      latest.tinyDuckSightings=Math.max(0,Number(latest.tinyDuckSightings)||0)+tinyDucks;
      addDashDuckCopyV232(latest,'tiny-duck',tinyDucks);
      if(latest.tinyDuckSightings>=4)addDashDuckCopyV232(latest,'tiny-duck-stack');
      if(latest.tinyDuckSightings>=100)addDashDuckCopyV232(latest,'pile-of-tiny-ducks');
    }
    hubSave=latest;
    return {coins:coinAward,tiny:tinyDucks};
  }"""
game = replace_once(game, record_tiny_old, reward_helpers_new, "Duckie Dash saved reward helpers")
game = replace_once(
    game,
    "if(o.kind==='tiny'){dash.tiny++;recordTinyDuck()}",
    "if(o.kind==='tiny'){dash.tiny++}",
    "Tiny Duck pickup counter",
)

finish_dash_old = "function finishDash(success){if(!dash.running)return;dash.running=false;cancelAnimationFrame(dash.raf);document.querySelector('#dashBubble')?.classList.remove('active');const base=success?20:5;const award=base+dash.coins;hubSave.coins=Math.max(0,Number(hubSave.coins)||0)+award;questSave.dash.runs=Math.max(0,Number(questSave.dash.runs)||0)+1;const score=Math.max(0,Math.floor(dash.elapsed*4+dash.coins*8+dash.tiny*60+(success?100:0)));questSave.dash.highScore=Math.max(questSave.dash.highScore,score);persistAll();refreshFeatureBadges();const ov=document.querySelector('#dashOverlay');if(ov){ov.classList.remove('hidden');ov.innerHTML=`<div class=\"dash-overlay-card\"><strong>${success?'Time’s Up!':'Run Ended!'}</strong><small>${success?'The timer reached zero — run complete!':'The run ended early.'}<br>Pink Coins +${award}<br>Tiny Ducks ${dash.tiny}<br>Score ${score}</small><div class=\"dash-result-actions-v193\"><button id=\"dashAgain\" class=\"pixel-button primary\" type=\"button\">Run Again</button><button id=\"dashRunMenuV193\" class=\"pixel-button\" type=\"button\">Dash Menu</button></div></div>`;ov.querySelector('#dashAgain')?.addEventListener('click',startDash);ov.querySelector('#dashRunMenuV193')?.addEventListener('click',leaveDashRunStage);}}"
finish_dash_new = """function finishDash(success){
    if(!dash.running)return;
    dash.running=false;
    cancelAnimationFrame(dash.raf);
    document.querySelector('#dashBubble')?.classList.remove('active');
    const rewards=awardDashRewardsV232(dash.coins,dash.tiny,success);
    questSave.dash.runs=Math.max(0,Number(questSave.dash.runs)||0)+1;
    const score=Math.max(0,Math.floor(dash.elapsed*4+dash.coins*8+dash.tiny*60+(success?100:0)));
    questSave.dash.highScore=Math.max(questSave.dash.highScore,score);
    persistAll();
    refreshFeatureBadges();
    const ov=document.querySelector('#dashOverlay');
    if(ov){
      ov.classList.remove('hidden');
      ov.innerHTML=`<div class="dash-overlay-card"><strong>${success?'Time’s Up!':'Run Ended!'}</strong><small>${success?'The timer reached zero — run complete!':'The run ended early.'}<br>Pink Coins +${rewards.coins}<br>Tiny Ducks +${rewards.tiny}<br>Score ${score}</small><div class="dash-result-actions-v193"><button id="dashAgain" class="pixel-button primary" type="button">Run Again</button><button id="dashRunMenuV193" class="pixel-button" type="button">Dash Menu</button></div></div>`;
      ov.querySelector('#dashAgain')?.addEventListener('click',startDash);
      ov.querySelector('#dashRunMenuV193')?.addEventListener('click',leaveDashRunStage);
    }
  }"""
game = replace_once(game, finish_dash_old, finish_dash_new, "Duckie Dash finish rewards")
write_text(game_path, game)

# ----- Crane game: paid attempts, paid restocks, and real duck copies -----
crane_script_path = repo / "crane-game/script-v24-40.js"
crane_script = crane_script_path.read_text(encoding="utf-8")
for marker in [
    "const PRIZE_COIN_REWARD = 3;",
    "const MACHINE_CLEAR_BONUS = 10;",
    "const RESET_COST = 10;",
    "const CATCH_CHANCE = 0.60;",
    "function addCoins(amount){",
    "function saveCraneState(){",
    "async function showWinToast(prize,machineCleared=false){",
    "async function dropClaw(){",
    "function resetPrizes(){",
]:
    if marker not in crane_script:
        fail(f"expected crane marker is missing: {marker}")

crane_script = replace_once(
    crane_script,
    "const PRIZE_COIN_REWARD = 3;\nconst MACHINE_CLEAR_BONUS = 10;\nconst RESET_COST = 10;\nconst CATCH_CHANCE = 0.60;",
    "const PLAY_COST = 10;\nconst RESET_COST = 50;\nconst CATCH_CHANCE = 0.60;\nwindow.DUCK_CRANE_REWARD_BUILD = '24.232-duck-copy-prizes';",
    "crane costs and build marker",
)

add_coins_old = """function addCoins(amount){
  const data = loadHubSave();
  data.coins = Math.max(0, Math.floor(Number(data.coins) || 0) + Math.floor(Number(amount) || 0));
  data.stats = data.stats && typeof data.stats === "object" ? data.stats : {};
  data.stats.cranePrizes = Math.max(0, Number(data.stats.cranePrizes) || 0) + 1;
  data.stats.coinsEarnedTotal = Math.max(0, Number(data.stats.coinsEarnedTotal) || 0) + Math.max(0, Math.floor(Number(amount) || 0));
  saveHubSave(data);
  coinCount.textContent = data.coins;
}
"""
award_duck_new = """function awardDuckCopy(duckId){
  const id = String(duckId || "");
  if(!DUCK_CATALOG[id]) return 0;
  const data = loadHubSave();
  if(!Array.isArray(data.unlockedDucks)) data.unlockedDucks = [];
  const wasUnlocked = data.unlockedDucks.includes(id);
  if(!wasUnlocked) data.unlockedDucks.push(id);
  if(!data.duckCollectionCounts || typeof data.duckCollectionCounts !== "object" || Array.isArray(data.duckCollectionCounts)){
    data.duckCollectionCounts = {};
  }
  const before = Math.max(wasUnlocked ? 1 : 0, Math.floor(Number(data.duckCollectionCounts[id]) || 0));
  const owned = before + 1;
  data.duckCollectionCounts[id] = owned;
  data.stats = data.stats && typeof data.stats === "object" ? data.stats : {};
  data.stats.cranePrizes = Math.max(0, Number(data.stats.cranePrizes) || 0) + 1;
  saveHubSave(data);
  return owned;
}

function pulseCoinBox(){
  const box = document.getElementById("coinBox");
  box?.animate(
    [
      {transform:"scale(1)"},
      {transform:"scale(1.08)"},
      {transform:"scale(1)"}
    ],
    {duration:360,easing:"ease-out"}
  );
}
"""
crane_script = replace_once(crane_script, add_coins_old, award_duck_new, "duck prize award function")

crane_script = replace_once(
    crane_script,
    "  dropButton.disabled = !hasDucks || busy;",
    "  dropButton.disabled = !hasDucks || !prizes.length || busy;",
    "drop availability",
)

toast_start = crane_script.index("async function showWinToast(prize,machineCleared=false){")
toast_end = crane_script.index("\nasync function returnClawToHome(){", toast_start)
if toast_start < 0 or toast_end < 0:
    fail("could not locate crane win toast function")
toast_new = """async function showWinToast(prize,machineCleared=false,owned=1){
  winImage.src = prize.image;
  winImage.alt = prize.name;
  winName.textContent = prize.name;
  winRewardText.textContent = `Duck collected! Owned ×${Math.max(1,Number(owned)||1)}`;
  winText.textContent = machineCleared
    ? `Machine cleared! A fresh set of ducks will be restocked for free. ♡`
    : `${prize.name} was added to your collection. ♡`;

  winToast.classList.add("show");
  winToast.setAttribute("aria-hidden","false");

  await new Promise(resolve=>{
    const handler = ()=>{
      keepPlayingBtn.removeEventListener("click",handler);
      winToast.classList.remove("show");
      winToast.setAttribute("aria-hidden","true");
      resolve();
    };
    keepPlayingBtn.addEventListener("click",handler);
  });
}
"""
crane_script = crane_script[:toast_start] + toast_new + crane_script[toast_end:]

drop_start_old = """async function dropClaw(){
  if(busy || !getUnlockedDuckIds().length) return;

  busy = true;"""
drop_start_new = """async function dropClaw(){
  if(busy || !getUnlockedDuckIds().length || !prizes.length) return;

  const coins = getCoins();
  if(coins < PLAY_COST){
    pulseCoinBox();
    setMessage(`You need ${PLAY_COST} Pink Coins to play!`);
    return;
  }
  setCoins(coins-PLAY_COST);

  busy = true;"""
crane_script = replace_once(crane_script, drop_start_old, drop_start_new, "paid crane attempt")

reward_old = """  addCoins(PRIZE_COIN_REWARD);
  if(machineCleared){
    // Clear bonus should not count as another crane prize statistic.
    const data = loadHubSave();
    data.coins = Math.max(0,Math.floor(Number(data.coins)||0)+MACHINE_CLEAR_BONUS);
    data.stats = data.stats && typeof data.stats === "object" ? data.stats : {};
    data.stats.coinsEarnedTotal = Math.max(0, Number(data.stats.coinsEarnedTotal) || 0) + MACHINE_CLEAR_BONUS;
    saveHubSave(data);
    coinCount.textContent = data.coins;
  }

  saveCraneState();
  await showWinToast(target,machineCleared);"""
reward_new = """  const owned = awardDuckCopy(target.duckId);
  saveCraneState();
  await showWinToast(target,machineCleared,owned);"""
crane_script = replace_once(crane_script, reward_old, reward_new, "real duck crane reward")

after_toast_old = """  if(machineCleared){
    newPrizeLayout();
  }else{
    renderPrizes();
    saveCraneState();
  }"""
after_toast_new = """  if(machineCleared){
    newPrizeLayout();
    setMessage("Machine cleared! Fresh ducks were restocked for free. ♡");
  }else{
    renderPrizes();
    saveCraneState();
  }"""
crane_script = replace_once(crane_script, after_toast_old, after_toast_new, "paid restock after clear")

insufficient_restock_old = """  if(coins < RESET_COST){
    // Keep the clean machine look; briefly pulse the coin counter instead of a big alert.
    const box = document.getElementById("coinBox");
    box.animate(
      [
        {transform:"scale(1)"},
        {transform:"scale(1.08)"},
        {transform:"scale(1)"}
      ],
      {duration:360,easing:"ease-out"}
    );
    return;
  }"""
insufficient_restock_new = """  if(coins < RESET_COST){
    pulseCoinBox();
    setMessage(`You need ${RESET_COST} Pink Coins to restock!`);
    return;
  }"""
crane_script = replace_once(crane_script, insufficient_restock_old, insufficient_restock_new, "restock affordability feedback")
write_text(crane_script_path, crane_script)

crane_play_path = repo / "crane-game/play-v24-40.html"
crane_play = crane_play_path.read_text(encoding="utf-8")
crane_play = replace_once(
    crane_play,
    '<link rel="stylesheet" href="style-v24-40.css">',
    '<link rel="stylesheet" href="style-v24-40.css?v=24-232">',
    "crane style cache key",
)
crane_play = replace_once(
    crane_play,
    '<div id="dropLabel" class="button-label">DROP!</div>',
    '''<div id="dropLabel" class="button-label">\n      <span>DROP!</span>\n      <span class="play-cost">\n        <img src="../assets/ui/pink-coin.png" alt="">\n        <span id="playCostText">10</span>\n      </span>\n    </div>''',
    "crane play cost label",
)
crane_play = replace_once(crane_play, '<span id="resetCostText">10</span>', '<span id="resetCostText">50</span>', "crane restock cost label")
crane_play = replace_once(
    crane_play,
    '''<div id="winReward">\n        <img src="../assets/ui/pink-coin.png" alt="">\n        <span id="winRewardText">+3 Pink Coins!</span>\n      </div>''',
    '''<div id="winReward">\n        <span id="winRewardText">Duck collected!</span>\n      </div>''',
    "crane duck reward label",
)
crane_play = replace_once(
    crane_play,
    '<script src="script-v24-40.js"></script>',
    '<script src="script-v24-40.js?v=24-232"></script>',
    "crane script cache key",
)
write_text(crane_play_path, crane_play)

crane_style_path = repo / "crane-game/style-v24-40.css"
crane_style = crane_style_path.read_text(encoding="utf-8")
crane_style = replace_once(
    crane_style,
    """#dropLabel{
  left:17.4%;
  top:91.6%;
  color:#2e5f8c;
  font-size:clamp(10px,1.55vw,24px);
}""",
    """#dropLabel{
  left:17.4%;
  top:91.6%;
  color:#2e5f8c;
  font-size:clamp(10px,1.55vw,24px);
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:2px;
}""",
    "crane play cost layout",
)
crane_style = replace_once(crane_style, ".reset-cost{", ".reset-cost,.play-cost{", "shared crane cost row")
crane_style = replace_once(crane_style, ".reset-cost img{", ".reset-cost img,.play-cost img{", "shared crane cost icon")
write_text(crane_style_path, crane_style)

crane_index_path = repo / "crane-game/index.html"
crane_index = crane_index_path.read_text(encoding="utf-8")
crane_index = replace_once(
    crane_index,
    '<meta http-equiv="refresh" content="0; url=play-v24-40.html">',
    '<meta http-equiv="refresh" content="0; url=play-v24-40.html?v=24-232">',
    "crane meta redirect",
)
crane_index = replace_once(crane_index, 'location.replace("play-v24-40.html")', 'location.replace("play-v24-40.html?v=24-232")', "crane script redirect")
write_text(crane_index_path, crane_index)

hub_script_path = repo / "script-v24-201.js"
hub_script = hub_script_path.read_text(encoding="utf-8")
hub_script = replace_once(hub_script, 'window.location.href = "crane-game/?v=24-40";', 'window.location.href = "crane-game/?v=24-232";', "hub crane cache key")
write_text(hub_script_path, hub_script)

hub_style_path = repo / "style-v24-201.css"
hub_style = hub_style_path.read_text(encoding="utf-8")
if ".duckipedia-room-book-v232" in hub_style:
    fail("Duckipedia room book rules are already present")
hub_style += """

/* v24.232 — use the Duckipedia duck-book icon as the room's Book object. */
#roomBookImage.duckipedia-room-book-v232{
  inset:auto;
  left:4.3%;
  right:auto;
  top:auto;
  bottom:.4%;
  width:19%;
  height:11%;
  object-fit:contain;
  object-position:center;
  transform:none;
  filter:drop-shadow(0 3px 2px rgba(70,48,55,.18));
}
#roomBookImage.duckipedia-room-book-v232.on-shelf{
  left:73.2%;
  top:91.2%;
  bottom:auto;
  width:20.5%;
  height:11.7%;
  transform:none;
}
#roomBookImage.duckipedia-room-book-v232.on-dresser{
  left:1.8%;
  top:54.8%;
  bottom:auto;
  width:19%;
  height:11.7%;
  transform:none;
}
@media(max-width:600px){
  #roomBookImage.duckipedia-room-book-v232,
  #roomBookImage.duckipedia-room-book-v232.on-shelf,
  #roomBookImage.duckipedia-room-book-v232.on-dresser{
    left:70.2%;
    right:auto;
    top:auto;
    bottom:11.8%;
    width:20.5%;
    height:11.7%;
    transform:none;
  }
}
"""
write_text(hub_style_path, hub_style)

dq_index_path = repo / "duck-quest/index.html"
dq_index = dq_index_path.read_text(encoding="utf-8")
if f"?v={START_SLUG}" not in dq_index:
    fail("v24.229 Duck Quest cache keys were not found")
dq_index = dq_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
write_text(dq_index_path, dq_index)

root_index_path = repo / "index.html"
root_index = root_index_path.read_text(encoding="utf-8")
root_index = replace_once(
    root_index,
    '<link rel="stylesheet" href="style-v24-201.css?v=24-201" />',
    '<link rel="stylesheet" href="style-v24-201.css?v=24-232" />',
    "hub stylesheet cache key",
)
root_index = replace_once(
    root_index,
    '<img id="roomBookImage" class="stage-layer room-object book-room-object" src="assets/ui/book-room.webp" alt="" aria-hidden="true" loading="eager" decoding="async" fetchpriority="high" />',
    '<img id="roomBookImage" class="stage-layer room-object book-room-object duckipedia-room-book-v232" src="assets/ui/icons/duckipedia.webp" alt="" aria-hidden="true" loading="eager" decoding="async" fetchpriority="high" />',
    "hub Duckipedia room book",
)
root_index = replace_once(
    root_index,
    '<script src="script-v24-201.js?v=24-201"></script>',
    '<script src="script-v24-201.js?v=24-232"></script>',
    "hub script cache key",
)
root_index, meta_count = re.subn(
    r'(<meta\s+name="duck-habit-build"\s+content=")[^"]+("\s*/?>)',
    rf'\g<1>{VERSION}\g<2>',
    root_index,
    count=1,
)
if meta_count != 1:
    fail("root build meta tag was not found")
root_index, build_count = re.subn(
    r'const\s+DUCK_HUB_BUILD\s*=\s*"[^"]+";',
    f'const DUCK_HUB_BUILD = "{VERSION}";',
    root_index,
    count=1,
)
if build_count != 1:
    fail("DUCK_HUB_BUILD marker was not found")
root_index = root_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
root_index, worker_count = re.subn(
    r'\./sw-v24-\d+\.js\?v=24-\d+',
    f'./sw-v{VERSION_SLUG}.js?v={VERSION_SLUG}',
    root_index,
    count=1,
)
if worker_count != 1:
    fail("service-worker registration was not found")
write_text(root_index_path, root_index)
write_text(version_path, json.dumps({"version": VERSION}, indent=2) + "\n")

source_worker = repo / f"sw-v{START_SLUG}.js"
if not source_worker.is_file():
    fail(f"{source_worker.name} is missing")
worker = source_worker.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-229", "duck-habit-hub-app-v24-232")
worker = worker.replace("duck-habit-hub-runtime-v24-229", "duck-habit-hub-runtime-v24-232")
worker = worker.replace("./sw-v24-229.js", "./sw-v24-232.js")
worker = worker.replace("?v=24-229", "?v=24-232")
worker = worker.replace(
    "'./style-v24-201.css','./script-v24-201.js',",
    "'./style-v24-201.css?v=24-232','./script-v24-201.js?v=24-232',",
)
worker = worker.replace(
    "'./assets/ui/pink-coin.webp','./assets/ducks/Standard-duck.webp',",
    "'./assets/ui/pink-coin.webp','./assets/ui/icons/duckipedia.webp','./assets/ducks/Standard-duck.webp',",
)
worker = worker.replace(
    "'./memory-game/index.html','./sort-game/index.html','./crane-game/index.html','./crane-game/play-v24-40.html',",
    "'./memory-game/index.html','./sort-game/index.html','./crane-game/index.html?v=24-232','./crane-game/play-v24-40.html?v=24-232','./crane-game/style-v24-40.css?v=24-232','./crane-game/script-v24-40.js?v=24-232',",
)
write_text(repo / "sw-v24-232.js", worker)
write_text(repo / "sw.js", "importScripts('./sw-v24-232.js');\n")

notes = """Duckie Days v24.232 — Dash Rewards + Duckipedia Hub Book

- Reloads the newest shared save when Duckie Dash ends, then reliably awards the run's Pink Coins.
- Adds every collected Tiny Duck to duckCollectionCounts so duplicates and Duck Trophy totals increase correctly.
- Keeps Tiny Duck sightings and the Tiny Duck Stack / Pile milestone unlocks working with multi-duck runs.
- Shows plus signs for both awarded Pink Coins and Tiny Ducks on the results screen.
- Replaces the main Hub's room Book art with the green Duckipedia duck-book icon.
- Keeps the replacement book aligned with its tap target in default, shelf, dresser, and phone layouts.
- Leaves the approved Sibling Spat cutscene unchanged.
- Flips the actual battle opponent inward for both Miho-versus-Miko and Miko-versus-Miho.
- Locks Sibling Spat opponent sizing by height, so Miko no longer shrinks when switching between differently sized sprite canvases.
- Matches the siblings' apparent battle heights and baselines in both directions.
- Keeps normal enemy battles unaffected and removes the special classes before later encounters.
- Charges 10 Pink Coins for every Duck Crane attempt, whether it catches, slips, or misses.
- Successful crane catches add that exact duck to duckCollectionCounts, including duplicates and Duck Trophy progress.
- Removes the old 3-coin catch reward and 10-coin machine-clear bonus.
- Changes manual restocking to 50 Pink Coins.
- Automatically restocks a fresh set for free after all five prizes are collected.
- Uses the 50-coin Restock button only as an optional random reroll of the current prizes.
- Preserves the v24.229 Duckie Dash alignment, speed, backgrounds, Merchant sale, and Quest flow.
"""
write_text(repo / "V24.232-NOTES.txt", notes)
print(f"Installed Duckie Days v{VERSION} over v{current_version}.")

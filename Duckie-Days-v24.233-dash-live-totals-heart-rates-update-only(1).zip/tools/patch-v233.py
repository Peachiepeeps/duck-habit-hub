#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path


VERSION = "24.233"
VERSION_SLUG = "24-233"
START_VERSION = "24.232"
START_SLUG = "24-232"


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        fail(f"expected exactly one {label}; found {count}")
    return text.replace(old, new, 1)


repo = Path.cwd().resolve()
payload = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else fail("payload directory was not provided")
if not (payload / "tools/patch-v233.py").is_file():
    fail("payload file is missing: tools/patch-v233.py")

version_path = repo / "version.json"
if not version_path.is_file():
    fail("run this installer from the repository root (version.json is missing)")
try:
    current_version = str(json.loads(version_path.read_text(encoding="utf-8")).get("version", ""))
except Exception as error:
    fail(f"could not read version.json: {error}")
if current_version != START_VERSION:
    fail(f"v{VERSION} must be installed over v{START_VERSION}; found v{current_version or 'unknown'}")

game_path = repo / "duck-quest/js/game-v96.js"
game = game_path.read_text(encoding="utf-8")
for marker in [
    "window.DUCKIE_DASH_CORE='24.229-aligned-foreground';",
    "window.DUCKIE_DASH_REWARD_FIX='24.232-persist-coins-and-tiny-ducks';",
    "function awardDashRewardsV232(collectedCoins,collectedTiny,success){",
    "const specialKind=specialRoll<0.006?'time-gold':specialRoll<0.036?'time-pink':specialRoll<0.054?'wing':specialRoll<0.072?'bubble':null;",
    "const rewards=awardDashRewardsV232(dash.coins,dash.tiny,success);",
    "<br>Pink Coins +${rewards.coins}<br>Tiny Ducks +${rewards.tiny}<br>Score ${score}",
    "window.SIBLING_SPAT_BATTLE_FIX='24.230-inward-equal-height';",
]:
    if marker not in game:
        fail(f"expected v24.232 marker is missing: {marker}")

game = replace_once(
    game,
    "window.DUCKIE_DASH_REWARD_FIX='24.232-persist-coins-and-tiny-ducks';",
    "window.DUCKIE_DASH_REWARD_FIX='24.232-persist-coins-and-tiny-ducks';\n  window.DUCKIE_DASH_LIVE_REWARDS='24.233-results-total-refresh';",
    "Duckie Dash live reward marker",
)

game = replace_once(
    game,
    "const specialKind=specialRoll<0.006?'time-gold':specialRoll<0.036?'time-pink':specialRoll<0.054?'wing':specialRoll<0.072?'bubble':null;",
    "const specialKind=specialRoll<0.008?'time-gold':specialRoll<0.042?'time-pink':specialRoll<0.060?'wing':specialRoll<0.078?'bubble':null;",
    "slightly increased Heart refill rates",
)

reward_tail_old = """    if(tinyDucks>0){
      latest.tinyDuckSightings=Math.max(0,Number(latest.tinyDuckSightings)||0)+tinyDucks;
      addDashDuckCopyV232(latest,'tiny-duck',tinyDucks);
      if(latest.tinyDuckSightings>=4)addDashDuckCopyV232(latest,'tiny-duck-stack');
      if(latest.tinyDuckSightings>=100)addDashDuckCopyV232(latest,'pile-of-tiny-ducks');
    }
    hubSave=latest;
    return {coins:coinAward,tiny:tinyDucks};"""
reward_tail_new = """    let tinyOwned=Math.max(
      Array.isArray(latest.unlockedDucks)&&latest.unlockedDucks.includes('tiny-duck')?1:0,
      Math.floor(Number(latest.duckCollectionCounts?.['tiny-duck'])||0)
    );
    if(tinyDucks>0){
      latest.tinyDuckSightings=Math.max(0,Number(latest.tinyDuckSightings)||0)+tinyDucks;
      tinyOwned=addDashDuckCopyV232(latest,'tiny-duck',tinyDucks);
      if(latest.tinyDuckSightings>=4)addDashDuckCopyV232(latest,'tiny-duck-stack');
      if(latest.tinyDuckSightings>=100)addDashDuckCopyV232(latest,'pile-of-tiny-ducks');
    }
    hubSave=latest;
    return {coins:coinAward,tiny:tinyDucks,totalCoins:Math.floor(latest.coins),tinyOwned};"""
game = replace_once(game, reward_tail_old, reward_tail_new, "Duckie Dash returned reward totals")

game = replace_once(
    game,
    "    persistAll();\n    refreshFeatureBadges();",
    "    persistAll();\n    if(ui.coinCount)ui.coinCount.textContent=rewards.totalCoins.toLocaleString();\n    refreshFeatureBadges();",
    "immediate Duckie Dash visible total refresh",
)

game = replace_once(
    game,
    "<br>Pink Coins +${rewards.coins}<br>Tiny Ducks +${rewards.tiny}<br>Score ${score}",
    "<br>Pink Coins +${rewards.coins} · Total ${rewards.totalCoins.toLocaleString()}<br>Tiny Ducks +${rewards.tiny} · Owned ×${rewards.tinyOwned}<br>Score ${score}",
    "Duckie Dash result totals",
)
write_text(game_path, game)

crane_play_path = repo / "crane-game/play-v24-40.html"
crane_play = crane_play_path.read_text(encoding="utf-8")
crane_play = replace_once(crane_play, "style-v24-40.css?v=24-232", "style-v24-40.css?v=24-233", "crane style cache key")
crane_play = replace_once(crane_play, "script-v24-40.js?v=24-232", "script-v24-40.js?v=24-233", "crane script cache key")
write_text(crane_play_path, crane_play)

crane_index_path = repo / "crane-game/index.html"
crane_index = crane_index_path.read_text(encoding="utf-8")
if crane_index.count("play-v24-40.html?v=24-232") != 2:
    fail("expected two v24.232 crane redirects")
crane_index = crane_index.replace("play-v24-40.html?v=24-232", "play-v24-40.html?v=24-233")
write_text(crane_index_path, crane_index)

hub_script_path = repo / "script-v24-201.js"
hub_script = hub_script_path.read_text(encoding="utf-8")
hub_script = replace_once(hub_script, 'window.location.href = "crane-game/?v=24-232";', 'window.location.href = "crane-game/?v=24-233";', "hub crane cache key")
write_text(hub_script_path, hub_script)

dq_index_path = repo / "duck-quest/index.html"
dq_index = dq_index_path.read_text(encoding="utf-8")
if f"?v={START_SLUG}" not in dq_index:
    fail("v24.232 Duck Quest cache keys were not found")
dq_index = dq_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
write_text(dq_index_path, dq_index)

root_index_path = repo / "index.html"
root_index = root_index_path.read_text(encoding="utf-8")
root_index, meta_count = re.subn(
    r'(<meta\s+name="duck-habit-build"\s+content=")[^"]+("\s*/?>)',
    rf'\g<1>{VERSION}\g<2>',
    root_index,
    count=1,
)
if meta_count != 1:
    fail("root build meta tag was not found")
root_index, build_count = re.subn(
    r'const\s+DUCK_HUB_BUILD\s*=\s*"[^"]+";',
    f'const DUCK_HUB_BUILD = "{VERSION}";',
    root_index,
    count=1,
)
if build_count != 1:
    fail("DUCK_HUB_BUILD marker was not found")
if f"?v={START_SLUG}" not in root_index:
    fail("v24.232 Hub cache keys were not found")
root_index = root_index.replace(f"?v={START_SLUG}", f"?v={VERSION_SLUG}")
root_index, worker_count = re.subn(
    r'\./sw-v24-\d+\.js\?v=24-\d+',
    f'./sw-v{VERSION_SLUG}.js?v={VERSION_SLUG}',
    root_index,
    count=1,
)
if worker_count != 1:
    fail("service-worker registration was not found")
write_text(root_index_path, root_index)
write_text(version_path, json.dumps({"version": VERSION}, indent=2) + "\n")

source_worker = repo / f"sw-v{START_SLUG}.js"
if not source_worker.is_file():
    fail(f"{source_worker.name} is missing")
worker = source_worker.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-232", "duck-habit-hub-app-v24-233")
worker = worker.replace("duck-habit-hub-runtime-v24-232", "duck-habit-hub-runtime-v24-233")
worker = worker.replace("./sw-v24-232.js", "./sw-v24-233.js")
worker = worker.replace("?v=24-232", "?v=24-233")
write_text(repo / "sw-v24-233.js", worker)
write_text(repo / "sw.js", "importScripts('./sw-v24-233.js');\n")

notes = """Duckie Days v24.233 — Live Dash Totals + Heart Refill Rates

- Refreshes the visible Pink Coin total immediately when a Duckie Dash run ends.
- Shows both the amount earned and the new overall Pink Coin total on the results screen.
- Shows both Tiny Ducks collected and the new owned Tiny Duck quantity on the results screen.
- Keeps the in-run HUD updating collected Pink Coins and Tiny Ducks as each pickup is collected.
- Slightly raises Pink Heart Refill opportunities from 3.0% to 3.4%.
- Slightly raises Gold Heart Refill opportunities from 0.6% to 0.8%.
- Preserves the Angel Wing and Bubble rates at 1.8% each.
- Preserves v24.232 Dash reward persistence, Duckipedia Hub book, Sibling Spat fixes, crane rewards, Merchant sale, Quest flow, Dash speed, alignment, and backgrounds.
"""
write_text(repo / "V24.233-NOTES.txt", notes)
print(f"Installed Duckie Days v{VERSION} over v{current_version}.")

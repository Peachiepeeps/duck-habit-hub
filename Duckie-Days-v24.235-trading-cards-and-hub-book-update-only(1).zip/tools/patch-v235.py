#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys

ROOT=Path.cwd()
PAYLOAD=Path(__file__).resolve().parents[1]
OLD="24.233"
NEW="24.235"

def read(rel): return (ROOT/rel).read_text(encoding="utf-8")
def write(rel,text):
    path=ROOT/rel; path.parent.mkdir(parents=True,exist_ok=True); path.write_text(text,encoding="utf-8")
def once(text,old,new,label):
    if new in text: return text
    count=text.count(old)
    if count!=1: raise RuntimeError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old,new,1)
def bump(text): return text.replace("24.233","24.235").replace("24-233","24-235")
def copy_payload():
    for src in PAYLOAD.rglob("*"):
        if not src.is_file() or "tools" in src.relative_to(PAYLOAD).parts: continue
        dst=ROOT/src.relative_to(PAYLOAD); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

def patch_root_html():
    t=read("index.html")
    t=bump(t)
    t=once(t,'  <link rel="stylesheet" href="style-v24-201.css?v=24-235" />','  <link rel="stylesheet" href="style-v24-201.css?v=24-235" />\n  <link rel="stylesheet" href="trading-cards-v235.css?v=24-235" />',"root card css")
    t=once(t,'  <script src="script-v24-201.js?v=24-235"></script>','  <script src="trading-cards-v235.js?v=24-235"></script>\n  <script src="script-v24-201.js?v=24-235"></script>',"root shared cards")
    t=once(t,'  <script src="hub-exp-candy-use-v215.js?v=24-235"></script>','  <script src="hub-exp-candy-use-v215.js?v=24-235"></script>\n  <script src="trading-cards-ui-v235.js?v=24-235"></script>',"root card ui")
    write("index.html",t)
    script=read("script-v24-201.js").replace('window.location.href = "crane-game/?v=24-233";','window.location.href = "crane-game/?v=24-235";')
    write("script-v24-201.js",script)

def patch_quest():
    idx=bump(read("duck-quest/index.html"))
    idx=once(idx,'  <script src="js/game-v96.js?v=24-235"></script>','  <script src="../trading-cards-v235.js?v=24-235"></script>\n  <script src="js/game-v96.js?v=24-235"></script>',"quest shared cards")
    idx=once(idx,'  <script src="js/dash-background-fix-v226.js?v=24-235"></script>','  <script src="js/dash-background-fix-v226.js?v=24-235"></script>\n  <script src="js/trading-card-drops-v235.js?v=24-235"></script>',"quest card drops")
    write("duck-quest/index.html",idx)
    rel="duck-quest/js/game-v96.js"; t=read(rel)
    t=once(t,"  const DASH_COST=3;","  const DASH_RUN_OPTIONS={30:{duration:30,cost:3},60:{duration:60,cost:5}};","dash options")
    t=once(t,"  const DASH_BASE_SPEED=.48;","  const DASH_BASE_SPEED=.54;","dash base speed")
    old='<div id="dashOverlay" class="dash-overlay"><div class="dash-overlay-card"><strong>Ready?</strong><small>Use 3 Jump Tokens to run. A rare Free Run is used first if you have one.</small><button id="dashStart" class="pixel-button primary" type="button">Start Duckie Dash</button></div></div>'
    new='<div id="dashOverlay" class="dash-overlay"><div class="dash-overlay-card"><strong>Ready?</strong><label class="dash-duration-label-v235">Run Length<select id="dashRunDurationV235"><option value="30">30 Seconds · 3 Tokens</option><option value="60">60 Seconds · 5 Tokens</option></select></label><small>A rare Free Run is used first if you have one.</small><button id="dashStart" class="pixel-button primary" type="button">Start Duckie Dash</button></div></div>'
    t=once(t,old,new,"initial dash dropdown")
    old="  function renderDashReadyOverlay(){const ov=document.querySelector('#dashOverlay');if(!ov)return;ov.classList.remove('hidden');ov.innerHTML=`<div class=\"dash-overlay-card\"><strong>Ready?</strong><small>Use 3 Jump Tokens to run. A rare Free Run is used first if you have one.</small><button id=\"dashStart\" class=\"pixel-button primary\" type=\"button\">Start Duckie Dash</button></div>`;ov.querySelector('#dashStart')?.addEventListener('click',e=>{e.stopPropagation();startDash()});}"
    new="  function selectedDashRunV235(){ensureExpansionSave();const select=document.querySelector('#dashRunDurationV235');const duration=Number(select?.value||questSave.dash.runDuration||30)===60?60:30;questSave.dash.runDuration=duration;return DASH_RUN_OPTIONS[duration];}\n  function renderDashReadyOverlay(){const ov=document.querySelector('#dashOverlay');if(!ov)return;ensureExpansionSave();const duration=Number(questSave.dash.runDuration)===60?60:30;ov.classList.remove('hidden');ov.innerHTML=`<div class=\"dash-overlay-card\"><strong>Ready?</strong><label class=\"dash-duration-label-v235\">Run Length<select id=\"dashRunDurationV235\"><option value=\"30\" ${duration===30?'selected':''}>30 Seconds · 3 Tokens</option><option value=\"60\" ${duration===60?'selected':''}>60 Seconds · 5 Tokens</option></select></label><small>A rare Free Run is used first if you have one.</small><button id=\"dashStart\" class=\"pixel-button primary\" type=\"button\">Start Duckie Dash</button></div>`;ov.querySelector('#dashRunDurationV235')?.addEventListener('change',()=>{questSave.dash.runDuration=Number(ov.querySelector('#dashRunDurationV235').value)===60?60:30;persistAll()});ov.querySelector('#dashStart')?.addEventListener('click',e=>{e.stopPropagation();startDash()});}"
    t=once(t,old,new,"ready dash dropdown")
    t=t.replace("dash.elapsed+=dt*(dash.speedBoost>0?1.4:1);","dash.elapsed+=dt;")
    t=t.replace("DASH_BASE_SPEED*(dash.speedBoost>0?1.4:1)","DASH_BASE_SPEED*(dash.speedBoost>0?1.55:1)")
    t=t.replace("dash.duration=(Number(dash.duration)||30)+10;runner?.classList.add('hit');syncDashDriverV208(true);showDashPowerPopV217('+10s')","dash.elapsed=Math.min(Number(dash.duration)||30,dash.elapsed+10);runner?.classList.add('hit');syncDashDriverV208(true);showDashPowerPopV217('-10s')")
    old="  function startDash(){if(dash.running)return;ensureExpansionSave();if(questSave.dash.freeRuns>0)questSave.dash.freeRuns--;else if(!useInventory('jump-token',DASH_COST)){setMessage('Duckie Dash costs 3 Jump Tokens.');refreshFeatureBadges();return;}clearDashObjects();Object.assign(dash,{running:true,last:0,elapsed:0,duration:30,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0,speedBoost:0,bubble:0,bgOffset:0});document.querySelector('#dashScreen')?.classList.add('dash-run-stage-v193');document.body.classList.add('dash-run-stage-v193-active');const ov=document.querySelector('#dashOverlay');ov?.classList.add('hidden');persistAll();refreshFeatureBadges();resetDashPreview();dash.raf=requestAnimationFrame(dashFrame)}"
    new="  function startDash(){if(dash.running)return;ensureExpansionSave();const run=selectedDashRunV235();if(questSave.dash.freeRuns>0)questSave.dash.freeRuns--;else if(!useInventory('jump-token',run.cost)){setMessage(`Duckie Dash costs ${run.cost} Jump Tokens for ${run.duration} seconds.`);refreshFeatureBadges();return;}clearDashObjects();Object.assign(dash,{running:true,last:0,elapsed:0,duration:run.duration,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0,speedBoost:0,bubble:0,bgOffset:0});document.querySelector('#dashScreen')?.classList.add('dash-run-stage-v193');document.body.classList.add('dash-run-stage-v193-active');const ov=document.querySelector('#dashOverlay');ov?.classList.add('hidden');persistAll();refreshFeatureBadges();resetDashPreview();dash.raf=requestAnimationFrame(dashFrame)}"
    t=once(t,old,new,"dash start options")
    t=once(t,'  if(rewards.charmTreasureBonus) textParts.push("Treasure Charm bonus!");','  if(rewards.charmTreasureBonus) textParts.push("Treasure Charm bonus!");\n  if(rewards.tradingCardResults?.length) textParts.push(rewards.tradingCardResults.map(result=>`${result.card.name} Card${result.isNew?" ✨":""}`).join(", "));',"quest reward card text")
    write(rel,t)
    css=read("duck-quest/css/style-v82.css")+'\n/* v24.235 faster configurable Duckie Dash */\n.dash-home-cost,.dash-title-cost{display:none!important}.dash-duration-label-v235{display:grid;gap:6px;font-weight:900;color:#70495d}.dash-duration-label-v235 select{width:100%;border:2px solid #db8eb0;border-radius:10px;background:#fff;padding:8px;color:#654356;font:inherit;font-weight:800}\n'
    write("duck-quest/css/style-v82.css",css)

def patch_memory():
    t=read("memory-game/index.html")
    t=t.replace("style-v24-42.css'","style-v24-42.css?v=24-235'").replace("script-v24-44.js'","script-v24-44.js?v=24-235'")
    t=once(t,"  <link rel='stylesheet' href='style-v24-42.css?v=24-235' />","  <link rel='stylesheet' href='style-v24-42.css?v=24-235' />\n  <link rel='stylesheet' href='../trading-cards-v235.css?v=24-235' />","memory card css")
    t=once(t,"  <script src='script-v24-44.js?v=24-235'></script>","  <script src='../trading-cards-v235.js?v=24-235'></script>\n  <script src='script-v24-44.js?v=24-235'></script>\n  <script src='trading-card-memory-v235.js?v=24-235'></script>","memory scripts")
    write("memory-game/index.html",t)

def patch_crane():
    idx=bump(read("crane-game/index.html")); write("crane-game/index.html",idx)
    html=bump(read("crane-game/play-v24-40.html"))
    html=once(html,'  <link rel="stylesheet" href="style-v24-40.css?v=24-235">','  <link rel="stylesheet" href="style-v24-40.css?v=24-235">\n  <link rel="stylesheet" href="../trading-cards-v235.css?v=24-235">',"crane card css")
    html=once(html,'  <script src="script-v24-40.js?v=24-235"></script>','  <script src="../trading-cards-v235.js?v=24-235"></script>\n  <script src="script-v24-40.js?v=24-235"></script>',"crane scripts")
    write("crane-game/play-v24-40.html",html)
    rel="crane-game/script-v24-40.js"; t=read(rel)
    anchor="function pulseCoinBox(){"
    addition='function awardCardPack(){\n  const data=loadHubSave();\n  const count=window.DuckieTradingCards?.grantPack(data,1)||0;\n  saveHubSave(data);\n  return count;\n}\n\n'
    t=once(t,anchor,addition+anchor,"crane award pack")
    old='''  prizes = lanes.map((x,i)=>{\n    const duckId = ids[i];\n    const duck = DUCK_CATALOG[duckId];\n    return {\n      uid:`${Date.now()}-${i}-${Math.random()}`,\n      duckId,\n      name:duck.name,\n      image:duck.image,\n      x:clamp(x+(Math.random()-.5)*.022,.390,.790),\n      y:clamp(yRows[i]+(Math.random()-.5)*.018,.605,.680),\n      rotation:(Math.random()-.5)*12\n    };\n  });'''
    new=old+'''\n\n  if(window.DuckieTradingCards && Math.random()<.03){\n    const index=Math.floor(Math.random()*prizes.length);\n    prizes[index]={...prizes[index],kind:"card-pack",duckId:null,name:"Card Pack",image:"../assets/trading-cards/card-pack-unopened.png"};\n  }'''
    t=once(t,old,new,"crane pack restock")
    old='''    const valid = saved.prizes.filter(p =>\n      p &&\n      typeof p.duckId === "string" &&\n      unlocked.has(p.duckId) &&\n      DUCK_CATALOG[p.duckId]\n    ).map(p => ({\n      ...p,\n      name:DUCK_CATALOG[p.duckId].name,\n      image:DUCK_CATALOG[p.duckId].image,\n      x:clamp(Number(p.x)||.50,.390,.790),\n      y:clamp(Number(p.y)||.64,.605,.685)\n    }));'''
    new='''    const valid = saved.prizes.filter(p =>\n      p && ((p.kind==="card-pack" && window.DuckieTradingCards) ||\n      (typeof p.duckId === "string" && unlocked.has(p.duckId) && DUCK_CATALOG[p.duckId]))\n    ).map(p => ({\n      ...p,\n      name:p.kind==="card-pack"?"Card Pack":DUCK_CATALOG[p.duckId].name,\n      image:p.kind==="card-pack"?"../assets/trading-cards/card-pack-unopened.png":DUCK_CATALOG[p.duckId].image,\n      x:clamp(Number(p.x)||.50,.390,.790),\n      y:clamp(Number(p.y)||.64,.605,.685)\n    }));'''
    t=once(t,old,new,"crane load packs")
    t=once(t,'    img.className = "prize";','    img.className = `prize${p.kind==="card-pack"?" crane-pack-prize":""}`;',"crane pack class")
    old='''  winRewardText.textContent = `Duck collected! Owned ×${Math.max(1,Number(owned)||1)}`;\n  winText.textContent = machineCleared\n    ? `Machine cleared! A fresh set of ducks will be restocked for free. ♡`\n    : `${prize.name} was added to your collection. ♡`;'''
    new='''  winRewardText.textContent = prize.kind==="card-pack" ? `Unopened packs ×${Math.max(1,Number(owned)||1)}` : `Duck collected! Owned ×${Math.max(1,Number(owned)||1)}`;\n  winText.textContent = prize.kind==="card-pack"\n    ? `A Card Pack was added to Trading Cards in Duckipedia! ♡`\n    : machineCleared\n      ? `Machine cleared! A fresh set of ducks will be restocked for free. ♡`\n      : `${prize.name} was added to your collection. ♡`;'''
    t=once(t,old,new,"crane pack toast")
    t=once(t,"  const owned = awardDuckCopy(target.duckId);","  const owned = target.kind===\"card-pack\" ? awardCardPack() : awardDuckCopy(target.duckId);","crane pack award")
    write(rel,t)

def patch_worker_and_version():
    src=ROOT/"sw-v24-233.js"; dst=ROOT/"sw-v24-235.js"; t=src.read_text(encoding="utf-8").replace("24-233","24-235")
    insert="""\n  './trading-cards-v235.css?v=24-235','./trading-cards-v235.js?v=24-235','./trading-cards-ui-v235.js?v=24-235',\n  './assets/trading-cards/card-common.png','./assets/trading-cards/card-uncommon.png','./assets/trading-cards/card-rare.png','./assets/trading-cards/card-back.png','./assets/trading-cards/card-pack-unopened.png','./assets/trading-cards/card-pack-ripped.png','./assets/trading-cards/card-pack-torn-top.png',\n  './memory-game/trading-card-memory-v235.js?v=24-235','./duck-quest/js/trading-card-drops-v235.js?v=24-235',"""
    t=once(t,"const APP_SHELL = [", "const APP_SHELL = ["+insert,"worker card precache")
    dst.write_text(t,encoding="utf-8")
    write("sw.js", "importScripts('./sw-v24-235.js?v=24-235');\n")
    write("version.json",json.dumps({"version":"24.235"},indent=2)+"\n")

def main():
    required=["index.html","script-v24-201.js","duck-quest/js/game-v96.js","memory-game/script-v24-44.js","crane-game/script-v24-40.js","sw-v24-233.js"]
    missing=[p for p in required if not (ROOT/p).exists()]
    if missing: raise RuntimeError("Missing expected v24.233 files: "+", ".join(missing))
    copy_payload(); patch_root_html(); patch_quest(); patch_memory(); patch_crane(); patch_worker_and_version()
    write("UPDATE-v24.235.txt","Duckie Days v24.235\n\nAdds the first 65-card Trading Card collection, binder, favorites, missing-card view, animated three-card packs, a free Starter Pack, Duck Quest drops, Daily Shop cards, Memory Match card pairs, Crane packs, and independent Gacha pack bonuses. Also includes the faster 30/60-second Duckie Dash choices and moves the Hub book to the true bottom-right corner.\n")
    print("Duckie Days v24.235 installed successfully.")

if __name__=="__main__":
    try: main()
    except Exception as exc:
        print(f"ERROR: {exc}",file=sys.stderr); sys.exit(1)

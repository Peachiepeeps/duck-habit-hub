#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys

ROOT=Path.cwd()
PAYLOAD=Path(__file__).resolve().parents[1]

def read(rel): return (ROOT/rel).read_text(encoding="utf-8")
def write(rel,text):
    path=ROOT/rel; path.parent.mkdir(parents=True,exist_ok=True); path.write_text(text,encoding="utf-8")
def once(text,old,new,label):
    if new in text: return text
    count=text.count(old)
    if count!=1: raise RuntimeError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old,new,1)
def bump(text): return text.replace("24.235","24.236").replace("24-235","24-236")
def copy_payload():
    for src in PAYLOAD.rglob("*"):
        if not src.is_file() or "tools" in src.relative_to(PAYLOAD).parts: continue
        dst=ROOT/src.relative_to(PAYLOAD); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

def patch_html():
    root=bump(read("index.html"))
    root=root.replace("trading-cards-v235.css","trading-cards-v236.css")
    root=root.replace("trading-cards-ui-v235.js","trading-cards-ui-v236.js")
    write("index.html",root)

    memory=bump(read("memory-game/index.html")).replace("../trading-cards-v235.css","../trading-cards-v236.css")
    write("memory-game/index.html",memory)
    crane=bump(read("crane-game/play-v24-40.html")).replace("../trading-cards-v235.css","../trading-cards-v236.css")
    write("crane-game/play-v24-40.html",crane)
    write("crane-game/index.html",bump(read("crane-game/index.html")))
    write("duck-quest/index.html",bump(read("duck-quest/index.html")))

    script=read("script-v24-201.js").replace('window.location.href = "crane-game/?v=24-235";','window.location.href = "crane-game/?v=24-236";')
    write("script-v24-201.js",script)

def patch_worker():
    src=ROOT/"sw-v24-235.js"
    if not src.exists(): raise RuntimeError("sw-v24-235.js is missing; install v24.235 first")
    t=bump(src.read_text(encoding="utf-8"))
    t=t.replace("trading-cards-v235.css","trading-cards-v236.css")
    t=t.replace("trading-cards-ui-v235.js","trading-cards-ui-v236.js")
    write("sw-v24-236.js",t)
    write("sw.js","importScripts('./sw-v24-236.js?v=24-236');\n")
    write("version.json",json.dumps({"version":"24.236"},indent=2)+"\n")

def main():
    required=["index.html","trading-cards-v235.js","trading-cards-v235.css","trading-cards-ui-v235.js","memory-game/index.html","crane-game/play-v24-40.html","sw-v24-235.js"]
    missing=[p for p in required if not (ROOT/p).exists()]
    if missing: raise RuntimeError("Missing expected v24.235 files: "+", ".join(missing))
    current=json.loads(read("version.json")).get("version")
    if str(current)!="24.235": raise RuntimeError(f"Expected Duckie Days v24.235, found {current!r}")
    copy_payload();patch_html();patch_worker()
    write("UPDATE-v24.236.txt","Duckie Days v24.236\n\nFixes Trading Card artwork and missing-card silhouettes so they render visibly above the opaque card templates. Expands Card Pack opening into an interactive sequence: Open a Pack, pack appears, click or swipe to rip, pack opens, cards rise into view, then tap each card to reveal it. Packs are consumed only when the rip begins.\n")
    print("Duckie Days v24.236 installed successfully.")

if __name__=="__main__":
    try: main()
    except Exception as exc:
        print(f"ERROR: {exc}",file=sys.stderr);sys.exit(1)

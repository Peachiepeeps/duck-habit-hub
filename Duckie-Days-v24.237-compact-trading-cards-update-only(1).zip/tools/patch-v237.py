#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys

ROOT=Path.cwd()
PAYLOAD=Path(__file__).resolve().parents[1]

def read(rel): return (ROOT/rel).read_text(encoding="utf-8")
def write(rel,text):
    path=ROOT/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding="utf-8")
def bump(text): return text.replace("24.236","24.237").replace("24-236","24-237")
def copy_payload():
    for src in PAYLOAD.rglob("*"):
        if not src.is_file() or "tools" in src.relative_to(PAYLOAD).parts: continue
        dst=ROOT/src.relative_to(PAYLOAD);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)

def patch_html():
    root=bump(read("index.html")).replace("trading-cards-v236.css","trading-cards-v237.css")
    write("index.html",root)
    memory=bump(read("memory-game/index.html")).replace("../trading-cards-v236.css","../trading-cards-v237.css")
    write("memory-game/index.html",memory)
    crane=bump(read("crane-game/play-v24-40.html")).replace("../trading-cards-v236.css","../trading-cards-v237.css")
    write("crane-game/play-v24-40.html",crane)
    write("crane-game/index.html",bump(read("crane-game/index.html")))
    write("duck-quest/index.html",bump(read("duck-quest/index.html")))
    script=read("script-v24-201.js").replace('window.location.href = "crane-game/?v=24-236";','window.location.href = "crane-game/?v=24-237";')
    write("script-v24-201.js",script)

def patch_worker():
    src=ROOT/"sw-v24-236.js"
    if not src.exists(): raise RuntimeError("sw-v24-236.js is missing; install v24.236 first")
    worker=bump(src.read_text(encoding="utf-8")).replace("trading-cards-v236.css","trading-cards-v237.css")
    write("sw-v24-237.js",worker)
    write("sw.js","importScripts('./sw-v24-237.js?v=24-237');\n")
    write("version.json",json.dumps({"version":"24.237"},indent=2)+"\n")

def main():
    required=["index.html","trading-cards-v235.js","trading-cards-v236.css","trading-cards-ui-v236.js","memory-game/index.html","crane-game/play-v24-40.html","sw-v24-236.js"]
    missing=[p for p in required if not (ROOT/p).exists()]
    if missing: raise RuntimeError("Missing expected v24.236 files: "+", ".join(missing))
    current=json.loads(read("version.json")).get("version")
    if str(current)!="24.236": raise RuntimeError(f"Expected Duckie Days v24.236, found {current!r}")
    copy_payload();patch_html();patch_worker()
    write("UPDATE-v24.237.txt","Duckie Days v24.237\n\nCompacts the mobile Trading Cards collection: four card thumbnails per phone row (about half their previous width), six on tablets, and eight on wide screens. Tapped card details open at a larger readable size. The Duckipedia tabs now remain on one line, and the Card Pack image, count, and Open Pack button share one condensed horizontal row. The collection count, rarity filter, and Show Missing control are also tightened into one row on phones.\n")
    print("Duckie Days v24.237 installed successfully.")

if __name__=="__main__":
    try:main()
    except Exception as exc:
        print(f"ERROR: {exc}",file=sys.stderr);sys.exit(1)

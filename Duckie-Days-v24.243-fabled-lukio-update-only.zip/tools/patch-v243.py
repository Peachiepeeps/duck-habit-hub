from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.243'
TARGET_QUERY = '24-243'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')

def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def replace_once(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f'{label}: expected exactly one match, found {n}')
    return text.replace(old, new, 1)

def replace_if(text, old, new):
    return text.replace(old, new) if old in text else text

def bump_238(text):
    return text.replace('24.238', TARGET_VERSION).replace('24-238', TARGET_QUERY)

# These giant v239-v242 workflows were rejected by GitHub before executing, so
# v24.238 is the expected live build. The alternate values allow recovery if a
# user manually applied part of a previous attempt.
required = ['index.html','version.json','script-v24-201.js','duck-quest/index.html','memory-game/index.html','crane-game/index.html','crane-game/play-v24-40.html']
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))
current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.238','24.239','24.240','24.241','24.242'}:
    raise RuntimeError(f'Expected Duckie Days v24.238-v24.242, found {current!r}')

# -------- Assets --------
for name in ['F-acorn-mouse.png','F-flower.png','F-bee.png','F-slime-kitty.png','F-mimic.png']:
    copy(f'assets/fabled/{name}', f'duck-quest/assets/trading-cards/fabled/{name}')

lukio_names = [
    'Lukio-duck.png','Lukio-idle-1.png','Lukio-idle-2.png','Lukio-wink.png','Pixel-heart.png',
    'Miko-Lukio-Booties.png','Miko-Lukio-Hair-Streak.png','Miko-Lukio-Shorts.png','Miko-Lukio-Socks.png',
    'Miko-Lukio-hoodie-shop.png','Miko-Lukio-hoodie.png','Miko-Lukio-reference.png','Miko-lukio-sleeve.png'
]
for name in lukio_names:
    copy(f'assets/lukio/{name}', f'duck-quest/assets/love-interests/lukio/{name}')

# Miko's Closet reads from assets/miko/.
for name in [
    'Miko-Lukio-Booties.png','Miko-Lukio-Hair-Streak.png','Miko-Lukio-Shorts.png','Miko-Lukio-Socks.png',
    'Miko-Lukio-hoodie-shop.png','Miko-Lukio-hoodie.png','Miko-lukio-sleeve.png'
]:
    copy(f'assets/lukio/{name}', f'assets/miko/{name}')

# -------- Trading Card core: Fabled + Lukio Rare --------
core_candidates = ['trading-cards-v242.js','trading-cards-v241.js','trading-cards-v240.js','trading-cards-v239.js','trading-cards-v235.js']
core_source = next((p for p in core_candidates if (ROOT / p).exists()), None)
if not core_source:
    raise RuntimeError('Could not find the Trading Card core.')
tc = read(core_source)

# Keep only the four active rarity tiers.
tc = replace_if(tc, 'const order={common:1,uncommon:2,rare:3,ultra:4,fabled:5};', 'const order={common:1,uncommon:2,rare:3,fabled:4};')
tc = replace_if(tc, 'const labels={common:"Common",uncommon:"Uncommon",rare:"Rare",ultra:"Ultra Rare",fabled:"Fabled"};', 'const labels={common:"Common",uncommon:"Uncommon",rare:"Rare",fabled:"Fabled"};')
tc = replace_if(tc, 'const templates={common:"card-common.png",uncommon:"card-uncommon.png",rare:"card-rare.png",ultra:"card-rare.png",fabled:"card-rare.png"};', 'const templates={common:"card-common.png",uncommon:"card-uncommon.png",rare:"card-rare.png",fabled:"card-rare.png"};')

if 'const fabled=[' not in tc:
    fabled = '''  const fabled=[
    ["slime-kitty","Slime Kitty","trading-cards/fabled/F-slime-kitty.png","Fabled"],
    ["acorn-mouse","Acorn Mouse","trading-cards/fabled/F-acorn-mouse.png","Fabled"],
    ["bee","Bee","trading-cards/fabled/F-bee.png","Fabled"],
    ["flower","Flower","trading-cards/fabled/F-flower.png","Fabled"],
    ["mimic","Mimic","trading-cards/fabled/F-mimic.png","Fabled"]
  ];
'''
    tc = replace_once(tc, '  const cards=[];', fabled + '  const cards=[];', 'insert Fabled card data')

if 'fabled.forEach(' not in tc:
    shiny_line = re.search(r'  shiny\.forEach\([^\n]+\);\n', tc)
    if not shiny_line:
        raise RuntimeError('Could not find shiny card builder.')
    addition = '  fabled.forEach((x,i)=>cards.push({id:`f-${x[0]}`,name:x[1],art:x[2],rarity:"fabled",number:`F-${String(i+1).padStart(3,"0")}`,category:x[3],hint:"Find this Fabled card in a Card Pack or as a very rare Daily Shop offer."}));\n'
    tc = tc[:shiny_line.end()] + addition + tc[shiny_line.end():]

# Lukio uses idle-1 as art and the standard Rare template, just like other Rare cards.
if 'r-love-lukio' not in tc:
    anchor = '  const byId=Object.fromEntries(cards.map(card=>[card.id,card]));'
    lukio_card = '  cards.push({id:"r-love-lukio",characterId:"lukio",name:"Lukio",art:"love-interests/lukio/Lukio-idle-1.png",rarity:"rare",number:"R-031",category:"Miko Love Interest",hint:"Meet Lukio while exploring Duck Quest as Miko."});\n'
    tc = replace_once(tc, anchor, lukio_card + anchor, 'insert Lukio Rare card')
else:
    tc = re.sub(r'(id:"r-love-lukio".*?art:")[^"]+(".*?rarity:")([^"]+)(")', r'\1love-interests/lukio/Lukio-idle-1.png\2rare\4', tc, count=1)

# Very rare Fabled chance in the third pack slot.
tc = replace_if(tc,
    'function rollRarity(weights={common:.8,uncommon:.18,rare:.02}){let roll=Math.random(),last="common";for(const [rarity,chance] of Object.entries(weights)){last=rarity;roll-=chance;if(roll<=0)return rarity;}return last;}',
    'function rollRarity(weights={common:.795,uncommon:.18,rare:.02,fabled:.005}){let roll=Math.random(),last="common";for(const [rarity,chance] of Object.entries(weights)){last=rarity;roll-=chance;if(roll<=0)return rarity;}return last;}'
)
tc = replace_if(tc,
    'function rollPack(){return [rollCard("common"),rollCard("common"),rollCard(rollRarity({common:.70,uncommon:.25,rare:.05}))];}',
    'function rollPack(){return [rollCard("common"),rollCard("common"),rollCard(rollRarity({common:.695,uncommon:.25,rare:.05,fabled:.005}))];}'
)
tc = tc.replace('card.rarity==="rare"||card.rarity==="ultra"||card.rarity==="fabled"', 'card.rarity==="rare"||card.rarity==="fabled"')
write('trading-cards-v243.js', tc)

# -------- Trading Card UI --------
ui_candidates = ['trading-cards-ui-v242.js','trading-cards-ui-v241.js','trading-cards-ui-v240.js','trading-cards-ui-v239.js','trading-cards-ui-v238.js','trading-cards-ui-v236.js']
ui_source = next((p for p in ui_candidates if (ROOT / p).exists()), None)
if not ui_source:
    raise RuntimeError('Could not find Trading Card UI.')
ui = read(ui_source)
ui = ui.replace('<option value="ultra">Ultra Rare</option>', '')
ui = ui.replace('const prices={common:40,uncommon:100,rare:300,ultra:500,fabled:750};', 'const prices={common:40,uncommon:100,rare:300,fabled:750};')
ui = ui.replace('TC.rollRarity({common:.58,uncommon:.37,rare:.05})', 'TC.rollRarity({common:.575,uncommon:.37,rare:.05,fabled:.005})')
ui = re.sub(r'window\.DUCKIE_TRADING_CARD_UI_BUILD="[^"]+";', 'window.DUCKIE_TRADING_CARD_UI_BUILD="24.243";', ui)
write('trading-cards-ui-v243.js', ui)

# -------- Trading Card CSS: extend collection area farther down --------
css_candidates = ['trading-cards-v242.css','trading-cards-v241.css','trading-cards-v240.css','trading-cards-v239.css','trading-cards-v238.css','trading-cards-v237.css']
css_source = next((p for p in css_candidates if (ROOT / p).exists()), None)
if not css_source:
    raise RuntimeError('Could not find Trading Card CSS.')
css = read(css_source)
css += '''\n\n/* v24.243 — use more of the lower Duckipedia space */
.tc-grid{max-height:min(66vh,680px)!important;padding-bottom:22px!important}
@media(max-width:560px){.tc-grid{max-height:58vh!important;padding-bottom:18px!important}}
'''
write('trading-cards-v243.css', css)

# -------- Miko Closet: add the Lukio set with the supplied layer order --------
hub = read('script-v24-201.js')
if '"lukio-hoodie"' not in hub:
    # Thumbnail crop bounds, using the transparent pixel bounds of the supplied 1080x1920 canvases.
    if 'const MIKO_THUMB_BOUNDS = {' in hub:
        hub = hub.replace('const MIKO_THUMB_BOUNDS = {', '''const MIKO_THUMB_BOUNDS = {
  "Miko-Lukio-Hair-Streak.png": [426,878,551,1049],
  "Miko-Lukio-hoodie-shop.png": [371,1189,739,1530],
  "Miko-Lukio-Shorts.png": [407,1403,660,1551],
  "Miko-Lukio-Socks.png": [385,1647,686,1796],
  "Miko-Lukio-Booties.png": [379,1723,691,1812],''', 1)

    asset_anchor = 'const MIKO_ASSETS = {'
    if asset_anchor not in hub:
        raise RuntimeError('Could not find MIKO_ASSETS in script-v24-201.js')
    asset_entries = '''const MIKO_ASSETS = {
  "lukio-hair-streak": { label: "Lukio Set · Hair Streak", file: "Miko-Lukio-Hair-Streak.png", z: 49 },
  "lukio-hoodie": { label: "Lukio Set · Hoodie", file: "Miko-Lukio-hoodie.png", previewFile: "Miko-Lukio-hoodie-shop.png", z: 34 },
  "lukio-sleeve": { label: "Lukio Set · Sleeve", file: "Miko-lukio-sleeve.png", z: 37 },
  "lukio-shorts": { label: "Lukio Set · Shorts", file: "Miko-Lukio-Shorts.png", z: 31 },
  "lukio-socks": { label: "Lukio Set · Socks", file: "Miko-Lukio-Socks.png", z: 29 },
  "lukio-booties": { label: "Lukio Set · Booties", file: "Miko-Lukio-Booties.png", z: 39 },'''
    hub = hub.replace(asset_anchor, asset_entries, 1)

    hub = hub.replace('options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer"]', 'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie"]')
    hub = hub.replace('options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts"]', 'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts"]')
    hub = hub.replace('options: ["socks", "socks-garter"]', 'options: ["socks", "socks-garter", "lukio-socks"]')
    hub = hub.replace('options: ["shoes-loafer", "shoes-fancy-loafers"]', 'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties"]')
    hub = hub.replace('options: ["headband", "hairpins-black"]', 'options: ["headband", "hairpins-black", "lukio-hair-streak"]')

    hub = hub.replace('[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer"].includes(outer)', '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie"].includes(outer)')
    hub = hub.replace('["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts"].includes(incoming.bottom)', '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts"].includes(incoming.bottom)')
    hub = hub.replace('["socks", "socks-garter"].includes(incoming.socks)', '["socks", "socks-garter", "lukio-socks"].includes(incoming.socks)')
    hub = hub.replace('[null, "shoes-loafer", "shoes-fancy-loafers"].includes(incoming.shoes)', '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties"].includes(incoming.shoes)')

    sleeve_anchor = '  else if (outfit.outer === "outer-black-blazer") ids.push("outer-black-blazer-arm");'
    if sleeve_anchor in hub:
        hub = hub.replace(sleeve_anchor, sleeve_anchor + '\n  else if (outfit.outer === "lukio-hoodie") ids.push("lukio-sleeve");', 1)
    else:
        raise RuntimeError('Could not find Miko sleeve-layer anchor.')
write('script-v24-201.js', hub)

# -------- Lukio encounter JS/CSS --------
copy('love-interest-lukio-v243.js', 'duck-quest/js/love-interest-lukio-v243.js')
copy('love-interest-lukio-v243.css', 'duck-quest/css/love-interest-lukio-v243.css')

# -------- HTML / cache-busting --------
def bump_page(rel):
    text = read(rel)
    # Recover from any partially committed previous references, though GitHub's 500 KB rejection normally means none executed.
    text = re.sub(r'trading-cards-v(?:235|239|240|241|242)\.js', 'trading-cards-v243.js', text)
    text = re.sub(r'trading-cards-ui-v(?:236|238|239|240|241|242)\.js', 'trading-cards-ui-v243.js', text)
    text = re.sub(r'trading-cards-v(?:237|238|239|240|241|242)\.css', 'trading-cards-v243.css', text)
    for old in ['24.238','24.239','24.240','24.241','24.242']:
        text = text.replace(old, TARGET_VERSION)
    for old in ['24-238','24-239','24-240','24-241','24-242']:
        text = text.replace(old, TARGET_QUERY)
    write(rel, text)

for rel in ['index.html','memory-game/index.html','crane-game/play-v24-40.html','duck-quest/index.html']:
    bump_page(rel)
write('crane-game/index.html', bump_238(read('crane-game/index.html')))

# Ensure Lukio encounter assets are loaded only inside Duck Quest.
quest = read('duck-quest/index.html')
if 'css/love-interest-lukio-v243.css' not in quest:
    tag = '  <link rel="stylesheet" href="css/love-interest-lukio-v243.css?v=24-243">\n'
    quest = quest.replace('</head>', tag + '</head>', 1) if '</head>' in quest else tag + quest
if 'js/love-interest-lukio-v243.js' not in quest:
    tag = '  <script src="js/love-interest-lukio-v243.js?v=24-243"></script>\n'
    quest = quest.replace('</body>', tag + '</body>', 1) if '</body>' in quest else quest + '\n' + tag
write('duck-quest/index.html', quest)

# Update only the crane URL query in the hub script; keep the stable script filename.
hub = read('script-v24-201.js')
hub = re.sub(r'crane-game/\?v=24-(?:238|239|240|241|242)', 'crane-game/?v=24-243', hub)
write('script-v24-201.js', hub)

# Service worker: copy the latest worker, update cache query/version and card filenames.
sw_candidates = ['sw-v24-242.js','sw-v24-241.js','sw-v24-240.js','sw-v24-239.js','sw-v24-238.js']
sw_source = next((p for p in sw_candidates if (ROOT / p).exists()), None)
if not sw_source:
    raise RuntimeError('Could not find service worker v24.238-v24.242.')
sw = read(sw_source)
for old in ['24.238','24.239','24.240','24.241','24.242']:
    sw = sw.replace(old, TARGET_VERSION)
for old in ['24-238','24-239','24-240','24-241','24-242']:
    sw = sw.replace(old, TARGET_QUERY)
sw = re.sub(r'trading-cards-v(?:235|239|240|241|242)\.js', 'trading-cards-v243.js', sw)
sw = re.sub(r'trading-cards-ui-v(?:236|238|239|240|241|242)\.js', 'trading-cards-ui-v243.js', sw)
sw = re.sub(r'trading-cards-v(?:237|238|239|240|241|242)\.css', 'trading-cards-v243.css', sw)
write('sw-v24-243.js', sw)
write('sw.js', "importScripts('./sw-v24-243.js?v=24-243');\n")
write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')

write('UPDATE-v24.243.txt', '''Duckie Days v24.243\n\n- Uses the proven small-workflow + ZIP installer format so GitHub does not reject the workflow for exceeding 500 KB.\n- Adds the 5 Fabled Trading Cards and keeps only Common / Uncommon / Rare / Fabled.\n- Extends the Trading Card collection scroll area farther down.\n- Adds Lukio's encounter for Miko, with the supplied dialogue, wink, and bouncing pixel heart finale.\n- Unlocks Lukio Duck, Lukio's three encounter sprites, Miko's Lukio outfit pieces in the Closet, and Lukio's Rare Trading Card.\n- Lukio's Rare card uses Lukio-idle-1.png inside the same Rare card template as the other Rare cards.\n''')

print('Duckie Days v24.243 Fabled + Lukio update installed.')

from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.244'
TARGET_QUERY = '24-244'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')

def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def replace_once(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f'{label}: expected exactly one match, found {n}')
    return text.replace(old, new, 1)

def replace_if(text, old, new):
    return text.replace(old, new) if old in text else text

def bump_versions(text):
    for old in ['24.238','24.239','24.240','24.241','24.242','24.243']:
        text = text.replace(old, TARGET_VERSION)
    for old in ['24-238','24-239','24-240','24-241','24-242','24-243']:
        text = text.replace(old, TARGET_QUERY)
    return text

required = [
    'index.html','version.json','script-v24-201.js','duck-quest/index.html',
    'memory-game/index.html','crane-game/index.html','crane-game/play-v24-40.html'
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.238','24.239','24.240','24.241','24.242','24.243'}:
    raise RuntimeError(f'Expected Duckie Days v24.238-v24.243, found {current!r}')

# ---------------- Assets ----------------
for name in ['F-acorn-mouse.png','F-flower.png','F-bee.png','F-slime-kitty.png','F-mimic.png']:
    copy(f'assets/fabled/{name}', f'duck-quest/assets/trading-cards/fabled/{name}')

lukio_names = [
    'Lukio-duck.png','Lukio-idle-1.png','Lukio-idle-2.png','Lukio-wink.png','Pixel-heart.png',
    'Miko-Lukio-Booties.png','Miko-Lukio-Hair-Streak.png','Miko-Lukio-Shorts.png','Miko-Lukio-Socks.png',
    'Miko-Lukio-hoodie-shop.png','Miko-Lukio-hoodie.png','Miko-Lukio-reference.png','Miko-lukio-sleeve.png'
]
for name in lukio_names:
    copy(f'assets/lukio/{name}', f'duck-quest/assets/love-interests/lukio/{name}')

for name in [
    'Miko-Lukio-Booties.png','Miko-Lukio-Hair-Streak.png','Miko-Lukio-Shorts.png','Miko-Lukio-Socks.png',
    'Miko-Lukio-hoodie-shop.png','Miko-Lukio-hoodie.png','Miko-lukio-sleeve.png'
]:
    copy(f'assets/lukio/{name}', f'assets/miko/{name}')

# ---------------- Trading Card core ----------------
core_candidates = ['trading-cards-v243.js','trading-cards-v242.js','trading-cards-v241.js','trading-cards-v240.js','trading-cards-v239.js','trading-cards-v235.js']
core_source = next((p for p in core_candidates if (ROOT / p).exists()), None)
if not core_source:
    raise RuntimeError('Could not find Trading Card core.')
tc = read(core_source)

tc = replace_if(tc, 'const order={common:1,uncommon:2,rare:3,ultra:4,fabled:5};', 'const order={common:1,uncommon:2,rare:3,fabled:4};')
tc = replace_if(tc, 'const labels={common:"Common",uncommon:"Uncommon",rare:"Rare",ultra:"Ultra Rare",fabled:"Fabled"};', 'const labels={common:"Common",uncommon:"Uncommon",rare:"Rare",fabled:"Fabled"};')
tc = replace_if(tc, 'const templates={common:"card-common.png",uncommon:"card-uncommon.png",rare:"card-rare.png",ultra:"card-rare.png",fabled:"card-rare.png"};', 'const templates={common:"card-common.png",uncommon:"card-uncommon.png",rare:"card-rare.png",fabled:"card-rare.png"};')

if 'const fabled=[' not in tc:
    fabled = '''  const fabled=[
    ["slime-kitty","Slime Kitty","trading-cards/fabled/F-slime-kitty.png","Fabled"],
    ["acorn-mouse","Acorn Mouse","trading-cards/fabled/F-acorn-mouse.png","Fabled"],
    ["bee","Bee","trading-cards/fabled/F-bee.png","Fabled"],
    ["flower","Flower","trading-cards/fabled/F-flower.png","Fabled"],
    ["mimic","Mimic","trading-cards/fabled/F-mimic.png","Fabled"]
  ];
'''
    tc = replace_once(tc, '  const cards=[];', fabled + '  const cards=[];', 'insert Fabled card data')

if 'fabled.forEach(' not in tc:
    shiny_line = re.search(r'  shiny\.forEach\([^\n]+\);\n', tc)
    if not shiny_line:
        raise RuntimeError('Could not find shiny card builder.')
    addition = '  fabled.forEach((x,i)=>cards.push({id:`f-${x[0]}`,name:x[1],art:x[2],rarity:"fabled",number:`F-${String(i+1).padStart(3,"0")}`,category:x[3],hint:"Find this Fabled card in a Card Pack or as a very rare Daily Shop offer."}));\n'
    tc = tc[:shiny_line.end()] + addition + tc[shiny_line.end():]

if 'r-love-lukio' not in tc:
    anchor = '  const byId=Object.fromEntries(cards.map(card=>[card.id,card]));'
    lukio_card = '  cards.push({id:"r-love-lukio",characterId:"lukio",name:"Lukio",art:"love-interests/lukio/Lukio-idle-1.png",rarity:"rare",number:"R-031",category:"Miko Love Interest",hint:"Meet Lukio while exploring Duck Quest as Miko."});\n'
    tc = replace_once(tc, anchor, lukio_card + anchor, 'insert Lukio Rare card')
else:
    tc = re.sub(r'(id:"r-love-lukio".*?art:")[^"]+(".*?rarity:")[^"]+(".*?number:")[^"]+(" )?', lambda m: m.group(0), tc, count=1)
    tc = re.sub(r'(id:"r-love-lukio".*?art:")[^"]+(")', r'\1love-interests/lukio/Lukio-idle-1.png\2', tc, count=1)
    tc = re.sub(r'(id:"r-love-lukio".*?rarity:")[^"]+(")', r'\1rare\2', tc, count=1)
    tc = re.sub(r'(id:"r-love-lukio".*?number:")[^"]+(")', r'\1R-031\2', tc, count=1)

tc = replace_if(tc,
    'function rollRarity(weights={common:.8,uncommon:.18,rare:.02}){let roll=Math.random(),last="common";for(const [rarity,chance] of Object.entries(weights)){last=rarity;roll-=chance;if(roll<=0)return rarity;}return last;}',
    'function rollRarity(weights={common:.795,uncommon:.18,rare:.02,fabled:.005}){let roll=Math.random(),last="common";for(const [rarity,chance] of Object.entries(weights)){last=rarity;roll-=chance;if(roll<=0)return rarity;}return last;}'
)
tc = replace_if(tc,
    'function rollPack(){return [rollCard("common"),rollCard("common"),rollCard(rollRarity({common:.70,uncommon:.25,rare:.05}))];}',
    'function rollPack(){return [rollCard("common"),rollCard("common"),rollCard(rollRarity({common:.695,uncommon:.25,rare:.05,fabled:.005}))];}'
)
tc = tc.replace('card.rarity==="rare"||card.rarity==="ultra"||card.rarity==="fabled"', 'card.rarity==="rare"||card.rarity==="fabled"')
write('trading-cards-v244.js', tc)

# ---------------- Trading Card UI ----------------
ui_candidates = ['trading-cards-ui-v243.js','trading-cards-ui-v242.js','trading-cards-ui-v241.js','trading-cards-ui-v240.js','trading-cards-ui-v239.js','trading-cards-ui-v238.js','trading-cards-ui-v236.js']
ui_source = next((p for p in ui_candidates if (ROOT / p).exists()), None)
if not ui_source:
    raise RuntimeError('Could not find Trading Card UI.')
ui = read(ui_source)
ui = ui.replace('<option value="ultra">Ultra Rare</option>', '')
ui = ui.replace('const prices={common:40,uncommon:100,rare:300,ultra:500,fabled:750};', 'const prices={common:40,uncommon:100,rare:300,fabled:750};')
ui = ui.replace('TC.rollRarity({common:.58,uncommon:.37,rare:.05})', 'TC.rollRarity({common:.575,uncommon:.37,rare:.05,fabled:.005})')
ui = ui.replace('TC.rollRarity({common:.57,uncommon:.36,rare:.06,fabled:.01})', 'TC.rollRarity({common:.575,uncommon:.37,rare:.05,fabled:.005})')
ui = re.sub(r'window\.DUCKIE_TRADING_CARD_UI_BUILD="[^"]+";', 'window.DUCKIE_TRADING_CARD_UI_BUILD="24.244";', ui)
write('trading-cards-ui-v244.js', ui)

# ---------------- Trading Card CSS ----------------
css_candidates = ['trading-cards-v243.css','trading-cards-v242.css','trading-cards-v241.css','trading-cards-v240.css','trading-cards-v239.css','trading-cards-v238.css','trading-cards-v237.css']
css_source = next((p for p in css_candidates if (ROOT / p).exists()), None)
if not css_source:
    raise RuntimeError('Could not find Trading Card CSS.')
css = read(css_source)
css += '''\n\n/* v24.244 — Trading Cards fill the Duckipedia body instead of leaving a cream gap */
.tc-panel:not(.hidden){display:flex!important;flex-direction:column;flex:1 1 auto;min-height:0!important;overflow:hidden!important}
.tc-grid{flex:1 1 auto!important;min-height:0!important;max-height:none!important;height:auto!important;overflow-y:auto!important;overflow-x:hidden!important;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding-right:4px!important;padding-bottom:18px!important;align-content:start!important}
@media(max-width:560px){.tc-grid{max-height:none!important;height:auto!important;padding-bottom:14px!important}}
'''
write('trading-cards-v244.css', css)

# ---------------- Hub / Duckipedia / Miko Closet ----------------
hub = read('script-v24-201.js')

# Register Lukio Duck so it appears as Missing before the event and as Discovered after it.
if '"lukio-duck": {' not in hub:
    anchor = 'const DUCKS = {'
    entry = '''const DUCKS = {
  "lukio-duck": {
    "name": "Lukio Duck",
    "file": "duck-quest/assets/love-interests/lukio/Lukio-duck.png",
    "acquisition": "love-interest-lukio"
  },'''
    hub = replace_once(hub, anchor, entry, 'register Lukio Duck in Duckipedia')

if 'case "love-interest-lukio":' not in hub:
    switch_anchor = '  switch (duck.acquisition) {'
    hub = replace_once(
        hub,
        switch_anchor,
        switch_anchor + '\n    case "love-interest-lukio":\n      return "Meet Lukio while exploring Duck Quest as Miko to unlock this special duck.";',
        'add Lukio Duck acquisition hint'
    )

# Keep encounter-only duck out of random gacha pools.
hub = hub.replace(
    'const GACHA_EXCLUDED_DUCKS = new Set(["tiny-duck", "tiny-duck-stack", "pile-of-tiny-ducks"]);',
    'const GACHA_EXCLUDED_DUCKS = new Set(["tiny-duck", "tiny-duck-stack", "pile-of-tiny-ducks", "lukio-duck"]);'
)

# Add Miko's Lukio outfit if v24.243 did not already do so.
if '"lukio-hoodie"' not in hub:
    if 'const MIKO_THUMB_BOUNDS = {' in hub:
        hub = hub.replace('const MIKO_THUMB_BOUNDS = {', '''const MIKO_THUMB_BOUNDS = {
  "Miko-Lukio-Hair-Streak.png": [426,878,551,1049],
  "Miko-Lukio-hoodie-shop.png": [371,1189,739,1530],
  "Miko-Lukio-Shorts.png": [407,1403,660,1551],
  "Miko-Lukio-Socks.png": [385,1647,686,1796],
  "Miko-Lukio-Booties.png": [379,1723,691,1812],''', 1)

    asset_anchor = 'const MIKO_ASSETS = {'
    asset_entries = '''const MIKO_ASSETS = {
  "lukio-hair-streak": { label: "Lukio Set · Hair Streak", file: "Miko-Lukio-Hair-Streak.png", z: 49 },
  "lukio-hoodie": { label: "Lukio Set · Hoodie", file: "Miko-Lukio-hoodie.png", previewFile: "Miko-Lukio-hoodie-shop.png", z: 34 },
  "lukio-sleeve": { label: "Lukio Set · Sleeve", file: "Miko-lukio-sleeve.png", z: 37 },
  "lukio-shorts": { label: "Lukio Set · Shorts", file: "Miko-Lukio-Shorts.png", z: 31 },
  "lukio-socks": { label: "Lukio Set · Socks", file: "Miko-Lukio-Socks.png", z: 29 },
  "lukio-booties": { label: "Lukio Set · Booties", file: "Miko-Lukio-Booties.png", z: 39 },'''
    hub = replace_once(hub, asset_anchor, asset_entries, 'add Lukio outfit assets')

    hub = hub.replace('options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer"]', 'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie"]')
    hub = hub.replace('options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts"]', 'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts"]')
    hub = hub.replace('options: ["socks", "socks-garter"]', 'options: ["socks", "socks-garter", "lukio-socks"]')
    hub = hub.replace('options: ["shoes-loafer", "shoes-fancy-loafers"]', 'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties"]')
    hub = hub.replace('options: ["headband", "hairpins-black"]', 'options: ["headband", "hairpins-black", "lukio-hair-streak"]')

    hub = hub.replace('[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer"].includes(outer)', '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie"].includes(outer)')
    hub = hub.replace('["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts"].includes(incoming.bottom)', '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts"].includes(incoming.bottom)')
    hub = hub.replace('["socks", "socks-garter"].includes(incoming.socks)', '["socks", "socks-garter", "lukio-socks"].includes(incoming.socks)')
    hub = hub.replace('[null, "shoes-loafer", "shoes-fancy-loafers"].includes(incoming.shoes)', '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties"].includes(incoming.shoes)')

    sleeve_anchor = '  else if (outfit.outer === "outer-black-blazer") ids.push("outer-black-blazer-arm");'
    hub = replace_once(hub, sleeve_anchor, sleeve_anchor + '\n  else if (outfit.outer === "lukio-hoodie") ids.push("lukio-sleeve");', 'add Lukio hoodie sleeve layer')

write('script-v24-201.js', hub)

# ---------------- Encounter ----------------
copy('love-interest-lukio-v244.js', 'duck-quest/js/love-interest-lukio-v244.js')
copy('love-interest-lukio-v244.css', 'duck-quest/css/love-interest-lukio-v244.css')

# ---------------- Page references / cache bust ----------------
def patch_page(rel):
    text = read(rel)
    text = re.sub(r'trading-cards-v(?:235|239|240|241|242|243)\.js', 'trading-cards-v244.js', text)
    text = re.sub(r'trading-cards-ui-v(?:236|238|239|240|241|242|243)\.js', 'trading-cards-ui-v244.js', text)
    text = re.sub(r'trading-cards-v(?:237|238|239|240|241|242|243)\.css', 'trading-cards-v244.css', text)
    text = bump_versions(text)
    write(rel, text)

for rel in ['index.html','memory-game/index.html','crane-game/play-v24-40.html','duck-quest/index.html']:
    patch_page(rel)
write('crane-game/index.html', bump_versions(read('crane-game/index.html')))

quest = read('duck-quest/index.html')
quest = re.sub(r'\s*<link[^>]+love-interest-lukio-v24[0-3]\.css[^>]*>\s*', '\n', quest)
quest = re.sub(r'\s*<script[^>]+love-interest-lukio-v24[0-3]\.js[^>]*></script>\s*', '\n', quest)
if 'css/love-interest-lukio-v244.css' not in quest:
    tag = '  <link rel="stylesheet" href="css/love-interest-lukio-v244.css?v=24-244">\n'
    quest = quest.replace('</head>', tag + '</head>', 1) if '</head>' in quest else tag + quest
if 'js/love-interest-lukio-v244.js' not in quest:
    tag = '  <script src="js/love-interest-lukio-v244.js?v=24-244"></script>\n'
    quest = quest.replace('</body>', tag + '</body>', 1) if '</body>' in quest else quest + '\n' + tag
write('duck-quest/index.html', quest)

hub = read('script-v24-201.js')
hub = re.sub(r'crane-game/\?v=24-(?:238|239|240|241|242|243)', 'crane-game/?v=24-244', hub)
write('script-v24-201.js', hub)

# ---------------- Service worker ----------------
sw_candidates = ['sw-v24-243.js','sw-v24-242.js','sw-v24-241.js','sw-v24-240.js','sw-v24-239.js','sw-v24-238.js']
sw_source = next((p for p in sw_candidates if (ROOT / p).exists()), None)
if not sw_source:
    raise RuntimeError('Could not find service worker v24.238-v24.243.')
sw = read(sw_source)
sw = bump_versions(sw)
sw = re.sub(r'trading-cards-v(?:235|239|240|241|242|243)\.js', 'trading-cards-v244.js', sw)
sw = re.sub(r'trading-cards-ui-v(?:236|238|239|240|241|242|243)\.js', 'trading-cards-ui-v244.js', sw)
sw = re.sub(r'trading-cards-v(?:237|238|239|240|241|242|243)\.css', 'trading-cards-v244.css', sw)

# Remove prior Lukio runtime refs from the precache list to avoid stale duplicates.
sw = re.sub(r"\s*'\./duck-quest/(?:js|css)/love-interest-lukio-v24[0-3]\.(?:js|css)\?v=24-244',?", '', sw)

precache_urls = [
    './trading-cards-v244.js?v=24-244',
    './trading-cards-ui-v244.js?v=24-244',
    './trading-cards-v244.css?v=24-244',
    './duck-quest/js/love-interest-lukio-v244.js?v=24-244',
    './duck-quest/css/love-interest-lukio-v244.css?v=24-244',
    './duck-quest/assets/trading-cards/fabled/F-acorn-mouse.png',
    './duck-quest/assets/trading-cards/fabled/F-flower.png',
    './duck-quest/assets/trading-cards/fabled/F-bee.png',
    './duck-quest/assets/trading-cards/fabled/F-slime-kitty.png',
    './duck-quest/assets/trading-cards/fabled/F-mimic.png',
    './duck-quest/assets/love-interests/lukio/Lukio-duck.png',
    './duck-quest/assets/love-interests/lukio/Lukio-idle-1.png',
    './duck-quest/assets/love-interests/lukio/Lukio-idle-2.png',
    './duck-quest/assets/love-interests/lukio/Lukio-wink.png',
    './duck-quest/assets/love-interests/lukio/Pixel-heart.png',
    './assets/miko/Miko-Lukio-Booties.png',
    './assets/miko/Miko-Lukio-Hair-Streak.png',
    './assets/miko/Miko-Lukio-Shorts.png',
    './assets/miko/Miko-Lukio-Socks.png',
    './assets/miko/Miko-Lukio-hoodie-shop.png',
    './assets/miko/Miko-Lukio-hoodie.png',
    './assets/miko/Miko-lukio-sleeve.png',
]
missing_urls = [u for u in precache_urls if u not in sw]
if missing_urls:
    arr = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS)\s*=\s*\[)(.*?)(\];)', sw, re.S)
    if not arr:
        raise RuntimeError('Could not locate service-worker precache array.')
    body = arr.group(2)
    if body.strip() and not body.rstrip().endswith(','):
        body = body.rstrip() + ','
    addition = ''.join(f"\n  '{u}'," for u in missing_urls)
    sw = sw[:arr.start(2)] + body + addition + '\n' + sw[arr.end(2):]

write('sw-v24-244.js', sw)
write('sw.js', "importScripts('./sw-v24-244.js?v=24-244');\n")
write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')

write('UPDATE-v24.244.txt', '''Duckie Days v24.244\n\n- Forces the Trading Card data/UI/CSS onto fresh v24.244 filenames so the old 65-card cache cannot win.\n- Expected Trading Card total is now 71: original 65 + five Fabled cards + Lukio.\n- Trading Card results now flex to the bottom of the Duckipedia panel instead of leaving a large cream gap.\n- Registers Lukio Duck in Duckipedia as a Missing entry before the encounter and unlocks it after meeting Lukio.\n- Keeps Lukio Duck out of random gacha pools.\n- Lukio's Rare card uses idle-1 in the standard Rare template and is rewarded by his encounter.\n- Adds robust fallback card saving if the encounter fires before the Trading Card helper is available.\n- Love-interest encounters use a 5% roll and are strictly disabled unless Miko is the active playable OC.\n''')

print('Duckie Days v24.244 card cache + Lukio Duck registration fix installed.')

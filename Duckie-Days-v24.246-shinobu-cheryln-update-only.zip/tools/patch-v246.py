from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.246'
TARGET_QUERY = '24-246'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')

def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old, new, 1)

def add_after_switch_case(text, case_id, message):
    needle = f'case "{case_id}":'
    if needle in text:
        return text
    switch_anchor = '  switch (duck.acquisition) {'
    insertion = f'\n    case "{case_id}":\n      return "{message}";'
    return replace_once(text, switch_anchor, switch_anchor + insertion, f'add acquisition hint for {case_id}')

def ensure_option_line(text, old_line, new_line, label):
    if new_line in text:
        return text
    if old_line not in text:
        raise RuntimeError(f'{label}: could not find expected options line')
    return text.replace(old_line, new_line, 1)

def bump_versions(text):
    text = text.replace('24.245', TARGET_VERSION)
    text = text.replace('24-245', TARGET_QUERY)
    return text

required = [
    'index.html','version.json','script-v24-201.js','duck-quest/index.html',
    'memory-game/index.html','crane-game/index.html','crane-game/play-v24-40.html',
    'trading-cards-v245.js','trading-cards-ui-v245.js','trading-cards-v245.css','sw-v24-245.js'
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.245', '24.246'}:
    raise RuntimeError(f'Expected Duckie Days v24.245, found {current!r}')

# ---------------- Assets ----------------
shinobu_names = [
    'Shinobu-duck.png','Shinobu-idle-1.png','Shinobu-idle-2.png','Shinobu-happy.png',
    'Miko-Shino-Baret.png','Miko-Shino-Boots.png','Miko-Shino-Jeans.png','Miko-Shino-Sweater.png',
    'Miko-Shino-Sweater-Shop.png','Miko-Shino-sleeve.png','Miko-Shinobu-Reference.png'
]
for name in shinobu_names:
    copy(f'assets/shinobu/{name}', f'duck-quest/assets/love-interests/shinobu/{name}')
for name in ['Miko-Shino-Baret.png','Miko-Shino-Boots.png','Miko-Shino-Jeans.png','Miko-Shino-Sweater.png','Miko-Shino-Sweater-Shop.png','Miko-Shino-sleeve.png','Miko-Shinobu-Reference.png']:
    copy(f'assets/shinobu/{name}', f'assets/miko/{name}')

cheryln_names = [
    'Cheryln-duck.png','Cheryln-idle-1.png','Cheryln-idle-2.png','Cheryln-happy.png',
    'Miko-Cheryln-Banana-Hairpin.png','Miko-Cheryln-boots.png','Miko-Cheryln-shorts.png',
    'Miko-Cheryln-sweater.png','Miko-Cheryln-white-tights.png','Miko-Cheryln-Reference.png'
]
for name in cheryln_names:
    copy(f'assets/cheryln/{name}', f'duck-quest/assets/love-interests/cheryln/{name}')
for name in ['Miko-Cheryln-Banana-Hairpin.png','Miko-Cheryln-boots.png','Miko-Cheryln-shorts.png','Miko-Cheryln-sweater.png','Miko-Cheryln-white-tights.png','Miko-Cheryln-Reference.png']:
    copy(f'assets/cheryln/{name}', f'assets/miko/{name}')

copy('love-interests-v246.js', 'duck-quest/js/love-interests-v246.js')
copy('love-interests-v246.css', 'duck-quest/css/love-interests-v246.css')

# ---------------- Trading Card core ----------------
tc = read('trading-cards-v245.js')
if 'id:"r-love-shinobu"' not in tc or 'id:"r-love-cheryln"' not in tc:
    anchor = '  const byId=Object.fromEntries(cards.map(card=>[card.id,card]));'
    addition = (
        '  cards.push({id:"r-love-shinobu",characterId:"shinobu",name:"Shinobu",art:"love-interests/shinobu/Shinobu-idle-1.png",rarity:"rare",number:"R-032",category:"Miko Love Interest",hint:"Witness Shinobu and Cheryln\'s reunion while exploring Duck Quest as Miko."});\n'
        '  cards.push({id:"r-love-cheryln",characterId:"cheryln",name:"Cheryln",art:"love-interests/cheryln/Cheryln-idle-1.png",rarity:"rare",number:"R-033",category:"Miko Love Interest",hint:"Witness Shinobu and Cheryln\'s reunion while exploring Duck Quest as Miko."});\n'
    )
    tc = replace_once(tc, anchor, addition + anchor, 'insert Shinobu and Cheryln rare cards')
write('trading-cards-v246.js', tc)

ui = read('trading-cards-ui-v245.js')
ui = re.sub(r'window\.DUCKIE_TRADING_CARD_UI_BUILD="[^"]+";', 'window.DUCKIE_TRADING_CARD_UI_BUILD="24.246";', ui)
write('trading-cards-ui-v246.js', ui)

css = read('trading-cards-v245.css')
write('trading-cards-v246.css', css)

# ---------------- Hub / Duckipedia / Miko Closet ----------------
hub = read('script-v24-201.js')

for duck_id, duck_name, duck_file, acq in [
    ('shinobu-duck', 'Shinobu Duck', 'duck-quest/assets/love-interests/shinobu/Shinobu-duck.png', 'love-interest-shinobu'),
    ('cheryln-duck', 'Cheryln Duck', 'duck-quest/assets/love-interests/cheryln/Cheryln-duck.png', 'love-interest-cheryln'),
]:
    if f'"{duck_id}": {{' not in hub:
        entry = f'''const DUCKS = {{
  "{duck_id}": {{
    "name": "{duck_name}",
    "file": "{duck_file}",
    "acquisition": "{acq}"
  }},'''
        hub = replace_once(hub, 'const DUCKS = {', entry, f'register {duck_id}')

hub = add_after_switch_case(hub, 'love-interest-shinobu', 'Meet Shinobu while exploring Duck Quest as Miko to unlock this special duck.')
hub = add_after_switch_case(hub, 'love-interest-cheryln', 'Meet Cheryln while exploring Duck Quest as Miko to unlock this special duck.')

for duck_id in ['shinobu-duck', 'cheryln-duck']:
    if duck_id not in hub.split('const GACHA_EXCLUDED_DUCKS = new Set(',1)[1]:
        hub = hub.replace(']);', f', "{duck_id}"]);', 1)

if '"shino-beret"' not in hub:
    asset_anchor = 'const MIKO_ASSETS = {'
    asset_entries = '''const MIKO_ASSETS = {
  "shino-beret": { label: "Shinobu Set · Beret", file: "Miko-Shino-Baret.png", z: 49 },
  "shino-sweater": { label: "Shinobu Set · Sweater", file: "Miko-Shino-Sweater.png", previewFile: "Miko-Shino-Sweater-Shop.png", z: 34 },
  "shino-sleeve": { label: "Shinobu Set · Sleeve", file: "Miko-Shino-sleeve.png", z: 37 },
  "shino-jeans": { label: "Shinobu Set · Jeans", file: "Miko-Shino-Jeans.png", z: 31 },
  "shino-boots": { label: "Shinobu Set · Boots", file: "Miko-Shino-Boots.png", z: 39 },
  "cheryln-hairpin": { label: "Cheryln Set · Banana Hairpin", file: "Miko-Cheryln-Banana-Hairpin.png", z: 49 },
  "cheryln-sweater": { label: "Cheryln Set · Sweater", file: "Miko-Cheryln-sweater.png", previewFile: "Miko-Cheryln-sweater.png", z: 34 },
  "cheryln-shorts": { label: "Cheryln Set · Shorts", file: "Miko-Cheryln-shorts.png", z: 31 },
  "cheryln-tights": { label: "Cheryln Set · White Tights", file: "Miko-Cheryln-white-tights.png", z: 29 },
  "cheryln-boots": { label: "Cheryln Set · Boots", file: "Miko-Cheryln-boots.png", z: 39 },'''
    hub = replace_once(hub, asset_anchor, asset_entries, 'add Shinobu and Cheryln outfit assets')

hub = ensure_option_line(
    hub,
    'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie"]',
    'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater"]',
    'outer options'
)
hub = ensure_option_line(
    hub,
    'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts"]',
    'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts"]',
    'bottom options'
)
hub = ensure_option_line(
    hub,
    'options: ["socks", "socks-garter", "lukio-socks"]',
    'options: ["socks", "socks-garter", "lukio-socks", "cheryln-tights"]',
    'socks options'
)
hub = ensure_option_line(
    hub,
    'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties"]',
    'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots"]',
    'shoe options'
)
hub = ensure_option_line(
    hub,
    'options: ["headband", "hairpins-black", "lukio-hair-streak"]',
    'options: ["headband", "hairpins-black", "lukio-hair-streak", "shino-beret", "cheryln-hairpin"]',
    'head options'
)

hub = hub.replace(
    '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie"].includes(outer)',
    '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater"].includes(outer)'
)
hub = hub.replace(
    '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts"].includes(incoming.bottom)',
    '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts"].includes(incoming.bottom)'
)
hub = hub.replace(
    '["socks", "socks-garter", "lukio-socks"].includes(incoming.socks)',
    '["socks", "socks-garter", "lukio-socks", "cheryln-tights"].includes(incoming.socks)'
)
hub = hub.replace(
    '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties"].includes(incoming.shoes)',
    '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots"].includes(incoming.shoes)'
)

sleeve_anchor = '  else if (outfit.outer === "lukio-hoodie") ids.push("lukio-sleeve");'
if 'outfit.outer === "shino-sweater"' not in hub:
    hub = replace_once(hub, sleeve_anchor, sleeve_anchor + '\n  else if (outfit.outer === "shino-sweater") ids.push("shino-sleeve");', 'add Shinobu sweater sleeve layer')

hub = re.sub(r'crane-game/\?v=24-245', 'crane-game/?v=24-246', hub)
write('script-v24-201.js', hub)

# ---------------- Page references ----------------
def patch_page(rel):
    text = read(rel)
    text = text.replace('trading-cards-v245.js', 'trading-cards-v246.js')
    text = text.replace('trading-cards-ui-v245.js', 'trading-cards-ui-v246.js')
    text = text.replace('trading-cards-v245.css', 'trading-cards-v246.css')
    text = bump_versions(text)
    write(rel, text)

for rel in ['index.html', 'memory-game/index.html', 'crane-game/index.html', 'crane-game/play-v24-40.html', 'duck-quest/index.html']:
    patch_page(rel)

quest = read('duck-quest/index.html')
quest = re.sub(r'\s*<link[^>]+(?:love-interest-lukio-v244|love-interests-v246)\.css[^>]*>\s*', '\n', quest)
quest = re.sub(r'\s*<script[^>]+(?:love-interest-lukio-v244|love-interests-v246)\.js[^>]*></script>\s*', '\n', quest)
if 'css/love-interests-v246.css' not in quest:
    quest = quest.replace('</head>', '  <link rel="stylesheet" href="css/love-interests-v246.css?v=24-246">\n</head>', 1)
if 'js/love-interests-v246.js' not in quest:
    quest = quest.replace('</body>', '  <script src="js/love-interests-v246.js?v=24-246"></script>\n</body>', 1)
write('duck-quest/index.html', quest)

# ---------------- Service worker ----------------
sw = read('sw-v24-245.js')
sw = bump_versions(sw)
sw = sw.replace('trading-cards-v245.js', 'trading-cards-v246.js')
sw = sw.replace('trading-cards-ui-v245.js', 'trading-cards-ui-v246.js')
sw = sw.replace('trading-cards-v245.css', 'trading-cards-v246.css')
sw = sw.replace('./sw-v24-245.js', './sw-v24-246.js')
# Remove old love-interest runtime refs.
sw = re.sub(r"\s*'\./duck-quest/(?:js|css)/(?:love-interest-lukio-v244|love-interests-v246)\.(?:js|css)\?v=24-246',?", '', sw)

precache_match = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not precache_match:
    raise RuntimeError('Could not locate service-worker precache array.')
body = precache_match.group(2)
add_urls = [
    './trading-cards-v246.js?v=24-246',
    './trading-cards-ui-v246.js?v=24-246',
    './trading-cards-v246.css?v=24-246',
    './duck-quest/js/love-interests-v246.js?v=24-246',
    './duck-quest/css/love-interests-v246.css?v=24-246',
    './duck-quest/assets/love-interests/shinobu/Shinobu-duck.png',
    './duck-quest/assets/love-interests/shinobu/Shinobu-idle-1.png',
    './duck-quest/assets/love-interests/shinobu/Shinobu-idle-2.png',
    './duck-quest/assets/love-interests/shinobu/Shinobu-happy.png',
    './duck-quest/assets/love-interests/shinobu/Miko-Shino-Baret.png',
    './duck-quest/assets/love-interests/shinobu/Miko-Shino-Boots.png',
    './duck-quest/assets/love-interests/shinobu/Miko-Shino-Jeans.png',
    './duck-quest/assets/love-interests/shinobu/Miko-Shino-Sweater.png',
    './duck-quest/assets/love-interests/shinobu/Miko-Shino-Sweater-Shop.png',
    './duck-quest/assets/love-interests/shinobu/Miko-Shino-sleeve.png',
    './duck-quest/assets/love-interests/cheryln/Cheryln-duck.png',
    './duck-quest/assets/love-interests/cheryln/Cheryln-idle-1.png',
    './duck-quest/assets/love-interests/cheryln/Cheryln-idle-2.png',
    './duck-quest/assets/love-interests/cheryln/Cheryln-happy.png',
    './duck-quest/assets/love-interests/cheryln/Miko-Cheryln-Banana-Hairpin.png',
    './duck-quest/assets/love-interests/cheryln/Miko-Cheryln-boots.png',
    './duck-quest/assets/love-interests/cheryln/Miko-Cheryln-shorts.png',
    './duck-quest/assets/love-interests/cheryln/Miko-Cheryln-sweater.png',
    './duck-quest/assets/love-interests/cheryln/Miko-Cheryln-white-tights.png',
]
for url in add_urls:
    if url not in body:
        body += f"\n  '{url}',"
sw = sw[:precache_match.start(2)] + body + sw[precache_match.end(2):]
write('sw-v24-246.js', sw)
write('sw.js', "importScripts('./sw-v24-246.js?v=24-246');\n")

write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')
write('UPDATE-v24.246.txt',
      'Duckie Days v24.246\\n\\n'
      '- Adds Shinobu and Cheryln as Miko love-interest encounters.\\n'
      '- Shared love-interest chance stays 5 percent total and remains Miko-only.\\n'
      '- Shinobu and Cheryln each grant their duck and Miko outfit on their solo encounter.\\n'
      '- Their Rare cards unlock together from the Shinobu x Cheryln reunion cutscene.\\n')

print('Installed Duckie Days v24.246.')

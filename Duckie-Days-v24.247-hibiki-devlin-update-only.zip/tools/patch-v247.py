from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.247'
TARGET_QUERY = '24-247'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')

def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old, new, 1)

def ensure_option_line(text, old_line, new_line, label):
    if new_line in text:
        return text
    if old_line not in text:
        raise RuntimeError(f'{label}: could not find expected options line')
    return text.replace(old_line, new_line, 1)

def add_duck_if_missing(text, duck_id, duck_name, duck_file, acq):
    if f'"{duck_id}": {{' in text:
        return text
    entry = f'''const DUCKS = {{
  "{duck_id}": {{
    "name": "{duck_name}",
    "file": "{duck_file}",
    "acquisition": "{acq}"
  }},'''
    return replace_once(text, 'const DUCKS = {', entry, f'register {duck_id}')

def add_after_switch_case(text, case_id, message):
    needle = f'case "{case_id}":'
    if needle in text:
        return text
    switch_anchor = '  switch (duck.acquisition) {'
    insertion = f'\n    case "{case_id}":\n      return "{message}";'
    return replace_once(text, switch_anchor, switch_anchor + insertion, f'add acquisition hint for {case_id}')

def bump_versions(text):
    text = text.replace('24.246', TARGET_VERSION)
    text = text.replace('24-246', TARGET_QUERY)
    return text

required = [
    'index.html','version.json','script-v24-201.js','duck-quest/index.html',
    'memory-game/index.html','crane-game/index.html','crane-game/play-v24-40.html',
    'trading-cards-v246.js','trading-cards-ui-v246.js','trading-cards-v246.css','sw-v24-246.js'
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.246', '24.247'}:
    raise RuntimeError(f'Expected Duckie Days v24.246, found {current!r}')

# ---------------- Assets ----------------
hibiki_names = [
    'Hibiki-duck.png','Hibiki-idle-1.png','Hibiki-idle-2.png','Hibiki-happy.png',
    'Miko-Hibiki-Ribbon.png','Miko-Hibiki-back-coat.png','Miko-Hibiki-boots.png','Miko-Hibiki-coat-shop.png',
    'Miko-Hibiki-coat-sleeve.png','Miko-Hibiki-coat.png','Miko-Hibiki-shirt.png','Miko-Hibiki-shorts.png',
    'Miko-Hibiki-stockings.png','Miko-Hibiki-Ref.png'
]
for name in hibiki_names:
    copy(f'assets/hibiki/{name}', f'duck-quest/assets/love-interests/hibiki/{name}')
for name in ['Miko-Hibiki-Ribbon.png','Miko-Hibiki-back-coat.png','Miko-Hibiki-boots.png','Miko-Hibiki-coat-shop.png','Miko-Hibiki-coat-sleeve.png','Miko-Hibiki-coat.png','Miko-Hibiki-shirt.png','Miko-Hibiki-shorts.png','Miko-Hibiki-stockings.png','Miko-Hibiki-Ref.png']:
    copy(f'assets/hibiki/{name}', f'assets/miko/{name}')

devlin_names = [
    'Devlin-duck.png','Devlin-idle-1.png','Devlin-idle-2.png','Devlin-angry.png',
    'Miko-Devlin-Belt.png','Miko-Devlin-Tie.png','Miko-Devlin-Vest.png','Miko-Devlin-loafers.png',
    'Miko-Devlin-pants.png','Miko-Devlin-reference.png','Miko-Devlin-shirt.png','Miko-bangs-pinned.png'
]
for name in devlin_names:
    copy(f'assets/devlin/{name}', f'duck-quest/assets/love-interests/devlin/{name}')
for name in ['Miko-Devlin-Belt.png','Miko-Devlin-Tie.png','Miko-Devlin-Vest.png','Miko-Devlin-loafers.png','Miko-Devlin-pants.png','Miko-Devlin-reference.png','Miko-Devlin-shirt.png','Miko-bangs-pinned.png']:
    copy(f'assets/devlin/{name}', f'assets/miko/{name}')

copy('love-interests-v247.js', 'duck-quest/js/love-interests-v247.js')
copy('love-interests-v247.css', 'duck-quest/css/love-interests-v247.css')

# ---------------- Trading cards ----------------
tc = read('trading-cards-v246.js')
if 'id:"r-love-hibiki"' not in tc or 'id:"r-love-devlin"' not in tc:
    anchor = '  const byId=Object.fromEntries(cards.map(card=>[card.id,card]));'
    addition = (
        '  cards.push({id:"r-love-hibiki",characterId:"hibiki",name:"Hibiki",art:"love-interests/hibiki/Hibiki-idle-1.png",rarity:"rare",number:"R-034",category:"Miko Love Interest",hint:"Witness Devlin and Hibiki\'s reunion while exploring Duck Quest as Miko."});\n'
        '  cards.push({id:"r-love-devlin",characterId:"devlin",name:"Devlin",art:"love-interests/devlin/Devlin-idle-1.png",rarity:"rare",number:"R-035",category:"Miko Love Interest",hint:"Witness Devlin and Hibiki\'s reunion while exploring Duck Quest as Miko."});\n'
    )
    tc = replace_once(tc, anchor, addition + anchor, 'insert Hibiki and Devlin rare cards')
write('trading-cards-v247.js', tc)

ui = read('trading-cards-ui-v246.js')
ui = re.sub(r'window\.DUCKIE_TRADING_CARD_UI_BUILD="[^"]+";', 'window.DUCKIE_TRADING_CARD_UI_BUILD="24.247";', ui)
write('trading-cards-ui-v247.js', ui)
css = read('trading-cards-v246.css')
write('trading-cards-v247.css', css)

# ---------------- Hub / Duckipedia / Miko closet ----------------
hub = read('script-v24-201.js')

hub = add_duck_if_missing(hub, 'hibiki-duck', 'Hibiki Duck', 'duck-quest/assets/love-interests/hibiki/Hibiki-duck.png', 'love-interest-hibiki')
hub = add_duck_if_missing(hub, 'devlin-duck', 'Devlin Duck', 'duck-quest/assets/love-interests/devlin/Devlin-duck.png', 'love-interest-devlin')

hub = add_after_switch_case(hub, 'love-interest-hibiki', 'Meet Hibiki while exploring Duck Quest as Miko to unlock this special duck.')
hub = add_after_switch_case(hub, 'love-interest-devlin', 'Meet Devlin while exploring Duck Quest as Miko to unlock this special duck.')

gacha_old = 'const GACHA_EXCLUDED_DUCKS = new Set(["tiny-duck", "tiny-duck-stack", "pile-of-tiny-ducks", "lukio-duck", "shinobu-duck", "cheryln-duck"]);'
gacha_new = 'const GACHA_EXCLUDED_DUCKS = new Set(["tiny-duck", "tiny-duck-stack", "pile-of-tiny-ducks", "lukio-duck", "shinobu-duck", "cheryln-duck", "hibiki-duck", "devlin-duck"]);'
if gacha_new not in hub:
    if gacha_old not in hub:
        raise RuntimeError('Could not locate GACHA_EXCLUDED_DUCKS.')
    hub = hub.replace(gacha_old, gacha_new, 1)

if '"hibiki-ribbon"' not in hub:
    asset_anchor = 'const MIKO_ASSETS = {'
    asset_entries = '''const MIKO_ASSETS = {
  "hibiki-ribbon": { label: "Hibiki Set · Ribbon", file: "Miko-Hibiki-Ribbon.png", z: 49 },
  "hibiki-shirt": { label: "Hibiki Set · Shirt", file: "Miko-Hibiki-shirt.png", z: 24 },
  "hibiki-back-coat": { label: "Hibiki Set · Back Coat", file: "Miko-Hibiki-back-coat.png", z: 21 },
  "hibiki-coat": { label: "Hibiki Set · Coat", file: "Miko-Hibiki-coat.png", previewFile: "Miko-Hibiki-coat-shop.png", z: 34 },
  "hibiki-coat-sleeve": { label: "Hibiki Set · Coat Sleeve", file: "Miko-Hibiki-coat-sleeve.png", z: 37 },
  "hibiki-shorts": { label: "Hibiki Set · Shorts", file: "Miko-Hibiki-shorts.png", z: 31 },
  "hibiki-stockings": { label: "Hibiki Set · Stockings", file: "Miko-Hibiki-stockings.png", z: 29 },
  "hibiki-boots": { label: "Hibiki Set · Boots", file: "Miko-Hibiki-boots.png", z: 39 },
  "devlin-shirt": { label: "Devlin Set · Shirt", file: "Miko-Devlin-shirt.png", z: 24 },
  "devlin-vest": { label: "Devlin Set · Vest", file: "Miko-Devlin-Vest.png", previewFile: "Miko-Devlin-Vest.png", z: 34 },
  "devlin-tie": { label: "Devlin Set · Tie", file: "Miko-Devlin-Tie.png", z: 36 },
  "devlin-pants": { label: "Devlin Set · Pants", file: "Miko-Devlin-pants.png", z: 31 },
  "devlin-belt": { label: "Devlin Set · Belt", file: "Miko-Devlin-Belt.png", z: 32 },
  "devlin-loafers": { label: "Devlin Set · Loafers", file: "Miko-Devlin-loafers.png", z: 39 },
  "devlin-bangs-pinned": { label: "Devlin Set · Pinned Bangs", file: "Miko-bangs-pinned.png", z: 49 },'''
    hub = replace_once(hub, asset_anchor, asset_entries, 'add Hibiki and Devlin outfit assets')

hub = ensure_option_line(
    hub,
    'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater"]',
    'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest"]',
    'outer options'
)
hub = ensure_option_line(
    hub,
    'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts"]',
    'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants"]',
    'bottom options'
)
hub = ensure_option_line(
    hub,
    'options: ["socks", "socks-garter", "lukio-socks", "cheryln-tights"]',
    'options: ["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings"]',
    'socks options'
)
hub = ensure_option_line(
    hub,
    'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots"]',
    'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers"]',
    'shoe options'
)

hub = hub.replace(
    '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater"].includes(outer)',
    '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest"].includes(outer)'
)
hub = hub.replace(
    '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts"].includes(incoming.bottom)',
    '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants"].includes(incoming.bottom)'
)
hub = hub.replace(
    '["socks", "socks-garter", "lukio-socks", "cheryln-tights"].includes(incoming.socks)',
    '["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings"].includes(incoming.socks)'
)
hub = hub.replace(
    '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots"].includes(incoming.shoes)',
    '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers"].includes(incoming.shoes)'
)

# Support extra auto-layer pieces for these outfits.
helper_anchor = '  else if (outfit.outer === "shino-sweater") ids.push("shino-sleeve");\n  return ids;'
helper_new = '  else if (outfit.outer === "shino-sweater") ids.push("shino-sleeve");\n  else if (outfit.outer === "hibiki-coat") ids.push("hibiki-back-coat", "hibiki-shirt", "hibiki-ribbon", "hibiki-coat-sleeve");\n  else if (outfit.outer === "devlin-vest") ids.push("devlin-shirt", "devlin-tie", "devlin-bangs-pinned");\n  if (outfit.bottom === "devlin-pants") ids.push("devlin-belt");\n  return ids;'
if 'outfit.outer === "hibiki-coat"' not in hub:
    hub = replace_once(hub, helper_anchor, helper_new, 'add Hibiki and Devlin helper layers')

hub = re.sub(r'crane-game/\?v=24-246', 'crane-game/?v=24-247', hub)
write('script-v24-201.js', hub)

# ---------------- Page references ----------------
def patch_page(rel):
    text = read(rel)
    text = text.replace('trading-cards-v246.js', 'trading-cards-v247.js')
    text = text.replace('trading-cards-ui-v246.js', 'trading-cards-ui-v247.js')
    text = text.replace('trading-cards-v246.css', 'trading-cards-v247.css')
    text = text.replace('love-interests-v246.js', 'love-interests-v247.js')
    text = text.replace('love-interests-v246.css', 'love-interests-v247.css')
    text = bump_versions(text)
    write(rel, text)

for rel in ['index.html', 'memory-game/index.html', 'crane-game/index.html', 'crane-game/play-v24-40.html', 'duck-quest/index.html']:
    patch_page(rel)

quest = read('duck-quest/index.html')
quest = re.sub(r'\s*<link[^>]+(?:love-interest-lukio-v244|love-interests-v246|love-interests-v247)\.css[^>]*>\s*', '\n', quest)
quest = re.sub(r'\s*<script[^>]+(?:love-interest-lukio-v244|love-interests-v246|love-interests-v247)\.js[^>]*></script>\s*', '\n', quest)
if 'css/love-interests-v247.css' not in quest:
    quest = quest.replace('</head>', '  <link rel="stylesheet" href="css/love-interests-v247.css?v=24-247">\n</head>', 1)
if 'js/love-interests-v247.js' not in quest:
    quest = quest.replace('</body>', '  <script src="js/love-interests-v247.js?v=24-247"></script>\n</body>', 1)
write('duck-quest/index.html', quest)

# ---------------- Service worker ----------------
sw = read('sw-v24-246.js')
sw = bump_versions(sw)
sw = sw.replace('trading-cards-v246.js', 'trading-cards-v247.js')
sw = sw.replace('trading-cards-ui-v246.js', 'trading-cards-ui-v247.js')
sw = sw.replace('trading-cards-v246.css', 'trading-cards-v247.css')
sw = sw.replace('./sw-v24-246.js', './sw-v24-247.js')
sw = sw.replace('love-interests-v246.js', 'love-interests-v247.js')
sw = sw.replace('love-interests-v246.css', 'love-interests-v247.css')

precache_match = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not precache_match:
    raise RuntimeError('Could not locate service-worker precache array.')
body = precache_match.group(2)
add_urls = [
    './trading-cards-v247.js?v=24-247',
    './trading-cards-ui-v247.js?v=24-247',
    './trading-cards-v247.css?v=24-247',
    './duck-quest/js/love-interests-v247.js?v=24-247',
    './duck-quest/css/love-interests-v247.css?v=24-247',
    './duck-quest/assets/love-interests/hibiki/Hibiki-duck.png',
    './duck-quest/assets/love-interests/hibiki/Hibiki-idle-1.png',
    './duck-quest/assets/love-interests/hibiki/Hibiki-idle-2.png',
    './duck-quest/assets/love-interests/hibiki/Hibiki-happy.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-Ribbon.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-back-coat.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-boots.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-coat-shop.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-coat-sleeve.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-coat.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-shirt.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-shorts.png',
    './duck-quest/assets/love-interests/hibiki/Miko-Hibiki-stockings.png',
    './duck-quest/assets/love-interests/devlin/Devlin-duck.png',
    './duck-quest/assets/love-interests/devlin/Devlin-idle-1.png',
    './duck-quest/assets/love-interests/devlin/Devlin-idle-2.png',
    './duck-quest/assets/love-interests/devlin/Devlin-angry.png',
    './duck-quest/assets/love-interests/devlin/Miko-Devlin-Belt.png',
    './duck-quest/assets/love-interests/devlin/Miko-Devlin-Tie.png',
    './duck-quest/assets/love-interests/devlin/Miko-Devlin-Vest.png',
    './duck-quest/assets/love-interests/devlin/Miko-Devlin-loafers.png',
    './duck-quest/assets/love-interests/devlin/Miko-Devlin-pants.png',
    './duck-quest/assets/love-interests/devlin/Miko-Devlin-shirt.png',
    './duck-quest/assets/love-interests/devlin/Miko-bangs-pinned.png',
]
for url in add_urls:
    if url not in body:
        body += f"\n  '{url}',"
sw = sw[:precache_match.start(2)] + body + sw[precache_match.end(2):]
write('sw-v24-247.js', sw)
write('sw.js', "importScripts('./sw-v24-247.js?v=24-247');\n")

write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')
write('UPDATE-v24.247.txt',
      'Duckie Days v24.247\\n\\n'
      '- Adds Hibiki and Devlin as Miko-only love-interest encounters.\\n'
      '- Shared love-interest chance stays 5 percent total.\\n'
      '- Hibiki and Devlin each grant their duck and Miko outfit on their solo encounter.\\n'
      '- Their Rare cards unlock together from the Devlin x Hibiki reunion cutscene.\\n')

print('Installed Duckie Days v24.247.')

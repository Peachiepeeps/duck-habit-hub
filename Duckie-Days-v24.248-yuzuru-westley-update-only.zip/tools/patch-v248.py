from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.248'
TARGET_QUERY = '24-248'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')


def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old, new, 1)


def ensure_option_line(text, old_line, new_line, label):
    if new_line in text:
        return text
    if old_line not in text:
        raise RuntimeError(f'{label}: could not find expected options line')
    return text.replace(old_line, new_line, 1)


def add_duck_if_missing(text, duck_id, duck_name, duck_file, acq):
    if f'"{duck_id}": {{' in text:
        return text
    entry = f'''const DUCKS = {{
  "{duck_id}": {{
    "name": "{duck_name}",
    "file": "{duck_file}",
    "acquisition": "{acq}"
  }},'''
    return replace_once(text, 'const DUCKS = {', entry, f'register {duck_id}')


def add_after_switch_case(text, case_id, message):
    needle = f'case "{case_id}":'
    if needle in text:
        return text
    switch_anchor = '  switch (duck.acquisition) {'
    insertion = f'\n    case "{case_id}":\n      return "{message}";'
    return replace_once(text, switch_anchor, switch_anchor + insertion, f'add acquisition hint for {case_id}')


def bump_versions(text):
    text = text.replace('24.247', TARGET_VERSION)
    text = text.replace('24-247', TARGET_QUERY)
    return text


required = [
    'index.html','version.json','script-v24-201.js','duck-quest/index.html',
    'memory-game/index.html','crane-game/index.html','crane-game/play-v24-40.html',
    'trading-cards-v247.js','trading-cards-ui-v247.js','trading-cards-v247.css','sw-v24-247.js'
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.247', '24.248'}:
    raise RuntimeError(f'Expected Duckie Days v24.247, found {current!r}')

# ---------------- Assets ----------------
yuzuru_names = [
    'Yuzuru-duck.png','Yuzuru-idle-1.png','Yuzuru-idle-2.png','Yuzuru-content.png',
    'Miko-Yuzuru-bracelet.png','Miko-Yuzuru-reference.png','Miko-Yuzuru-shirt.png',
    'Miko-Yuzuru-shorts.png','Miko-Yuzuru-socks.png','Miko-Yuzuru-shoes.png'
]
for name in yuzuru_names:
    copy(f'assets/yuzuru/{name}', f'duck-quest/assets/love-interests/yuzuru/{name}')
for name in ['Miko-Yuzuru-bracelet.png','Miko-Yuzuru-reference.png','Miko-Yuzuru-shirt.png','Miko-Yuzuru-shorts.png','Miko-Yuzuru-socks.png','Miko-Yuzuru-shoes.png']:
    copy(f'assets/yuzuru/{name}', f'assets/miko/{name}')

westley_names = [
    'Westley-duck.png','Westley-idle-1.png','Westley-idle-2.png','Westley-happy.png',
    'Miko-Westley-reference.png','Miko-Westley-top.png','Miko-Westley-Jacket.png','Miko-Westley-Jacket-shop.png',
    'Miko-Westley-sleeve.png','Miko-Westley-pants.png','Miko-Westley-boots.png','Miko-Westley-Face-makeup.png'
]
for name in westley_names:
    copy(f'assets/westley/{name}', f'duck-quest/assets/love-interests/westley/{name}')
for name in ['Miko-Westley-reference.png','Miko-Westley-top.png','Miko-Westley-Jacket.png','Miko-Westley-Jacket-shop.png','Miko-Westley-sleeve.png','Miko-Westley-pants.png','Miko-Westley-boots.png','Miko-Westley-Face-makeup.png']:
    copy(f'assets/westley/{name}', f'assets/miko/{name}')

copy('love-interests-v248.js', 'duck-quest/js/love-interests-v248.js')
copy('love-interests-v248.css', 'duck-quest/css/love-interests-v248.css')

# ---------------- Trading cards ----------------
tc = read('trading-cards-v247.js')
if 'id:"r-love-yuzuru"' not in tc or 'id:"r-love-westley"' not in tc:
    anchor = '  const byId=Object.fromEntries(cards.map(card=>[card.id,card]));'
    addition = (
        '  cards.push({id:"r-love-yuzuru",characterId:"yuzuru",name:"Yuzuru",art:"love-interests/yuzuru/Yuzuru-idle-1.png",rarity:"rare",number:"R-036",category:"Miko Love Interest",hint:"Witness Westley and Yuzuru\'s reunion while exploring Duck Quest as Miko."});\n'
        '  cards.push({id:"r-love-westley",characterId:"westley",name:"Westley",art:"love-interests/westley/Westley-idle-1.png",rarity:"rare",number:"R-037",category:"Miko Love Interest",hint:"Witness Westley and Yuzuru\'s reunion while exploring Duck Quest as Miko."});\n'
    )
    tc = replace_once(tc, anchor, addition + anchor, 'insert Yuzuru and Westley rare cards')
write('trading-cards-v248.js', tc)

ui = read('trading-cards-ui-v247.js')
ui = re.sub(r'window\.DUCKIE_TRADING_CARD_UI_BUILD="[^"]+";', 'window.DUCKIE_TRADING_CARD_UI_BUILD="24.248";', ui)
write('trading-cards-ui-v248.js', ui)
css = read('trading-cards-v247.css')
write('trading-cards-v248.css', css)

# ---------------- Hub / Duckipedia / Miko closet ----------------
hub = read('script-v24-201.js')

hub = add_duck_if_missing(hub, 'yuzuru-duck', 'Yuzuru Duck', 'duck-quest/assets/love-interests/yuzuru/Yuzuru-duck.png', 'love-interest-yuzuru')
hub = add_duck_if_missing(hub, 'westley-duck', 'Westley Duck', 'duck-quest/assets/love-interests/westley/Westley-duck.png', 'love-interest-westley')

hub = add_after_switch_case(hub, 'love-interest-yuzuru', 'Meet Yuzuru while exploring Duck Quest as Miko to unlock this special duck.')
hub = add_after_switch_case(hub, 'love-interest-westley', 'Meet Westley while exploring Duck Quest as Miko to unlock this special duck.')

gacha_old = 'const GACHA_EXCLUDED_DUCKS = new Set(["tiny-duck", "tiny-duck-stack", "pile-of-tiny-ducks", "lukio-duck", "shinobu-duck", "cheryln-duck", "hibiki-duck", "devlin-duck"]);'
gacha_new = 'const GACHA_EXCLUDED_DUCKS = new Set(["tiny-duck", "tiny-duck-stack", "pile-of-tiny-ducks", "lukio-duck", "shinobu-duck", "cheryln-duck", "hibiki-duck", "devlin-duck", "yuzuru-duck", "westley-duck"]);'
if gacha_new not in hub:
    if gacha_old not in hub:
        raise RuntimeError('Could not locate GACHA_EXCLUDED_DUCKS.')
    hub = hub.replace(gacha_old, gacha_new, 1)

if '"yuzuru-shirt"' not in hub:
    asset_anchor = 'const MIKO_ASSETS = {'
    asset_entries = '''const MIKO_ASSETS = {
  "yuzuru-shirt": { label: "Yuzuru Set · Shirt", file: "Miko-Yuzuru-shirt.png", z: 34 },
  "yuzuru-shorts": { label: "Yuzuru Set · Shorts", file: "Miko-Yuzuru-shorts.png", z: 31 },
  "yuzuru-socks": { label: "Yuzuru Set · Socks", file: "Miko-Yuzuru-socks.png", z: 29 },
  "yuzuru-shoes": { label: "Yuzuru Set · Shoes", file: "Miko-Yuzuru-shoes.png", z: 39 },
  "yuzuru-bracelet": { label: "Yuzuru Set · Bracelet", file: "Miko-Yuzuru-bracelet.png", z: 55 },
  "westley-top": { label: "Westley Set · Top", file: "Miko-Westley-top.png", z: 24 },
  "westley-jacket": { label: "Westley Set · Jacket", file: "Miko-Westley-Jacket.png", previewFile: "Miko-Westley-Jacket-shop.png", z: 34 },
  "westley-sleeve": { label: "Westley Set · Sleeve", file: "Miko-Westley-sleeve.png", z: 37 },
  "westley-pants": { label: "Westley Set · Pants", file: "Miko-Westley-pants.png", z: 31 },
  "westley-boots": { label: "Westley Set · Boots", file: "Miko-Westley-boots.png", z: 39 },
  "westley-face-makeup": { label: "Westley Set · Face Makeup", file: "Miko-Westley-Face-makeup.png", z: 52 },'''
    hub = replace_once(hub, asset_anchor, asset_entries, 'add Yuzuru and Westley outfit assets')

hub = ensure_option_line(
    hub,
    'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest"]',
    'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "yuzuru-shirt", "westley-jacket"]',
    'outer options'
)
hub = ensure_option_line(
    hub,
    'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants"]',
    'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants", "yuzuru-shorts", "westley-pants"]',
    'bottom options'
)
hub = ensure_option_line(
    hub,
    'options: ["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings"]',
    'options: ["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings", "yuzuru-socks"]',
    'socks options'
)
hub = ensure_option_line(
    hub,
    'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers"]',
    'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers", "yuzuru-shoes", "westley-boots"]',
    'shoe options'
)

hub = hub.replace(
    '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest"].includes(outer)',
    '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "yuzuru-shirt", "westley-jacket"].includes(outer)'
)
hub = hub.replace(
    '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants"].includes(incoming.bottom)',
    '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants", "yuzuru-shorts", "westley-pants"].includes(incoming.bottom)'
)
hub = hub.replace(
    '["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings"].includes(incoming.socks)',
    '["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings", "yuzuru-socks"].includes(incoming.socks)'
)
hub = hub.replace(
    '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers"].includes(incoming.shoes)',
    '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers", "yuzuru-shoes", "westley-boots"].includes(incoming.shoes)'
)

helper_anchor = '  else if (outfit.outer === "devlin-vest") ids.push("devlin-shirt", "devlin-tie", "devlin-bangs-pinned");'
helper_new = helper_anchor + '\n  else if (outfit.outer === "yuzuru-shirt") ids.push("yuzuru-bracelet");\n  else if (outfit.outer === "westley-jacket") ids.push("westley-top", "westley-sleeve", "westley-face-makeup");'
if 'outfit.outer === "yuzuru-shirt"' not in hub:
    hub = replace_once(hub, helper_anchor, helper_new, 'add Yuzuru and Westley helper layers')

hub = re.sub(r'crane-game/\?v=24-247', 'crane-game/?v=24-248', hub)
write('script-v24-201.js', hub)

# ---------------- Page references ----------------
def patch_page(rel):
    text = read(rel)
    text = text.replace('trading-cards-v247.js', 'trading-cards-v248.js')
    text = text.replace('trading-cards-ui-v247.js', 'trading-cards-ui-v248.js')
    text = text.replace('trading-cards-v247.css', 'trading-cards-v248.css')
    text = text.replace('love-interests-v247.js', 'love-interests-v248.js')
    text = text.replace('love-interests-v247.css', 'love-interests-v248.css')
    text = bump_versions(text)
    write(rel, text)

for rel in ['index.html', 'memory-game/index.html', 'crane-game/index.html', 'crane-game/play-v24-40.html', 'duck-quest/index.html']:
    patch_page(rel)

quest = read('duck-quest/index.html')
quest = re.sub(r'\s*<link[^>]+love-interests-v24[0-9]+\.css[^>]*>\s*', '\n', quest)
quest = re.sub(r'\s*<link[^>]+love-interests-v247\.css[^>]*>\s*', '\n', quest)
quest = re.sub(r'\s*<link[^>]+love-interests-v248\.css[^>]*>\s*', '\n', quest)
quest = re.sub(r'\s*<script[^>]+love-interests-v24[0-9]+\.js[^>]*></script>\s*', '\n', quest)
quest = re.sub(r'\s*<script[^>]+love-interests-v247\.js[^>]*></script>\s*', '\n', quest)
quest = re.sub(r'\s*<script[^>]+love-interests-v248\.js[^>]*></script>\s*', '\n', quest)
if 'css/love-interests-v248.css' not in quest:
    quest = quest.replace('</head>', '  <link rel="stylesheet" href="css/love-interests-v248.css?v=24-248">\n</head>', 1)
if 'js/love-interests-v248.js' not in quest:
    quest = quest.replace('</body>', '  <script src="js/love-interests-v248.js?v=24-248"></script>\n</body>', 1)
write('duck-quest/index.html', quest)

# ---------------- Service worker ----------------
sw = read('sw-v24-247.js')
sw = bump_versions(sw)
sw = sw.replace('trading-cards-v247.js', 'trading-cards-v248.js')
sw = sw.replace('trading-cards-ui-v247.js', 'trading-cards-ui-v248.js')
sw = sw.replace('trading-cards-v247.css', 'trading-cards-v248.css')
sw = sw.replace('./sw-v24-247.js', './sw-v24-248.js')
sw = sw.replace('love-interests-v247.js', 'love-interests-v248.js')
sw = sw.replace('love-interests-v247.css', 'love-interests-v248.css')

precache_match = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not precache_match:
    raise RuntimeError('Could not locate service-worker precache array.')
body = precache_match.group(2)
add_urls = [
    './trading-cards-v248.js?v=24-248',
    './trading-cards-ui-v248.js?v=24-248',
    './trading-cards-v248.css?v=24-248',
    './duck-quest/js/love-interests-v248.js?v=24-248',
    './duck-quest/css/love-interests-v248.css?v=24-248',
    './duck-quest/assets/love-interests/yuzuru/Yuzuru-duck.png',
    './duck-quest/assets/love-interests/yuzuru/Yuzuru-idle-1.png',
    './duck-quest/assets/love-interests/yuzuru/Yuzuru-idle-2.png',
    './duck-quest/assets/love-interests/yuzuru/Yuzuru-content.png',
    './duck-quest/assets/love-interests/yuzuru/Miko-Yuzuru-bracelet.png',
    './duck-quest/assets/love-interests/yuzuru/Miko-Yuzuru-shirt.png',
    './duck-quest/assets/love-interests/yuzuru/Miko-Yuzuru-shorts.png',
    './duck-quest/assets/love-interests/yuzuru/Miko-Yuzuru-socks.png',
    './duck-quest/assets/love-interests/yuzuru/Miko-Yuzuru-shoes.png',
    './duck-quest/assets/love-interests/westley/Westley-duck.png',
    './duck-quest/assets/love-interests/westley/Westley-idle-1.png',
    './duck-quest/assets/love-interests/westley/Westley-idle-2.png',
    './duck-quest/assets/love-interests/westley/Westley-happy.png',
    './duck-quest/assets/love-interests/westley/Miko-Westley-top.png',
    './duck-quest/assets/love-interests/westley/Miko-Westley-Jacket.png',
    './duck-quest/assets/love-interests/westley/Miko-Westley-Jacket-shop.png',
    './duck-quest/assets/love-interests/westley/Miko-Westley-sleeve.png',
    './duck-quest/assets/love-interests/westley/Miko-Westley-pants.png',
    './duck-quest/assets/love-interests/westley/Miko-Westley-boots.png',
    './duck-quest/assets/love-interests/westley/Miko-Westley-Face-makeup.png',
]
for url in add_urls:
    if url not in body:
        body += f"\n  '{url}',"
sw = sw[:precache_match.start(2)] + body + sw[precache_match.end(2):]
write('sw-v24-248.js', sw)
write('sw.js', "importScripts('./sw-v24-248.js?v=24-248');\n")

write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')
write('UPDATE-v24.248.txt',
      'Duckie Days v24.248\\n\\n'
      '- Adds Yuzuru and Westley as Miko-only love-interest encounters.\\n'
      '- Shared love-interest chance stays 5 percent total.\\n'
      '- Yuzuru and Westley each grant their duck and Miko outfit on their solo encounter.\\n'
      '- Their Rare cards unlock together from the Westley x Yuzuru reunion cutscene.\\n')

print('Installed Duckie Days v24.248.')

from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.249'
TARGET_QUERY = '24-249'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')


def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old, new, 1)


def ensure_option_line(text, old_line, new_line, label):
    if new_line in text:
        return text
    if old_line not in text:
        raise RuntimeError(f'{label}: could not find expected options line')
    return text.replace(old_line, new_line, 1)


def add_duck_if_missing(text, duck_id, duck_name, duck_file, acq):
    if f'"{duck_id}": {{' in text:
        return text
    entry = f'''const DUCKS = {{
  "{duck_id}": {{
    "name": "{duck_name}",
    "file": "{duck_file}",
    "acquisition": "{acq}"
  }},'''
    return replace_once(text, 'const DUCKS = {', entry, f'register {duck_id}')


def add_after_switch_case(text, case_id, message):
    needle = f'case "{case_id}":'
    if needle in text:
        return text
    switch_anchor = '  switch (duck.acquisition) {'
    insertion = f'\n    case "{case_id}":\n      return "{message}";'
    return replace_once(text, switch_anchor, switch_anchor + insertion, f'add acquisition hint for {case_id}')


def bump_versions(text):
    text = text.replace('24.248', TARGET_VERSION)
    text = text.replace('24-248', TARGET_QUERY)
    return text


required = [
    'index.html','version.json','script-v24-201.js','duck-quest/index.html',
    'memory-game/index.html','crane-game/index.html','crane-game/play-v24-40.html',
    'trading-cards-v248.js','trading-cards-ui-v248.js','trading-cards-v248.css','sw-v24-248.js'
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.248', '24.249'}:
    raise RuntimeError(f'Expected Duckie Days v24.248, found {current!r}')

# ---------------- Assets ----------------
circe_names = [
    'Circe-duck.png','Circe-idle-1.png','Circe-idle-2.png','Circe-happy.png',
    'Miko-circe-reference.png','Miko-circe-tank-top.png','Miko-circe-sweater.png','Miko-circe-sweater-shop.png',
    'Miko-circe-sleeve.png','Miko-circe-shorts.png','Miko-circe-stockings.png','Miko-circe-shoes.png','Miko-circe-choker.png'
]
for name in circe_names:
    copy(f'assets/circe/{name}', f'duck-quest/assets/love-interests/circe/{name}')
for name in ['Miko-circe-reference.png','Miko-circe-tank-top.png','Miko-circe-sweater.png','Miko-circe-sweater-shop.png','Miko-circe-sleeve.png','Miko-circe-shorts.png','Miko-circe-stockings.png','Miko-circe-shoes.png','Miko-circe-choker.png']:
    copy(f'assets/circe/{name}', f'assets/miko/{name}')

quin_names = [
    'Quin-duck.png','Quin-idle-1.png','Quin-idle-2.png','Quin-threaten.png',
    'Miko-Quin-Reference.png','Miko-Quin-shirt.png','Miko-Quin-jacket.png','Miko-Quin-jacket-shop.png',
    'Miko-Quin-back-jacket.png','Miko-Quin-sleeve.png','Miko-Quin-shorts.png','Miko-Quin-boots.png','Miko-Quin-Hairpins.png'
]
for name in quin_names:
    copy(f'assets/quin/{name}', f'duck-quest/assets/love-interests/quin/{name}')
for name in ['Miko-Quin-Reference.png','Miko-Quin-shirt.png','Miko-Quin-jacket.png','Miko-Quin-jacket-shop.png','Miko-Quin-back-jacket.png','Miko-Quin-sleeve.png','Miko-Quin-shorts.png','Miko-Quin-boots.png','Miko-Quin-Hairpins.png']:
    copy(f'assets/quin/{name}', f'assets/miko/{name}')

copy('love-interests-v249.js', 'duck-quest/js/love-interests-v249.js')
copy('love-interests-v249.css', 'duck-quest/css/love-interests-v249.css')

# ---------------- Trading cards ----------------
tc = read('trading-cards-v248.js')
if 'id:"r-love-circe"' not in tc or 'id:"r-love-quin"' not in tc:
    anchor = '  const byId=Object.fromEntries(cards.map(card=>[card.id,card]));'
    addition = (
        '  cards.push({id:"r-love-circe",characterId:"circe",name:"Circe",art:"love-interests/circe/Circe-idle-1.png",rarity:"rare",number:"R-038",category:"Miko Love Interest",hint:"Witness Circe and Quin\'s reunion while exploring Duck Quest as Miko."});\n'
        '  cards.push({id:"r-love-quin",characterId:"quin",name:"Quin",art:"love-interests/quin/Quin-idle-1.png",rarity:"rare",number:"R-039",category:"Miko Love Interest",hint:"Witness Circe and Quin\'s reunion while exploring Duck Quest as Miko."});\n'
    )
    tc = replace_once(tc, anchor, addition + anchor, 'insert Circe and Quin rare cards')
write('trading-cards-v249.js', tc)

ui = read('trading-cards-ui-v248.js')
ui = re.sub(r'window\.DUCKIE_TRADING_CARD_UI_BUILD="[^"]+";', 'window.DUCKIE_TRADING_CARD_UI_BUILD="24.249";', ui)
write('trading-cards-ui-v249.js', ui)
write('trading-cards-v249.css', read('trading-cards-v248.css'))

# ---------------- Hub / Duckipedia / Miko closet ----------------
hub = read('script-v24-201.js')

hub = add_duck_if_missing(hub, 'circe-duck', 'Circe Duck', 'duck-quest/assets/love-interests/circe/Circe-duck.png', 'love-interest-circe')
hub = add_duck_if_missing(hub, 'quin-duck', 'Quin Duck', 'duck-quest/assets/love-interests/quin/Quin-duck.png', 'love-interest-quin')

hub = add_after_switch_case(hub, 'love-interest-circe', 'Meet Circe while exploring Duck Quest as Miko to unlock this special duck.')
hub = add_after_switch_case(hub, 'love-interest-quin', 'Meet Quin while exploring Duck Quest as Miko to unlock this special duck.')

gacha_old = 'const GACHA_EXCLUDED_DUCKS = new Set(["tiny-duck", "tiny-duck-stack", "pile-of-tiny-ducks", "lukio-duck", "shinobu-duck", "cheryln-duck", "hibiki-duck", "devlin-duck", "yuzuru-duck", "westley-duck"]);'
gacha_new = 'const GACHA_EXCLUDED_DUCKS = new Set(["tiny-duck", "tiny-duck-stack", "pile-of-tiny-ducks", "lukio-duck", "shinobu-duck", "cheryln-duck", "hibiki-duck", "devlin-duck", "yuzuru-duck", "westley-duck", "circe-duck", "quin-duck"]);'
if gacha_new not in hub:
    if gacha_old not in hub:
        raise RuntimeError('Could not locate GACHA_EXCLUDED_DUCKS.')
    hub = hub.replace(gacha_old, gacha_new, 1)

if '"circe-tank-top"' not in hub:
    asset_anchor = 'const MIKO_ASSETS = {'
    asset_entries = '''const MIKO_ASSETS = {
  "circe-tank-top": { label: "Circe Set · Tank Top", file: "Miko-circe-tank-top.png", z: 24 },
  "circe-sweater": { label: "Circe Set · Sweater", file: "Miko-circe-sweater.png", previewFile: "Miko-circe-sweater-shop.png", z: 34 },
  "circe-sleeve": { label: "Circe Set · Sleeve", file: "Miko-circe-sleeve.png", z: 37 },
  "circe-shorts": { label: "Circe Set · Shorts", file: "Miko-circe-shorts.png", z: 31 },
  "circe-stockings": { label: "Circe Set · Stockings", file: "Miko-circe-stockings.png", z: 29 },
  "circe-shoes": { label: "Circe Set · Shoes", file: "Miko-circe-shoes.png", z: 39 },
  "circe-choker": { label: "Circe Set · Choker", file: "Miko-circe-choker.png", z: 55 },
  "quin-shirt": { label: "Quin Set · Shirt", file: "Miko-Quin-shirt.png", z: 24 },
  "quin-jacket": { label: "Quin Set · Jacket", file: "Miko-Quin-jacket.png", previewFile: "Miko-Quin-jacket-shop.png", z: 34 },
  "quin-back-jacket": { label: "Quin Set · Back Jacket", file: "Miko-Quin-back-jacket.png", z: 22 },
  "quin-sleeve": { label: "Quin Set · Sleeve", file: "Miko-Quin-sleeve.png", z: 37 },
  "quin-shorts": { label: "Quin Set · Shorts", file: "Miko-Quin-shorts.png", z: 31 },
  "quin-boots": { label: "Quin Set · Boots", file: "Miko-Quin-boots.png", z: 39 },
  "quin-hairpins": { label: "Quin Set · Hairpins", file: "Miko-Quin-Hairpins.png", z: 55 },'''
    hub = replace_once(hub, asset_anchor, asset_entries, 'add Circe and Quin outfit assets')

hub = ensure_option_line(
    hub,
    'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "yuzuru-shirt", "westley-jacket"]',
    'options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "yuzuru-shirt", "westley-jacket", "circe-sweater", "quin-jacket"]',
    'outer options'
)
hub = ensure_option_line(
    hub,
    'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants", "yuzuru-shorts", "westley-pants"]',
    'options: ["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants", "yuzuru-shorts", "westley-pants", "circe-shorts", "quin-shorts"]',
    'bottom options'
)
hub = ensure_option_line(
    hub,
    'options: ["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings", "yuzuru-socks"]',
    'options: ["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings", "yuzuru-socks", "circe-stockings"]',
    'socks options'
)
hub = ensure_option_line(
    hub,
    'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers", "yuzuru-shoes", "westley-boots"]',
    'options: ["shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers", "yuzuru-shoes", "westley-boots", "circe-shoes", "quin-boots"]',
    'shoe options'
)

hub = hub.replace(
    '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "yuzuru-shirt", "westley-jacket"].includes(outer)',
    '[null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "yuzuru-shirt", "westley-jacket", "circe-sweater", "quin-jacket"].includes(outer)'
)
hub = hub.replace(
    '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants", "yuzuru-shorts", "westley-pants"].includes(incoming.bottom)',
    '["bottom-capris", "bottom-jeans", "bottom-boxers", "bottom-shorts", "lukio-shorts", "shino-jeans", "cheryln-shorts", "hibiki-shorts", "devlin-pants", "yuzuru-shorts", "westley-pants", "circe-shorts", "quin-shorts"].includes(incoming.bottom)'
)
hub = hub.replace(
    '["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings", "yuzuru-socks"].includes(incoming.socks)',
    '["socks", "socks-garter", "lukio-socks", "cheryln-tights", "hibiki-stockings", "yuzuru-socks", "circe-stockings"].includes(incoming.socks)'
)
hub = hub.replace(
    '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers", "yuzuru-shoes", "westley-boots"].includes(incoming.shoes)',
    '[null, "shoes-loafer", "shoes-fancy-loafers", "lukio-booties", "shino-boots", "cheryln-boots", "hibiki-boots", "devlin-loafers", "yuzuru-shoes", "westley-boots", "circe-shoes", "quin-boots"].includes(incoming.shoes)'
)

helper_anchor = '  else if (outfit.outer === "westley-jacket") ids.push("westley-top", "westley-sleeve", "westley-face-makeup");'
helper_new = helper_anchor + '\n  else if (outfit.outer === "circe-sweater") ids.push("circe-tank-top", "circe-sleeve", "circe-choker");\n  else if (outfit.outer === "quin-jacket") ids.push("quin-back-jacket", "quin-shirt", "quin-sleeve", "quin-hairpins");'
if 'outfit.outer === "circe-sweater"' not in hub:
    hub = replace_once(hub, helper_anchor, helper_new, 'add Circe and Quin helper layers')

hub = re.sub(r'crane-game/\?v=24-248', 'crane-game/?v=24-249', hub)
write('script-v24-201.js', hub)

# ---------------- Page references ----------------
def patch_page(rel):
    text = read(rel)
    text = text.replace('trading-cards-v248.js', 'trading-cards-v249.js')
    text = text.replace('trading-cards-ui-v248.js', 'trading-cards-ui-v249.js')
    text = text.replace('trading-cards-v248.css', 'trading-cards-v249.css')
    text = text.replace('love-interests-v248.js', 'love-interests-v249.js')
    text = text.replace('love-interests-v248.css', 'love-interests-v249.css')
    text = bump_versions(text)
    write(rel, text)

for rel in ['index.html', 'memory-game/index.html', 'crane-game/index.html', 'crane-game/play-v24-40.html', 'duck-quest/index.html']:
    patch_page(rel)

quest = read('duck-quest/index.html')
quest = re.sub(r'\s*<link[^>]+love-interests-v24[0-9]+\.css[^>]*>\s*', '\n', quest)
quest = re.sub(r'\s*<script[^>]+love-interests-v24[0-9]+\.js[^>]*></script>\s*', '\n', quest)
if 'css/love-interests-v249.css' not in quest:
    quest = quest.replace('</head>', '  <link rel="stylesheet" href="css/love-interests-v249.css?v=24-249">\n</head>', 1)
if 'js/love-interests-v249.js' not in quest:
    quest = quest.replace('</body>', '  <script src="js/love-interests-v249.js?v=24-249"></script>\n</body>', 1)
write('duck-quest/index.html', quest)

# ---------------- Service worker ----------------
sw = read('sw-v24-248.js')
sw = bump_versions(sw)
sw = sw.replace('trading-cards-v248.js', 'trading-cards-v249.js')
sw = sw.replace('trading-cards-ui-v248.js', 'trading-cards-ui-v249.js')
sw = sw.replace('trading-cards-v248.css', 'trading-cards-v249.css')
sw = sw.replace('./sw-v24-248.js', './sw-v24-249.js')
sw = sw.replace('love-interests-v248.js', 'love-interests-v249.js')
sw = sw.replace('love-interests-v248.css', 'love-interests-v249.css')

precache_match = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not precache_match:
    raise RuntimeError('Could not locate service-worker precache array.')
body = precache_match.group(2)
add_urls = [
    './trading-cards-v249.js?v=24-249',
    './trading-cards-ui-v249.js?v=24-249',
    './trading-cards-v249.css?v=24-249',
    './duck-quest/js/love-interests-v249.js?v=24-249',
    './duck-quest/css/love-interests-v249.css?v=24-249',
    './duck-quest/assets/love-interests/circe/Circe-duck.png',
    './duck-quest/assets/love-interests/circe/Circe-idle-1.png',
    './duck-quest/assets/love-interests/circe/Circe-idle-2.png',
    './duck-quest/assets/love-interests/circe/Circe-happy.png',
    './duck-quest/assets/love-interests/circe/Miko-circe-tank-top.png',
    './duck-quest/assets/love-interests/circe/Miko-circe-sweater.png',
    './duck-quest/assets/love-interests/circe/Miko-circe-sweater-shop.png',
    './duck-quest/assets/love-interests/circe/Miko-circe-sleeve.png',
    './duck-quest/assets/love-interests/circe/Miko-circe-shorts.png',
    './duck-quest/assets/love-interests/circe/Miko-circe-stockings.png',
    './duck-quest/assets/love-interests/circe/Miko-circe-shoes.png',
    './duck-quest/assets/love-interests/circe/Miko-circe-choker.png',
    './duck-quest/assets/love-interests/quin/Quin-duck.png',
    './duck-quest/assets/love-interests/quin/Quin-idle-1.png',
    './duck-quest/assets/love-interests/quin/Quin-idle-2.png',
    './duck-quest/assets/love-interests/quin/Quin-threaten.png',
    './duck-quest/assets/love-interests/quin/Miko-Quin-shirt.png',
    './duck-quest/assets/love-interests/quin/Miko-Quin-jacket.png',
    './duck-quest/assets/love-interests/quin/Miko-Quin-jacket-shop.png',
    './duck-quest/assets/love-interests/quin/Miko-Quin-back-jacket.png',
    './duck-quest/assets/love-interests/quin/Miko-Quin-sleeve.png',
    './duck-quest/assets/love-interests/quin/Miko-Quin-shorts.png',
    './duck-quest/assets/love-interests/quin/Miko-Quin-boots.png',
    './duck-quest/assets/love-interests/quin/Miko-Quin-Hairpins.png',
]
for url in add_urls:
    if url not in body:
        body += f"\n  '{url}',"
sw = sw[:precache_match.start(2)] + body + sw[precache_match.end(2):]
write('sw-v24-249.js', sw)
write('sw.js', "importScripts('./sw-v24-249.js?v=24-249');\n")

write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')
write('UPDATE-v24.249.txt',
      'Duckie Days v24.249\\n\\n'
      '- Adds Circe and Quin as Miko-only love-interest encounters.\\n'
      '- Shared love-interest chance stays 5 percent total.\\n'
      '- Circe and Quin each grant their duck and Miko outfit on their solo encounter.\\n'
      '- Their Rare cards unlock together from the Circe x Quin reunion cutscene.\\n')

print('Installed Duckie Days v24.249.')

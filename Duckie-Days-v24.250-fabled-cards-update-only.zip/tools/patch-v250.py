from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.250'
TARGET_QUERY = '24-250'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')


def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old, new, 1)


def bump_versions(text):
    text = text.replace('24.249', TARGET_VERSION)
    text = text.replace('24-249', TARGET_QUERY)
    return text


required = [
    'index.html','version.json','trading-cards-v249.js','trading-cards-ui-v249.js','trading-cards-v249.css',
    'duck-quest/index.html','memory-game/index.html','crane-game/index.html','crane-game/play-v24-40.html','sw-v24-249.js'
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.249', '24.250'}:
    raise RuntimeError(f'Expected Duckie Days v24.249, found {current!r}')

# ---------------- New Fabled full-art assets ----------------
for name in ['F-peep.png','F-io.png','F-annika.png','F-miho.png','F-shinobu-cheryln.png']:
    copy(f'assets/fabled/{name}', f'duck-quest/assets/trading-cards/fabled/{name}')

# ---------------- Trading-card data ----------------
tc = read('trading-cards-v249.js')
old_fabled = '''  const fabled=[
    ["slime-kitty","Slime Kitty","trading-cards/fabled/F-slime-kitty.png","Fabled"],
    ["acorn-mouse","Acorn Mouse","trading-cards/fabled/F-acorn-mouse.png","Fabled"],
    ["bee","Bee","trading-cards/fabled/F-bee.png","Fabled"],
    ["flower","Flower","trading-cards/fabled/F-flower.png","Fabled"],
    ["mimic","Mimic","trading-cards/fabled/F-mimic.png","Fabled"]
  ];'''
new_fabled = '''  const fabled=[
    ["slime-kitty","Slime Kitty","trading-cards/fabled/F-slime-kitty.png","Fabled"],
    ["acorn-mouse","Acorn Mouse","trading-cards/fabled/F-acorn-mouse.png","Fabled"],
    ["bee","Bee","trading-cards/fabled/F-bee.png","Fabled"],
    ["flower","Flower","trading-cards/fabled/F-flower.png","Fabled"],
    ["mimic","Mimic","trading-cards/fabled/F-mimic.png","Fabled"],
    ["peep","Peep","trading-cards/fabled/F-peep.png","Fabled"],
    ["io","Io","trading-cards/fabled/F-io.png","Fabled"],
    ["annika","Annika","trading-cards/fabled/F-annika.png","Fabled"],
    ["miho","Miho","trading-cards/fabled/F-miho.png","Fabled"],
    ["shinobu-cheryln","Shinobu x Cheryln","trading-cards/fabled/F-shinobu-cheryln.png","Fabled"]
  ];'''
if 'F-shinobu-cheryln.png' not in tc:
    tc = replace_once(tc, old_fabled, new_fabled, 'extend Fabled card list')
write('trading-cards-v250.js', tc)

# ---------------- Duckipedia card ordering ----------------
ui = read('trading-cards-ui-v249.js')
old_sort = '.sort((a,b)=>Number(isFavorite(b.id))-Number(isFavorite(a.id))||TC.order[b.rarity]-TC.order[a.rarity]||a.number.localeCompare(b.number));'
new_sort = '.sort((a,b)=>TC.order[a.rarity]-TC.order[b.rarity]||Number(isFavorite(b.id))-Number(isFavorite(a.id))||a.number.localeCompare(b.number));'
if new_sort not in ui:
    ui = replace_once(ui, old_sort, new_sort, 'change Duckipedia cards to Common-through-Fabled order')
ui = re.sub(r'window\.DUCKIE_TRADING_CARD_UI_BUILD="[^"]+";', 'window.DUCKIE_TRADING_CARD_UI_BUILD="24.250";', ui)
write('trading-cards-ui-v250.js', ui)
write('trading-cards-v250.css', read('trading-cards-v249.css'))

# ---------------- Page references ----------------
def patch_page(rel):
    text = read(rel)
    text = text.replace('trading-cards-v249.js', 'trading-cards-v250.js')
    text = text.replace('trading-cards-ui-v249.js', 'trading-cards-ui-v250.js')
    text = text.replace('trading-cards-v249.css', 'trading-cards-v250.css')
    text = bump_versions(text)
    write(rel, text)

for rel in ['index.html','duck-quest/index.html','memory-game/index.html','crane-game/index.html','crane-game/play-v24-40.html']:
    patch_page(rel)

# The hub comment says this is a stable service-worker URL, but v24.249 still
# pointed at an old versioned file that cleanup removes. Use sw.js as intended.
index = read('index.html')
index = re.sub(
    r'navigator\.serviceWorker\.register\("\.\/sw-v24-244\.js\?v=24-250",',
    'navigator.serviceWorker.register("./sw.js?v=24-250",',
    index,
    count=1,
)
write('index.html', index)

# ---------------- Service worker ----------------
sw = read('sw-v24-249.js')
sw = bump_versions(sw)
sw = sw.replace('trading-cards-v249.js', 'trading-cards-v250.js')
sw = sw.replace('trading-cards-ui-v249.js', 'trading-cards-ui-v250.js')
sw = sw.replace('trading-cards-v249.css', 'trading-cards-v250.css')
sw = sw.replace('./sw-v24-249.js', './sw-v24-250.js')

precache_match = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not precache_match:
    raise RuntimeError('Could not locate service-worker precache array.')
body = precache_match.group(2)
add_urls = [
    './trading-cards-v250.js?v=24-250',
    './trading-cards-ui-v250.js?v=24-250',
    './trading-cards-v250.css?v=24-250',
    './duck-quest/assets/trading-cards/fabled/F-peep.png',
    './duck-quest/assets/trading-cards/fabled/F-io.png',
    './duck-quest/assets/trading-cards/fabled/F-annika.png',
    './duck-quest/assets/trading-cards/fabled/F-miho.png',
    './duck-quest/assets/trading-cards/fabled/F-shinobu-cheryln.png',
]
for url in add_urls:
    if url not in body:
        body += f"\n  '{url}',"
sw = sw[:precache_match.start(2)] + body + sw[precache_match.end(2):]
write('sw-v24-250.js', sw)
write('sw.js', "importScripts('./sw-v24-250.js?v=24-250');\n")

write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')
write('UPDATE-v24.250.txt',
      'Duckie Days v24.250\\n\\n'
      '- Adds five new finished full-art Fabled Trading Cards: Peep, Io, Annika, Miho, and Shinobu x Cheryln.\\n'
      '- Duckipedia Trading Cards now sort Common, Uncommon, Rare, then Fabled.\\n'
      '- Favorites remain grouped within each rarity instead of jumping ahead of lower rarities.\\n'
      '- Repairs the hub service-worker registration to use the stable sw.js entry point.\\n')

print('Installed Duckie Days v24.250.')

from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = "24.251"
TARGET_QUERY = "24-251"


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")


def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old, new, 1)


def bump(text):
    return text.replace("24.250", TARGET_VERSION).replace("24-250", TARGET_QUERY)


required = [
    "version.json", "index.html", "script-v24-201.js", "duck-quest/index.html",
    "duck-quest/js/game-v96.js", "memory-game/index.html", "crane-game/index.html",
    "crane-game/play-v24-40.html", "sw-v24-250.js", "sw.js",
    "trading-cards-v250.js", "trading-cards-ui-v250.js", "trading-cards-v250.css"
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError("Missing required files: " + ", ".join(missing))

current = str(json.loads(read("version.json")).get("version"))
if current not in {"24.250", "24.251"}:
    raise RuntimeError(f"Expected Duckie Days v24.250, found {current!r}")

# New love-interest battlefield runtime.
copy("love-interests-v251.js", "duck-quest/js/love-interests-v251.js")
copy("love-interests-v251.css", "duck-quest/css/love-interests-v251.css")

# ---------------------------------------------------------------------------
# Duck Quest: make love-interest rewards merge into the live in-memory hubSave
# before persistAll(). This fixes rewards being immediately overwritten after
# the cutscene continues into the next encounter.
# ---------------------------------------------------------------------------
game = read("duck-quest/js/game-v96.js")
bridge_marker = "window.DuckieQuestLoveRewardSync = function(incoming)"
if bridge_marker not in game:
    anchor = "\nfunction clampInt(value,min,max,fallback) {"
    if anchor not in game:
        raise RuntimeError("Could not locate post-persistAll insertion point in game-v96.js")
    bridge = r'''

// v24.251 — Love-interest reward bridge. The love-interest runtime lives in a
// separate script, while Duck Quest keeps an in-memory hubSave object. Merge
// only the reward-bearing fields here so a subsequent persistAll() cannot
// overwrite a freshly-earned duck, outfit, or Trading Card.
window.DuckieQuestLoveRewardSync = function(incoming){
  try{
    if(!incoming || typeof incoming!=="object") return false;

    if(!hubSave.loveInterests || typeof hubSave.loveInterests!=="object") hubSave.loveInterests={};
    for(const [id,state] of Object.entries(incoming.loveInterests||{})){
      if(!state || typeof state!=="object") continue;
      hubSave.loveInterests[id]={...(hubSave.loveInterests[id]||{}),...state};
    }

    if(!hubSave.loveInterestPairs || typeof hubSave.loveInterestPairs!=="object") hubSave.loveInterestPairs={};
    for(const [id,state] of Object.entries(incoming.loveInterestPairs||{})){
      if(!state || typeof state!=="object") continue;
      hubSave.loveInterestPairs[id]={...(hubSave.loveInterestPairs[id]||{}),...state};
    }

    if(!hubSave.characterUnlockedItems || typeof hubSave.characterUnlockedItems!=="object") hubSave.characterUnlockedItems={};
    const currentMiko=Array.isArray(hubSave.characterUnlockedItems.miko)?hubSave.characterUnlockedItems.miko:[];
    const incomingMiko=Array.isArray(incoming.characterUnlockedItems?.miko)?incoming.characterUnlockedItems.miko:[];
    hubSave.characterUnlockedItems.miko=[...new Set([...currentMiko,...incomingMiko])];

    const currentDucks=Array.isArray(hubSave.unlockedDucks)?hubSave.unlockedDucks:[];
    const incomingDucks=Array.isArray(incoming.unlockedDucks)?incoming.unlockedDucks:[];
    hubSave.unlockedDucks=[...new Set([...currentDucks,...incomingDucks])];

    if(!hubSave.duckCollectionCounts || typeof hubSave.duckCollectionCounts!=="object") hubSave.duckCollectionCounts={};
    for(const [duckId,count] of Object.entries(incoming.duckCollectionCounts||{})){
      hubSave.duckCollectionCounts[duckId]=Math.max(Number(hubSave.duckCollectionCounts[duckId]||0),Number(count||0));
    }

    if(!hubSave.tradingCards || typeof hubSave.tradingCards!=="object") hubSave.tradingCards={};
    if(!hubSave.tradingCards.owned || typeof hubSave.tradingCards.owned!=="object") hubSave.tradingCards.owned={};
    const incomingCards=incoming.tradingCards && typeof incoming.tradingCards==="object"?incoming.tradingCards:{};
    for(const [cardId,count] of Object.entries(incomingCards.owned||{})){
      hubSave.tradingCards.owned[cardId]=Math.max(Number(hubSave.tradingCards.owned[cardId]||0),Number(count||0));
    }
    const unseenNow=Array.isArray(hubSave.tradingCards.unseen)?hubSave.tradingCards.unseen:[];
    const unseenIncoming=Array.isArray(incomingCards.unseen)?incomingCards.unseen:[];
    hubSave.tradingCards.unseen=[...new Set([...unseenNow,...unseenIncoming])];

    persistAll();
    return true;
  }catch(error){
    console.warn("Love-interest reward sync failed:",error);
    return false;
  }
};
'''
    game = game.replace(anchor, bridge + anchor, 1)
write("duck-quest/js/game-v96.js", game)

# ---------------------------------------------------------------------------
# Hub Closet: accurate crop bounds for the encounter-exclusive Miko outfits.
# Without these, the Closet fits the full 1080x1920 transparent canvas and the
# actual clothing art looks tiny.
# ---------------------------------------------------------------------------
hub = read("script-v24-201.js")
thumb_entries = {
  "Miko-Shino-Baret.png": [286,612,845,1004],
  "Miko-Shino-Boots.png": [383,1673,689,1805],
  "Miko-Shino-Jeans.png": [403,1407,667,1772],
  "Miko-Shino-Sweater-Shop.png": [377,1199,736,1508],
  "Miko-Shino-Sweater.png": [399,1220,736,1508],
  "Miko-Shino-sleeve.png": [377,1199,492,1357],
  "Miko-Cheryln-Banana-Hairpin.png": [682,910,743,993],
  "Miko-Cheryln-boots.png": [385,1725,687,1805],
  "Miko-Cheryln-shorts.png": [398,1388,673,1524],
  "Miko-Cheryln-sweater.png": [388,1215,693,1447],
  "Miko-Cheryln-white-tights.png": [388,1412,685,1793],
  "Miko-Hibiki-Ribbon.png": [761,978,861,1101],
  "Miko-Hibiki-back-coat.png": [485,1437,581,1605],
  "Miko-Hibiki-boots.png": [385,1701,685,1807],
  "Miko-Hibiki-coat-shop.png": [352,1202,810,1639],
  "Miko-Hibiki-coat-sleeve.png": [385,978,861,1357],
  "Miko-Hibiki-coat.png": [352,1225,810,1639],
  "Miko-Hibiki-shirt.png": [430,1216,642,1442],
  "Miko-Hibiki-shorts.png": [404,1358,669,1547],
  "Miko-Hibiki-stockings.png": [388,1571,682,1794],
  "Miko-Devlin-Belt.png": [420,1414,664,1454],
  "Miko-Devlin-Tie.png": [515,1246,560,1392],
  "Miko-Devlin-Vest.png": [424,1221,650,1433],
  "Miko-Devlin-loafers.png": [380,1746,691,1808],
  "Miko-Devlin-pants.png": [405,1436,664,1769],
  "Miko-Devlin-shirt.png": [391,1216,673,1463],
  "Miko-Yuzuru-bracelet.png": [427,1204,483,1229],
  "Miko-Yuzuru-shirt.png": [383,1226,694,1526],
  "Miko-Yuzuru-shoes.png": [382,1721,689,1811],
  "Miko-Yuzuru-shorts.png": [411,1407,662,1548],
  "Miko-Yuzuru-socks.png": [386,1653,686,1795],
  "Miko-Westley-Face-makeup.png": [395,1127,678,1175],
  "Miko-Westley-Jacket-shop.png": [376,1179,763,1533],
  "Miko-Westley-Jacket.png": [389,1208,763,1533],
  "Miko-Westley-boots.png": [384,1633,687,1817],
  "Miko-Westley-pants.png": [399,1407,675,1646],
  "Miko-Westley-sleeve.png": [376,1179,500,1359],
  "Miko-Westley-top.png": [427,1221,654,1429],
  "Miko-circe-choker.png": [507,1220,566,1246],
  "Miko-circe-shoes.png": [383,1724,687,1804],
  "Miko-circe-shorts.png": [403,1417,664,1561],
  "Miko-circe-stockings.png": [385,1403,685,1795],
  "Miko-circe-sweater-shop.png": [373,1195,735,1458],
  "Miko-circe-sweater.png": [396,1210,735,1458],
  "Miko-circe-tank-top.png": [427,1223,647,1452],
  "Miko-circe-sleeve.png": [373,1195,491,1355],
  "Miko-Quin-Hairpins.png": [685,954,741,1037],
  "Miko-Quin-back-jacket.png": [455,1227,604,1507],
  "Miko-Quin-boots.png": [383,1699,688,1805],
  "Miko-Quin-jacket-shop.png": [386,1168,773,1548],
  "Miko-Quin-jacket.png": [386,1216,773,1548],
  "Miko-Quin-shirt.png": [422,1221,660,1494],
  "Miko-Quin-shorts.png": [400,1408,669,1536],
  "Miko-Quin-sleeve.png": [387,1168,535,1357]
}
block_start = hub.find("const MIKO_THUMB_BOUNDS = {")
block_end = hub.find("\n};\n\nconst MIKO_ASSETS", block_start)
if block_start < 0 or block_end < 0:
    raise RuntimeError("Could not locate MIKO_THUMB_BOUNDS block")
block = hub[block_start:block_end]
new_lines=[]
for filename,bounds in thumb_entries.items():
    if f'"{filename}"' not in block:
        new_lines.append(f'  "{filename}": {json.dumps(bounds)}')
if new_lines:
    existing = hub[block_start:block_end].rstrip()
    if not existing.endswith("{") and not existing.endswith(","):
        existing += ","
    existing += "\n" + ",\n".join(new_lines)
    hub = hub[:block_start] + existing + hub[block_end:]

# Love-interest wardrobes are encounter rewards, never Shop purchases. Give a
# correct lock hint instead of the generic "unlock it from the Shop" message.
old_return = '  return questRewardHints[id] || `${asset.label} is locked — unlock it from the Shop!`;'
if old_return not in hub:
    raise RuntimeError("Could not locate Closet locked-message return line")
love_hint_code = r'''  const loveInterestWardrobe = {
    "lukio-hair-streak":"Lukio","lukio-hoodie":"Lukio","lukio-shorts":"Lukio","lukio-socks":"Lukio","lukio-booties":"Lukio",
    "shino-beret":"Shinobu","shino-sweater":"Shinobu","shino-sleeve":"Shinobu","shino-jeans":"Shinobu","shino-boots":"Shinobu",
    "cheryln-hairpin":"Cheryln","cheryln-sweater":"Cheryln","cheryln-shorts":"Cheryln","cheryln-tights":"Cheryln","cheryln-boots":"Cheryln",
    "hibiki-ribbon":"Hibiki","hibiki-shirt":"Hibiki","hibiki-coat":"Hibiki","hibiki-back-coat":"Hibiki","hibiki-coat-sleeve":"Hibiki","hibiki-shorts":"Hibiki","hibiki-stockings":"Hibiki","hibiki-boots":"Hibiki",
    "devlin-shirt":"Devlin","devlin-vest":"Devlin","devlin-tie":"Devlin","devlin-pants":"Devlin","devlin-belt":"Devlin","devlin-loafers":"Devlin","devlin-bangs-pinned":"Devlin",
    "yuzuru-shirt":"Yuzuru","yuzuru-shorts":"Yuzuru","yuzuru-socks":"Yuzuru","yuzuru-shoes":"Yuzuru","yuzuru-bracelet":"Yuzuru",
    "westley-top":"Westley","westley-jacket":"Westley","westley-sleeve":"Westley","westley-pants":"Westley","westley-boots":"Westley","westley-face-makeup":"Westley",
    "circe-tank-top":"Circe","circe-sweater":"Circe","circe-sleeve":"Circe","circe-shorts":"Circe","circe-stockings":"Circe","circe-shoes":"Circe","circe-choker":"Circe",
    "quin-shirt":"Quin","quin-jacket":"Quin","quin-back-jacket":"Quin","quin-sleeve":"Quin","quin-shorts":"Quin","quin-boots":"Quin","quin-hairpins":"Quin"
  };
  if (loveInterestWardrobe[id]) return `${asset.label} is locked — meet ${loveInterestWardrobe[id]} while exploring Duck Quest as Miko!`;
  return questRewardHints[id] || `${asset.label} is locked — unlock it from the Shop!`;'''
hub = hub.replace(old_return, love_hint_code, 1)
write("script-v24-201.js", hub)

# ---------------------------------------------------------------------------
# Page references + version bump.
# ---------------------------------------------------------------------------
for rel in ["index.html", "memory-game/index.html", "crane-game/index.html", "crane-game/play-v24-40.html"]:
    write(rel, bump(read(rel)))

quest = read("duck-quest/index.html")
quest = quest.replace("css/love-interests-v249.css", "css/love-interests-v251.css")
quest = quest.replace("js/love-interests-v249.js", "js/love-interests-v251.js")
quest = bump(quest)
write("duck-quest/index.html", quest)

# ---------------------------------------------------------------------------
# Service worker. Keep the legacy v24.244 bridge alive because some installed
# PWAs can still have that exact worker URL registered.
# ---------------------------------------------------------------------------
sw = bump(read("sw-v24-250.js"))
sw = sw.replace("love-interests-v249.js", "love-interests-v251.js")
sw = sw.replace("love-interests-v249.css", "love-interests-v251.css")
sw = sw.replace("./sw-v24-250.js", "./sw-v24-251.js")

m = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not m:
    raise RuntimeError("Could not locate service-worker precache array")
body = m.group(2)
if "./sw-v24-244.js" not in body:
    body += "\n  './sw-v24-244.js',"
sw = sw[:m.start(2)] + body + sw[m.end(2):]
write("sw-v24-251.js", sw)
write("sw.js", "importScripts('./sw-v24-251.js?v=24-251');\n")
write("sw-v24-244.js", "// Legacy installed-PWA compatibility bridge.\nimportScripts('./sw-v24-251.js?v=24-251');\n")

write("version.json", json.dumps({"version": TARGET_VERSION}, indent=2) + "\n")
write("UPDATE-v24.251.txt", """Duckie Days v24.251

- Love-interest encounters now play directly on the Duck Quest battle background like Sibling Spat.
- Both scene characters animate and face each other.
- Expression directions such as Happy, smug, content, angry, and threaten are sprite changes only and no longer appear in dialogue text.
- Shared Miko love-interest encounter chance reduced from 5% to 2%.
- Fixed love-interest duck/outfit/card rewards being overwritten by Duck Quest's in-memory save.
- Love-interest outfits remain encounter-exclusive and are not Shop purchases.
- Added accurate Closet crop bounds so love-interest outfit thumbnails appear at a useful size.
""")

print("Installed Duckie Days v24.251 patch.")

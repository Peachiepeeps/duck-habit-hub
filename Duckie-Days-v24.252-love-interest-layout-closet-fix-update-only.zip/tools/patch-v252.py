from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = "24.252"
TARGET_QUERY = "24-252"


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")


def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old, new, 1)


def bump(text):
    return text.replace("24.251", TARGET_VERSION).replace("24-251", TARGET_QUERY)


required = [
    "version.json", "index.html", "script-v24-201.js", "duck-quest/index.html",
    "duck-quest/js/game-v96.js", "duck-quest/js/love-interests-v251.js",
    "duck-quest/css/love-interests-v251.css", "memory-game/index.html",
    "crane-game/index.html", "crane-game/play-v24-40.html", "sw-v24-251.js",
    "sw.js", "sw-v24-244.js"
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError("Missing required files: " + ", ".join(missing))

current = str(json.loads(read("version.json")).get("version"))
if current not in {"24.251", "24.252"}:
    raise RuntimeError(f"Expected Duckie Days v24.251, found {current!r}")

# ---------------------------------------------------------------------------
# Love-interest battle presentation v24.252.
# ---------------------------------------------------------------------------
copy("love-interests-v252.js", "duck-quest/js/love-interests-v252.js")
copy("love-interests-v252.css", "duck-quest/css/love-interests-v252.css")

# ---------------------------------------------------------------------------
# Miko Closet organization.
# - Move Big Shirt + Yuzuru Shirt into Shirts.
# - Expose the missing encounter-earned tops under Shirts.
# - Expose encounter accessories under Extras.
# ---------------------------------------------------------------------------
hub = read("script-v24-201.js")

old_shirt = '{ id: "shirt", label: "Shirt", type: "single", allowNone: true, options: ["top-button", "shirt-blouse"] },'
new_shirt = '{ id: "shirt", label: "Shirts", type: "single", allowNone: true, options: ["top-button", "shirt-blouse", "top-big-shirt", "westley-top", "quin-shirt", "circe-tank-top", "yuzuru-shirt"] },'
hub = replace_once(hub, old_shirt, new_shirt, "Miko Shirts category")

old_outer = '{ id: "outer", label: "Layers", type: "single", allowNone: true, options: ["top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "yuzuru-shirt", "westley-jacket", "circe-sweater", "quin-jacket"] },'
new_outer = '{ id: "outer", label: "Layers", type: "single", allowNone: true, options: ["top-hoodie", "top-sweater", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "westley-jacket", "circe-sweater", "quin-jacket"] },'
hub = replace_once(hub, old_outer, new_outer, "Miko Layers category")

old_extras = 'options: ["belt", "headband", "hairpins-black", "shino-beret", "cheryln-hairpin", "daisy-crown", "ocean-sunglasses", "halo", "candy-hairclip"]'
new_extras = 'options: ["belt", "headband", "hairpins-black", "lukio-hair-streak", "shino-beret", "cheryln-hairpin", "hibiki-ribbon", "westley-face-makeup", "yuzuru-bracelet", "devlin-belt", "devlin-tie", "circe-choker", "quin-hairpins", "daisy-crown", "ocean-sunglasses", "halo", "candy-hairclip"]'
hub = replace_once(hub, old_extras, new_extras, "Miko Extras category")

# Normalize/migrate old saved outfits now that Big Shirt and Yuzuru Shirt are
# Shirts rather than outer Layers.
old_validation = '''  if (!hadShirtField) shirt = "top-button";
  if (![null, "top-button", "shirt-blouse"].includes(shirt)) shirt = "top-button";
  if (![null, "top-hoodie", "top-sweater", "top-big-shirt", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "yuzuru-shirt", "westley-jacket", "circe-sweater", "quin-jacket"].includes(outer)) outer = "top-hoodie";
'''
new_validation = '''  if (!hadShirtField) shirt = "top-button";

  // v24.252: Big Shirt and Yuzuru Shirt moved from Layers to Shirts. Preserve
  // any existing equipped look by migrating the old outer selection.
  if (outer === "top-big-shirt" || outer === "yuzuru-shirt") {
    shirt = outer;
    outer = null;
  }

  if (![null, "top-button", "shirt-blouse", "top-big-shirt", "westley-top", "quin-shirt", "circe-tank-top", "yuzuru-shirt"].includes(shirt)) shirt = "top-button";
  if (![null, "top-hoodie", "top-sweater", "outer-black-blazer", "lukio-hoodie", "shino-sweater", "cheryln-sweater", "hibiki-coat", "devlin-vest", "westley-jacket", "circe-sweater", "quin-jacket"].includes(outer)) outer = "top-hoodie";
'''
hub = replace_once(hub, old_validation, new_validation, "Miko shirt/layer normalizer")

old_norm_extras = '''  const extras = Array.isArray(incoming.extras)
    ? incoming.extras.filter(id => ["belt", "headband", "hairpins-black", "daisy-crown", "ocean-sunglasses", "halo", "candy-hairclip"].includes(id))
    : [];
'''
new_norm_extras = '''  const extras = Array.isArray(incoming.extras)
    ? incoming.extras.filter(id => ["belt", "headband", "hairpins-black", "lukio-hair-streak", "shino-beret", "cheryln-hairpin", "hibiki-ribbon", "westley-face-makeup", "yuzuru-bracelet", "devlin-belt", "devlin-tie", "circe-choker", "quin-hairpins", "daisy-crown", "ocean-sunglasses", "halo", "candy-hairclip"].includes(id))
    : [];
'''
hub = replace_once(hub, old_norm_extras, new_norm_extras, "Miko extras normalizer")

old_shirt_render = '''  if (outfit.shirt === "top-button") ids.push("top-button");
  else if (outfit.shirt === "shirt-blouse") ids.push("shirt-blouse");
'''
new_shirt_render = '''  if (outfit.shirt === "top-button") ids.push("top-button");
  else if (outfit.shirt === "shirt-blouse") ids.push("shirt-blouse");
  else if (outfit.shirt === "top-big-shirt") ids.push("top-big-shirt");
  else if (outfit.shirt === "westley-top") ids.push("westley-top");
  else if (outfit.shirt === "quin-shirt") ids.push("quin-shirt");
  else if (outfit.shirt === "circe-tank-top") ids.push("circe-tank-top");
  else if (outfit.shirt === "yuzuru-shirt") ids.push("yuzuru-shirt");
'''
hub = replace_once(hub, old_shirt_render, new_shirt_render, "Miko shirt renderer")

# Remove accessories/under-shirts that should now be independently equipped
# from their proper Closet categories. Keep structural sleeves/back pieces tied
# to their matching outer Layers.
replacements = {
    '  else if (outfit.outer === "hibiki-coat") ids.push("hibiki-back-coat", "hibiki-shirt", "hibiki-ribbon", "hibiki-coat-sleeve");':
        '  else if (outfit.outer === "hibiki-coat") ids.push("hibiki-back-coat", "hibiki-shirt", "hibiki-coat-sleeve");',
    '  else if (outfit.outer === "devlin-vest") ids.push("devlin-shirt", "devlin-tie", "devlin-bangs-pinned");':
        '  else if (outfit.outer === "devlin-vest") ids.push("devlin-shirt", "devlin-bangs-pinned");',
    '  else if (outfit.outer === "yuzuru-shirt") ids.push("yuzuru-bracelet");\n': '',
    '  else if (outfit.outer === "westley-jacket") ids.push("westley-top", "westley-sleeve", "westley-face-makeup");':
        '  else if (outfit.outer === "westley-jacket") ids.push("westley-sleeve");',
    '  else if (outfit.outer === "circe-sweater") ids.push("circe-tank-top", "circe-sleeve", "circe-choker");':
        '  else if (outfit.outer === "circe-sweater") ids.push("circe-sleeve");',
    '  else if (outfit.outer === "quin-jacket") ids.push("quin-back-jacket", "quin-shirt", "quin-sleeve", "quin-hairpins");':
        '  else if (outfit.outer === "quin-jacket") ids.push("quin-back-jacket", "quin-sleeve");',
    '  if (outfit.bottom === "devlin-pants") ids.push("devlin-belt");\n': ''
}
for old, new in replacements.items():
    hub = replace_once(hub, old, new, f"Miko independent Closet piece: {old[:48]}")

write("script-v24-201.js", hub)

# ---------------------------------------------------------------------------
# References + version bump.
# ---------------------------------------------------------------------------
for rel in ["index.html", "memory-game/index.html", "crane-game/index.html", "crane-game/play-v24-40.html"]:
    write(rel, bump(read(rel)))

quest = read("duck-quest/index.html")
quest = quest.replace("css/love-interests-v251.css", "css/love-interests-v252.css")
quest = quest.replace("js/love-interests-v251.js", "js/love-interests-v252.js")
quest = bump(quest)
write("duck-quest/index.html", quest)

# ---------------------------------------------------------------------------
# Service worker + installed-PWA bridge.
# ---------------------------------------------------------------------------
sw = bump(read("sw-v24-251.js"))
sw = sw.replace("love-interests-v251.js", "love-interests-v252.js")
sw = sw.replace("love-interests-v251.css", "love-interests-v252.css")
sw = sw.replace("./sw-v24-251.js", "./sw-v24-252.js")
write("sw-v24-252.js", sw)
write("sw.js", "importScripts('./sw-v24-252.js?v=24-252');\n")
write("sw-v24-244.js", "// Legacy installed-PWA compatibility bridge.\nimportScripts('./sw-v24-252.js?v=24-252');\n")

write("version.json", json.dumps({"version": TARGET_VERSION}, indent=2) + "\n")
write("UPDATE-v24.252.txt", """Duckie Days v24.252

- Love-interest cutscenes now fully hide the normal battle Miko so only one Miko appears.
- Scene portraits preserve their original source-pixel size differences, keeping shorter and taller OCs proportional to Miko.
- Dialogue is larger and the Next/Finish button is horizontal and centered.
- The empty command area is removed during love-interest dialogue.
- Miko Shirts now include Westley Top, Quin Shirt, Circe Tank Top, Yuzuru Shirt, and Big Shirt.
- Big Shirt and Yuzuru Shirt moved out of Layers and into Shirts.
- Miko Extras now include Hibiki Ribbon, Westley Face Makeup, Yuzuru Bracelet, Devlin Belt, Devlin Tie, Circe Choker, Quin Hairpins, and Lukio Hair Streak.
- Love-interest accessories are independently equippable instead of being forced on by jackets/pants.
""")

print("Installed Duckie Days v24.252 patch.")

from pathlib import Path
import json, re, shutil, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.254'
TARGET_QUERY = '24-254'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')


def copy(src_rel, dst_rel):
    src = PKG / src_rel
    dst = ROOT / dst_rel
    if not src.exists():
        raise RuntimeError(f'Package file missing: {src_rel}')
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old, new, 1)


def bump_versions(text):
    # v24.254 deliberately supersedes the uninstalled v24.253 package as well.
    return (text
        .replace('24.253', TARGET_VERSION).replace('24-253', TARGET_QUERY)
        .replace('24.252', TARGET_VERSION).replace('24-252', TARGET_QUERY))


required = [
    'index.html', 'version.json', 'script-v24-201.js', 'style-v24-201.css',
    'trading-cards-v250.js', 'trading-cards-ui-v250.js',
    'duck-quest/index.html', 'duck-quest/js/game-v96.js',
    'duck-quest/js/merchant-fix-v218.js',
    'memory-game/index.html', 'crane-game/index.html', 'crane-game/play-v24-40.html',
    'sw.js'
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.252', '24.254'}:
    raise RuntimeError(f'Expected Duckie Days v24.252, found {current!r}. Do not install an older intermediate update first.')

sw_source = ROOT / 'sw-v24-252.js'
if not sw_source.exists() and current != '24.254':
    raise RuntimeError('Missing sw-v24-252.js required to build the new service worker.')

# ---------------------------------------------------------------------------
# Package files + new Task Shop art.
# ---------------------------------------------------------------------------
copy('task-progression-v254.js', 'task-progression-v254.js')
copy('task-progression-v254.css', 'task-progression-v254.css')
copy('duck-quest/js/task-buddy-boost-v254.js', 'duck-quest/js/task-buddy-boost-v254.js')
for name in [
    'Duck-bucks.png',
    'Task-plush-1.png', 'Task-plush-2.png', 'Task-plush-3.png',
    'Task-plush-4.png', 'Task-plush-5.png'
]:
    copy(f'assets/task-shop/{name}', f'assets/task-shop/{name}')

# ---------------------------------------------------------------------------
# Duck Quest: Miko Failed Spell gamble, still all-enemy in Double Trouble.
# 84% normal 1.85x, 15% huge 4.25x, 1% non-lethal 25%-max-HP backfire.
# ---------------------------------------------------------------------------
game = read('duck-quest/js/game-v96.js')
old_skill = '''  {
    id: "failed-spell",
    name: "Failed Spell",
    unlock: 25,
    type: "damage",
    multiplier: 1.85,
    hitsAll: true,
    cooldown: 2,
    sprite: "assets/characters/miko/base/failed-spell.webp",
    description: "A magical mishap explodes for heavy damage. Hits all enemies in Double Trouble."
  },'''
new_skill = '''  {
    id: "failed-spell",
    name: "Failed Spell",
    unlock: 25,
    type: "damage",
    multiplier: 1.85,
    hitsAll: true,
    cooldown: 2,
    sprite: "assets/characters/miko/base/failed-spell.webp",
    description: "A chaotic gamble! Usually 1.85× to all enemies, with a 15% chance for a huge 4.25× blast and a tiny 1% chance to backfire on Miko."
  },'''
if new_skill not in game:
    game = replace_once(game, old_skill, new_skill, 'update Failed Spell description')

all_enemy_old = '''  if(heroCanMissFromFluster(skill)){
    setMessage(`${heroDisplayName()} got too flustered and the attack missed everybody!`);
    await sleep(600);
  } else {
    const names=targets.map(enemy=>enemy.name).join(" and ");
    setMessage(`${skillDisplayName(skill)} hits ${names}!`);
    await sleep(260);

    for(const target of targets){
      if(!target || target.hpNow<=0) continue;
      selectCurrentEnemy(target);
      const stats=peepStats();
      const boostedAttack=stats.attack
        *(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)
        *(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)
        *(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
      const crit=Math.random()<0.11;
      const variance=0.92+Math.random()*0.16;
      const multiplier=Number(skill.multiplier)||1;
      const dmg=Math.max(1,Math.round(boostedAttack*multiplier*variance*(crit?1.5:1)));
      await hurtEnemy(dmg);

      if(skill.type==="damage-burn" && target.hpNow>0 && Math.random()<Number(skill.burnChance||1)){
        skillState.enemyBurnTurns=Math.max(Number(skillState.enemyBurnTurns||0),Number(skill.burnTurns||99));
        skillState.enemyBurnDamagePercent=Number(skill.burnDamagePercent||0.08);
        saveCurrentEnemyEffects(target);
      }
      if(target.hpNow>0) saveCurrentEnemyEffects(target);
      await sleep(80);
    }
  }'''
all_enemy_new = '''  if(heroCanMissFromFluster(skill)){
    setMessage(`${heroDisplayName()} got too flustered and the attack missed everybody!`);
    await sleep(600);
  } else {
    const failedSpellRoll=skill.id==="failed-spell"?Math.random():null;
    const failedSpellBackfire=skill.id==="failed-spell" && failedSpellRoll<0.01;
    const failedSpellHuge=skill.id==="failed-spell" && !failedSpellBackfire && failedSpellRoll<0.16;

    if(failedSpellBackfire){
      const before=currentRun.hp;
      const backlash=Math.max(1,Math.round(currentRun.maxHp*0.25));
      currentRun.hp=Math.max(1,currentRun.hp-backlash);
      const lost=Math.max(0,before-currentRun.hp);
      setMessage(`Failed Spell BACKFIRED! The magic loops around and bonks Miko for ${lost} HP!`);
      if(lost>0) showFloat(`-${lost}`,"damage","peep");
      renderPeepHp();
      await sleep(700);
    } else {
      const names=targets.map(enemy=>enemy.name).join(" and ");
      setMessage(failedSpellHuge
        ? `Failed Spell goes WILD! A huge blast hits ${names}!`
        : `${skillDisplayName(skill)} hits ${names}!`);
      await sleep(260);

      for(const target of targets){
        if(!target || target.hpNow<=0) continue;
        selectCurrentEnemy(target);
        const stats=peepStats();
        const boostedAttack=stats.attack
          *(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)
          *(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)
          *(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
        const crit=Math.random()<0.11;
        const variance=0.92+Math.random()*0.16;
        const multiplier=failedSpellHuge?4.25:(Number(skill.multiplier)||1);
        const dmg=Math.max(1,Math.round(boostedAttack*multiplier*variance*(crit?1.5:1)));
        await hurtEnemy(dmg);

        if(skill.type==="damage-burn" && target.hpNow>0 && Math.random()<Number(skill.burnChance||1)){
          skillState.enemyBurnTurns=Math.max(Number(skillState.enemyBurnTurns||0),Number(skill.burnTurns||99));
          skillState.enemyBurnDamagePercent=Number(skill.burnDamagePercent||0.08);
          saveCurrentEnemyEffects(target);
        }
        if(target.hpNow>0) saveCurrentEnemyEffects(target);
        await sleep(80);
      }
    }
  }'''
if 'Failed Spell BACKFIRED!' not in game:
    game = replace_once(game, all_enemy_old, all_enemy_new, 'add all-enemy Failed Spell gamble')

single_anchor = '''  } else if(skill.type==="damage-burn") {'''
single_branch = '''  } else if(skill.id==="failed-spell") {
    if(heroCanMissFromFluster(skill)) {
      setMessage(`${heroDisplayName()} got too flustered and missed!`);
      await sleep(540);
    } else {
      if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
      if(skill.oncePerBattle) skillState.onceUsed[skill.id]=true;
      const roll=Math.random();
      if(roll<0.01){
        const before=currentRun.hp;
        const backlash=Math.max(1,Math.round(currentRun.maxHp*0.25));
        currentRun.hp=Math.max(1,currentRun.hp-backlash);
        const lost=Math.max(0,before-currentRun.hp);
        setMessage(`Failed Spell BACKFIRED! The magic loops around and bonks Miko for ${lost} HP!`);
        if(lost>0) showFloat(`-${lost}`,"damage","peep");
        renderPeepHp();
        await sleep(700);
      } else {
        const huge=roll<0.16;
        const multiplier=huge?4.25:(skill.multiplier||1.85);
        const stats=peepStats();
        const boostedAttack=stats.attack*(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)*(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)*(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
        const crit=Math.random()<0.11;
        const variance=0.9+Math.random()*0.2;
        const dmg=Math.max(1,Math.round(boostedAttack*multiplier*variance*(crit?1.5:1)));
        setMessage((huge?"Failed Spell goes WILD! HUGE DAMAGE!":"Failed Spell!") + (crit?" CRITICAL!":""));
        await sleep(280);
        await hurtEnemy(dmg);
      }
    }
  } else if(skill.type==="damage-burn") {'''
if 'Failed Spell goes WILD! HUGE DAMAGE!' not in game:
    game = replace_once(game, single_anchor, single_branch, 'add single-enemy Failed Spell gamble')
write('duck-quest/js/game-v96.js', game)

# ---------------------------------------------------------------------------
# Mysterious Merchant: after both wares sell, tip hat and leave automatically.
# ---------------------------------------------------------------------------
merchant = read('duck-quest/js/merchant-fix-v218.js')
merchant = re.sub(
    r"window\.DUCKIE_DAYS_MERCHANT_FIX='[^']+';",
    "window.DUCKIE_DAYS_MERCHANT_FIX='24.254-auto-leave';",
    merchant,
    count=1
)
style_anchor = '''      #eventChoiceActions.${HOLDER_CLASS} .merchant-leave-v218{
        grid-template-columns:1fr!important;
        min-height:46px!important;
        text-align:center!important;
      }'''
style_new = style_anchor + '''
      #chestSprite.merchant-tip-hat-v254{
        transform-origin:55% 28%!important;
        animation:merchantTipHatV254 .62s ease-in-out 1!important;
      }
      @keyframes merchantTipHatV254{
        0%,100%{transform:translateY(0) rotate(0deg)}
        35%{transform:translateY(3px) rotate(9deg)}
        65%{transform:translateY(1px) rotate(-3deg)}
      }'''
if 'merchantTipHatV254' not in merchant:
    merchant = replace_once(merchant, style_anchor, style_new, 'add merchant hat-tip animation')

buy_old = '''    try{ setMessage(`Bought ${ware.name}!`); }catch(error){ /* non-fatal */ }
    mountMerchant(true);
  }'''
buy_new = '''    try{ setMessage(`Bought ${ware.name}!`); }catch(error){ /* non-fatal */ }

    const soldOut=Array.isArray(chest.wares) && chest.wares.length>0 && chest.wares.every(item=>Boolean(item?.sold));
    if(soldOut){
      chest.autoLeavingV254=true;
      if(ui?.chestSprite){
        ui.chestSprite.classList.remove('merchant-tip-hat-v254');
        void ui.chestSprite.offsetWidth;
        ui.chestSprite.classList.add('merchant-tip-hat-v254');
      }
      try{ setMessage('Sold out! Gentleman Duck tips his hat and heads on his way.'); }catch(error){ /* non-fatal */ }
      setTimeout(()=>leaveMerchant(),720);
      return;
    }

    mountMerchant(true);
  }'''
if 'autoLeavingV254' not in merchant:
    merchant = replace_once(merchant, buy_old, buy_new, 'auto-leave Merchant after both purchases')

mount_old = '''    const chest=currentMerchant();
    const holder=ui?.eventChoiceActions;
    if(!chest || !holder) return false;'''
mount_new = '''    const chest=currentMerchant();
    const holder=ui?.eventChoiceActions;
    if(!chest || !holder) return false;
    if(chest.autoLeavingV254) return true;'''
if 'if(chest.autoLeavingV254) return true;' not in merchant:
    merchant = replace_once(merchant, mount_old, mount_new, 'stop Merchant watchdog during auto-leave')
write('duck-quest/js/merchant-fix-v218.js', merchant)

# ---------------------------------------------------------------------------
# Hub HTML: Task Shop, Duck Bucks UI, and the 50-task collectible shelf.
# ---------------------------------------------------------------------------
index = read('index.html')

css_link = '  <link rel="stylesheet" href="task-progression-v254.css?v=24-254" />\n'
if 'task-progression-v254.css' not in index:
    anchor = '  <link rel="stylesheet" href="trading-cards-v250.css?v=24-252" />\n'
    if anchor not in index:
        anchor = re.search(r'\s*<link rel="stylesheet" href="trading-cards-v250\.css\?v=[^"]+"\s*/>\s*', index)
        if not anchor:
            raise RuntimeError('Could not locate Trading Card stylesheet link.')
        insertion_at = anchor.end()
        index = index[:insertion_at] + css_link + index[insertion_at:]
    else:
        index = index.replace(anchor, anchor + css_link, 1)

shelf_button_anchor = '''      <button id="roomWingButton" class="room-wing-button hidden" type="button" aria-label="Visit Shelf of Ducks area">
        <span id="roomWingArrow" aria-hidden="true">‹</span>
      </button>'''
shelf_button_markup = shelf_button_anchor + '''

      <button id="taskShelfButton" class="task-shelf-button-v254" type="button" aria-label="Collect 50 lifetime tasks to unlock the Task Collectible Shelf">
        <span id="taskShelfArrow" aria-hidden="true">›</span>
        <small id="taskShelfLock" class="task-shelf-lock-v254">🔒 0/50</small>
      </button>'''
if 'id="taskShelfButton"' not in index:
    index = replace_once(index, shelf_button_anchor, shelf_button_markup, 'add right-side Task Shelf arrow')

picker_anchor = '''      <div id="wingDuckPicker" class="wing-duck-picker hidden" aria-hidden="true">'''
shelf_markup = '''      <section id="taskCollectibleWing" class="task-collectible-wing-v254 hidden" aria-label="Task Collectible Shelf">
        <div class="task-collectible-title-v254">
          <span>TASK TREASURES</span>
          <strong>Collectible Shelf</strong>
        </div>
        <div id="taskCollectibleSlots" class="task-collectible-slots-v254"></div>
      </section>

      <div id="taskCollectiblePicker" class="task-collectible-picker-v254 hidden" aria-hidden="true">
        <button id="taskCollectiblePickerBackdrop" class="task-collectible-picker-backdrop-v254" type="button" aria-label="Close collectible picker"></button>
        <section class="task-collectible-picker-card-v254" aria-label="Choose a Task Shop collectible">
          <button id="closeTaskCollectiblePicker" class="task-collectible-picker-close-v254" type="button" aria-label="Close collectible picker">×</button>
          <p class="eyebrow">TASK TREASURES</p>
          <h2>Choose a Collectible</h2>
          <p>Place one of your Task Shop collectibles on this shelf spot.</p>
          <button id="clearTaskCollectibleSlot" class="task-collectible-clear-v254" type="button">Leave This Spot Empty</button>
          <div id="taskCollectiblePickerGrid" class="task-collectible-picker-grid-v254"></div>
        </section>
      </div>

'''
if 'id="taskCollectibleWing"' not in index:
    index = replace_once(index, picker_anchor, shelf_markup + picker_anchor, 'add Task Collectible Shelf area')

task_actions_anchor = '''          <div class="tasks-header-actions">
            <button id="completedTab" class="completed-tasks-button" type="button" aria-selected="false">✓ Completed</button>'''
task_actions_new = '''          <div class="tasks-header-actions">
            <button id="openTaskShopButton" class="task-shop-open-v254" type="button">
              <img src="assets/task-shop/Duck-bucks.png" alt="" />
              <span>Task Shop</span>
              <strong id="taskHeaderBuckCount">0</strong>
            </button>
            <button id="completedTab" class="completed-tasks-button" type="button" aria-selected="false">✓ Completed</button>'''
if 'id="openTaskShopButton"' not in index:
    index = replace_once(index, task_actions_anchor, task_actions_new, 'add Task Shop button')

tasks_tail = '''        <div id="tasksContent" class="tasks-content"></div>
        <p class="task-kind-note">Anytime tasks wait until you complete them once. Pinned dated tasks stay on Today. No penalties. ♡</p>
      </section>

      <section id="taskFormPanel"'''
task_shop_panel = '''        <div id="tasksContent" class="tasks-content"></div>
        <p class="task-kind-note">Anytime tasks wait until you complete them once. Pinned dated tasks stay on Today. No penalties. ♡</p>
      </section>

      <section id="taskShopPanel" class="panel task-shop-panel-v254 hidden" aria-label="Task Shop">
        <div class="panel-header task-shop-header-v254">
          <div class="task-shop-heading-v254">
            <p class="eyebrow">SPEND YOUR DUCK BUCKS</p>
            <h1>Task Shop</h1>
          </div>
          <div class="task-shop-buck-pill-v254" aria-label="Duck Bucks balance">
            <img src="assets/task-shop/Duck-bucks.png" alt="" />
            <strong id="taskShopBuckCount">0</strong>
          </div>
          <button id="closeTaskShop" class="close-button" type="button" aria-label="Return to Tasks">×</button>
        </div>
        <p class="task-shop-intro-v254">Duck Bucks are earned from completing Tasks and can only be spent here. Plushes are permanent Task Shop collectibles for your shelf. ♡</p>
        <div id="taskShopGrid" class="task-shop-grid-v254"></div>
      </section>

      <section id="taskFormPanel"'''
if 'id="taskShopPanel"' not in index:
    index = replace_once(index, tasks_tail, task_shop_panel, 'add Task Shop panel')

script_anchor = '  <script src="trading-cards-ui-v250.js?v=24-252"></script>\n'
if 'task-progression-v254.js' not in index:
    if script_anchor in index:
        index = index.replace(script_anchor, script_anchor + '  <script src="task-progression-v254.js?v=24-254"></script>\n', 1)
    else:
        match = re.search(r'(\s*<script src="trading-cards-ui-v250\.js\?v=[^"]+"></script>\s*)', index)
        if not match:
            raise RuntimeError('Could not locate Trading Card UI script.')
        index = index[:match.end()] + '  <script src="task-progression-v254.js?v=24-254"></script>\n' + index[match.end():]

index = bump_versions(index)
write('index.html', index)

# Duck Quest Buddy Boost plugin loads after existing Quest scripts.
dq = read('duck-quest/index.html')
if 'js/task-buddy-boost-v254.js' not in dq:
    dq = dq.replace('</body>', '  <script src="js/task-buddy-boost-v254.js?v=24-254"></script>\n</body>', 1)
dq = bump_versions(dq)
write('duck-quest/index.html', dq)

# Other app surfaces only need the build/cache query bump.
for rel in ['memory-game/index.html', 'crane-game/index.html', 'crane-game/play-v24-40.html']:
    write(rel, bump_versions(read(rel)))

# ---------------------------------------------------------------------------
# Service worker: new build + assets, plus old-service-worker compatibility.
# ---------------------------------------------------------------------------
if current == '24.254' and (ROOT / 'sw-v24-254.js').exists():
    sw = read('sw-v24-254.js')
else:
    sw = bump_versions(read('sw-v24-252.js'))
sw = sw.replace('./sw-v24-252.js', './sw-v24-254.js')

precache_match = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not precache_match:
    raise RuntimeError('Could not locate service-worker precache array.')
body = precache_match.group(2)
new_urls = [
    './task-progression-v254.js?v=24-254',
    './task-progression-v254.css?v=24-254',
    './assets/task-shop/Duck-bucks.png',
    './assets/task-shop/Task-plush-1.png',
    './assets/task-shop/Task-plush-2.png',
    './assets/task-shop/Task-plush-3.png',
    './assets/task-shop/Task-plush-4.png',
    './assets/task-shop/Task-plush-5.png',
    './duck-quest/js/task-buddy-boost-v254.js?v=24-254',
]
for url in new_urls:
    if url not in body:
        body += f"\n  '{url}',"
sw = sw[:precache_match.start(2)] + body + sw[precache_match.end(2):]
write('sw-v24-254.js', sw)
write('sw.js', "importScripts('./sw-v24-254.js?v=24-254');\n")
write('sw-v24-244.js', "// Legacy service-worker bridge.\nimportScripts('./sw-v24-254.js?v=24-254');\n")

write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')
write('UPDATE-v24.254.txt', '''Duckie Days v24.254 — Task Progression\n\n- New Duck Bucks currency: +1 for every completed Task, spendable only in the Task Shop.\n- Task Shop includes five exclusive plushes at 20 Duck Bucks each, EXP Candies, Card Packs, Rare Eggs, and Jump Token bundles.\n- New 12-slot Task Collectible Shelf unlocks at 50 lifetime completed tasks and is reached from a new right-side room arrow.\n- Task Treasure Meter keeps rewarding beyond 1/5/15, with fixed rewards through 60 and repeat Duck Buck rewards every 20 tasks after that.\n- Perfect Day Chest rewards finishing every Task due that day.\n- Every Task has a 15% chance for a Surprise Task Drop.\n- Completing 5 Tasks in a day activates a +20% Buddy ability boost in Duck Quest until the daily reset.\n- Miko Failed Spell is now a gamble: 84% normal 1.85x, 15% huge 4.25x, 1% non-lethal backfire.\n- Mysterious Merchant tips his hat and automatically leaves after both wares are purchased.\n''')

print('Installed Duckie Days v24.254 Task Progression update.')

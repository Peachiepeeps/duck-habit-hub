from pathlib import Path
import json, re, sys

ROOT = Path.cwd()
PKG = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TARGET_VERSION = '24.255'
TARGET_QUERY = '24-255'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')


def copy(rel):
    src = PKG / rel
    dst = ROOT / rel
    if not src.exists():
        raise RuntimeError(f'Missing package file: {rel}')
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(src.read_bytes())


required = ['index.html', 'version.json', 'task-progression-v254.js', 'task-progression-v254.css', 'sw.js']
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current = str(json.loads(read('version.json')).get('version'))
if current not in {'24.254', '24.255'}:
    raise RuntimeError(f'Expected Duckie Days v24.254, found {current!r}.')

copy('task-progression-v255.js')
copy('task-progression-v255.css')

index = read('index.html')
if 'task-progression-v255.css' not in index:
    if 'task-progression-v254.css' in index:
        index = index.replace('task-progression-v254.css?v=24-254', 'task-progression-v254.css?v=24-254" />\n  <link rel="stylesheet" href="task-progression-v255.css?v=24-255', 1)
    else:
        index = index.replace('</head>', '  <link rel="stylesheet" href="task-progression-v255.css?v=24-255" />\n</head>', 1)
if 'task-progression-v255.js' not in index:
    if 'task-progression-v254.js' in index:
        index = index.replace('task-progression-v254.js?v=24-254"></script>', 'task-progression-v254.js?v=24-254"></script>\n  <script src="task-progression-v255.js?v=24-255"></script>', 1)
    else:
        index = index.replace('</body>', '  <script src="task-progression-v255.js?v=24-255"></script>\n</body>', 1)
write('index.html', index)

# Bump other surfaces for cache busting.
for rel in ['memory-game/index.html', 'crane-game/index.html', 'crane-game/play-v24-40.html', 'duck-quest/index.html']:
    p = ROOT / rel
    if p.exists():
        write(rel, read(rel).replace('24-254', TARGET_QUERY).replace('24.254', TARGET_VERSION))

# New service worker based on v24.254.
sw_source = ROOT / 'sw-v24-254.js'
if not sw_source.exists():
    raise RuntimeError('Missing sw-v24-254.js required for v24.255 cache wiring.')

sw = sw_source.read_text(encoding='utf-8').replace('24-254', TARGET_QUERY).replace('24.254', TARGET_VERSION)
precache_match = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not precache_match:
    raise RuntimeError('Could not locate service-worker precache array.')
body = precache_match.group(2)
for url in [
    './task-progression-v255.js?v=24-255',
    './task-progression-v255.css?v=24-255',
]:
    if url not in body:
        body += f"\n  '{url}',"
sw = sw[:precache_match.start(2)] + body + sw[precache_match.end(2):]
write('sw-v24-255.js', sw)
write('sw.js', "importScripts('./sw-v24-255.js?v=24-255');\n")
write('sw-v24-244.js', "// Legacy service-worker bridge.\nimportScripts('./sw-v24-255.js?v=24-255');\n")

write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')
write('UPDATE-v24.255.txt', '''Duckie Days v24.255 — Task UI + Collectible Shelf Polish\n\n- Tasks window compacted: centered title at the top, then a clean row for Task Shop, Completed, and Add Task.\n- Collectible Shelf now mirrors the same kind of layout behavior as the Shelf of Ducks and adds color/theme swapping.\n- Room polish: mirror and book moved upward; right shelf arrow aligned with the left-side duck shelf arrow.\n''')
print('Patched Duckie Days to v24.255 successfully.')

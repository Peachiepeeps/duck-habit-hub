#!/usr/bin/env python3
import json, pathlib, re, sys, shutil

ROOT = pathlib.Path('.').resolve()
if len(sys.argv) > 1:
    candidate = pathlib.Path(sys.argv[1]).resolve()
    if candidate.is_dir() and (candidate / 'tools').exists():
        ROOT = candidate.parent.resolve()

TARGET_VERSION='24.256'
TARGET_QUERY='24-256'


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def write(rel, text):
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')

def copy(src_rel, dest_rel):
    src = pathlib.Path(sys.argv[1]).resolve() / src_rel if len(sys.argv) > 1 else pathlib.Path(src_rel)
    if not src.exists():
        src = pathlib.Path(src_rel)
    dest = ROOT / dest_rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)

required=['index.html','version.json','task-progression-v255.js','task-progression-v255.css','sw.js','sw-v24-255.js']
missing=[p for p in required if not (ROOT / p).exists()]
if missing:
    raise RuntimeError('Missing required files: ' + ', '.join(missing))

current=str(json.loads(read('version.json')).get('version'))
if current != '24.255':
    raise RuntimeError(f'Expected Duckie Days v24.255, found {current!r}.')

copy('task-progression-v256.js','task-progression-v256.js')
copy('task-progression-v256.css','task-progression-v256.css')

index = read('index.html')
css_link='  <link rel="stylesheet" href="task-progression-v256.css?v=24-256" />\n'
if 'task-progression-v256.css' not in index:
    anchor='  <link rel="stylesheet" href="task-progression-v255.css?v=24-255" />\n'
    if anchor in index:
        index=index.replace(anchor, anchor+css_link, 1)
    else:
        idx=index.rfind('</head>')
        index=index[:idx]+css_link+index[idx:]
script_tag='  <script src="task-progression-v256.js?v=24-256"></script>\n'
if 'task-progression-v256.js' not in index:
    anchor='  <script src="task-progression-v255.js?v=24-255"></script>\n'
    if anchor in index:
        index=index.replace(anchor, anchor+script_tag, 1)
    else:
        idx=index.rfind('</body>')
        index=index[:idx]+script_tag+index[idx:]
write('index.html', index)

sw = read('sw-v24-255.js')
sw = sw.replace('24.255', TARGET_VERSION).replace('24-255', TARGET_QUERY).replace('./sw-v24-255.js', './sw-v24-256.js')
precache_match = re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)', sw, re.S)
if not precache_match:
    raise RuntimeError('Could not locate service-worker precache array.')
body = precache_match.group(2)
for url in ['./task-progression-v256.js?v=24-256','./task-progression-v256.css?v=24-256']:
    if url not in body:
        body += f"\n  '{url}',"
sw = sw[:precache_match.start(2)] + body + sw[precache_match.end(2):]
write('sw-v24-256.js', sw)
write('sw.js', "importScripts('./sw-v24-256.js?v=24-256');\n")

write('version.json', json.dumps({'version': TARGET_VERSION}, indent=2) + '\n')
write('UPDATE-v24.256.txt', 'Duckie Days v24.256 installed.\n')
print('Patched Duckie Days to v24.256')

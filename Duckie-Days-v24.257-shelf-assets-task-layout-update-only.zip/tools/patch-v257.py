from pathlib import Path
import json, re, shutil, sys

ROOT=Path.cwd()
PKG=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[0]
TARGET='24.257'
QUERY='24-257'

def read(rel): return (ROOT/rel).read_text(encoding='utf-8')
def write(rel,text):
    p=ROOT/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8')
def copy(src_rel,dst_rel=None):
    src=PKG/src_rel; dst=ROOT/(dst_rel or src_rel)
    if not src.exists(): raise RuntimeError(f'Missing package file: {src_rel}')
    dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
def replace_once(text,old,new,label):
    count=text.count(old)
    if count!=1: raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old,new,1)

required=['index.html','version.json','task-progression-v254.js','task-progression-v254.css','style-v24-201.css','sw-v24-256.js','sw.js']
missing=[p for p in required if not (ROOT/p).exists()]
if missing: raise RuntimeError('Missing required files: '+', '.join(missing))
current=str(json.loads(read('version.json')).get('version'))
if current!='24.256': raise RuntimeError(f'Expected Duckie Days v24.256, found {current!r}.')

copy('task-progression-v257.js')
copy('task-progression-v257.css')

# ------------------------------------------------------------------
# Use the real 24-slot Shelf-of-Ducks asset/layout for collectibles.
# ------------------------------------------------------------------
index=read('index.html')
old_shelf='''      <section id="taskCollectibleWing" class="task-collectible-wing-v254 hidden" aria-label="Task Collectible Shelf">
        <div class="task-collectible-title-v254">
          <span>TASK TREASURES</span>
          <strong>Collectible Shelf</strong>
        </div>
        <div id="taskCollectibleSlots" class="task-collectible-slots-v254"></div>
      </section>'''
new_shelf='''      <section id="taskCollectibleWing" class="task-collectible-wing-v254 task-collectible-wing-v257 hidden" aria-label="Task Collectible Shelf">
        <img id="taskCollectibleShelfImage" class="wing-shelf-image task-collectible-shelf-image-v257" src="assets/room-expansion/shelves/shelf-cream.webp" alt="" aria-hidden="true" loading="lazy" decoding="async" />

        <div class="task-collectible-title-v254">
          <span>TASK TREASURES</span>
          <strong>Collectible Shelf</strong>
        </div>

        <div id="taskCollectibleShelfStylePicker" class="task-shelf-style-picker-v257" aria-label="Collectible shelf style">
          <span>Shelf</span>
          <button type="button" data-task-shelf-style="cream" aria-label="Cream shelf" title="Cream shelf"></button>
          <button type="button" data-task-shelf-style="brown" aria-label="Brown shelf" title="Brown shelf"></button>
          <button type="button" data-task-shelf-style="dark-brown" aria-label="Dark brown shelf" title="Dark brown shelf"></button>
        </div>

        <div id="taskCollectibleSlots" class="task-collectible-slots-v254"></div>
      </section>'''
index=replace_once(index,old_shelf,new_shelf,'replace collectible shelf markup')

# ------------------------------------------------------------------
# Tasks header order exactly: Your Tasks / actions / tabs / treasure / list.
# ------------------------------------------------------------------
old_header='''        <div class="panel-header tasks-header">
          <div class="tasks-heading">
            <p class="eyebrow">YOUR TASKS</p>
            <h1>Tasks</h1>
          </div>
          <div class="tasks-header-actions">
            <button id="openTaskShopButton" class="task-shop-open-v254" type="button">
              <img src="assets/task-shop/Duck-bucks.png" alt="" />
              <span>Task Shop</span>
              <strong id="taskHeaderBuckCount">0</strong>
            </button>
            <button id="completedTab" class="completed-tasks-button" type="button" aria-selected="false">✓ Completed</button>
            <button id="addTaskButton" class="add-task-button" type="button">＋ Add Task</button>
          </div>
          <button id="closeTasks" class="close-button" type="button" aria-label="Return to menu">×</button>
        </div>'''
new_header='''        <div class="tasks-header-v257">
          <h1>Your Tasks</h1>
          <button id="closeTasks" class="close-button" type="button" aria-label="Return to menu">×</button>
        </div>

        <div class="tasks-header-actions-v257">
          <button id="openTaskShopButton" class="task-shop-open-v254" type="button">
            <img src="assets/task-shop/Duck-bucks.png" alt="" />
            <span>Task Shop</span>
            <strong id="taskHeaderBuckCount">0</strong>
          </button>
          <button id="completedTab" class="completed-tasks-button" type="button" aria-selected="false">✓ Completed</button>
          <button id="addTaskButton" class="add-task-button" type="button">＋ Add Task</button>
        </div>'''
index=replace_once(index,old_header,new_header,'replace task header')
index=index.replace('<section id="tasksPanel" class="panel tasks-panel hidden"','<section id="tasksPanel" class="panel tasks-panel tasks-panel-v257 hidden"',1)

# Retire the two experimental layout layers; keep v254 progression + new v257 polish.
index=re.sub(r'\s*<link rel="stylesheet" href="task-progression-v255\.css\?v=[^"]+"\s*/>','',index)
index=re.sub(r'\s*<link rel="stylesheet" href="task-progression-v256\.css\?v=[^"]+"\s*/>','',index)
index=re.sub(r'\s*<script src="task-progression-v255\.js\?v=[^"]+"></script>','',index)
index=re.sub(r'\s*<script src="task-progression-v256\.js\?v=[^"]+"></script>','',index)

# Cache-bust modified progression JS and load v257 last.
index=re.sub(r'task-progression-v254\.js\?v=[^"\s]+','task-progression-v254.js?v=24-257',index)
css_anchor=re.search(r'(\s*<link rel="stylesheet" href="task-progression-v254\.css\?v=[^"]+"\s*/>)',index)
if not css_anchor: raise RuntimeError('Could not locate v254 task CSS link')
if 'task-progression-v257.css' not in index:
    pos=css_anchor.end(); index=index[:pos]+'\n  <link rel="stylesheet" href="task-progression-v257.css?v=24-257" />'+index[pos:]
script_anchor=re.search(r'(\s*<script src="task-progression-v254\.js\?v=[^"]+"></script>)',index)
if not script_anchor: raise RuntimeError('Could not locate v254 task JS script')
if 'task-progression-v257.js' not in index:
    pos=script_anchor.end(); index=index[:pos]+'\n  <script src="task-progression-v257.js?v=24-257"></script>'+index[pos:]

# Fix root app build/update checker so installed apps actually refresh to this build.
index=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";',f'const DUCK_HUB_BUILD = "{TARGET}";',index)
index=re.sub(r'navigator\.serviceWorker\.register\("\.\/sw\.js\?v=[^"]+"',f'navigator.serviceWorker.register("./sw.js?v={QUERY}"',index)
write('index.html',index)

# ------------------------------------------------------------------
# Patch v254 progression logic: 24 slots + compact treasure outside task list.
# ------------------------------------------------------------------
task=read('task-progression-v254.js')
task=replace_once(task,'const SHELF_SLOTS=12;','const SHELF_SLOTS=24;','expand collectible shelf to 24 slots')
task=task.replace("btn.className=`task-collectible-slot-v254${item?' occupied':''}`;","btn.className=`wing-duck-slot task-collectible-slot-v254${item?' occupied':''}`;",1)

pattern=r'''  function renderTaskProgressCard\(\)\{.*?\n  \}\n\n  function queueMessages'''
replacement='''  function renderTaskProgressCard(){
    const p=ensureProgress();
    const card=document.createElement('section');
    card.className='task-treasure-card-v254 task-treasure-card-v257';

    const head=document.createElement('div');head.className='task-treasure-head-v257';
    const label=document.createElement('span');label.textContent='TREASURE TASKS';
    const completed=document.createElement('strong');completed.textContent=`${p.completedToday} task${p.completedToday===1?'':'s'} completed today`;
    head.append(label,completed);

    const next=nextTreasureTarget(p.completedToday);
    const prev=previousTreasureTarget(p.completedToday,next);
    const ratio=Math.max(0,Math.min(1,(p.completedToday-prev)/Math.max(1,next-prev)));
    const bar=document.createElement('div');bar.className='task-treasure-bar-v254';
    const fill=document.createElement('span');fill.style.width=`${ratio*100}%`;bar.append(fill);
    const progress=document.createElement('div');progress.className='task-treasure-progress-v254';
    progress.innerHTML=`<span>Next treasure at <b>${next}</b></span><span>${p.completedToday} / ${next}</span>`;

    const milestones=document.createElement('div');milestones.className='task-treasure-milestones-v254';
    FIXED_MILESTONES.forEach(m=>{
      const chip=document.createElement('div');
      const claimed=Boolean(p.claimedMilestones[m.key]);
      chip.className=`task-treasure-chip-v254${claimed?' claimed':''}`;
      chip.innerHTML=`<b>${claimed?'✓':m.label}</b><span>${m.reward}</span>`;
      milestones.append(chip);
    });

    const statusRow=document.createElement('div');statusRow.className='task-treasure-status-row-v257';

    const bucks=document.createElement('div');bucks.className='task-treasure-status-v257';
    bucks.append(makeBuckInline(p.duckBucks));

    const perfect=document.createElement('div');perfect.className=`task-treasure-status-v257${p.perfectDayClaimed?' active':''}`;
    const perfectIcon=document.createElement('span');perfectIcon.className='status-icon-v257';perfectIcon.textContent='🧰';
    const perfectCopy=document.createElement('span');perfectCopy.className='status-copy-v257';
    perfectCopy.innerHTML=`<strong>Perfect Day</strong><small>${p.perfectDayClaimed?'Obtained':'Not yet'}</small>`;
    perfect.append(perfectIcon,perfectCopy);

    const boost=document.createElement('div');boost.className=`task-treasure-status-v257${p.buddyBoostActive?' active':''}`;
    const boostIcon=document.createElement('span');boostIcon.className='status-icon-v257';boostIcon.textContent='🐷';
    const boostCopy=document.createElement('span');boostCopy.className='status-copy-v257';
    boostCopy.innerHTML=`<strong>Buddy Boost</strong><small>${p.buddyBoostActive?'Activated':'5 tasks'}</small>`;
    boost.append(boostIcon,boostCopy);

    statusRow.append(bucks,perfect,boost);
    card.append(head,bar,progress,milestones,statusRow);
    return card;
  }

  function queueMessages'''
task,new_count=re.subn(pattern,replacement,task,count=1,flags=re.S)
if new_count!=1: raise RuntimeError(f'replace Task Treasure renderer: found {new_count}')

old_hook='''  if(typeof renderTasks==='function'){
    const previousRenderTasks=renderTasks;
    renderTasks=function(){
      const result=previousRenderTasks.apply(this,arguments);
      ensureProgress();
      if(currentTaskTab==='today' && tasksContent && !tasksContent.querySelector('.task-treasure-card-v254')){
        tasksContent.prepend(renderTaskProgressCard());
      }
      renderDuckBuckBalances();
      return result;
    };
  }'''
new_hook='''  if(typeof renderTasks==='function'){
    const previousRenderTasks=renderTasks;
    renderTasks=function(){
      const result=previousRenderTasks.apply(this,arguments);
      ensureProgress();
      if(tasksContent){
        const panel=tasksContent.closest('#tasksPanel');
        panel?.querySelectorAll('.task-treasure-card-v254').forEach(node=>node.remove());
        if(currentTaskTab==='today') tasksContent.before(renderTaskProgressCard());
      }
      renderDuckBuckBalances();
      return result;
    };
  }'''
task=replace_once(task,old_hook,new_hook,'move Task Treasure above assigned tasks')
write('task-progression-v254.js',task)

# ------------------------------------------------------------------
# Service worker + version.
# ------------------------------------------------------------------
sw=read('sw-v24-256.js')
sw=sw.replace('24-256',QUERY).replace('24.256',TARGET).replace('./sw-v24-256.js','./sw-v24-257.js')
# Retire v255/v256 layout files from shell if they survived the simple build replacement.
for old in [
    "  './task-progression-v255.js?v=24-257',\n",
    "  './task-progression-v255.css?v=24-257',\n",
    "  './task-progression-v256.js?v=24-257',\n",
    "  './task-progression-v256.css?v=24-257',\n",
]:
    sw=sw.replace(old,'')
sw=sw.replace("'./task-progression-v254.js?v=24-257'","'./task-progression-v254.js?v=24-257'")
match=re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)',sw,re.S)
if not match: raise RuntimeError('Could not locate service-worker APP_SHELL array')
body=match.group(2)
for url in [
    './task-progression-v257.js?v=24-257',
    './task-progression-v257.css?v=24-257',
    './assets/room-expansion/shelves/shelf-cream.webp',
    './assets/room-expansion/shelves/shelf-brown.webp',
    './assets/room-expansion/shelves/shelf-dark-brown.webp',
]:
    if url not in body: body += f"\n  '{url}',"
sw=sw[:match.start(2)]+body+sw[match.end(2):]
write('sw-v24-257.js',sw)
write('sw.js',"importScripts('./sw-v24-257.js?v=24-257');\n")
write('sw-v24-244.js',"// Legacy service-worker bridge.\nimportScripts('./sw-v24-257.js?v=24-257');\n")
write('version.json',json.dumps({'version':TARGET},indent=2)+'\n')
write('UPDATE-v24.257.txt','''Duckie Days v24.257 — Shelf Asset + Tasks Layout Correction\n\n- Collectible Shelf now uses the exact same user-drawn shelf assets and slot geometry as Shelf of Ducks.\n- Collectible shelf supports cream, brown, and dark-brown shelf assets.\n- Main room right arrow lines up with the left arrow; Book sits above it with a larger tap target.\n- Tasks now follow the requested order and the Task Treasure area is condensed to match the reference.\n''')
print('Patched Duckie Days to v24.257 successfully.')

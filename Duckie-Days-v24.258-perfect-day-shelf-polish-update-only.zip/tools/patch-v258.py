from pathlib import Path
import json, re, shutil, sys

ROOT=Path.cwd()
PKG=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[0]
TARGET='24.258'
QUERY='24-258'


def read(rel):
    return (ROOT/rel).read_text(encoding='utf-8')

def write(rel,text):
    p=ROOT/rel
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding='utf-8')

def copy(src_rel,dst_rel=None):
    src=PKG/src_rel
    dst=ROOT/(dst_rel or src_rel)
    if not src.exists():
        raise RuntimeError(f'Missing package file: {src_rel}')
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)

def replace_once(text,old,new,label):
    count=text.count(old)
    if count!=1:
        raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old,new,1)

required=['index.html','version.json','task-progression-v254.js','task-progression-v257.css','sw-v24-257.js','sw.js']
missing=[p for p in required if not (ROOT/p).exists()]
if missing:
    raise RuntimeError('Missing required files: '+', '.join(missing))
current=str(json.loads(read('version.json')).get('version'))
if current!='24.257':
    raise RuntimeError(f'Expected Duckie Days v24.257, found {current!r}.')

copy('task-progression-v258.css')

# ------------------------------------------------------------------
# Index: load v258 css, remove Task Shop number, refresh build/cache.
# ------------------------------------------------------------------
index=read('index.html')
index=index.replace('task-progression-v254.js?v=24-257','task-progression-v254.js?v=24-258')
index=index.replace('task-progression-v257.css?v=24-257','task-progression-v257.css?v=24-258')
index=index.replace('task-progression-v257.js?v=24-257','task-progression-v257.js?v=24-258')
if 'task-progression-v258.css' not in index:
    anchor='<link rel="stylesheet" href="task-progression-v257.css?v=24-258" />'
    index=replace_once(index,anchor,anchor+'\n  <link rel="stylesheet" href="task-progression-v258.css?v=24-258" />','insert v258 css link')
old_button='''          <button id="openTaskShopButton" class="task-shop-open-v254" type="button">
            <img src="assets/task-shop/Duck-bucks.png" alt="" />
            <span>Task Shop</span>
            <strong id="taskHeaderBuckCount">0</strong>
          </button>'''
new_button='''          <button id="openTaskShopButton" class="task-shop-open-v254" type="button">
            <img src="assets/task-shop/Duck-bucks.png" alt="" />
            <span>Task Shop</span>
          </button>'''
if old_button in index:
    index=index.replace(old_button,new_button,1)
index=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";',f'const DUCK_HUB_BUILD = "{TARGET}";',index)
index=re.sub(r'navigator\.serviceWorker\.register\("\.\/sw\.js\?v=[^"]+"',f'navigator.serviceWorker.register("./sw.js?v={QUERY}"',index)
write('index.html',index)

# ------------------------------------------------------------------
# Task progression: icons + 5-task Perfect Day gate.
# ------------------------------------------------------------------
task=read('task-progression-v254.js')
old_block='''    const statusRow=document.createElement('div');statusRow.className='task-treasure-status-row-v257';

    const bucks=document.createElement('div');bucks.className='task-treasure-status-v257';
    bucks.append(makeBuckInline(p.duckBucks));

    const perfect=document.createElement('div');perfect.className=`task-treasure-status-v257${p.perfectDayClaimed?' active':''}`;
    const perfectIcon=document.createElement('span');perfectIcon.className='status-icon-v257';perfectIcon.textContent='🧰';
    const perfectCopy=document.createElement('span');perfectCopy.className='status-copy-v257';
    perfectCopy.innerHTML=`<strong>Perfect Day</strong><small>${p.perfectDayClaimed?'Obtained':'Not yet'}</small>`;
    perfect.append(perfectIcon,perfectCopy);

    const boost=document.createElement('div');boost.className=`task-treasure-status-v257${p.buddyBoostActive?' active':''}`;
    const boostIcon=document.createElement('span');boostIcon.className='status-icon-v257';boostIcon.textContent='🐷';
    const boostCopy=document.createElement('span');boostCopy.className='status-copy-v257';
    boostCopy.innerHTML=`<strong>Buddy Boost</strong><small>${p.buddyBoostActive?'Activated':'5 tasks'}</small>`;
    boost.append(boostIcon,boostCopy);

    statusRow.append(bucks,perfect,boost);'''
new_block='''    const statusRow=document.createElement('div');statusRow.className='task-treasure-status-row-v257';

    const bucks=document.createElement('div');bucks.className='task-treasure-status-v257';
    bucks.append(makeBuckInline(p.duckBucks));

    const perfect=document.createElement('div');perfect.className=`task-treasure-status-v257${p.perfectDayClaimed?' active':''}`;
    const perfectIcon=document.createElement('img');perfectIcon.className='status-icon-img-v258';perfectIcon.src='duck-quest/assets/items/chests/treasure/closed.png';perfectIcon.alt='';
    const perfectCopy=document.createElement('span');perfectCopy.className='status-copy-v257';
    perfectCopy.innerHTML=`<strong>Perfect Day</strong><small>${p.perfectDayClaimed?'Obtained':'5 tasks + clear list'}</small>`;
    perfect.append(perfectIcon,perfectCopy);

    const boost=document.createElement('div');boost.className=`task-treasure-status-v257${p.buddyBoostActive?' active':''}`;
    const boostIcon=document.createElement('img');boostIcon.className='status-icon-img-v258';boostIcon.src='duck-quest/assets/enemies/cat-slime/base/Strawberry-idle-1-neutral.png';boostIcon.alt='';
    const boostCopy=document.createElement('span');boostCopy.className='status-copy-v257';
    boostCopy.innerHTML=`<strong>Buddy Boost</strong><small>${p.buddyBoostActive?'Activated':'5 tasks'}</small>`;
    boost.append(boostIcon,boostCopy);

    statusRow.append(bucks,perfect,boost);'''
task=replace_once(task,old_block,new_block,'replace status row icons')
old_gate="""      const dueAfter=readyTodayCount();
      if(dueBefore>0 && dueAfter===0 && !p.perfectDayClaimed){
        p.perfectDayClaimed=true;
        messages.push(perfectDayReward());
      }"""
new_gate="""      const dueAfter=readyTodayCount();
      if(dueBefore>0 && dueAfter===0 && p.completedToday>=5 && !p.perfectDayClaimed){
        p.perfectDayClaimed=true;
        messages.push(perfectDayReward());
      }"""
task=replace_once(task,old_gate,new_gate,'require 5 tasks for Perfect Day')
write('task-progression-v254.js',task)

# ------------------------------------------------------------------
# Service worker + version.
# ------------------------------------------------------------------
sw=read('sw-v24-257.js')
sw=sw.replace('24-257',QUERY).replace('24.257',TARGET).replace('./sw-v24-257.js','./sw-v24-258.js')
match=re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)',sw,re.S)
if not match:
    raise RuntimeError('Could not locate service-worker asset array')
body=match.group(2)
for url in [
    './task-progression-v258.css?v=24-258',
    './duck-quest/assets/items/chests/treasure/closed.png',
    './duck-quest/assets/enemies/cat-slime/base/Strawberry-idle-1-neutral.png',
]:
    if url not in body:
        body += f"\n  '{url}',"
sw=sw[:match.start(2)]+body+sw[match.end(2):]
write('sw-v24-258.js',sw)
write('sw.js',"importScripts('./sw-v24-258.js?v=24-258');\n")
write('sw-v24-244.js',"// Legacy service-worker bridge.\nimportScripts('./sw-v24-258.js?v=24-258');\n")
write('version.json',json.dumps({'version':TARGET},indent=2)+'\n')
write('UPDATE-v24.258.txt','''Duckie Days v24.258 — Task polish follow-up\n\n- Task Shop header button no longer shows a number.\n- Perfect Day now requires 5 completed tasks plus clearing today\'s due tasks.\n- Task Treasure status row now uses the requested closed chest and pink cat-slime icons.\n- Collectible shelf slot positions now mirror Shelf of Ducks lower-row placement.\n- Main-room arrows line up and the Book is lifted higher for easier access.\n''')
print('Patched Duckie Days to v24.258 successfully.')

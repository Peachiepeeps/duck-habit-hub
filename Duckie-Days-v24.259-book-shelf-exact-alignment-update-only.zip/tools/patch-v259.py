from pathlib import Path
import json, re, shutil, sys

ROOT=Path.cwd()
PKG=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[0]
TARGET='24.259'
QUERY='24-259'


def read(rel): return (ROOT/rel).read_text(encoding='utf-8')
def write(rel,text):
    p=ROOT/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8')
def copy(src_rel,dst_rel=None):
    src=PKG/src_rel; dst=ROOT/(dst_rel or src_rel)
    if not src.exists(): raise RuntimeError(f'Missing package file: {src_rel}')
    dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
def replace_once(text,old,new,label):
    count=text.count(old)
    if count!=1: raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old,new,1)

required=['index.html','version.json','task-progression-v254.js','task-progression-v257.js','task-progression-v258.css','sw-v24-258.js','sw.js']
missing=[p for p in required if not (ROOT/p).exists()]
if missing: raise RuntimeError('Missing required files: '+', '.join(missing))
current=str(json.loads(read('version.json')).get('version'))
if current!='24.258': raise RuntimeError(f'Expected Duckie Days v24.258, found {current!r}.')

copy('task-progression-v259.css')

index=read('index.html')
# Let the task collectible grid literally share the Shelf of Ducks grid class.
index=replace_once(index,
    '<div id="taskCollectibleSlots" class="task-collectible-slots-v254"></div>',
    '<div id="taskCollectibleSlots" class="wing-duck-slots task-collectible-slots-v254"></div>',
    'add exact duck shelf grid class')

# Bump task asset queries and add the final corrective CSS last.
index=index.replace('task-progression-v254.css?v=24-254','task-progression-v254.css?v=24-259')
index=index.replace('task-progression-v254.js?v=24-258','task-progression-v254.js?v=24-259')
index=index.replace('task-progression-v257.css?v=24-258','task-progression-v257.css?v=24-259')
index=index.replace('task-progression-v257.js?v=24-258','task-progression-v257.js?v=24-259')
index=index.replace('task-progression-v258.css?v=24-258','task-progression-v258.css?v=24-259')
if 'task-progression-v259.css' not in index:
    anchor='<link rel="stylesheet" href="task-progression-v258.css?v=24-259" />'
    index=replace_once(index,anchor,anchor+'\n  <link rel="stylesheet" href="task-progression-v259.css?v=24-259" />','insert v259 css')

index=re.sub(r'<meta name="duck-habit-build" content="[^"]+"\s*/>',f'<meta name="duck-habit-build" content="{TARGET}" />',index)
index=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";',f'const DUCK_HUB_BUILD = "{TARGET}";',index)
index=re.sub(r'navigator\.serviceWorker\.register\("\.\/sw\.js\?v=[^"]+"',f'navigator.serviceWorker.register("./sw.js?v={QUERY}"',index)
write('index.html',index)

# Service worker.
sw=read('sw-v24-258.js')
sw=sw.replace('24-258',QUERY).replace('24.258',TARGET).replace('./sw-v24-258.js','./sw-v24-259.js')
match=re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)',sw,re.S)
if not match: raise RuntimeError('Could not locate service-worker asset array')
body=match.group(2)
url='./task-progression-v259.css?v=24-259'
if url not in body: body += f"\n  '{url}',"
sw=sw[:match.start(2)]+body+sw[match.end(2):]
write('sw-v24-259.js',sw)
write('sw.js',"importScripts('./sw-v24-259.js?v=24-259');\n")
write('sw-v24-244.js',"// Legacy service-worker bridge.\nimportScripts('./sw-v24-259.js?v=24-259');\n")
write('version.json',json.dumps({'version':TARGET},indent=2)+'\n')
write('UPDATE-v24.259.txt','''Duckie Days v24.259 — Book + Collectible Shelf Exact Alignment\n\n- Book is moved much higher than the room arrows, with its tap target moved with it.\n- Collectible Shelf now literally uses the Shelf of Ducks grid class.\n- Collectible shelf rows use the exact final Shelf of Ducks row heights and tall-phone geometry.\n- Collectible item and empty-slot baselines match the current Shelf of Ducks seating rules.\n- Task panel layout is otherwise unchanged.\n''')
print('Patched Duckie Days to v24.259 successfully.')

from pathlib import Path
import json, re, shutil, sys

ROOT=Path.cwd()
PKG=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[0]
TARGET='24.260'
QUERY='24-260'


def read(rel): return (ROOT/rel).read_text(encoding='utf-8')
def write(rel,text):
    p=ROOT/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8')
def copy(src_rel,dst_rel=None):
    src=PKG/src_rel; dst=ROOT/(dst_rel or src_rel)
    if not src.exists(): raise RuntimeError(f'Missing package file: {src_rel}')
    dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
def replace_once(text,old,new,label):
    count=text.count(old)
    if count!=1: raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old,new,1)

required=['index.html','version.json','task-progression-v254.js','task-progression-v259.css','sw-v24-259.js','sw.js']
missing=[p for p in required if not (ROOT/p).exists()]
if missing: raise RuntimeError('Missing required files: '+', '.join(missing))
current=str(json.loads(read('version.json')).get('version'))
if current!='24.259': raise RuntimeError(f'Expected Duckie Days v24.259, found {current!r}.')

copy('task-progression-v260.js')
copy('task-progression-v260.css')

# ------------------------------------------------------------------
# Tasks: make the Treasure bar visibly fill with every completed task,
# and keep a collectible unique when moved back from dresser to shelf.
# ------------------------------------------------------------------
task=read('task-progression-v254.js')
old_ratio='''    const next=nextTreasureTarget(p.completedToday);\n    const prev=previousTreasureTarget(p.completedToday,next);\n    const ratio=Math.max(0,Math.min(1,(p.completedToday-prev)/Math.max(1,next-prev)));'''
new_ratio='''    const next=nextTreasureTarget(p.completedToday);\n    const ratio=Math.max(0,Math.min(1,p.completedToday/Math.max(1,next)));'''
task=replace_once(task,old_ratio,new_ratio,'make Task Treasure bar fill per task')

old_choose='''  function chooseTaskCollectible(id){\n    if(!Number.isInteger(selectedTaskCollectibleSlot)) return;\n    const p=ensureProgress();\n    if(!p.collectiblesOwned.includes(id)) return;\n    p.shelfSlots.forEach((current,index)=>{if(current===id)p.shelfSlots[index]=null;});\n    p.shelfSlots[selectedTaskCollectibleSlot]=id;\n    saveNow();closeTaskCollectiblePicker();renderTaskShelf();\n  }'''
new_choose='''  function chooseTaskCollectible(id){\n    if(!Number.isInteger(selectedTaskCollectibleSlot)) return;\n    const p=ensureProgress();\n    if(!p.collectiblesOwned.includes(id)) return;\n    p.shelfSlots.forEach((current,index)=>{if(current===id)p.shelfSlots[index]=null;});\n    if(p.dresserCollectibleByRoom && typeof p.dresserCollectibleByRoom==='object'){\n      Object.keys(p.dresserCollectibleByRoom).forEach(room=>{\n        if(p.dresserCollectibleByRoom[room]===id) delete p.dresserCollectibleByRoom[room];\n      });\n    }\n    p.shelfSlots[selectedTaskCollectibleSlot]=id;\n    saveNow();closeTaskCollectiblePicker();renderTaskShelf();\n    try{window.DuckieTaskDresserV260?.renderDresserCollectible?.();}catch(error){}\n  }'''
task=replace_once(task,old_choose,new_choose,'keep collectible unique between shelf and dresser')
write('task-progression-v254.js',task)

# ------------------------------------------------------------------
# Index: remove the bottom helper text, add v260 assets, bump cache keys.
# ------------------------------------------------------------------
index=read('index.html')
index=index.replace('''        <p class="task-kind-note">Anytime tasks wait until you complete them once. Pinned dated tasks stay on Today. No penalties. ♡</p>\n''','',1)

for name in ['254','257','258','259']:
    index=index.replace(f'task-progression-v{name}.css?v=24-259',f'task-progression-v{name}.css?v=24-260')
for name in ['254','257']:
    index=index.replace(f'task-progression-v{name}.js?v=24-259',f'task-progression-v{name}.js?v=24-260')

if 'task-progression-v260.css' not in index:
    anchor='<link rel="stylesheet" href="task-progression-v259.css?v=24-260" />'
    index=replace_once(index,anchor,anchor+'\n  <link rel="stylesheet" href="task-progression-v260.css?v=24-260" />','insert v260 css')
if 'task-progression-v260.js' not in index:
    anchor='<script src="task-progression-v257.js?v=24-260"></script>'
    index=replace_once(index,anchor,anchor+'\n  <script src="task-progression-v260.js?v=24-260"></script>','insert v260 js')

index=re.sub(r'<meta name="duck-habit-build" content="[^"]+"\s*/>',f'<meta name="duck-habit-build" content="{TARGET}" />',index)
index=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";',f'const DUCK_HUB_BUILD = "{TARGET}";',index)
index=re.sub(r'navigator\.serviceWorker\.register\("\.\/sw\.js\?v=[^"]+"',f'navigator.serviceWorker.register("./sw.js?v={QUERY}"',index)
write('index.html',index)

# ------------------------------------------------------------------
# Service worker + version.
# ------------------------------------------------------------------
sw=read('sw-v24-259.js')
sw=sw.replace('24-259',QUERY).replace('24.259',TARGET).replace('./sw-v24-259.js','./sw-v24-260.js')
match=re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)',sw,re.S)
if not match: raise RuntimeError('Could not locate service-worker asset array')
body=match.group(2)
for url in [
    './task-progression-v260.js?v=24-260',
    './task-progression-v260.css?v=24-260',
]:
    if url not in body: body += f"\n  '{url}',"
sw=sw[:match.start(2)]+body+sw[match.end(2):]
write('sw-v24-260.js',sw)
write('sw.js',"importScripts('./sw-v24-260.js?v=24-260');\n")
write('sw-v24-244.js',"// Legacy service-worker bridge.\nimportScripts('./sw-v24-260.js?v=24-260');\n")
write('version.json',json.dumps({'version':TARGET},indent=2)+'\n')
write('UPDATE-v24.260.txt','''Duckie Days v24.260 — Home Plush + Task Polish\n\n- Room Book nudged a little farther right while keeping its current height.\n- Owned Task Shop plushes can be placed on the dresser in the current home room.\n- One dresser plush can be displayed at a time; placing it there moves it off the Task Treasure shelf.\n- Task Treasure progress bar now visibly fills with each completed task.\n- Removed the helper text from the bottom of the Tasks window.\n''')
print('Patched Duckie Days to v24.260 successfully.')

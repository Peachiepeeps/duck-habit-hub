from pathlib import Path
import json, re, shutil, sys

ROOT=Path.cwd()
PKG=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
TARGET='24.261'
QUERY='24-261'


def read(rel):
    return (ROOT/rel).read_text(encoding='utf-8')

def write(rel,text):
    p=ROOT/rel
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding='utf-8')

def copy(src_rel,dst_rel=None):
    src=PKG/src_rel
    dst=ROOT/(dst_rel or src_rel)
    if not src.exists():
        raise RuntimeError(f'Missing package file: {src_rel}')
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)

def replace_once(text,old,new,label):
    count=text.count(old)
    if count!=1:
        raise RuntimeError(f'{label}: expected exactly one match, found {count}')
    return text.replace(old,new,1)

required=['index.html','version.json','task-progression-v254.js','task-progression-v260.css','sw-v24-260.js','sw.js']
missing=[p for p in required if not (ROOT/p).exists()]
if missing:
    raise RuntimeError('Missing required files: '+', '.join(missing))
current=str(json.loads(read('version.json')).get('version'))
if current!='24.260':
    raise RuntimeError(f'Expected Duckie Days v24.260, found {current!r}.')

copy('task-progression-v261.js')
copy('task-progression-v261.css')

# ------------------------------------------------------------------
# Task Treasure bar: fill against the full 60-task daily ladder.
# ------------------------------------------------------------------
task=read('task-progression-v254.js')
old='''    const next=nextTreasureTarget(p.completedToday);\n    const ratio=Math.max(0,Math.min(1,p.completedToday/Math.max(1,next)));\n    const bar=document.createElement('div');bar.className='task-treasure-bar-v254';\n    const fill=document.createElement('span');fill.style.width=`${ratio*100}%`;bar.append(fill);\n    const progress=document.createElement('div');progress.className='task-treasure-progress-v254';\n    progress.innerHTML=`<span>Next treasure at <b>${next}</b></span><span>${p.completedToday} / ${next}</span>`;'''
new='''    const next=nextTreasureTarget(p.completedToday);\n    const dailyTotal=60;\n    const ratio=Math.max(0,Math.min(1,p.completedToday/Math.max(1,dailyTotal)));\n    const bar=document.createElement('div');bar.className='task-treasure-bar-v254';\n    const fill=document.createElement('span');fill.style.width=`${ratio*100}%`;bar.append(fill);\n    const progress=document.createElement('div');progress.className='task-treasure-progress-v254';\n    progress.innerHTML=`<span>Daily Task Treasure Goal <b>${dailyTotal}</b></span><span>${p.completedToday} / ${dailyTotal}</span>`;'''
task=replace_once(task,old,new,'set Task Treasure bar to 60-task daily fill')
write('task-progression-v254.js',task)

# ------------------------------------------------------------------
# Index + cache keys.
# ------------------------------------------------------------------
index=read('index.html')
index=re.sub(r'(task-progression-v\d+\.(?:css|js)\?v=)24-260',r'\g<1>'+QUERY,index)
if 'task-progression-v261.css' not in index:
    anchor='<link rel="stylesheet" href="task-progression-v260.css?v=24-261" />'
    index=replace_once(index,anchor,anchor+'\n  <link rel="stylesheet" href="task-progression-v261.css?v=24-261" />','insert v261 css')
if 'task-progression-v261.js' not in index:
    anchor='<script src="task-progression-v260.js?v=24-261"></script>'
    index=replace_once(index,anchor,anchor+'\n  <script src="task-progression-v261.js?v=24-261"></script>','insert v261 js')
index=re.sub(r'<meta name="duck-habit-build" content="[^"]+"\s*/>',f'<meta name="duck-habit-build" content="{TARGET}" />',index)
index=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";',f'const DUCK_HUB_BUILD = "{TARGET}";',index)
index=re.sub(r'navigator\.serviceWorker\.register\("\.\/sw\.js\?v=[^"]+"',f'navigator.serviceWorker.register("./sw.js?v={QUERY}"',index)
write('index.html',index)

# ------------------------------------------------------------------
# Service worker + version.
# ------------------------------------------------------------------
sw=read('sw-v24-260.js')
sw=sw.replace('24-260',QUERY).replace('24.260',TARGET).replace('./sw-v24-260.js','./sw-v24-261.js')
match=re.search(r'(const\s+(?:PRECACHE_URLS|ASSETS|APP_ASSETS|APP_SHELL)\s*=\s*\[)(.*?)(\n\];)',sw,re.S)
if not match:
    raise RuntimeError('Could not locate service-worker asset array')
body=match.group(2)
for url in [
    './task-progression-v261.js?v=24-261',
    './task-progression-v261.css?v=24-261',
]:
    if url not in body:
        body += f"\n  '{url}',"
sw=sw[:match.start(2)] + body + sw[match.end(2):]
write('sw-v24-261.js',sw)
write('sw.js',"importScripts('./sw-v24-261.js?v=24-261');\n")
write('sw-v24-244.js',"// Legacy service-worker bridge.\nimportScripts('./sw-v24-261.js?v=24-261');\n")
write('version.json',json.dumps({'version':TARGET},indent=2)+'\n')
write('UPDATE-v24.261.txt','''Duckie Days v24.261 — Snuggle Ducks + Task Treasure 60\n\n- Added a permanent Task Shop perk using the standard duck asset: Snuggle Ducks.\n- Once unlocked, every OC can wear a second head duck, facing the first duck like a snuggle/kiss.\n- Added a second duck assignment button in Duckipedia when the perk is owned.\n- Head-duck doubles now appear in the room, profiles, and Status portrait.\n- Task Treasure progress now fills across the full daily 60-task ladder and displays x / 60.\n- Book nudged a little farther right again.\n''')
print('Patched Duckie Days to v24.261 successfully.')

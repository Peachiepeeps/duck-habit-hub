#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys, re

ROOT=Path.cwd()
SRC=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
PAYLOAD=SRC/'payload'
BUILD='24.262'
QV='24-262'


def copy_payload():
    if not PAYLOAD.is_dir(): raise SystemExit(f'Missing payload: {PAYLOAD}')
    for src in PAYLOAD.rglob('*'):
        if src.is_file():
            rel=src.relative_to(PAYLOAD); dst=ROOT/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

def replace_once(text, old, new, label):
    if new in text: return text
    if old not in text: raise SystemExit(f'Could not patch {label}: marker missing')
    return text.replace(old,new,1)

def patch_root_index():
    p=ROOT/'index.html'; s=p.read_text(encoding='utf-8')
    s=re.sub(r'<meta name="duck-habit-build" content="[^"]+"\s*/>',f'<meta name="duck-habit-build" content="{BUILD}" />',s,1)
    s=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";',f'const DUCK_HUB_BUILD = "{BUILD}";',s,1)
    s=re.sub(r'navigator\.serviceWorker\.register\("\./sw\.js\?v=[^"]+"',f'navigator.serviceWorker.register("./sw.js?v={QV}"',s,1)
    # Card Workshop CSS and JS.
    if 'trading-cards-v262.css' not in s:
        s=replace_once(s,'<link rel="stylesheet" href="trading-cards-v250.css?v=24-254" />',
            '<link rel="stylesheet" href="trading-cards-v250.css?v=24-254" />\n  <link rel="stylesheet" href="trading-cards-v262.css?v=24-262" />','root card CSS')
    if 'trading-cards-v262.js' not in s:
        s=replace_once(s,'<script src="trading-cards-v250.js?v=24-254"></script>',
            '<script src="trading-cards-v250.js?v=24-254"></script>\n  <script src="trading-cards-v262.js?v=24-262"></script>','root card core JS')
    if 'trading-cards-ui-v262.js' not in s:
        s=replace_once(s,'<script src="trading-cards-ui-v250.js?v=24-254"></script>',
            '<script src="trading-cards-ui-v250.js?v=24-254"></script>\n  <script src="trading-cards-ui-v262.js?v=24-262"></script>','root card UI JS')
    p.write_text(s,encoding='utf-8')

def patch_duck_quest_index():
    p=ROOT/'duck-quest/index.html'; s=p.read_text(encoding='utf-8')
    if 'special-encounters-v262.css' not in s:
        s=replace_once(s,'<link rel="stylesheet" href="css/love-interests-v252.css?v=24-255">',
            '<link rel="stylesheet" href="css/love-interests-v252.css?v=24-255">\n  <link rel="stylesheet" href="css/special-encounters-v262.css?v=24-262">','quest special CSS')
    if '../trading-cards-v262.js' not in s:
        s=replace_once(s,'<script src="../trading-cards-v250.js?v=24-255"></script>',
            '<script src="../trading-cards-v250.js?v=24-255"></script>\n  <script src="../trading-cards-v262.js?v=24-262"></script>','quest card core JS')
    if 'special-encounters-v262.js' not in s:
        s=replace_once(s,'<script src="js/task-buddy-boost-v254.js?v=24-255"></script>',
            '<script src="js/task-buddy-boost-v254.js?v=24-255"></script>\n  <script src="js/special-encounters-v262.js?v=24-262"></script>','quest special JS')
    p.write_text(s,encoding='utf-8')

def patch_love_boost():
    p=ROOT/'duck-quest/js/love-interests-v252.js'; s=p.read_text(encoding='utf-8')
    if 'LUV_BIRDIE_FOCUS_V262' in s: return
    old='''  function eligibleScenes(){
    const data = load();
    const root = ensureAll(data);
    const ids = [];

    if (!root.loveInterests.lukio.encountered) ids.push("lukio");
    if (!root.loveInterests.shinobu.encountered) ids.push("shinobu");
    if (!root.loveInterests.cheryln.encountered) ids.push("cheryln");
    if (!root.loveInterests.hibiki.encountered) ids.push("hibiki");
    if (!root.loveInterests.devlin.encountered) ids.push("devlin");
    if (!root.loveInterests.yuzuru.encountered) ids.push("yuzuru");
    if (!root.loveInterests.westley.encountered) ids.push("westley");
    if (!root.loveInterests.circe.encountered) ids.push("circe");
    if (!root.loveInterests.quin.encountered) ids.push("quin");

    if (root.loveInterests.shinobu.encountered && root.loveInterests.cheryln.encountered && !root.pairScenes.shinobuCheryln.cardsGranted) {
      ids.push("shinobu-cheryln");
    }
    if (root.loveInterests.hibiki.encountered && root.loveInterests.devlin.encountered && !root.pairScenes.devlinHibiki.cardsGranted) {
      ids.push("devlin-hibiki");
    }
    if (root.loveInterests.yuzuru.encountered && root.loveInterests.westley.encountered && !root.pairScenes.westleyYuzuru.cardsGranted) {
      ids.push("westley-yuzuru");
    }
    if (root.loveInterests.circe.encountered && root.loveInterests.quin.encountered && !root.pairScenes.circeQuin.cardsGranted) {
      ids.push("circe-quin");
    }
    return ids;
  }

  function chooseScene(ids){
    const pairScenes = ids.filter(id => id.includes("-"));
    if (pairScenes.length) return pairScenes[Math.floor(Math.random() * pairScenes.length)];
    return ids[Math.floor(Math.random() * ids.length)];
  }

  function maybeBeforeNextEncounter(continueFn){
    if (bypassNextRoll) {
      bypassNextRoll = false;
      return false;
    }
    if (open || !isMiko()) return false;

    const ids = eligibleScenes();
    if (!ids.length) return false;
    if (Math.random() >= SHARED_CHANCE) return false;

    return showScene(chooseScene(ids), continueFn);
  }
'''
    new='''  // LUV_BIRDIE_FOCUS_V262: Luv & Birdie can temporarily weight one Miko love interest.
  function luvBirdieFocus(data){
    const focus=data?.luvBirdieFocusV262;
    if(!focus || !focus.characterId || Number(focus.rollsRemaining)<=0) return null;
    return focus;
  }

  function eligibleScenes(){
    const data = load();
    const root = ensureAll(data);
    const ids = [];

    if (!root.loveInterests.lukio.encountered) ids.push("lukio");
    if (!root.loveInterests.shinobu.encountered) ids.push("shinobu");
    if (!root.loveInterests.cheryln.encountered) ids.push("cheryln");
    if (!root.loveInterests.hibiki.encountered) ids.push("hibiki");
    if (!root.loveInterests.devlin.encountered) ids.push("devlin");
    if (!root.loveInterests.yuzuru.encountered) ids.push("yuzuru");
    if (!root.loveInterests.westley.encountered) ids.push("westley");
    if (!root.loveInterests.circe.encountered) ids.push("circe");
    if (!root.loveInterests.quin.encountered) ids.push("quin");

    const focus=luvBirdieFocus(data);
    if(focus && CHARACTERS[focus.characterId] && !ids.includes(focus.characterId)) ids.push(focus.characterId);

    if (root.loveInterests.shinobu.encountered && root.loveInterests.cheryln.encountered && !root.pairScenes.shinobuCheryln.cardsGranted) ids.push("shinobu-cheryln");
    if (root.loveInterests.hibiki.encountered && root.loveInterests.devlin.encountered && !root.pairScenes.devlinHibiki.cardsGranted) ids.push("devlin-hibiki");
    if (root.loveInterests.yuzuru.encountered && root.loveInterests.westley.encountered && !root.pairScenes.westleyYuzuru.cardsGranted) ids.push("westley-yuzuru");
    if (root.loveInterests.circe.encountered && root.loveInterests.quin.encountered && !root.pairScenes.circeQuin.cardsGranted) ids.push("circe-quin");
    return ids;
  }

  function chooseScene(ids, data){
    const focus=luvBirdieFocus(data);
    if(focus && ids.includes(focus.characterId)){
      const weighted=[];
      ids.forEach(id=>{const weight=id===focus.characterId?Math.max(1,Number(focus.weight)||3):1;for(let i=0;i<weight;i++)weighted.push(id);});
      return weighted[Math.floor(Math.random()*weighted.length)];
    }
    const pairScenes = ids.filter(id => id.includes("-"));
    if (pairScenes.length) return pairScenes[Math.floor(Math.random() * pairScenes.length)];
    return ids[Math.floor(Math.random() * ids.length)];
  }

  function maybeBeforeNextEncounter(continueFn){
    if (bypassNextRoll) { bypassNextRoll = false; return false; }
    if (open || !isMiko()) return false;

    const data=load();
    const ids = eligibleScenes();
    if (!ids.length) return false;
    if (Math.random() >= SHARED_CHANCE) return false;

    const chosen=chooseScene(ids,data);
    const focus=luvBirdieFocus(data);
    if(focus){
      focus.rollsRemaining=Math.max(0,Number(focus.rollsRemaining)-1);
      if(chosen===focus.characterId || focus.rollsRemaining<=0) delete data.luvBirdieFocusV262;
      save(data);
    }
    return showScene(chosen, continueFn);
  }
'''
    if old not in s: raise SystemExit('Could not patch Luv & Birdie love weighting block')
    p.write_text(s.replace(old,new,1),encoding='utf-8')

def patch_game_helpers():
    p=ROOT/'duck-quest/js/game-v96.js'; s=p.read_text(encoding='utf-8')
    if 'enemy.plushbunVariant' not in s:
        s=s.replace('enemy.cherubDuckVariant || "base"','enemy.cherubDuckVariant || enemy.plushbunVariant || "base"',1)
    # Once Plushbun is caught it should be discoverable under Meadow in the existing Buddy Book tabs.
    if '"plushbun","mushroom-cat"' not in s:
        s=s.replace('meadow:["cat-slime","bee","flower","acorn-mouse","catterpillar","mushroom-cat"',
                    'meadow:["cat-slime","bee","flower","acorn-mouse","catterpillar","plushbun","mushroom-cat"',1)
    p.write_text(s,encoding='utf-8')

def patch_version_and_sw():
    (ROOT/'version.json').write_text(json.dumps({'version':BUILD},indent=2)+'\n',encoding='utf-8')
    note='''Duckie Days v24.262\n\n- Adds Card Dust and the Card Workshop: duplicate conversion, rarity upgrades, normal color variant unlocks, and Holo finishes.\n- Adds 10 new Fabled cards to Card Packs.\n- Adds animated Luv & Birdie as a Miko special encounter with temporary 3x love-interest weighting.\n- Adds the card-focused Gift Box encounter and Gift Box Mimic.\n- Adds Plushbun as a universal wandering enemy with normal shiny odds and Stuffed Surprise rewards.\n'''
    (ROOT/'UPDATE-v24.262.txt').write_text(note,encoding='utf-8')
    old=ROOT/'sw-v24-261.js'
    if not old.exists(): raise SystemExit('Missing sw-v24-261.js')
    sw=old.read_text(encoding='utf-8').replace('v24-261','v24-262').replace('sw-v24-261.js','sw-v24-262.js')
    additions=[
      './trading-cards-v262.css?v=24-262','./trading-cards-v262.js?v=24-262','./trading-cards-ui-v262.js?v=24-262',
      './duck-quest/css/special-encounters-v262.css?v=24-262','./duck-quest/js/special-encounters-v262.js?v=24-262',
      './duck-quest/assets/events/luv-and-birdie/idle-1.png','./duck-quest/assets/events/luv-and-birdie/idle-2.png',
      './duck-quest/assets/events/gift-box/regular-closed.png','./duck-quest/assets/events/gift-box/regular-open.png','./duck-quest/assets/events/gift-box/lucky-closed.png','./duck-quest/assets/events/gift-box/lucky-idle-1.png','./duck-quest/assets/events/gift-box/lucky-idle-2.png','./duck-quest/assets/events/gift-box/lucky-open.png','./duck-quest/assets/events/gift-box/shiny-closed.png','./duck-quest/assets/events/gift-box/shiny-open.png','./duck-quest/assets/events/gift-box/mimic-idle-1.png','./duck-quest/assets/events/gift-box/mimic-idle-2.png','./duck-quest/assets/events/gift-box/mimic-shiny-idle-1.png','./duck-quest/assets/events/gift-box/mimic-shiny-idle-2.png'
    ]
    additions += [f'./duck-quest/assets/enemies/plushbun/base/{n}' for n in ['idle-1.png','idle-2.png','hurt.png','pink-idle-1.png','pink-idle-2.png','pink-hurt.png','mint-idle-1.png','mint-idle-2.png','mint-hurt.png','purple-idle-1.png','purple-idle-2.png','purple-hurt.png','red-idle-1.png','red-idle-2.png','red-hurt.png','shiny-idle-1.png','shiny-idle-2.png','shiny-hurt.png']]
    additions += [f'./duck-quest/assets/trading-cards/fabled/{n}' for n in ['F-hibiki-jackie.png','F-loofah.png','F-cool-seagull.png','F-seaunicorn-seaturtle.png','F-miko-espurr.png','F-frappe.png','F-gummy-shark.png','F-venni.png','F-catfish.png','F-silly.png']]
    marker='const APP_SHELL = ['
    idx=sw.find(marker); end=sw.find('];',idx)
    if idx<0 or end<0: raise SystemExit('Could not find APP_SHELL in service worker')
    existing=sw[idx:end]
    lines=[]
    for item in additions:
        if item not in existing: lines.append(f"  '{item}',")
    sw=sw[:end]+''.join('\n'+x for x in lines)+'\n'+sw[end:]
    (ROOT/'sw-v24-262.js').write_text(sw,encoding='utf-8')
    (ROOT/'sw.js').write_text("importScripts('./sw-v24-262.js?v=24-262');\n",encoding='utf-8')

def main():
    copy_payload(); patch_root_index(); patch_duck_quest_index(); patch_love_boost(); patch_game_helpers(); patch_version_and_sw()
    print('Installed Duckie Days v24.262 Card Dust + Special Encounters update.')

if __name__=='__main__': main()

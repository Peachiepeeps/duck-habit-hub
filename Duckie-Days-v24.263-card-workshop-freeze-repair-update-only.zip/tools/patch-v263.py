#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys, re

ROOT=Path.cwd()
SRC=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
PAYLOAD=SRC/'payload'
BUILD='24.263'
QV='24-263'


def copy_payload():
    if not PAYLOAD.is_dir():
        raise SystemExit(f'Missing payload: {PAYLOAD}')
    for src in PAYLOAD.rglob('*'):
        if src.is_file():
            rel=src.relative_to(PAYLOAD)
            dst=ROOT/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)


def patch_root_index():
    p=ROOT/'index.html'
    s=p.read_text(encoding='utf-8')
    s=re.sub(r'<meta name="duck-habit-build" content="[^"]+"\s*/>',f'<meta name="duck-habit-build" content="{BUILD}" />',s,1)
    s=re.sub(r'const DUCK_HUB_BUILD = "[^"]+";',f'const DUCK_HUB_BUILD = "{BUILD}";',s,1)
    s=re.sub(r'navigator\.serviceWorker\.register\("\./sw\.js\?v=[^"]+"',f'navigator.serviceWorker.register("./sw.js?v={QV}"',s,1)
    old='<script src="trading-cards-ui-v262.js?v=24-262"></script>'
    new='<script src="trading-cards-ui-v263.js?v=24-263"></script>'
    if new not in s:
        if old not in s:
            raise SystemExit('Could not find v24.262 Card Workshop UI script in index.html')
        s=s.replace(old,new,1)
    p.write_text(s,encoding='utf-8')


def patch_version_and_sw():
    (ROOT/'version.json').write_text(json.dumps({'version':BUILD},indent=2)+'\n',encoding='utf-8')
    note='''Duckie Days v24.263 — Card Workshop Startup Repair\n\n- Fixes the v24.262 Card Workshop MutationObserver loop that could freeze the hub during startup.\n- Card Dust count updates now avoid unnecessary DOM mutations.\n- Card detail updates now observe only the trading-card detail layer opening/closing instead of the entire document.\n- Keeps all v24.262 cards, Luv & Birdie, Gift Box Mimic, Plushbun, Card Dust, rarity upgrades, variants, and Holo features.\n'''
    (ROOT/'UPDATE-v24.263.txt').write_text(note,encoding='utf-8')

    old=ROOT/'sw-v24-262.js'
    if not old.exists():
        raise SystemExit('Missing sw-v24-262.js; v24.262 must be installed first.')
    sw=old.read_text(encoding='utf-8')
    sw=sw.replace("duck-habit-hub-app-v24-262","duck-habit-hub-app-v24-263")
    sw=sw.replace("duck-habit-hub-runtime-v24-262","duck-habit-hub-runtime-v24-263")
    sw=sw.replace("'./sw-v24-262.js'","'./sw-v24-263.js'")
    sw=sw.replace("'./trading-cards-ui-v262.js?v=24-262'","'./trading-cards-ui-v263.js?v=24-263'")
    (ROOT/'sw-v24-263.js').write_text(sw,encoding='utf-8')
    (ROOT/'sw.js').write_text("importScripts('./sw-v24-263.js?v=24-263');\n",encoding='utf-8')


def main():
    copy_payload()
    patch_root_index()
    patch_version_and_sw()
    print('Installed Duckie Days v24.263 Card Workshop startup repair.')

if __name__=='__main__':
    main()

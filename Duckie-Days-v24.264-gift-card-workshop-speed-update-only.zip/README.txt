Duckie Days v24.264 update-only bundle
Upload this ZIP unchanged to the repository root beside index.html, then upload the matching workflow YAML to .github/workflows/.

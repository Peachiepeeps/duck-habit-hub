#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

bundle = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path('.').resolve()
repo = Path.cwd().resolve()
payload = bundle / 'payload'

if not payload.is_dir():
    raise SystemExit(f'ERROR: payload folder missing: {payload}')

# Require the expected base so an old installer cannot silently overwrite a different build.
version_path = repo / 'version.json'
if not version_path.exists() or '24.264' not in version_path.read_text(encoding='utf-8'):
    raise SystemExit('ERROR: v24.265 expects Duckie Days v24.264 as the installed base.')

def copy_payload_tree():
    for src in payload.rglob('*'):
        if not src.is_file():
            continue
        rel = src.relative_to(payload)
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def replace_exact(path, old, new, expected=1):
    p = repo / path
    text = p.read_text(encoding='utf-8')
    count = text.count(old)
    if count != expected:
        raise SystemExit(f'ERROR: {path}: expected {expected} occurrence(s) of {old!r}, found {count}.')
    p.write_text(text.replace(old, new), encoding='utf-8')

# Existing source fixes that should live in the base files rather than depend only on overlays.
replace_exact('script-v24-201.js',
              'unlocked.forEach(([id, duck]) => {',
              'unlocked.forEach(([id, duck], index) => {')
replace_exact('duck-quest/js/game-v96.js',
              'await hit(1.6,.12,1.6);',
              'await hit(skill.multiplier||1.6,skill.critChance||.12,skill.critMultiplier||1.6);')
replace_exact('duck-quest/js/game-v96.js',
              'const healed=healHero(.25);',
              'const healed=healHero(skill.healPercent||.25);')

# Hub wiring.
replace_exact('index.html', '<meta name="duck-habit-build" content="24.264" />', '<meta name="duck-habit-build" content="24.265" />')
replace_exact('index.html', '<link rel="stylesheet" href="task-progression-v261.css?v=24-261" />', '<link rel="stylesheet" href="task-progression-v261.css?v=24-261" />\n  <link rel="stylesheet" href="hub-v265.css?v=24-265" />')
replace_exact('index.html', '<script src="trading-cards-v262.js?v=24-262"></script>', '<script src="trading-cards-v262.js?v=24-262"></script>\n  <script src="trading-cards-v265.js?v=24-265"></script>')
replace_exact('index.html', '<script src="trading-cards-ui-v264.js?v=24-264"></script>', '<script src="trading-cards-ui-v265.js?v=24-265"></script>')
replace_exact('index.html', '<script src="task-progression-v261.js?v=24-261"></script>', '<script src="task-progression-v261.js?v=24-261"></script>\n  <script src="hub-v265.js?v=24-265"></script>')
replace_exact('index.html', 'const DUCK_HUB_BUILD = "24.264";', 'const DUCK_HUB_BUILD = "24.265";')
replace_exact('index.html', 'navigator.serviceWorker.register("./sw.js?v=24-264"', 'navigator.serviceWorker.register("./sw.js?v=24-265"')
# Cache-bust the two directly modified base JS files.
replace_exact('index.html', '<script src="script-v24-201.js?v=24-264"></script>', '<script src="script-v24-201.js?v=24-265"></script>')
replace_exact('index.html', '<script src="trading-cards-ui-v250.js?v=24-264"></script>', '<script src="trading-cards-ui-v250.js?v=24-265"></script>')

# Duck Quest wiring.
replace_exact('duck-quest/index.html', '<link rel="stylesheet" href="css/special-encounters-v264.css?v=24-264">', '<link rel="stylesheet" href="css/special-encounters-v264.css?v=24-264">\n  <link rel="stylesheet" href="css/quest-v265.css?v=24-265">')
replace_exact('duck-quest/index.html', '<script src="../trading-cards-v262.js?v=24-262"></script>', '<script src="../trading-cards-v262.js?v=24-262"></script>\n  <script src="../trading-cards-v265.js?v=24-265"></script>')
replace_exact('duck-quest/index.html', '<script src="js/special-encounters-v264.js?v=24-264"></script>', '<script src="js/special-encounters-v265.js?v=24-265"></script>\n  <script src="js/quest-v265.js?v=24-265"></script>')
# game-v96 was patched above, so force browsers/PWA to request the new bytes.
replace_exact('duck-quest/index.html', '<script src="js/game-v96.js?v=24-255"></script>', '<script src="js/game-v96.js?v=24-265"></script>')

copy_payload_tree()
print('Installed Duckie Days v24.265 payload and source patches.')

#!/usr/bin/env python3
from pathlib import Path
import re, subprocess, sys

repo = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()

def read(path):
    p=repo/path
    if not p.exists(): raise SystemExit(f'ERROR: missing {path}')
    return p.read_text(encoding='utf-8')

def require(path, needle):
    text=read(path)
    if needle not in text: raise SystemExit(f'ERROR: {path} missing marker: {needle}')

def forbid(path, needle):
    text=read(path)
    if needle in text: raise SystemExit(f'ERROR: {path} still contains forbidden marker: {needle}')

require(Path('version.json'), '"version": "24.265"')
require(Path('index.html'), '<meta name="duck-habit-build" content="24.265" />')
require(Path('index.html'), 'trading-cards-v265.js?v=24-265')
require(Path('index.html'), 'trading-cards-ui-v265.js?v=24-265')
require(Path('index.html'), 'hub-v265.css?v=24-265')
require(Path('index.html'), 'hub-v265.js?v=24-265')
require(Path('index.html'), 'const DUCK_HUB_BUILD = "24.265";')
require(Path('index.html'), 'navigator.serviceWorker.register("./sw.js?v=24-265"')
require(Path('script-v24-201.js'), 'unlocked.forEach(([id, duck], index) => {')
require(Path('duck-quest/index.html'), '../trading-cards-v265.js?v=24-265')
require(Path('duck-quest/index.html'), 'js/game-v96.js?v=24-265')
require(Path('duck-quest/index.html'), 'css/quest-v265.css?v=24-265')
require(Path('duck-quest/index.html'), 'js/special-encounters-v265.js?v=24-265')
require(Path('duck-quest/index.html'), 'js/quest-v265.js?v=24-265')
require(Path('duck-quest/js/game-v96.js'), 'await hit(skill.multiplier||1.6,skill.critChance||.12,skill.critMultiplier||1.6);')
require(Path('duck-quest/js/game-v96.js'), 'const healed=healHero(skill.healPercent||.25);')

# Power Up Dust + Card Workshop.
require(Path('trading-cards-v265.js'), 'powerUpDust')
require(Path('trading-cards-v265.js'), "window.DUCKIE_POWER_UP_DUST_CORE='24.265';")
require(Path('trading-cards-ui-v265.js'), 'Power Up Dust')
forbid(Path('trading-cards-ui-v265.js'), 'Card Dust')
require(Path('trading-cards-ui-v265.js'), 'DuckieCardWorkshopV265')

# Hub requested changes.
require(Path('hub-v265.js'), 'openTaskEditor')
require(Path('hub-v265.js'), 'organizeBattleInventory')
require(Path('hub-v265.js'), "listing?.wallpaperId")
require(Path('hub-v265.css'), '.tc-detail-actions-v264{grid-template-columns:repeat(2')
require(Path('hub-v265.css'), '.tc-shop-grid{grid-template-columns:repeat(3')
require(Path('hub-v265.css'), '#roomBookImage.duckipedia-room-book-v232.on-dresser')

# Buddy Box / leveling + Dash cleanup.
require(Path('duck-quest/js/quest-v265.js'), 'buddyBoxV265')
require(Path('duck-quest/js/quest-v265.js'), 'level:1')
require(Path('duck-quest/js/quest-v265.js'), 'Max Affordable')
require(Path('duck-quest/js/quest-v265.js'), 'Release +')
require(Path('duck-quest/js/quest-v265.js'), 'Pink Coins')
require(Path('duck-quest/js/quest-v265.js'), 'Jump Tokens')
require(Path('duck-quest/css/quest-v265.css'), '.buddy-box-grid-v265')
require(Path('duck-quest/css/quest-v265.css'), '.dash-config-v265')
require(Path('duck-quest/js/special-encounters-v265.js'), 'powerUpDust')
forbid(Path('duck-quest/js/special-encounters-v265.js'), 'Card Dust')

# Cache wiring.
require(Path('sw.js'), "importScripts('./sw-v24-265.js?v=24-265');")
require(Path('sw-v24-265.js'), "duck-habit-hub-app-v24-265")
require(Path('sw-v24-265.js'), "./trading-cards-v265.js?v=24-265")
require(Path('sw-v24-265.js'), "./hub-v265.js?v=24-265")
require(Path('sw-v24-265.js'), "./duck-quest/js/quest-v265.js?v=24-265")

# Every local file pre-cached by the service worker must actually exist.
sw=read(Path('sw-v24-265.js'))
m=re.search(r'const APP_SHELL = \[(.*?)\];', sw, re.S)
if not m: raise SystemExit('ERROR: could not parse APP_SHELL')
refs=re.findall(r"['\"](\./[^'\"]+)['\"]",m.group(1))
missing=[]
for ref in refs:
    path=ref.split('?',1)[0]
    if path in ('./','./index.html'): continue
    if not (repo/path[2:]).exists(): missing.append(ref)
if missing: raise SystemExit('ERROR: service worker references missing files: '+', '.join(missing[:12]))

# Syntax checks for changed/new JS.
for rel in [
    'script-v24-201.js','trading-cards-v265.js','trading-cards-ui-v265.js','hub-v265.js',
    'duck-quest/js/game-v96.js','duck-quest/js/special-encounters-v265.js','duck-quest/js/quest-v265.js','sw-v24-265.js'
]:
    subprocess.run(['node','--check',str(repo/rel)],check=True)

print('VERIFIED: Duckie Days v24.265 update is structurally valid.')

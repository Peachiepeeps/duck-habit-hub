#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

bundle = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path('.').resolve()
repo = Path.cwd().resolve()
payload = bundle / 'payload'
if not payload.is_dir():
    raise SystemExit(f'ERROR: payload folder missing: {payload}')

version_path = repo / 'version.json'
if not version_path.exists() or '24.265' not in version_path.read_text(encoding='utf-8'):
    raise SystemExit('ERROR: v24.266 expects Duckie Days v24.265 as the installed base.')

def copy_payload_tree():
    for src in payload.rglob('*'):
        if not src.is_file():
            continue
        rel = src.relative_to(payload)
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def replace_exact(path, old, new, expected=1):
    p = repo / path
    text = p.read_text(encoding='utf-8')
    count = text.count(old)
    if count != expected:
        raise SystemExit(f'ERROR: {path}: expected {expected} occurrence(s) of {old!r}, found {count}.')
    p.write_text(text.replace(old, new), encoding='utf-8')

replace_exact('index.html', '<meta name="duck-habit-build" content="24.265" />', '<meta name="duck-habit-build" content="24.266" />')
replace_exact('index.html', '<link rel="stylesheet" href="hub-v265.css?v=24-265" />', '<link rel="stylesheet" href="hub-v266.css?v=24-266" />')
replace_exact('index.html', '<script src="trading-cards-ui-v265.js?v=24-265"></script>', '<script src="trading-cards-ui-v266.js?v=24-266"></script>')
replace_exact('index.html', '<script src="hub-v265.js?v=24-265"></script>', '<script src="hub-v266.js?v=24-266"></script>')
replace_exact('index.html', 'const DUCK_HUB_BUILD = "24.265";', 'const DUCK_HUB_BUILD = "24.266";')
replace_exact('index.html', 'navigator.serviceWorker.register("./sw.js?v=24-265"', 'navigator.serviceWorker.register("./sw.js?v=24-266"')

replace_exact('duck-quest/index.html', '<link rel="stylesheet" href="css/quest-v265.css?v=24-265">', '<link rel="stylesheet" href="css/quest-v266.css?v=24-266">')
replace_exact('duck-quest/index.html', '<script src="js/quest-v265.js?v=24-265"></script>', '<script src="js/quest-v266.js?v=24-266"></script>')

copy_payload_tree()
print('Installed Duckie Days v24.266 payload and source patches.')

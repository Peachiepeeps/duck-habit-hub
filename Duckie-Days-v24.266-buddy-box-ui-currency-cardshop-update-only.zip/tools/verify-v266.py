#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
repo = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()

def read(path):
    p = repo / path
    if not p.exists():
        raise SystemExit(f'ERROR: missing {path}')
    return p.read_text(encoding='utf-8')

def require(path, needle):
    text = read(path)
    if needle not in text:
        raise SystemExit(f'ERROR: {path} missing marker: {needle}')

require(Path('version.json'), '24.266')
require(Path('index.html'), 'duck-habit-build" content="24.266')
require(Path('index.html'), 'hub-v266.css?v=24-266')
require(Path('index.html'), 'trading-cards-ui-v266.js?v=24-266')
require(Path('index.html'), 'hub-v266.js?v=24-266')
require(Path('index.html'), 'navigator.serviceWorker.register("./sw.js?v=24-266"')
require(Path('duck-quest/index.html'), 'css/quest-v266.css?v=24-266')
require(Path('duck-quest/index.html'), 'js/quest-v266.js?v=24-266')
require(Path('hub-v266.js'), 'Power Up Dust')
require(Path('hub-v266.js'), 'removeDustInventoryCard')
require(Path('hub-v266.js'), 'moveOcSkillsToStatusPageV266')
require(Path('hub-v266.css'), '.tc-shop-grid-v266')
require(Path('hub-v266.css'), '.power-up-dust-currency-v266')
require(Path('trading-cards-ui-v266.js'), 'Power Up Dust')
require(Path('quest-v266.py') if False else Path('duck-quest/js/quest-v266.js'), 'strawberry slime cat')
require(Path('duck-quest/js/quest-v266.js'), 'Buddy Box')
require(Path('duck-quest/js/quest-v266.js'), 'Equip Charm')
require(Path('duck-quest/js/quest-v266.js'), 'OC Skills')
require(Path('sw.js'), 'sw-v24-266.js?v=24-266')
require(Path('sw-v24-266.js'), 'duck-habit-hub-app-v24-266')

for rel in ['hub-v266.js','trading-cards-ui-v266.js','duck-quest/js/quest-v266.js','sw-v24-266.js']:
    subprocess.run(['node','--check',str(repo/rel)], check=True)
print('VERIFIED: Duckie Days v24.266 update is structurally valid.')

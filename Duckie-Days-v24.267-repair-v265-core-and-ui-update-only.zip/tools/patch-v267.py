#!/usr/bin/env python3
from pathlib import Path
import shutil, sys
bundle = Path(sys.argv[1]).resolve()
repo = Path.cwd().resolve()
payload = bundle / 'payload'
if '24.266' not in (repo / 'version.json').read_text(encoding='utf-8'):
    raise SystemExit('ERROR: v24.267 expects v24.266 base.')

def repl(path, old, new):
    p = repo / path
    t = p.read_text(encoding='utf-8')
    n = t.count(old)
    if n != 1:
        raise SystemExit(f'ERROR: {path}: expected one {old!r}, found {n}')
    p.write_text(t.replace(old, new), encoding='utf-8')

repl('index.html', '<meta name="duck-habit-build" content="24.266" />', '<meta name="duck-habit-build" content="24.267" />')
repl('index.html', '<link rel="stylesheet" href="hub-v266.css?v=24-266" />', '<link rel="stylesheet" href="hub-v265.css?v=24-265" />\n  <link rel="stylesheet" href="hub-v267.css?v=24-267" />')
repl('index.html', '<script src="trading-cards-ui-v266.js?v=24-266"></script>', '<script src="trading-cards-ui-v265.js?v=24-265"></script>\n  <script src="trading-cards-ui-v267.js?v=24-267"></script>')
repl('index.html', '<script src="hub-v266.js?v=24-266"></script>', '<script src="hub-v265.js?v=24-265"></script>\n  <script src="hub-v267.js?v=24-267"></script>')
repl('index.html', 'const DUCK_HUB_BUILD = "24.266";', 'const DUCK_HUB_BUILD = "24.267";')
repl('index.html', 'navigator.serviceWorker.register("./sw.js?v=24-266"', 'navigator.serviceWorker.register("./sw.js?v=24-267"')
repl('duck-quest/index.html', '<link rel="stylesheet" href="css/quest-v266.css?v=24-266">', '<link rel="stylesheet" href="css/quest-v265.css?v=24-265">\n  <link rel="stylesheet" href="css/quest-v267.css?v=24-267">')
repl('duck-quest/index.html', '<script src="js/quest-v266.js?v=24-266"></script>', '<script src="js/quest-v265.js?v=24-265"></script>\n  <script src="js/quest-v267.js?v=24-267"></script>')

for src in payload.rglob('*'):
    if src.is_file():
        dst = repo / src.relative_to(payload)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
print('Installed v24.267 repair.')

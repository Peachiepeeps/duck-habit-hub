#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
repo=Path(sys.argv[1]).resolve()
def req(p,s):
 t=(repo/p).read_text(encoding='utf-8')
 if s not in t: raise SystemExit(f'ERROR: {p} missing {s}')
req(Path('version.json'),'24.267')
req(Path('index.html'),'hub-v265.js?v=24-265')
req(Path('index.html'),'hub-v267.js?v=24-267')
req(Path('index.html'),'trading-cards-ui-v265.js?v=24-265')
req(Path('index.html'),'trading-cards-ui-v267.js?v=24-267')
req(Path('duck-quest/index.html'),'js/quest-v265.js?v=24-265')
req(Path('duck-quest/index.html'),'js/quest-v267.js?v=24-267')
req(Path('hub-v267.js'),'assets/ingredients/Sparkle.webp')
req(Path('hub-v267.js'),'statusOcSkillsV267')
req(Path('hub-v267.css'),'.shop-grid > .tc-shop-grid')
req(Path('duck-quest/js/quest-v267.js'),'#questHomeTools')
req(Path('duck-quest/js/quest-v267.js'),'Strawberry-idle-1-neutral.webp')
req(Path('duck-quest/js/quest-v267.js'),'DUCKIE_BUDDY_BOX_V265')
req(Path('sw.js'),'sw-v24-267.js?v=24-267')
for rel in ['hub-v267.js','trading-cards-ui-v267.js','duck-quest/js/quest-v267.js','sw-v24-267.js']:
 subprocess.run(['node','--check',str(repo/rel)],check=True)
print('VERIFIED: v24.267 repair valid.')

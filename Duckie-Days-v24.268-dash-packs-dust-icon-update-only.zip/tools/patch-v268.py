#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

bundle=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('.').resolve()
repo=Path.cwd().resolve()
payload=bundle/'payload'
if not payload.is_dir():
    raise SystemExit(f'ERROR: payload missing: {payload}')

version=repo/'version.json'
if not version.exists() or '24.267' not in version.read_text(encoding='utf-8'):
    raise SystemExit('ERROR: v24.268 expects Duckie Days v24.267 as the installed base.')

def replace_once(path,old,new):
    p=repo/path
    text=p.read_text(encoding='utf-8')
    count=text.count(old)
    if count!=1:
        raise SystemExit(f'ERROR: {path}: expected 1 occurrence of {old!r}; found {count}.')
    p.write_text(text.replace(old,new),encoding='utf-8')

# Main hub version and overlays.
replace_once(Path('index.html'),
             '<meta name="duck-habit-build" content="24.267" />',
             '<meta name="duck-habit-build" content="24.268" />')
replace_once(Path('index.html'),
             '<link rel="stylesheet" href="hub-v267.css?v=24-267" />',
             '<link rel="stylesheet" href="hub-v267.css?v=24-267" />\n  <link rel="stylesheet" href="hub-v268.css?v=24-268" />')
replace_once(Path('index.html'),
             '<script src="trading-cards-ui-v267.js?v=24-267"></script>',
             '<script src="trading-cards-ui-v267.js?v=24-267"></script>\n  <script src="trading-cards-ui-v268.js?v=24-268"></script>')
replace_once(Path('index.html'),
             'const DUCK_HUB_BUILD = "24.267";',
             'const DUCK_HUB_BUILD = "24.268";')
replace_once(Path('index.html'),
             'navigator.serviceWorker.register("./sw.js?v=24-267"',
             'navigator.serviceWorker.register("./sw.js?v=24-268"')

# Duck Quest overlay. Keep v24.265 + v24.267 intact.
replace_once(Path('duck-quest/index.html'),
             '<link rel="stylesheet" href="css/quest-v267.css?v=24-267">',
             '<link rel="stylesheet" href="css/quest-v267.css?v=24-267">\n  <link rel="stylesheet" href="css/quest-v268.css?v=24-268">')
replace_once(Path('duck-quest/index.html'),
             '<script src="js/quest-v267.js?v=24-267"></script>',
             '<script src="js/quest-v267.js?v=24-267"></script>\n  <script src="js/quest-v268.js?v=24-268"></script>')

for src in payload.rglob('*'):
    if not src.is_file():
        continue
    rel=src.relative_to(payload)
    dst=repo/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)

print('Installed Duckie Days v24.268.')

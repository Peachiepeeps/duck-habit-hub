#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys

repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()

def read(path):
    p=repo/path
    if not p.exists(): raise SystemExit(f'ERROR: missing {path}')
    return p.read_text(encoding='utf-8')

def require(path,needle):
    if needle not in read(path):
        raise SystemExit(f'ERROR: {path} missing marker {needle!r}')

require(Path('version.json'),'24.268')
require(Path('index.html'),'duck-habit-build" content="24.268')
require(Path('index.html'),'hub-v268.css?v=24-268')
require(Path('index.html'),'trading-cards-ui-v268.js?v=24-268')
require(Path('index.html'),'const DUCK_HUB_BUILD = "24.268";')
require(Path('index.html'),'./sw.js?v=24-268')
require(Path('index.html'),'trading-cards-ui-v265.js?v=24-265')
require(Path('index.html'),'trading-cards-ui-v267.js?v=24-267')

require(Path('hub-v268.css'),'width:7px!important')
require(Path('trading-cards-ui-v268.js'),'const PACK_PRICE=150')
require(Path('trading-cards-ui-v268.js'),'const DAILY_LIMIT=3')
require(Path('trading-cards-ui-v268.js'),'dailyPackShopV268')
require(Path('trading-cards-ui-v268.js'),'card-pack-unopened.png')

require(Path('duck-quest/index.html'),'css/quest-v265.css?v=24-265')
require(Path('duck-quest/index.html'),'css/quest-v267.css?v=24-267')
require(Path('duck-quest/index.html'),'css/quest-v268.css?v=24-268')
require(Path('duck-quest/index.html'),'js/quest-v265.js?v=24-265')
require(Path('duck-quest/index.html'),'js/quest-v267.js?v=24-267')
require(Path('duck-quest/index.html'),'js/quest-v268.js?v=24-268')
require(Path('duck-quest/css/quest-v268.css'),'#dashScreen:not(.dash-run-stage-v193) .dash-playbox')
require(Path('duck-quest/js/quest-v268.js'),'dashStartMenuV268')
require(Path('duck-quest/js/quest-v268.js'),"typeof startDash==='function'")
require(Path('duck-quest/js/quest-v268.js'),'renderDashReadyOverlay')

require(Path('sw.js'),"sw-v24-268.js?v=24-268")
require(Path('sw-v24-268.js'),"duck-habit-hub-app-v24-268")
require(Path('sw-v24-268.js'),'quest-v265.js?v=24-265')
require(Path('sw-v24-268.js'),'quest-v267.js?v=24-267')
require(Path('sw-v24-268.js'),'quest-v268.js?v=24-268')

for rel in ['trading-cards-ui-v268.js','duck-quest/js/quest-v268.js','sw-v24-268.js']:
    subprocess.run(['node','--check',str(repo/rel)],check=True)

print('VERIFIED: Duckie Days v24.268 structure and JavaScript are valid.')

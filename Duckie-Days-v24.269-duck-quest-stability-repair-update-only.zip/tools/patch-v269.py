#!/usr/bin/env python3
from pathlib import Path
import re, shutil, sys

bundle=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('.').resolve()
repo=Path.cwd().resolve()
payload=bundle/'payload'
if not payload.is_dir():
    raise SystemExit(f'ERROR: payload missing: {payload}')

version=repo/'version.json'
if not version.exists() or '24.268' not in version.read_text(encoding='utf-8'):
    raise SystemExit('ERROR: v24.269 expects Duckie Days v24.268 as the installed base.')

def read(path):
    p=repo/path
    if not p.exists(): raise SystemExit(f'ERROR: missing {path}')
    return p.read_text(encoding='utf-8')

def write(path,text):
    (repo/path).write_text(text,encoding='utf-8')

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f'ERROR: {path}: expected one occurrence of {old!r}; found {count}.')
    write(path,text.replace(old,new))

replace_once(Path('index.html'),'<meta name="duck-habit-build" content="24.268" />','<meta name="duck-habit-build" content="24.269" />')
replace_once(Path('index.html'),'const DUCK_HUB_BUILD = "24.268";','const DUCK_HUB_BUILD = "24.269";')
replace_once(Path('index.html'),'navigator.serviceWorker.register("./sw.js?v=24-268"','navigator.serviceWorker.register("./sw.js?v=24-269"')

qpath=Path('duck-quest/index.html')
html=read(qpath)

quick_pat=re.compile(r'          <div class="hero-quick-actions" aria-label="Hero information">.*?          </div>',re.S)
quick_new='''          <div class="hero-quick-actions" aria-label="Hero information">
            <button id="openCharmScreen" class="pixel-button hero-info-button" type="button">Equip Charm</button>
            <button id="openBuddyCollection" class="pixel-button hero-info-button" type="button">Buddy Book</button>
            <button id="openUiThemes" class="pixel-button hero-info-button hero-theme-button" type="button">UI Themes</button>
          </div>
          <button id="openSkillBook" class="pixel-button hero-info-button home-skills-hidden-v269" type="button" tabindex="-1" aria-hidden="true">OC Skills</button>'''
html,n=quick_pat.subn(quick_new,html,count=1)
if n!=1: raise SystemExit('ERROR: Could not replace hero quick actions.')

tools_pat=re.compile(r'          <div id="questHomeTools" class="quest-home-tools" aria-label="Duck Quest tools">.*?          </div>',re.S)
tools_new='''          <div id="questHomeTools" class="quest-home-tools" aria-label="Duck Quest tools">
            <button id="openBuddyBoxHomeV269" class="pixel-button quest-home-tool-button" type="button">
              <img src="assets/enemies/cat-slime/base/Strawberry-idle-1-neutral.webp" alt="">
              <span>Buddy Box</span>
            </button>
            <button id="openHatchery" class="pixel-button quest-home-tool-button" type="button">
              <img class="home-hatch-icon" src="assets/eggs/Common-egg.png" alt="">
              <span class="home-hatch-label">Hatching Area</span>
              <span id="hatchReadyBadge"></span>
            </button>
          </div>'''
html,n=tools_pat.subn(tools_new,html,count=1)
if n!=1: raise SystemExit('ERROR: Could not replace Duck Quest tools.')

for old in [
    '  <link rel="stylesheet" href="css/quest-v267.css?v=24-267">\n',
    '  <link rel="stylesheet" href="css/quest-v268.css?v=24-268">\n'
]:
    if html.count(old)!=1: raise SystemExit(f'ERROR: missing stylesheet line {old.strip()}')
    html=html.replace(old,'')
base_style='  <link rel="stylesheet" href="css/quest-v265.css?v=24-265">\n'
if html.count(base_style)!=1: raise SystemExit('ERROR: quest-v265 stylesheet tag missing.')
html=html.replace(base_style,base_style+'  <link rel="stylesheet" href="css/quest-v269.css?v=24-269">\n',1)

old_game='<script src="js/game-v96.js?v=24-265"></script>'
if html.count(old_game)!=1: raise SystemExit('ERROR: game-v96 tag missing.')
html=html.replace(old_game,'<script src="js/game-v96.js?v=24-269"></script>',1)

for old in [
    '  <script src="js/quest-v267.js?v=24-267"></script>\n',
    '  <script src="js/quest-v268.js?v=24-268"></script>\n'
]:
    if html.count(old)!=1: raise SystemExit(f'ERROR: missing script line {old.strip()}')
    html=html.replace(old,'')
base_script='  <script src="js/quest-v265.js?v=24-265"></script>\n'
if html.count(base_script)!=1: raise SystemExit('ERROR: quest-v265 tag missing.')
html=html.replace(base_script,'  <script src="js/quest-v265.js?v=24-269-core"></script>\n  <script src="js/quest-v269.js?v=24-269"></script>\n',1)
write(qpath,html)

# Remove v24.265 Dash DOM polling/re-parenting while preserving Buddy Box.
p265=Path('duck-quest/js/quest-v265.js')
text=read(p265)
start=text.find('  // ---- Duckie Dash setup cleanup -----------------------------------------')
end=text.find('\n  ensureBox();dustState();installBuddyBoxButton();',start)
if start<0 or end<0: raise SystemExit('ERROR: Could not locate v24.265 Dash patch block.')
text=text[:start] + '  // v24.269: Dash UI patch removed; game-v96 + quest-v269 own Dash navigation.\n' + text[end:]
tail_pat=re.compile(r"  ensureBox\(\);dustState\(\);installBuddyBoxButton\(\);\n  requestAnimationFrame\(\(\)=>\{installBuddyBoxButton\(\);applyDashSetupV265\(\);\}\);\n  setInterval\(\(\)=>\{const dashScreen=document\.querySelector\('#dashScreen'\);if\(dashScreen&&!dashScreen\.classList\.contains\('hidden'\)\)\{applyDashSetupV265\(\);updateDashBalances\(\);\}\},700\);")
text,n=tail_pat.subn('  ensureBox();dustState();',text,count=1)
if n!=1: raise SystemExit('ERROR: Could not remove v24.265 Dash timer tail.')
write(p265,text)

# Export the real startDash from inside game-v96's Dash IIFE.
gpath=Path('duck-quest/js/game-v96.js')
game=read(gpath)
marker='  window.DuckieHatchApiV178={'
if 'window.DUCKIE_DASH_API_V269=' not in game:
    if game.count(marker)!=1: raise SystemExit('ERROR: Dash API insertion marker not unique.')
    bridge="""  window.DUCKIE_DASH_API_V269={
    start:startDash,
    getStatus:()=>( {
      tokens:specialQty('jump-token'),
      freeRuns:Math.max(0,Math.floor(Number(questSave.dash.freeRuns)||0)),
      duration:Number(questSave.dash.runDuration)===60?60:30,
      coins:Math.max(0,Number(hubSave.coins)||0)
    }),
    setDuration:(value)=>{
      questSave.dash.runDuration=Number(value)===60?60:30;
      persistAll();
    },
    refresh:refreshFeatureBadges
  };

"""
    game=game.replace(marker,bridge+marker,1)
write(gpath,game)

for src in payload.rglob('*'):
    if src.is_file():
        rel=src.relative_to(payload)
        dst=repo/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst)

print('Installed Duckie Days v24.269 stability repair.')

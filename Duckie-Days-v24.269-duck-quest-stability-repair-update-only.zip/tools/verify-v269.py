#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()
def read(path):
    p=repo/path
    if not p.exists(): raise SystemExit(f'ERROR: missing {path}')
    return p.read_text(encoding='utf-8')
def require(path,needle):
    if needle not in read(path): raise SystemExit(f'ERROR: {path} missing {needle!r}')
def forbid(path,needle):
    if needle in read(path): raise SystemExit(f'ERROR: {path} still contains {needle!r}')
require(Path('version.json'),'24.269')
require(Path('index.html'),'duck-habit-build" content="24.269')
require(Path('index.html'),'const DUCK_HUB_BUILD = "24.269";')
require(Path('index.html'),'./sw.js?v=24-269')
q=Path('duck-quest/index.html')
require(q,'id="openCharmScreen" class="pixel-button hero-info-button"')
require(q,'id="openBuddyBoxHomeV269"')
require(q,'home-skills-hidden-v269')
require(q,'css/quest-v269.css?v=24-269')
require(q,'js/game-v96.js?v=24-269')
require(q,'js/quest-v265.js?v=24-269-core')
require(q,'js/quest-v269.js?v=24-269')
forbid(q,'quest-v267.js?v=24-267')
forbid(q,'quest-v268.js?v=24-268')
q265=Path('duck-quest/js/quest-v265.js')
forbid(q265,'applyDashSetupV265();')
forbid(q265,'setInterval(()=>{const dashScreen=')
require(q265,'window.DUCKIE_BUDDY_BOX_V265=')
game=Path('duck-quest/js/game-v96.js')
require(game,'window.DUCKIE_DASH_API_V269=')
require(game,'start:startDash')
require(game,"tokens:specialQty('jump-token')")
q269=Path('duck-quest/js/quest-v269.js')
require(q269,'dashStartMenuV269')
require(q269,'DUCKIE_DASH_API_V269')
forbid(q269,'setInterval(')
forbid(q269,'MutationObserver')
require(Path('sw.js'),"sw-v24-269.js?v=24-269")
require(Path('sw-v24-269.js'),"duck-habit-hub-app-v24-269")
for rel in ['duck-quest/js/quest-v265.js','duck-quest/js/game-v96.js','duck-quest/js/quest-v269.js','sw-v24-269.js']:
    subprocess.run(['node','--check',str(repo/rel)],check=True)
print('VERIFIED: Duck Quest v24.269 is structurally stable and Dash uses the real game start function.')

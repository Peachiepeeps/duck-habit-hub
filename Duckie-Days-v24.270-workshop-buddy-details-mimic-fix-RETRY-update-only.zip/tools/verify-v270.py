#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys

repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()

def read(path):
    p=repo/path
    if not p.exists(): raise SystemExit(f'ERROR: missing {path}')
    return p.read_text(encoding='utf-8')

def require(path,needle):
    if needle not in read(path): raise SystemExit(f'ERROR: {path} missing marker {needle!r}')

require(Path('version.json'),'24.270')
require(Path('index.html'),'duck-habit-build" content="24.270')
require(Path('index.html'),'hub-v270.css?v=24-270')
require(Path('index.html'),'trading-cards-ui-v270.js?v=24-270')
require(Path('index.html'),'const DUCK_HUB_BUILD = "24.270";')
require(Path('index.html'),'./sw.js?v=24-270')

require(Path('hub-v270.css'),'.tc-variant-preview-layer-v270')
require(Path('hub-v270.css'),'bottom:3.8%!important')
require(Path('trading-cards-ui-v270.js'),'stopImmediatePropagation')
require(Path('trading-cards-ui-v270.js'),"action.textContent='Upgrade'")
require(Path('trading-cards-ui-v270.js'),'Preview only — no Power Up Dust has been spent yet.')
require(Path('trading-cards-ui-v270.js'),'rerenderWorkshopKeepingScroll')

require(Path('duck-quest/index.html'),'css/quest-v269.css?v=24-269')
require(Path('duck-quest/index.html'),'css/quest-v270.css?v=24-270')
require(Path('duck-quest/index.html'),'js/quest-v269.js?v=24-269')
require(Path('duck-quest/index.html'),'js/quest-v270.js?v=24-270')
require(Path('duck-quest/js/quest-v270.js'),'lucky mimic')
require(Path('duck-quest/js/quest-v270.js'),'mimic/lucky/idle-1.webp')
require(Path('duck-quest/js/quest-v270.js'),'Buddy Boost')
require(Path('duck-quest/js/quest-v270.js'),'Not Assigned')
require(Path('duck-quest/js/quest-v270.js'),'Power Up Dust is only spent')
require(Path('duck-quest/css/quest-v270.css'),'.buddy-detail-status-v270')

# Preserve stability fixes: v24.269 remains loaded and no new polling observers are introduced.
require(Path('duck-quest/index.html'),'js/quest-v269.js?v=24-269')
forbid_text=read(Path('duck-quest/js/quest-v270.js'))
if 'setInterval(' in forbid_text or 'MutationObserver' in forbid_text:
    raise SystemExit('ERROR: v24.270 Buddy enhancement must not add polling/MutationObserver.')

require(Path('sw.js'),"sw-v24-270.js?v=24-270")
require(Path('sw-v24-270.js'),"duck-habit-hub-app-v24-270")

for rel in ['trading-cards-ui-v270.js','duck-quest/js/quest-v270.js','sw-v24-270.js']:
    subprocess.run(['node','--check',str(repo/rel)],check=True)

print('VERIFIED: v24.270 variant preview, card number position, Buddy Details, Boost status, and Mimic art repair are installed.')

#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

bundle=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('.').resolve()
repo=Path.cwd().resolve()
payload=bundle/'payload'
if not payload.is_dir():
    raise SystemExit(f'ERROR: payload missing: {payload}')

version=repo/'version.json'
if not version.exists() or '24.269' not in version.read_text(encoding='utf-8'):
    raise SystemExit('ERROR: v24.270 expects Duckie Days v24.269 as the installed base.')

def read(path):
    p=repo/path
    if not p.exists(): raise SystemExit(f'ERROR: missing {path}')
    return p.read_text(encoding='utf-8')

def write(path,text):
    (repo/path).write_text(text,encoding='utf-8')

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f'ERROR: {path}: expected exactly one occurrence of {old!r}; found {count}.')
    write(path,text.replace(old,new))

# Main Hub.
replace_once(Path('index.html'),
             '<meta name="duck-habit-build" content="24.269" />',
             '<meta name="duck-habit-build" content="24.270" />')
replace_once(Path('index.html'),
             '  <link rel="stylesheet" href="hub-v268.css?v=24-268" />',
             '  <link rel="stylesheet" href="hub-v268.css?v=24-268" />\n  <link rel="stylesheet" href="hub-v270.css?v=24-270" />')
replace_once(Path('index.html'),
             '  <script src="trading-cards-ui-v268.js?v=24-268"></script>',
             '  <script src="trading-cards-ui-v268.js?v=24-268"></script>\n  <script src="trading-cards-ui-v270.js?v=24-270"></script>')
replace_once(Path('index.html'),
             'const DUCK_HUB_BUILD = "24.269";',
             'const DUCK_HUB_BUILD = "24.270";')
replace_once(Path('index.html'),
             'navigator.serviceWorker.register("./sw.js?v=24-269"',
             'navigator.serviceWorker.register("./sw.js?v=24-270"')

# Duck Quest detail enhancement + mimic save repair.
replace_once(Path('duck-quest/index.html'),
             '  <link rel="stylesheet" href="css/quest-v269.css?v=24-269">',
             '  <link rel="stylesheet" href="css/quest-v269.css?v=24-269">\n  <link rel="stylesheet" href="css/quest-v270.css?v=24-270">')
replace_once(Path('duck-quest/index.html'),
             '  <script src="js/quest-v269.js?v=24-269"></script>',
             '  <script src="js/quest-v269.js?v=24-269"></script>\n  <script src="js/quest-v270.js?v=24-270"></script>')

# Copy payload last.
for src in payload.rglob('*'):
    if not src.is_file():
        continue
    rel=src.relative_to(payload)
    dst=repo/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)

print('Installed Duckie Days v24.270.')

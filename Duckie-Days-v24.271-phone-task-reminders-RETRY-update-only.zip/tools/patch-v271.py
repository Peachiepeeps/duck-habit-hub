#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT=Path.cwd()
BUNDLE=Path(__file__).resolve().parent.parent
PAYLOAD=BUNDLE/"payload"

def require(path, marker):
    text=Path(path).read_text(encoding="utf-8")
    if marker not in text:
        raise SystemExit(f"ERROR: {path} missing marker {marker!r}")
    return text

def replace_once(text, old, new, label):
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"ERROR: {label}: expected exactly 1 match, found {count}")
    return text.replace(old,new,1)

version=require("version.json",'"version": "24.270"')
index=require("index.html",'content="24.270"')
require("index.html",'trading-cards-ui-v270.js?v=24-270')
require("index.html",'task-progression-v261.js?v=24-261')
require("duck-quest/index.html",'quest-v270.js?v=24-270')

index=replace_once(
    index,
    '<meta name="duck-habit-build" content="24.270" />',
    '<meta name="duck-habit-build" content="24.271" />',
    "build meta"
)
index=replace_once(
    index,
    '  <link rel="stylesheet" href="hub-v270.css?v=24-270" />',
    '  <link rel="stylesheet" href="hub-v270.css?v=24-270" />\n  <link rel="stylesheet" href="task-reminders-v271.css?v=24-271" />',
    "v271 css include"
)
index=replace_once(
    index,
    '  <script src="task-progression-v261.js?v=24-261"></script>',
    '  <script src="task-progression-v261.js?v=24-261"></script>\n'
    '  <script type="module" src="firebase-reminders-v271.mjs?v=24-271"></script>\n'
    '  <script src="task-reminders-v271.js?v=24-271"></script>',
    "v271 reminder scripts"
)
index=replace_once(
    index,
    'const DUCK_HUB_BUILD = "24.270";',
    'const DUCK_HUB_BUILD = "24.271";',
    "build constant"
)
index=replace_once(
    index,
    'navigator.serviceWorker.register("./sw.js?v=24-270", { updateViaCache: "none" })',
    'navigator.serviceWorker.register("./sw.js?v=24-271", { updateViaCache: "none" })',
    "service worker registration"
)
Path("index.html").write_text(index,encoding="utf-8")

for source in PAYLOAD.rglob("*"):
    if not source.is_file():
        continue
    rel=source.relative_to(PAYLOAD)
    dest=ROOT/rel
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,dest)

print("Installed Duckie Days v24.271.")

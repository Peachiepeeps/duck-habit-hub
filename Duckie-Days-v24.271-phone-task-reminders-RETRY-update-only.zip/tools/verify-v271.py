#!/usr/bin/env python3
from pathlib import Path

def need(path, marker):
    p=Path(path)
    if not p.exists():
        raise SystemExit(f"ERROR: missing {path}")
    text=p.read_text(encoding="utf-8")
    if marker not in text:
        raise SystemExit(f"ERROR: {path} missing marker {marker!r}")
    return text

need("version.json",'"version": "24.271"')
index=need("index.html",'content="24.271"')
for marker in [
    'task-reminders-v271.css?v=24-271',
    'firebase-reminders-v271.mjs?v=24-271',
    'task-reminders-v271.js?v=24-271',
    'const DUCK_HUB_BUILD = "24.271";',
    'sw.js?v=24-271',
    'trading-cards-ui-v270.js?v=24-270',
    'task-progression-v261.js?v=24-261'
]:
    if marker not in index:
        raise SystemExit(f"ERROR: index.html missing {marker!r}")

need("sw.js","sw-v24-271.js?v=24-271")
sw=need("sw-v24-271.js","firebase-messaging-compat.js")
for marker in [
    "duck-habit-hub-app-v24-271",
    "firebase-reminders-v271.mjs?v=24-271",
    "task-reminders-v271.js?v=24-271",
    "task-reminders-v271.css?v=24-271"
]:
    if marker not in sw:
        raise SystemExit(f"ERROR: sw-v24-271.js missing {marker!r}")

firebase=need("firebase-reminders-v271.mjs","onRegistered")
for marker in [
    'register(messaging',
    'vapidKey: VAPID_KEY',
    '"users", user.uid, "settings", "notifications"',
    '"taskReminders"',
    'fid: null',
    '12.19.0'
]:
    if marker not in firebase:
        raise SystemExit(f"ERROR: firebase-reminders-v271.mjs missing {marker!r}")

ui=need("task-reminders-v271.js","taskNotificationsButtonV271")
for marker in [
    "taskReminderFieldsV271",
    "task-reminder-button-v271",
    "Deadline time",
    "Remind me before the deadline",
    "openTasks",
    "syncAll",
    "Anytime tasks"
]:
    if marker not in ui:
        raise SystemExit(f"ERROR: task-reminders-v271.js missing {marker!r}")

need("task-reminders-v271.css",".task-reminder-modal-v271")
backend=need("firebase-backend/sendDueTaskReminders-v271.js","sendDueTaskReminders")
for marker in ['schedule: "* * * * *"','fid,','collection("taskReminders")']:
    if marker not in backend:
        raise SystemExit(f"ERROR: backend backup missing {marker!r}")

quest=need("duck-quest/index.html","quest-v269.js?v=24-269")
if "quest-v270.js?v=24-270" not in quest:
    raise SystemExit("ERROR: Duck Quest v24.270 layer missing")

print("Verified Duckie Days v24.271 phone reminders.")

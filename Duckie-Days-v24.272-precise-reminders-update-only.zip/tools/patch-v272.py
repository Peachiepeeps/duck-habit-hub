#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path.cwd()
PAYLOAD = Path(__file__).resolve().parent.parent / "payload"


def replace_exact(text, old, new, label):
    if text.count(old) != 1:
        raise SystemExit(f"ERROR: {label}: expected one v24.271 marker; found {text.count(old)}")
    return text.replace(old, new, 1)


version = (ROOT / "version.json").read_text(encoding="utf-8")
if '"version": "24.271"' not in version:
    raise SystemExit("ERROR: Expected installed Duckie Days v24.271; update was not applied.")

index_file = ROOT / "index.html"
index = index_file.read_text(encoding="utf-8")
for old, new, label in [
    ('content="24.271"', 'content="24.272"', "build meta"),
    ('task-reminders-v271.css?v=24-271', 'task-reminders-v271.css?v=24-272', "reminder CSS"),
    ('firebase-reminders-v271.mjs?v=24-271', 'firebase-reminders-v271.mjs?v=24-272', "Firebase client"),
    ('task-reminders-v271.js?v=24-271', 'task-reminders-v271.js?v=24-272', "reminder UI"),
    ('const DUCK_HUB_BUILD = "24.271";', 'const DUCK_HUB_BUILD = "24.272";', "build constant"),
    ('sw.js?v=24-271', 'sw.js?v=24-272', "service worker registration"),
]:
    index = replace_exact(index, old, new, label)
index_file.write_text(index, encoding="utf-8")

for source in PAYLOAD.rglob("*"):
    if source.is_file():
        target = ROOT / source.relative_to(PAYLOAD)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

# The new backend source is the only deployment target.
for old in ["firebase-backend/sendDueTaskReminders-v271.js", "firebase-backend/README-v271.md"]:
    (ROOT / old).unlink(missing_ok=True)

print("Installed Duckie Days v24.272 precise task reminders.")

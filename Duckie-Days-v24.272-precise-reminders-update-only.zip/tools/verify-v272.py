#!/usr/bin/env python3
from pathlib import Path

def need(name, markers):
    path = Path(name)
    if not path.exists():
        raise SystemExit(f"ERROR: missing {name}")
    content = path.read_text(encoding="utf-8")
    for marker in markers:
        if marker not in content:
            raise SystemExit(f"ERROR: {name} missing {marker!r}")
    return content

need("version.json", ['"version": "24.272"'])
need("index.html", [
    'content="24.272"', 'const DUCK_HUB_BUILD = "24.272";',
    'task-reminders-v271.css?v=24-272',
    'firebase-reminders-v271.mjs?v=24-272',
    'task-reminders-v271.js?v=24-272', 'sw.js?v=24-272',
])
need("sw.js", ["sw-v24-272.js?v=24-272"])
need("sw-v24-272.js", ["duck-habit-hub-app-v24-272", "firebase-messaging-compat.js"])
need("firebase-reminders-v271.mjs", ["runTransaction", "scheduleKey", 'const BUILD = "24.272"'])
need("task-reminders-v271.js", ['const BUILD="24.272"', "new Date()"])
need("firebase-backend/index.js", ["queueTaskReminder", "dispatchTaskReminder", "queueFutureTaskReminders", "sendDueTaskReminders", "fid,"])
if Path("firebase-backend/sendDueTaskReminders-v271.js").exists():
    raise SystemExit("ERROR: old backend deployment source remains")
print("Verified Duckie Days v24.272 app and backend source.")

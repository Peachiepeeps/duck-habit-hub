#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT=Path.cwd()
PAYLOAD=Path(__file__).resolve().parent.parent/'payload'

def replace_one(text,old,new,label):
    n=text.count(old)
    if n!=1: raise SystemExit(f'ERROR: {label}: expected one v24.272 marker, found {n}')
    return text.replace(old,new,1)

version=(ROOT/'version.json').read_text(encoding='utf-8')
if '"version": "24.272"' not in version:
    raise SystemExit('ERROR: Duckie Days v24.272 must be installed first.')
index_file=ROOT/'index.html'
index=index_file.read_text(encoding='utf-8')
for old,new,label in [
    ('content="24.272"','content="24.273"','build meta'),
    ('task-reminders-v271.css?v=24-272','task-reminders-v271.css?v=24-273','reminder CSS'),
    ('firebase-reminders-v271.mjs?v=24-272','firebase-reminders-v271.mjs?v=24-273','Firebase client'),
    ('task-reminders-v271.js?v=24-272','task-reminders-v271.js?v=24-273','reminder UI'),
    ('const DUCK_HUB_BUILD = "24.272";','const DUCK_HUB_BUILD = "24.273";','build constant'),
    ('sw.js?v=24-272','sw.js?v=24-273','service worker'),
]: index=replace_one(index,old,new,label)
index_file.write_text(index,encoding='utf-8')
for source in PAYLOAD.rglob('*'):
    if source.is_file():
        target=ROOT/source.relative_to(PAYLOAD)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target)
print('Installed Duckie Days v24.273 reminder creation repair.')

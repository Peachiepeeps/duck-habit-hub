#!/usr/bin/env python3
from pathlib import Path

def need(name,*markers):
    path=Path(name)
    if not path.exists(): raise SystemExit(f'ERROR: missing {name}')
    content=path.read_text(encoding='utf-8')
    for marker in markers:
        if marker not in content: raise SystemExit(f'ERROR: {name} missing {marker!r}')

need('version.json','"version": "24.273"')
need('index.html','content="24.273"','const DUCK_HUB_BUILD = "24.273";',
     'firebase-reminders-v271.mjs?v=24-273','task-reminders-v271.js?v=24-273',
     'task-reminders-v271.css?v=24-273','sw.js?v=24-273')
need('firebase-reminders-v271.mjs','const BUILD = "24.273"','rememberSchedule','permission-denied','await setDoc(ref, fields(), {merge: true})')
need('task-reminders-v271.js','const BUILD="24.273"','Phone reminder could not be scheduled')
need('sw.js','sw-v24-273.js?v=24-273')
need('sw-v24-273.js','duck-habit-hub-app-v24-273')
need('firebase-backend/index.js','dispatchTaskReminder','sendDueTaskReminders')
print('Verified Duckie Days v24.273.')

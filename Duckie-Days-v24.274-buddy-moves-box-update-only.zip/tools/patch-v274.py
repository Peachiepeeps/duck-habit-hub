#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path.cwd()
PAYLOAD = Path(__file__).resolve().parent.parent / 'payload'

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'ERROR: {label}: expected one v24.273 marker, found {count}')
    return text.replace(old, new, 1)

version = (ROOT / 'version.json').read_text(encoding='utf-8')
if '"version": "24.273"' not in version:
    raise SystemExit('ERROR: Install v24.273 before installing this Buddy update.')

index_path = ROOT / 'index.html'
index = index_path.read_text(encoding='utf-8')
for before, after, label in [
    ('content="24.273"', 'content="24.274"', 'build meta'),
    ('const DUCK_HUB_BUILD = "24.273";', 'const DUCK_HUB_BUILD = "24.274";', 'build constant'),
    ('sw.js?v=24-273', 'sw.js?v=24-274', 'service worker'),
]:
    index = replace_once(index, before, after, label)

quest_path = ROOT / 'duck-quest/index.html'
quest = quest_path.read_text(encoding='utf-8')
for before, after, label in [
    ('<link rel="stylesheet" href="css/quest-v270.css?v=24-270">',
     '<link rel="stylesheet" href="css/quest-v270.css?v=24-270">\n  <link rel="stylesheet" href="css/quest-v274.css?v=24-274">', 'Buddy Box stylesheet'),
    ('js/game-v96.js?v=24-269', 'js/game-v96.js?v=24-274', 'battle core'),
    ('js/quest-v265.js?v=24-269-core', 'js/quest-v265.js?v=24-274', 'Buddy Box'),
    ('js/quest-v270.js?v=24-270', 'js/quest-v270.js?v=24-274', 'Buddy detail compatibility'),
]:
    quest = replace_once(quest, before, after, label)

index_path.write_text(index, encoding='utf-8')
quest_path.write_text(quest, encoding='utf-8')
for source in PAYLOAD.rglob('*'):
    if source.is_file():
        target = ROOT / source.relative_to(PAYLOAD)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
print('Installed Duckie Days v24.274 Buddy move and Box update.')

#!/usr/bin/env python3
from pathlib import Path

def need(name, *markers):
    path = Path(name)
    if not path.is_file():
        raise SystemExit(f'ERROR: missing {name}')
    content = path.read_text(encoding='utf-8')
    for marker in markers:
        if marker not in content:
            raise SystemExit(f'ERROR: {name} missing {marker!r}')

need('version.json', '"version": "24.274"')
need('index.html', 'content="24.274"', 'const DUCK_HUB_BUILD = "24.274";',
     'sw.js?v=24-274', 'firebase-reminders-v271.mjs?v=24-273',
     'task-reminders-v271.js?v=24-273')
need('duck-quest/index.html', 'css/quest-v274.css?v=24-274',
     'js/game-v96.js?v=24-274', 'js/quest-v265.js?v=24-274',
     'js/quest-v270.js?v=24-274')
need('duck-quest/js/game-v96.js', 'scaleSkill?.(baseSkill,buddy?.level||1)')
need('duck-quest/js/quest-v265.js', 'buddy-box-info-v274', 'buddyBoxNicknameV274',
     'buddyBoxGenderV274', 'buddyBoxUnassignV274', 'scaleSkill:scaledBuddySkill')
need('duck-quest/js/quest-v270.js', "detail.querySelector('.buddy-box-info-v274')")
need('duck-quest/css/quest-v274.css', '.buddy-box-customize-v274')
need('sw.js', 'sw-v24-274.js?v=24-274')
need('sw-v24-274.js', 'duck-habit-hub-app-v24-274',
     './duck-quest/css/quest-v274.css?v=24-274',
     './duck-quest/js/game-v96.js?v=24-274',
     './task-reminders-v271.js?v=24-273')
print('Verified Duckie Days v24.274 Buddy move and Box update.')

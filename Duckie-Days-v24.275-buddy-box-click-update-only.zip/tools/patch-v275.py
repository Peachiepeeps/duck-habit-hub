#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT=Path.cwd()
PAYLOAD=Path(__file__).resolve().parent.parent/'payload'

def replace_once(content,old,new,label):
    count=content.count(old)
    if count!=1: raise SystemExit(f'ERROR: {label}: expected one marker, found {count}')
    return content.replace(old,new,1)

if '"version": "24.274"' not in (ROOT/'version.json').read_text(encoding='utf-8'):
    raise SystemExit('ERROR: Install v24.274 before the Buddy Box click repair.')

hub_path=ROOT/'index.html'
hub=hub_path.read_text(encoding='utf-8')
for old,new,label in [
    ('content="24.274"','content="24.275"','build meta'),
    ('const DUCK_HUB_BUILD = "24.274";','const DUCK_HUB_BUILD = "24.275";','build constant'),
    ('sw.js?v=24-274','sw.js?v=24-275','service worker'),
]: hub=replace_once(hub,old,new,label)

quest_path=ROOT/'duck-quest/index.html'
quest=replace_once(quest_path.read_text(encoding='utf-8'),
    'js/quest-v265.js?v=24-274','js/quest-v265.js?v=24-275','Buddy Box script')

hub_path.write_text(hub,encoding='utf-8')
quest_path.write_text(quest,encoding='utf-8')
for source in PAYLOAD.rglob('*'):
    if source.is_file():
        dest=ROOT/source.relative_to(PAYLOAD)
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,dest)
print('Installed Duckie Days v24.275 Buddy Box click repair.')

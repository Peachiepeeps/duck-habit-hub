#!/usr/bin/env python3
from pathlib import Path

def need(name,*markers):
    path=Path(name)
    if not path.is_file(): raise SystemExit(f'ERROR: missing {name}')
    data=path.read_text(encoding='utf-8')
    for marker in markers:
        if marker not in data: raise SystemExit(f'ERROR: {name} missing {marker!r}')

need('version.json','"version": "24.275"')
need('index.html','content="24.275"','const DUCK_HUB_BUILD = "24.275";','sw.js?v=24-275')
need('duck-quest/index.html','js/quest-v265.js?v=24-275','css/quest-v274.css?v=24-274')
need('duck-quest/js/quest-v265.js',"button.addEventListener('click',()=>renderBuddyBoxDetail(entry.id))",'buddy-box-info-v274')
need('sw.js','sw-v24-275.js?v=24-275')
need('sw-v24-275.js','duck-habit-hub-app-v24-275','./duck-quest/js/quest-v265.js?v=24-275',
     './duck-quest/js/game-v96.js?v=24-274','./task-reminders-v271.js?v=24-273')
print('Verified Duckie Days v24.275 Buddy Box click repair.')

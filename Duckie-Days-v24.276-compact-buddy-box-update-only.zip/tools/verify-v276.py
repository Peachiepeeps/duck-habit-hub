#!/usr/bin/env python3
from pathlib import Path

def need(name,*markers):
    path=Path(name)
    if not path.is_file():raise SystemExit(f'ERROR: missing {name}')
    data=path.read_text(encoding='utf-8')
    for marker in markers:
        if marker not in data:raise SystemExit(f'ERROR: {name} missing {marker!r}')

need('version.json','"version": "24.276"')
need('index.html','content="24.276"','const DUCK_HUB_BUILD = "24.276";','sw.js?v=24-276',
     'firebase-reminders-v271.mjs?v=24-273')
need('duck-quest/index.html','css/quest-v276.css?v=24-276','js/quest-v265.js?v=24-276')
need('duck-quest/js/quest-v265.js','buddy-box-detail-layout-v276','buddy-box-icon-window-v276',
     'buddyBoxLevelDialogV276','buddyBoxConfirmLevelV276',"button.addEventListener('click',()=>renderBuddyBoxDetail(entry.id))")
need('duck-quest/css/quest-v276.css','--buddy-icon-bg:#fff','overflow:hidden;scrollbar-gutter:auto',
     '.buddy-box-main-v276','.buddy-box-level-dialog-v276')
need('sw.js','sw-v24-276.js?v=24-276')
need('sw-v24-276.js','duck-habit-hub-app-v24-276',
     './duck-quest/js/quest-v265.js?v=24-276',
     './duck-quest/css/quest-v276.css?v=24-276',
     './duck-quest/js/game-v96.js?v=24-274')
print('Verified Duckie Days v24.276 compact Buddy Box.')

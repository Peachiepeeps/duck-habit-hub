#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT=Path.cwd()
PAYLOAD=Path(__file__).resolve().parent.parent/'payload'

def replace_once(content,old,new,label):
    count=content.count(old)
    if count!=1: raise SystemExit(f'ERROR: {label}: expected one marker, found {count}')
    return content.replace(old,new,1)

if '"version": "24.276"' not in (ROOT/'version.json').read_text(encoding='utf-8'):
    raise SystemExit('ERROR: Install v24.276 before the stacked Buddy Box update.')

hub_path=ROOT/'index.html'
hub=hub_path.read_text(encoding='utf-8')
for old,new,label in [
    ('content="24.276"','content="24.277"','build meta'),
    ('const DUCK_HUB_BUILD = "24.276";','const DUCK_HUB_BUILD = "24.277";','build constant'),
    ('sw.js?v=24-276','sw.js?v=24-277','service worker'),
]: hub=replace_once(hub,old,new,label)

quest_path=ROOT/'duck-quest/index.html'
quest=quest_path.read_text(encoding='utf-8')
quest=replace_once(quest,'<link rel="stylesheet" href="css/quest-v276.css?v=24-276">',
    '<link rel="stylesheet" href="css/quest-v276.css?v=24-276">\n  <link rel="stylesheet" href="css/quest-v277.css?v=24-277">','stacked layout CSS')
quest=replace_once(quest,'js/quest-v265.js?v=24-276','js/quest-v265.js?v=24-277','Buddy Box JS')

hub_path.write_text(hub,encoding='utf-8')
quest_path.write_text(quest,encoding='utf-8')
for source in PAYLOAD.rglob('*'):
    if source.is_file():
        dest=ROOT/source.relative_to(PAYLOAD)
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,dest)
print('Installed Duckie Days v24.277 stacked Buddy Box.')

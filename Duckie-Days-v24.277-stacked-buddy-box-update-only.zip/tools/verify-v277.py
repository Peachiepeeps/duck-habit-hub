#!/usr/bin/env python3
from pathlib import Path

def need(name,*markers):
    path=Path(name)
    if not path.is_file():raise SystemExit(f'ERROR: missing {name}')
    data=path.read_text(encoding='utf-8')
    for marker in markers:
        if marker not in data:raise SystemExit(f'ERROR: {name} missing {marker!r}')

need('version.json','"version": "24.277"')
need('index.html','content="24.277"','const DUCK_HUB_BUILD = "24.277";','sw.js?v=24-277',
     'firebase-reminders-v271.mjs?v=24-273')
need('duck-quest/index.html','css/quest-v276.css?v=24-276','css/quest-v277.css?v=24-277','js/quest-v265.js?v=24-277')
need('duck-quest/js/quest-v265.js','buddy-box-detail-actions-v277','buddyBoxInfoDialogV277',
     'buddyBoxCancelInfoV277','buddyBoxLevelDialogV276','buddyBoxConfirmLevelV276','buddy-box-icon-window-v276',
     "button.addEventListener('click',()=>renderBuddyBoxDetail(entry.id))")
need('duck-quest/css/quest-v277.css','.buddy-box-main-v276{grid-template-columns:minmax(0,1fr)',
     '.buddy-box-detail-actions-v277{display:grid;grid-template-columns:repeat(2',
     '.buddy-box-info-fields-v277','.buddy-box-footer-v276 .danger{grid-column:auto}')
need('sw.js','sw-v24-277.js?v=24-277')
need('sw-v24-277.js','duck-habit-hub-app-v24-277','./duck-quest/js/quest-v265.js?v=24-277',
     './duck-quest/css/quest-v277.css?v=24-277','./duck-quest/js/game-v96.js?v=24-274')
print('Verified Duckie Days v24.277 stacked Buddy Box.')

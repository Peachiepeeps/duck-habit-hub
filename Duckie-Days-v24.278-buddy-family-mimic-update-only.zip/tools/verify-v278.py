#!/usr/bin/env python3
from pathlib import Path

def need(name,*markers):
    p=Path(name)
    if not p.is_file():raise SystemExit(f'ERROR: missing {name}')
    s=p.read_text(encoding='utf-8')
    for marker in markers:
        if marker not in s:raise SystemExit(f'ERROR: {name} missing {marker!r}')

need('version.json','"version": "24.278"')
need('index.html','content="24.278"','const DUCK_HUB_BUILD = "24.278";','sw.js?v=24-278',
     'firebase-reminders-v271.mjs?v=24-273')
need('duck-quest/index.html','css/quest-v277.css?v=24-277','css/quest-v278.css?v=24-278','js/quest-v265.js?v=24-278')
need('duck-quest/js/quest-v265.js','Family (color order)','compareBuddyFamily','closeBuddyBoxDetail();try{persistAll();renderBuddyCollection?.();}',
     'assets/enemies/mimic/lucky/idle-2.webp','assets/enemies/mimic/healthy/idle-2.webp','buddyBoxRestorePinkV278',
     "hubSave.buddies.equippedByCharacter.peep[0]='mimic:base'")
need('duck-quest/css/quest-v278.css','.buddy-box-restore-v278')
need('sw.js','sw-v24-278.js?v=24-278')
need('sw-v24-278.js','duck-habit-hub-app-v24-278','./duck-quest/js/quest-v265.js?v=24-278',
     './duck-quest/css/quest-v278.css?v=24-278','./duck-quest/css/quest-v277.css?v=24-277')
print('Verified Duckie Days v24.278 Buddy Box family and Mimic update.')

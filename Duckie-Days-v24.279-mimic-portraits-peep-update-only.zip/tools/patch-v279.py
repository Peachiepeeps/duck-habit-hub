#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT=Path.cwd()
PAYLOAD=Path(__file__).resolve().parent.parent/'payload'

def replace_once(path,old,new):
    content=path.read_text(encoding='utf-8')
    count=content.count(old)
    if count!=1:raise SystemExit(f'ERROR: {path}: expected one {old!r}, found {count}')
    path.write_text(content.replace(old,new,1),encoding='utf-8')

if '"version": "24.278"' not in (ROOT/'version.json').read_text(encoding='utf-8'):
    raise SystemExit('ERROR: Install v24.278 before this Mimic update.')

hub=ROOT/'index.html'
replace_once(hub,'content="24.278"','content="24.279"')
replace_once(hub,'const DUCK_HUB_BUILD = "24.278";','const DUCK_HUB_BUILD = "24.279";')
replace_once(hub,'sw.js?v=24-278','sw.js?v=24-279')
replace_once(hub,'script-v24-201.js?v=24-265','script-v24-201.js?v=24-279')
quest=ROOT/'duck-quest/index.html'
replace_once(quest,'quest-v265.js?v=24-278','quest-v265.js?v=24-279')
replace_once(quest,'quest-v270.js?v=24-274','quest-v270.js?v=24-279')
replace_once(ROOT/'sw.js','sw-v24-278.js?v=24-278','sw-v24-279.js?v=24-279')
replace_once(ROOT/'version.json','"version": "24.278"','"version": "24.279"')
for source in PAYLOAD.rglob('*'):
    if source.is_file():
        dest=ROOT/source.relative_to(PAYLOAD)
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,dest)
print('Installed Duckie Days v24.279 Mimic portraits and Peep profile correction.')

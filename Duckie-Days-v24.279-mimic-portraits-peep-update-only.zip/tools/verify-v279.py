#!/usr/bin/env python3
from pathlib import Path

def need(name,*markers):
    p=Path(name)
    if not p.is_file():raise SystemExit(f'ERROR: missing {name}')
    text=p.read_text(encoding='utf-8')
    for marker in markers:
        if marker not in text:raise SystemExit(f'ERROR: {name}: missing {marker!r}')

need('version.json','"version": "24.279"')
need('index.html','content="24.279"','const DUCK_HUB_BUILD = "24.279";','sw.js?v=24-279','script-v24-201.js?v=24-279')
need('script-v24-201.js','"mimic:base": "assets/enemies/mimic/base/open-1.webp"','"mimic:lucky": "assets/enemies/mimic/lucky/open.webp"')
need('duck-quest/index.html','quest-v265.js?v=24-279','quest-v270.js?v=24-279')
need('duck-quest/js/quest-v265.js',"'mimic:base':'assets/enemies/mimic/base/open-1.webp'",'Object.entries(MIMIC_BOX_ICONS)',"collection['mimic:base'].image=MIMIC_BOX_ICONS['mimic:base']")
need('duck-quest/js/quest-v270.js',"'mimic:base':['assets/enemies/mimic/base/open-1.webp'", "'mimic:healthy':['assets/enemies/mimic/healthy/open.webp'")
need('sw.js','sw-v24-279.js?v=24-279')
need('sw-v24-279.js','duck-habit-hub-app-v24-279','script-v24-201.js?v=24-279','quest-v265.js?v=24-279','quest-v270.js?v=24-279')
for asset in ['duck-quest/assets/enemies/mimic/base/open-1.webp','duck-quest/assets/enemies/mimic/lucky/open.webp','duck-quest/assets/enemies/mimic/healthy/open.webp','duck-quest/assets/shinies/amethyst-mimic-idle-1.webp']:
    if not Path(asset).is_file():raise SystemExit(f'ERROR: missing Mimic portrait {asset}')
print('Verified v24.279 Mimic portraits and Peep profile correction.')

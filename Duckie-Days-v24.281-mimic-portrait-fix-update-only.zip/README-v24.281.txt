Duckie Days v24.281 - Mimic Portrait Fix

Upload BOTH files:

1. Duckie-Days-v24.281-mimic-portrait-fix-update-only.zip
   -> repository root

2. install-duckie-days-v24-281-mimic-portrait-fix.yml
   -> .github/workflows/

This patches the current v24.280 app rather than replacing the whole app.

Canonical Buddy portraits:
- Pink/base Mimic: base/open-1.webp
- Lucky Mimic: lucky/open.webp
- Healthy Mimic: healthy/open.webp
- Amethyst Mimic: amethyst-mimic-idle-1.webp

All use the eyes-visible / no-white-claw appearance.

The update also repairs existing saved Mimics, fixes Peep's profile portrait,
and keeps chest disguise art and battle animation frames separate.

from pathlib import Path
import json
import re

ROOT = Path.cwd()
VERSION = "24.281"
QUERY = "24-281"

def load(path):
    p = ROOT / path
    if not p.exists():
        raise RuntimeError(f"Missing required file: {path}")
    return p.read_text(encoding="utf-8")

def save(path, text):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")

def replace_once(path, old, new, label):
    text = load(path)
    if new in text:
        return
    if old not in text:
        raise RuntimeError(f"{label}: expected text not found in {path}")
    save(path, text.replace(old, new, 1))

def replace_between(path, start_marker, end_marker, replacement, label):
    text = load(path)
    start = text.find(start_marker)
    if start < 0:
        raise RuntimeError(f"{label}: start marker not found in {path}")
    end = text.find(end_marker, start)
    if end < 0:
        raise RuntimeError(f"{label}: end marker not found in {path}")
    save(path, text[:start] + replacement + text[end:])

def regex_once(path, pattern, replacement, label):
    text = load(path)
    new_text, count = re.subn(pattern, replacement, text, count=1, flags=re.M)
    if count != 1:
        raise RuntimeError(f"{label}: expected 1 match in {path}, found {count}")
    save(path, new_text)

version_file = ROOT / "version.json"
version_data = json.loads(version_file.read_text(encoding="utf-8"))
current = str(version_data.get("version", ""))
if current not in {"24.280", VERSION}:
    raise RuntimeError(
        f"Expected Duckie Days v24.280 before installing this fix; found {current!r}."
    )

GAME = "duck-quest/js/game-v96.js"

replace_once(
    GAME,
    '''    idle: [
      "assets/enemies/mimic/base/open-1.webp",
      "assets/enemies/mimic/base/open-2.webp"
    ],
    hurt: "assets/items/chests/treasure/closed.webp",''',
    '''    portrait: "assets/enemies/mimic/base/open-1.webp",
    idle: [
      "assets/enemies/mimic/base/open-1.webp",
      "assets/enemies/mimic/base/open-2.webp"
    ],
    hurt: "assets/items/chests/treasure/closed.webp",''',
    "regular Mimic portrait"
)

replace_once(
    GAME,
    '''  "mimic": {
    id:"amethyst", name:"Amethyst Mimic",
    idle:["assets/shinies/amethyst-mimic-idle-1.webp","assets/shinies/amethyst-mimic-idle-2.webp"],
    hurt:"assets/shinies/amethyst-mimic-closed.webp"
  },''',
    '''  "mimic": {
    id:"amethyst", name:"Amethyst Mimic",
    portrait:"assets/shinies/amethyst-mimic-idle-1.webp",
    idle:["assets/shinies/amethyst-mimic-idle-1.webp","assets/shinies/amethyst-mimic-idle-2.webp"],
    hurt:"assets/shinies/amethyst-mimic-closed.webp"
  },''',
    "Amethyst Mimic portrait"
)

replace_once(
    GAME,
    '    image:String(idleFrames[0] || ""),',
    '    image:String(variant?.portrait || idleFrames[0] || ""),',
    "catalog portrait field"
)

replace_once(
    GAME,
    '''  entries.push(catalogEntry("mimic","lucky",{
    id:"lucky",name:"Lucky Mimic",
    idle:["assets/enemies/mimic/lucky/idle-1.webp","assets/enemies/mimic/lucky/idle-2.webp"],
    hurt:"assets/enemies/mimic/lucky/closed.webp"
  },false,false));''',
    '''  entries.push(catalogEntry("mimic","lucky",{
    id:"lucky",name:"Lucky Mimic",
    portrait:"assets/enemies/mimic/lucky/open.webp",
    idle:["assets/enemies/mimic/lucky/idle-1.webp","assets/enemies/mimic/lucky/idle-2.webp"],
    hurt:"assets/enemies/mimic/lucky/closed.webp"
  },false,false));''',
    "Lucky Mimic portrait"
)

replace_once(
    GAME,
    '''  entries.push(catalogEntry("mimic","healthy",{
    id:"healthy",name:"Healthy Mimic",
    idle:["assets/enemies/mimic/healthy/idle-1.webp","assets/enemies/mimic/healthy/idle-2.webp"],
    hurt:"assets/enemies/mimic/healthy/closed.webp"
  },false,false));''',
    '''  entries.push(catalogEntry("mimic","healthy",{
    id:"healthy",name:"Healthy Mimic",
    portrait:"assets/enemies/mimic/healthy/open.webp",
    idle:["assets/enemies/mimic/healthy/idle-1.webp","assets/enemies/mimic/healthy/idle-2.webp"],
    hurt:"assets/enemies/mimic/healthy/closed.webp"
  },false,false));''',
    "Healthy Mimic portrait"
)

BOX = "duck-quest/js/quest-v265.js"
replace_once(
    BOX,
    '''  const MIMIC_BOX_ICONS={
    'mimic:lucky':'assets/enemies/mimic/lucky/idle-2.webp',
    'mimic:healthy':'assets/enemies/mimic/healthy/idle-2.webp'
  };''',
    '''  const MIMIC_BOX_ICONS=Object.freeze({
    'mimic:base':'assets/enemies/mimic/base/open-1.webp',
    'mimic:lucky':'assets/enemies/mimic/lucky/open.webp',
    'mimic:healthy':'assets/enemies/mimic/healthy/open.webp',
    'mimic:shiny':'assets/shinies/amethyst-mimic-idle-1.webp',
    'mimic:amethyst':'assets/shinies/amethyst-mimic-idle-1.webp'
  });''',
    "Buddy Box Mimic icon map"
)

REPAIR = "duck-quest/js/quest-v270.js"
new_mimic_art = '''  function mimicArt(entry){
    if(!entry) return null;
    const enemyId=String(entry.enemyId||'').toLowerCase();
    const key=String(entry.key||'').toLowerCase();
    const variant=String(entry.variantId||'').toLowerCase();
    const name=String(entry.name||'').toLowerCase();
    const isMimic=enemyId==='mimic' || key.startsWith('mimic:') || name.includes('mimic');
    if(!isMimic) return null;

    if(key==='mimic:lucky' || variant==='lucky' || name.includes('lucky mimic')){
      return {
        image:'assets/enemies/mimic/lucky/open.webp',
        idle:['assets/enemies/mimic/lucky/idle-1.webp','assets/enemies/mimic/lucky/idle-2.webp']
      };
    }
    if(key==='mimic:healthy' || variant==='healthy' || name.includes('healthy mimic')){
      return {
        image:'assets/enemies/mimic/healthy/open.webp',
        idle:['assets/enemies/mimic/healthy/idle-1.webp','assets/enemies/mimic/healthy/idle-2.webp']
      };
    }
    if(key==='mimic:shiny' || key==='mimic:amethyst' || variant==='amethyst' || variant==='shiny' || name.includes('amethyst mimic')){
      return {
        image:'assets/shinies/amethyst-mimic-idle-1.webp',
        idle:['assets/shinies/amethyst-mimic-idle-1.webp','assets/shinies/amethyst-mimic-idle-2.webp']
      };
    }
    return {
      image:'assets/enemies/mimic/base/open-1.webp',
      idle:['assets/enemies/mimic/base/open-1.webp','assets/enemies/mimic/base/open-2.webp']
    };
  }

'''
replace_between(
    REPAIR,
    "  function mimicArt(entry){",
    "  function repairEntry(entry){",
    new_mimic_art,
    "saved Mimic portrait repair"
)

PROFILE = "script-v24-201.js"
new_profile_resolver = '''const PROFILE_MIMIC_PORTRAITS = Object.freeze({
  base: "duck-quest/assets/enemies/mimic/base/open-1.webp",
  lucky: "duck-quest/assets/enemies/mimic/lucky/open.webp",
  healthy: "duck-quest/assets/enemies/mimic/healthy/open.webp",
  amethyst: "duck-quest/assets/shinies/amethyst-mimic-idle-1.webp"
});

function profileMimicPortraitSource(buddy) {
  if (!buddy) return "";
  const enemyId = String(buddy.enemyId || "").toLowerCase();
  const key = String(buddy.key || "").toLowerCase();
  const variant = String(buddy.variantId || "").toLowerCase();
  const name = String(buddy.name || "").toLowerCase();
  const isMimic = enemyId === "mimic" || key.startsWith("mimic:") || name.includes("mimic");
  if (!isMimic) return "";

  if (key === "mimic:lucky" || variant === "lucky" || name.includes("lucky mimic")) {
    return PROFILE_MIMIC_PORTRAITS.lucky;
  }
  if (key === "mimic:healthy" || variant === "healthy" || name.includes("healthy mimic")) {
    return PROFILE_MIMIC_PORTRAITS.healthy;
  }
  if (
    key === "mimic:shiny" ||
    key === "mimic:amethyst" ||
    variant === "amethyst" ||
    variant === "shiny" ||
    name.includes("amethyst mimic")
  ) {
    return PROFILE_MIMIC_PORTRAITS.amethyst;
  }
  return PROFILE_MIMIC_PORTRAITS.base;
}

function buddyImageSource(buddy) {
  const mimicPortrait = profileMimicPortraitSource(buddy);
  if (mimicPortrait) return mimicPortrait;

  const image = String(buddy?.image || "").trim();
  if (!image) return "";
  if (/^(?:https?:|data:|blob:|\\/)/i.test(image)) return image;
  if (image.startsWith("../assets/")) return `duck-quest/${image.slice(3)}`;
  if (image.startsWith("./assets/")) return `duck-quest/${image.slice(2)}`;
  if (image.startsWith("duck-quest/")) return image;
  if (image.startsWith("assets/")) return `duck-quest/${image}`;
  return image;
}

'''
replace_between(
    PROFILE,
    "function buddyImageSource(buddy) {",
    "function buddyFallbackImageSource(src) {",
    new_profile_resolver,
    "profile Mimic portrait resolver"
)

QUEST_INDEX = "duck-quest/index.html"
for filename in ("game-v96.js", "quest-v265.js", "quest-v270.js"):
    regex_once(
        QUEST_INDEX,
        rf'({re.escape(filename)}\?v=)[^"]+',
        rf'\g<1>{QUERY}',
        f"cache bust {filename}"
    )

ROOT_INDEX = "index.html"
regex_once(
    ROOT_INDEX,
    r'(<meta name="duck-habit-build" content=")[^"]+(" />)',
    rf'\g<1>{VERSION}\2',
    "root build meta"
)
regex_once(
    ROOT_INDEX,
    r'(script-v24-201\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "profile script cache bust"
)
regex_once(
    ROOT_INDEX,
    r'(const DUCK_HUB_BUILD = ")[^"]+(";\s*)',
    rf'\g<1>{VERSION}\2',
    "DUCK_HUB_BUILD"
)
regex_once(
    ROOT_INDEX,
    r'(\./sw\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "service worker registration"
)

version_file.write_text(json.dumps({"version": VERSION}, indent=2) + "\n", encoding="utf-8")

old_worker = ROOT / "sw-v24-280.js"
if not old_worker.exists():
    raise RuntimeError("Missing sw-v24-280.js")

worker = old_worker.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-280", "duck-habit-hub-app-v24-281")
worker = worker.replace("./sw.js?v=24-280", "./sw.js?v=24-281")

worker = re.sub(
    r"'./duck-quest/js/game-v96\.js\?v=[^']+'",
    "'./duck-quest/js/game-v96.js?v=24-281'",
    worker,
    count=1
)
worker = re.sub(
    r"'./duck-quest/js/quest-v265\.js\?v=[^']+'",
    "'./duck-quest/js/quest-v265.js?v=24-281'",
    worker,
    count=1
)
worker = re.sub(
    r"'./duck-quest/js/quest-v270\.js\?v=[^']+'",
    "'./duck-quest/js/quest-v270.js?v=24-281'",
    worker,
    count=1
)

if "./script-v24-201.js?v=24-281" not in worker:
    anchor = "'./hub-v265.js?v=24-265','./hub-v267.js?v=24-267',"
    if anchor not in worker:
        raise RuntimeError("Could not add profile script to the service-worker app shell.")
    worker = worker.replace(
        anchor,
        anchor + "\n './script-v24-201.js?v=24-281',",
        1
    )

if "./duck-quest/assets/enemies/mimic/base/open-1.webp" not in worker:
    anchor = " './assets/ingredients/Sparkle.webp',"
    if anchor not in worker:
        raise RuntimeError("Could not add Mimic portrait assets to the service-worker app shell.")
    worker = worker.replace(
        anchor,
        ''' './assets/ingredients/Sparkle.webp',
 './duck-quest/assets/enemies/mimic/base/open-1.webp',
 './duck-quest/assets/enemies/mimic/lucky/open.webp',
 './duck-quest/assets/enemies/mimic/healthy/open.webp',''',
        1
    )

save("sw-v24-281.js", worker)
save("sw.js", "importScripts('./sw-v24-281.js?v=24-281');\n")

save(
    "UPDATE-v24.281.txt",
    '''Duckie Days v24.281 - Mimic Portrait Fix

All Mimic Buddy icons now use a consistent eyes-visible, no-white-claw portrait.

Pink/base:
  duck-quest/assets/enemies/mimic/base/open-1.webp

Lucky:
  duck-quest/assets/enemies/mimic/lucky/open.webp

Healthy:
  duck-quest/assets/enemies/mimic/healthy/open.webp

Amethyst:
  duck-quest/assets/shinies/amethyst-mimic-idle-1.webp

This also repairs already-saved Mimic copies and makes the main OC profile
use the same resolver as the Buddy system, including Peep's pink Mimic.
Chest disguise art and two-frame battle animations remain separate.
'''
)

print("Duckie Days v24.281 patch applied.")

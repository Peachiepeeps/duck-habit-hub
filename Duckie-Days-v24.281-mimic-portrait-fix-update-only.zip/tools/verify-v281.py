from pathlib import Path
import json

ROOT = Path.cwd()

def read(path):
    p = ROOT / path
    assert p.exists(), f"Missing: {path}"
    return p.read_text(encoding="utf-8")

def has(path, needle):
    assert needle in read(path), f"{path} missing expected text: {needle}"

assert json.loads(read("version.json")).get("version") == "24.281"

for asset in (
    "duck-quest/assets/enemies/mimic/base/open-1.webp",
    "duck-quest/assets/enemies/mimic/lucky/open.webp",
    "duck-quest/assets/enemies/mimic/healthy/open.webp",
    "duck-quest/assets/shinies/amethyst-mimic-idle-1.webp",
):
    assert (ROOT / asset).exists(), f"Missing portrait asset: {asset}"

has("duck-quest/js/game-v96.js", 'portrait: "assets/enemies/mimic/base/open-1.webp"')
has("duck-quest/js/game-v96.js", 'portrait:"assets/enemies/mimic/lucky/open.webp"')
has("duck-quest/js/game-v96.js", 'portrait:"assets/enemies/mimic/healthy/open.webp"')
has("duck-quest/js/game-v96.js", 'portrait:"assets/shinies/amethyst-mimic-idle-1.webp"')
has("duck-quest/js/game-v96.js", 'image:String(variant?.portrait || idleFrames[0] || "")')

has("duck-quest/js/quest-v265.js", "'mimic:base':'assets/enemies/mimic/base/open-1.webp'")
has("duck-quest/js/quest-v265.js", "'mimic:lucky':'assets/enemies/mimic/lucky/open.webp'")
has("duck-quest/js/quest-v265.js", "'mimic:healthy':'assets/enemies/mimic/healthy/open.webp'")
has("duck-quest/js/quest-v265.js", "'mimic:shiny':'assets/shinies/amethyst-mimic-idle-1.webp'")

has("duck-quest/js/quest-v270.js", "image:'assets/enemies/mimic/base/open-1.webp'")
has("duck-quest/js/quest-v270.js", "image:'assets/enemies/mimic/lucky/open.webp'")
has("duck-quest/js/quest-v270.js", "image:'assets/enemies/mimic/healthy/open.webp'")
has("duck-quest/js/quest-v270.js", "image:'assets/shinies/amethyst-mimic-idle-1.webp'")

has("script-v24-201.js", "const PROFILE_MIMIC_PORTRAITS = Object.freeze({")
has("script-v24-201.js", 'base: "duck-quest/assets/enemies/mimic/base/open-1.webp"')
has("script-v24-201.js", 'lucky: "duck-quest/assets/enemies/mimic/lucky/open.webp"')
has("script-v24-201.js", 'healthy: "duck-quest/assets/enemies/mimic/healthy/open.webp"')
has("script-v24-201.js", 'amethyst: "duck-quest/assets/shinies/amethyst-mimic-idle-1.webp"')
has("script-v24-201.js", "const mimicPortrait = profileMimicPortraitSource(buddy);")

quest_index = read("duck-quest/index.html")
for filename in ("game-v96.js", "quest-v265.js", "quest-v270.js"):
    assert f"{filename}?v=24-281" in quest_index

root_index = read("index.html")
assert 'duck-habit-build" content="24.281"' in root_index
assert 'script-v24-201.js?v=24-281' in root_index
assert 'const DUCK_HUB_BUILD = "24.281";' in root_index
assert './sw.js?v=24-281' in root_index

has("sw.js", "sw-v24-281.js?v=24-281")
worker = read("sw-v24-281.js")
assert "duck-habit-hub-app-v24-281" in worker
assert "./script-v24-201.js?v=24-281" in worker
assert "./duck-quest/js/game-v96.js?v=24-281" in worker
assert "./duck-quest/js/quest-v265.js?v=24-281" in worker
assert "./duck-quest/js/quest-v270.js?v=24-281" in worker
assert "./duck-quest/assets/enemies/mimic/base/open-1.webp" in worker
assert "./duck-quest/assets/enemies/mimic/lucky/open.webp" in worker
assert "./duck-quest/assets/enemies/mimic/healthy/open.webp" in worker

has("UPDATE-v24.281.txt", "Mimic Portrait Fix")
print("VERIFIED: v24.281 Mimic portrait fix.")

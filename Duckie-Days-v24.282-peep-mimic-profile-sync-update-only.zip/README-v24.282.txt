Duckie Days v24.282 - Peep Mimic Profile Sync

Upload BOTH:
1) Duckie-Days-v24.282-peep-mimic-profile-sync-update-only.zip
   -> repository root

2) install-duckie-days-v24-282-peep-mimic-profile-sync.yml
   -> .github/workflows/

This update fixes the final Peep Mimic issue shown on the main profile.

The art from v24.281 was already correct. The remaining problem was that:
- Buddy Box had Peep's actual pink Mimic instance.
- Peep's main profile slot still stored the old mimic:lucky form key.

v24.282 repairs that stale Mimic key from the individual Buddy Box instance
and keeps future profile assignments synchronized with Buddy Box assignments.

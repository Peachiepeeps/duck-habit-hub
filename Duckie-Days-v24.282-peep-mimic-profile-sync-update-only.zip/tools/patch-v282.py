from pathlib import Path
import json
import re

ROOT = Path.cwd()
VERSION = "24.282"
QUERY = "24-282"

def load(path):
    p = ROOT / path
    if not p.exists():
        raise RuntimeError(f"Missing required file: {path}")
    return p.read_text(encoding="utf-8")

def save(path, content):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")

def replace_once(path, old, new, label):
    text = load(path)
    if new in text:
        return
    if old not in text:
        raise RuntimeError(f"{label}: expected source block not found in {path}")
    save(path, text.replace(old, new, 1))

def regex_once(path, pattern, replacement, label):
    text = load(path)
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.M)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one match in {path}, found {count}")
    save(path, updated)

version_path = ROOT / "version.json"
version = json.loads(version_path.read_text(encoding="utf-8"))
current = str(version.get("version", ""))
if current not in {"24.281", VERSION}:
    raise RuntimeError(
        f"This installer expects Duckie Days v24.281. Repository reports {current!r}."
    )

SCRIPT = "script-v24-201.js"

old_get_slots = '''function getBuddySlots(characterId = save.selectedCharacter) {
  if (!save.buddies || typeof save.buddies !== "object") save.buddies = normalizeBuddySave(null);
  if (!save.buddies.equippedByCharacter || typeof save.buddies.equippedByCharacter !== "object") {
    save.buddies.equippedByCharacter = {};
  }

  const source = Array.isArray(save.buddies.equippedByCharacter[characterId])
    ? save.buddies.equippedByCharacter[characterId]
    : [];
  const slots = Array.from({ length: BUDDY_SLOT_COUNT }, (_, index) => {
    const key = typeof source[index] === "string" ? source[index] : null;
    return key && buddyByKey(key) ? key : null;
  });
  save.buddies.equippedByCharacter[characterId] = slots;
  return slots;
}'''

new_get_slots = '''function buddyBoxMappedEntry(characterId, slotIndex) {
  const box = save.buddyBoxV265;
  if (!box || typeof box !== "object" || !Array.isArray(box.entries)) return null;
  const maps = box.equippedInstanceByCharacter;
  if (!maps || typeof maps !== "object") return null;
  const mapped = Array.isArray(maps[characterId]) ? maps[characterId] : [];
  const instanceId = typeof mapped[slotIndex] === "string" ? mapped[slotIndex] : null;
  if (!instanceId) return null;
  return box.entries.find(entry => entry && entry.id === instanceId) || null;
}

function syncProfileBuddyInstanceAssignment(characterId, slotIndex, buddyKey) {
  const box = save.buddyBoxV265;
  if (!box || typeof box !== "object" || !Array.isArray(box.entries)) return;

  if (!box.equippedInstanceByCharacter || typeof box.equippedInstanceByCharacter !== "object") {
    box.equippedInstanceByCharacter = {};
  }

  const current = Array.isArray(box.equippedInstanceByCharacter[characterId])
    ? box.equippedInstanceByCharacter[characterId]
    : [];
  const mapped = Array.from({ length: BUDDY_SLOT_COUNT }, (_, index) =>
    typeof current[index] === "string" ? current[index] : null
  );

  const safeIndex = Math.max(0, Math.min(BUDDY_SLOT_COUNT - 1, Number(slotIndex) || 0));

  if (!buddyKey) {
    mapped[safeIndex] = null;
    box.equippedInstanceByCharacter[characterId] = mapped;
    return;
  }

  const currentEntry = box.entries.find(
    entry => entry && entry.id === mapped[safeIndex] && entry.key === buddyKey
  );
  if (currentEntry) {
    box.equippedInstanceByCharacter[characterId] = mapped;
    return;
  }

  const used = new Set();
  for (const [otherCharacterId, otherSlotsRaw] of Object.entries(box.equippedInstanceByCharacter)) {
    const otherSlots = Array.isArray(otherSlotsRaw) ? otherSlotsRaw : [];
    otherSlots.forEach((instanceId, index) => {
      if (otherCharacterId === characterId && index === safeIndex) return;
      if (typeof instanceId === "string") used.add(instanceId);
    });
  }

  const candidate = box.entries.find(
    entry => entry && entry.key === buddyKey && !used.has(entry.id)
  );

  mapped[safeIndex] = candidate?.id || null;
  box.equippedInstanceByCharacter[characterId] = mapped;
}

function getBuddySlots(characterId = save.selectedCharacter) {
  if (!save.buddies || typeof save.buddies !== "object") save.buddies = normalizeBuddySave(null);
  if (!save.buddies.equippedByCharacter || typeof save.buddies.equippedByCharacter !== "object") {
    save.buddies.equippedByCharacter = {};
  }

  const source = Array.isArray(save.buddies.equippedByCharacter[characterId])
    ? save.buddies.equippedByCharacter[characterId]
    : [];

  let repairedMimicAssignment = false;
  const slots = Array.from({ length: BUDDY_SLOT_COUNT }, (_, index) => {
    let key = typeof source[index] === "string" ? source[index] : null;

    // v24.282:
    // Buddy Box owns the individual Buddy copy. If an older aggregate Mimic
    // key disagrees with the actual mapped Mimic instance, trust the instance.
    // This repairs Peep's stale mimic:lucky Main Buddy -> mimic:base without
    // changing unrelated Buddy families.
    const mappedEntry = buddyBoxMappedEntry(characterId, index);
    const keyIsMimic = typeof key === "string" && key.startsWith("mimic:");
    const mappedIsMimic =
      mappedEntry?.enemyId === "mimic" ||
      (typeof mappedEntry?.key === "string" && mappedEntry.key.startsWith("mimic:"));

    if (
      keyIsMimic &&
      mappedIsMimic &&
      mappedEntry.key !== key &&
      buddyByKey(mappedEntry.key)
    ) {
      key = mappedEntry.key;
      repairedMimicAssignment = true;
    }

    return key && buddyByKey(key) ? key : null;
  });

  save.buddies.equippedByCharacter[characterId] = slots;

  if (repairedMimicAssignment) {
    persist();
  }

  return slots;
}'''

replace_once(
    SCRIPT,
    old_get_slots,
    new_get_slots,
    "profile Buddy Box reconciliation"
)

old_assign = '''function assignBuddyToProfile(characterId, slotIndex, buddyKey) {
  if (!CHARACTERS[characterId]) return;
  const slots = getBuddySlots(characterId);
  const index = Math.max(0, Math.min(BUDDY_SLOT_COUNT - 1, Number(slotIndex) || 0));

  const previousKey = slots[index];
  if (buddyKey) {
    const buddy = buddyByKey(buddyKey);
    if (!buddy) return;
    const equippedElsewhere = buddyEquippedCount(buddyKey, characterId, index);
    if (equippedElsewhere >= Math.max(1, Number(buddy.quantity) || 1)) {
      showToast(`All ${buddy.name} copies are already assigned.`);
      return;
    }
    slots[index] = buddyKey;
  } else {
    slots[index] = null;
  }

  save.buddies.equippedByCharacter[characterId] = slots;
  if (previousKey !== slots[index]) clearBuddySlotPersonalization(characterId, index);
  persist();
  renderProfileBuddies(characterId);
  closeProfileBuddyPicker();
}'''

new_assign = '''function assignBuddyToProfile(characterId, slotIndex, buddyKey) {
  if (!CHARACTERS[characterId]) return;
  const slots = getBuddySlots(characterId);
  const index = Math.max(0, Math.min(BUDDY_SLOT_COUNT - 1, Number(slotIndex) || 0));

  const previousKey = slots[index];
  if (buddyKey) {
    const buddy = buddyByKey(buddyKey);
    if (!buddy) return;
    const equippedElsewhere = buddyEquippedCount(buddyKey, characterId, index);
    if (equippedElsewhere >= Math.max(1, Number(buddy.quantity) || 1)) {
      showToast(`All ${buddy.name} copies are already assigned.`);
      return;
    }
    slots[index] = buddyKey;
  } else {
    slots[index] = null;
  }

  save.buddies.equippedByCharacter[characterId] = slots;

  // Keep the newer individual Buddy Box assignment synchronized when a
  // profile Buddy circle is changed. Duck Quest already syncs the reverse
  // direction, so after v24.282 both screens use the same Buddy copy.
  syncProfileBuddyInstanceAssignment(characterId, index, slots[index]);

  if (previousKey !== slots[index]) clearBuddySlotPersonalization(characterId, index);
  persist();
  renderProfileBuddies(characterId);
  closeProfileBuddyPicker();
}'''

replace_once(
    SCRIPT,
    old_assign,
    new_assign,
    "profile-to-Buddy-Box assignment synchronization"
)

# Cache-bust root script and update app build.
INDEX = "index.html"
regex_once(
    INDEX,
    r'(<meta name="duck-habit-build" content=")[^"]+(" />)',
    rf'\g<1>{VERSION}\2',
    "root build meta"
)
regex_once(
    INDEX,
    r'(script-v24-201\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "root script cache bust"
)
regex_once(
    INDEX,
    r'(const DUCK_HUB_BUILD = ")[^"]+(";\s*)',
    rf'\g<1>{VERSION}\2',
    "DUCK_HUB_BUILD"
)
regex_once(
    INDEX,
    r'(\./sw\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "service worker registration cache bust"
)

version_path.write_text(
    json.dumps({"version": VERSION}, indent=2) + "\n",
    encoding="utf-8"
)

old_sw = ROOT / "sw-v24-281.js"
if not old_sw.exists():
    raise RuntimeError("Missing sw-v24-281.js required for v24.282.")

worker = old_sw.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-281", "duck-habit-hub-app-v24-282")
worker = worker.replace("./sw.js?v=24-281", "./sw.js?v=24-282")
worker = re.sub(
    r"'./script-v24-201\.js\?v=[^']+'",
    "'./script-v24-201.js?v=24-282'",
    worker,
    count=1
)

save("sw-v24-282.js", worker)
save("sw.js", "importScripts('./sw-v24-282.js?v=24-282');\n")

save(
    "UPDATE-v24.282.txt",
    '''Duckie Days v24.282 - Peep Mimic Profile Assignment Sync

Fixes the final Peep Mimic mismatch between Duck Quest and the main OC profile.

What was wrong:
- Buddy Box tracked the correct individual pink Mimic instance.
- The main profile still read the older aggregate key mimic:lucky.
- The portrait resolver was therefore correctly showing gold for the stale key.

What this update changes:
- If a Mimic profile key disagrees with the Mimic instance assigned in Buddy Box,
  the profile trusts the individual Buddy Box instance and repairs the stale key.
- Peep's current Main Buddy should automatically repair from mimic:lucky to
  mimic:base when the profile is opened/rendered.
- Profile-side Buddy assignments now also update the Buddy Box instance mapping,
  preventing the two systems from drifting apart again.
- No Mimic artwork is changed in this update.
'''
)

print("Applied Duckie Days v24.282 profile/Buddy Box synchronization fix.")

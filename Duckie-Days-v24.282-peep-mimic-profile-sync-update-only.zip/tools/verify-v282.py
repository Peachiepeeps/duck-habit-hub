from pathlib import Path
import json

ROOT = Path.cwd()

def read(path):
    p = ROOT / path
    assert p.exists(), f"Missing required file: {path}"
    return p.read_text(encoding="utf-8")

def require(path, needle):
    assert needle in read(path), f"{path} is missing expected text: {needle}"

assert json.loads(read("version.json")).get("version") == "24.282"

require("script-v24-201.js", "function buddyBoxMappedEntry(characterId, slotIndex)")
require("script-v24-201.js", "function syncProfileBuddyInstanceAssignment(characterId, slotIndex, buddyKey)")
require("script-v24-201.js", "const mappedEntry = buddyBoxMappedEntry(characterId, index);")
require("script-v24-201.js", "mappedEntry.key !== key")
require("script-v24-201.js", "key = mappedEntry.key;")
require("script-v24-201.js", "syncProfileBuddyInstanceAssignment(characterId, index, slots[index]);")
require("script-v24-201.js", "if (repairedMimicAssignment) {")
require("script-v24-201.js", "persist();")

root = read("index.html")
assert 'duck-habit-build" content="24.282"' in root
assert "script-v24-201.js?v=24-282" in root
assert 'const DUCK_HUB_BUILD = "24.282";' in root
assert "./sw.js?v=24-282" in root

require("sw.js", "sw-v24-282.js?v=24-282")
sw = read("sw-v24-282.js")
assert "duck-habit-hub-app-v24-282" in sw
assert "./script-v24-201.js?v=24-282" in sw

# Make sure the v24.281 canonical portrait resolver remains intact.
require("script-v24-201.js", 'base: "duck-quest/assets/enemies/mimic/base/open-1.webp"')
require("script-v24-201.js", 'lucky: "duck-quest/assets/enemies/mimic/lucky/open.webp"')
require("script-v24-201.js", 'healthy: "duck-quest/assets/enemies/mimic/healthy/open.webp"')
require("script-v24-201.js", 'amethyst: "duck-quest/assets/shinies/amethyst-mimic-idle-1.webp"')

require("UPDATE-v24.282.txt", "Peep Mimic Profile Assignment Sync")

print("VERIFIED: Duckie Days v24.282 profile/Buddy Box sync is installed.")

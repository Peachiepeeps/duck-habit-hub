Duckie Days v24.283 - Peep Pink Mimic Hard Repair

Upload BOTH:

1) Duckie-Days-v24.283-peep-pink-mimic-hard-repair-update-only.zip
   -> repository root

2) install-duckie-days-v24-283-peep-pink-mimic-hard-repair.yml
   -> .github/workflows/

What this does:
- Explicitly repairs Peep's Main Buddy from the stale Lucky Mimic key to an
  available regular pink Mimic instance.
- Repairs both the legacy form-key assignment and the individual Buddy Box ID.
- Runs only once, so it will not override later intentional Buddy changes.
- Makes the individual Buddy instance authoritative in Buddy Box reconciliation.
- Includes a main-profile fallback repair so Duck Quest does not have to be
  opened first.

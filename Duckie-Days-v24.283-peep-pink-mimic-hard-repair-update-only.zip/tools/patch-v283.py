from pathlib import Path
import json
import re

ROOT = Path.cwd()
VERSION = "24.283"
QUERY = "24-283"

def load(path):
    p = ROOT / path
    if not p.exists():
        raise RuntimeError(f"Missing required file: {path}")
    return p.read_text(encoding="utf-8")

def save(path, text):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")

def replace_once(path, old, new, label):
    text = load(path)
    if new in text:
        return
    if old not in text:
        raise RuntimeError(f"{label}: expected block not found in {path}")
    save(path, text.replace(old, new, 1))

def regex_once(path, pattern, replacement, label):
    text = load(path)
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.M)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one match in {path}, found {count}")
    save(path, updated)

version_path = ROOT / "version.json"
version_data = json.loads(version_path.read_text(encoding="utf-8"))
current = str(version_data.get("version", ""))
if current not in {"24.282", VERSION}:
    raise RuntimeError(
        f"This installer expects Duckie Days v24.282. Repository reports {current!r}."
    )

# ---------------------------------------------------------------------------
# Duck Quest Buddy Box:
# 1) One-time repair Peep Main Buddy back to the regular pink Mimic.
# 2) Thereafter, a valid individual Buddy instance wins over a stale form key.
# ---------------------------------------------------------------------------
QUEST_BOX = "duck-quest/js/quest-v265.js"

old_sync = '''  function syncBoxAssignments(box=hubSave.buddyBoxV265){
    if(!box)return false;
    let changed=false;
    const used=new Set();
    CHARACTER_IDS.forEach(characterId=>{
      const slots=hubSave.buddies?.equippedByCharacter?.[characterId]||Array(6).fill(null);
      const personals=hubSave.buddies?.personalizationByCharacter?.[characterId]||Array(6).fill(null);
      const mapped=box.equippedInstanceByCharacter[characterId]||Array(6).fill(null);
      for(let i=0;i<6;i++){
        const key=typeof slots[i]==='string'?slots[i]:null;
        if(!key){if(mapped[i]){mapped[i]=null;changed=true;}continue;}
        let instance=box.entries.find(entry=>entry.id===mapped[i]&&entry.key===key&&!used.has(entry.id));
        if(!instance)instance=box.entries.find(entry=>entry.key===key&&!used.has(entry.id));
        if(!instance){
          const record=hubSave.buddies.collection?.[key];
          if(record){instance=instanceFromRecord(record);box.entries.push(instance);changed=true;}
        }
        if(instance){
          if(mapped[i]!==instance.id){mapped[i]=instance.id;changed=true;}
          used.add(instance.id);
          const personal=personals[i];
          if(personal){
            const nickname=String(personal.nickname||'').slice(0,20);
            const gender=['female','male','nonbinary'].includes(personal.gender)?personal.gender:'';
            if(instance.nickname!==nickname){instance.nickname=nickname;changed=true;}
            if(instance.gender!==gender){instance.gender=gender;changed=true;}
          }
        }
      }
      box.equippedInstanceByCharacter[characterId]=mapped;
    });
    return changed;
  }'''

new_sync = '''  function syncBoxAssignments(box=hubSave.buddyBoxV265){
    if(!box)return false;
    let changed=false;

    // v24.283 one-time repair for the save that originally converted Peep's
    // pink Mimic into a Lucky Mimic. Prefer an unassigned regular/base Mimic
    // instance and repair BOTH assignment systems before normal reconciliation.
    if(!box.peepPinkMimicRepairV24283){
      const peepSlots=hubSave.buddies?.equippedByCharacter?.peep;
      const peepMapped=box.equippedInstanceByCharacter?.peep;
      if(Array.isArray(peepSlots) && peepSlots[0]==='mimic:lucky' && Array.isArray(peepMapped)){
        const usedElsewhere=new Set();
        for(const characterId of CHARACTER_IDS){
          const ids=box.equippedInstanceByCharacter?.[characterId];
          if(!Array.isArray(ids))continue;
          ids.forEach((id,index)=>{
            if(characterId==='peep' && index===0)return;
            if(typeof id==='string')usedElsewhere.add(id);
          });
        }
        const pink=box.entries.find(entry=>entry?.key==='mimic:base' && !usedElsewhere.has(entry.id));
        if(pink && hubSave.buddies?.collection?.['mimic:base']){
          peepSlots[0]='mimic:base';
          peepMapped[0]=pink.id;
          box.peepPinkMimicRepairV24283=true;
          changed=true;
        }
      }
    }

    const used=new Set();
    CHARACTER_IDS.forEach(characterId=>{
      const slots=hubSave.buddies?.equippedByCharacter?.[characterId]||Array(6).fill(null);
      const personals=hubSave.buddies?.personalizationByCharacter?.[characterId]||Array(6).fill(null);
      const mapped=box.equippedInstanceByCharacter[characterId]||Array(6).fill(null);

      for(let i=0;i<6;i++){
        let key=typeof slots[i]==='string'?slots[i]:null;

        // The individual Buddy instance is the newer, more precise assignment.
        // If it is valid and unused, trust its key instead of replacing it
        // because an older aggregate form key disagrees.
        let instance=box.entries.find(entry=>entry?.id===mapped[i]&&!used.has(entry.id));
        if(instance){
          if(key!==instance.key){
            slots[i]=instance.key;
            key=instance.key;
            changed=true;
          }
        }

        if(!key){
          if(mapped[i]){mapped[i]=null;changed=true;}
          continue;
        }

        if(!instance || instance.key!==key){
          instance=box.entries.find(entry=>entry.key===key&&!used.has(entry.id));
        }

        if(!instance){
          const record=hubSave.buddies.collection?.[key];
          if(record){
            instance=instanceFromRecord(record);
            box.entries.push(instance);
            changed=true;
          }
        }

        if(instance){
          if(mapped[i]!==instance.id){mapped[i]=instance.id;changed=true;}
          used.add(instance.id);
          const personal=personals[i];
          if(personal){
            const nickname=String(personal.nickname||'').slice(0,20);
            const gender=['female','male','nonbinary'].includes(personal.gender)?personal.gender:'';
            if(instance.nickname!==nickname){instance.nickname=nickname;changed=true;}
            if(instance.gender!==gender){instance.gender=gender;changed=true;}
          }
        }
      }

      box.equippedInstanceByCharacter[characterId]=mapped;
      if(hubSave.buddies?.equippedByCharacter){
        hubSave.buddies.equippedByCharacter[characterId]=slots;
      }
    });

    return changed;
  }'''

replace_once(
    QUEST_BOX,
    old_sync,
    new_sync,
    "Buddy Box source-of-truth reconciliation"
)

# ---------------------------------------------------------------------------
# Main hub/profile fallback:
# Repair Peep even if the user opens the profile before entering Duck Quest.
# ---------------------------------------------------------------------------
PROFILE = "script-v24-201.js"

anchor = '''function getBuddySlots(characterId = save.selectedCharacter) {
  if (!save.buddies || typeof save.buddies !== "object") save.buddies = normalizeBuddySave(null);'''

replacement = '''function repairPeepPinkMimicMainV24283() {
  const box = save.buddyBoxV265;
  const buddies = save.buddies;
  if (!box || typeof box !== "object" || !Array.isArray(box.entries)) return false;
  if (box.peepPinkMimicRepairV24283) return false;
  if (!buddies || typeof buddies !== "object") return false;

  const peepSlots = Array.isArray(buddies.equippedByCharacter?.peep)
    ? buddies.equippedByCharacter.peep
    : null;
  if (!peepSlots || peepSlots[0] !== "mimic:lucky") return false;
  if (!buddies.collection?.["mimic:base"]) return false;

  if (!box.equippedInstanceByCharacter || typeof box.equippedInstanceByCharacter !== "object") {
    box.equippedInstanceByCharacter = {};
  }
  const currentPeepMap = Array.isArray(box.equippedInstanceByCharacter.peep)
    ? box.equippedInstanceByCharacter.peep
    : [];
  const peepMap = Array.from({ length: BUDDY_SLOT_COUNT }, (_, index) =>
    typeof currentPeepMap[index] === "string" ? currentPeepMap[index] : null
  );

  const usedElsewhere = new Set();
  for (const [otherCharacterId, rawSlots] of Object.entries(box.equippedInstanceByCharacter)) {
    const slots = Array.isArray(rawSlots) ? rawSlots : [];
    slots.forEach((instanceId, index) => {
      if (otherCharacterId === "peep" && index === 0) return;
      if (typeof instanceId === "string") usedElsewhere.add(instanceId);
    });
  }

  const pink = box.entries.find(
    entry => entry && entry.key === "mimic:base" && !usedElsewhere.has(entry.id)
  );
  if (!pink) return false;

  peepSlots[0] = "mimic:base";
  peepMap[0] = pink.id;
  box.equippedInstanceByCharacter.peep = peepMap;
  box.peepPinkMimicRepairV24283 = true;
  persist();
  return true;
}

function getBuddySlots(characterId = save.selectedCharacter) {
  if (characterId === "peep") repairPeepPinkMimicMainV24283();
  if (!save.buddies || typeof save.buddies !== "object") save.buddies = normalizeBuddySave(null);'''

replace_once(
    PROFILE,
    anchor,
    replacement,
    "main profile one-time Peep pink Mimic repair"
)

# ---------------------------------------------------------------------------
# Version/cache busting.
# ---------------------------------------------------------------------------
regex_once(
    "duck-quest/index.html",
    r'(quest-v265\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "Duck Quest Buddy Box cache bust"
)

INDEX = "index.html"
regex_once(
    INDEX,
    r'(<meta name="duck-habit-build" content=")[^"]+(" />)',
    rf'\g<1>{VERSION}\2',
    "root build meta"
)
regex_once(
    INDEX,
    r'(script-v24-201\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "profile script cache bust"
)
regex_once(
    INDEX,
    r'(const DUCK_HUB_BUILD = ")[^"]+(";\s*)',
    rf'\g<1>{VERSION}\2',
    "DUCK_HUB_BUILD"
)
regex_once(
    INDEX,
    r'(\./sw\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "service worker registration"
)

version_path.write_text(
    json.dumps({"version": VERSION}, indent=2) + "\n",
    encoding="utf-8"
)

old_worker = ROOT / "sw-v24-282.js"
if not old_worker.exists():
    raise RuntimeError("Missing sw-v24-282.js.")

worker = old_worker.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-282", "duck-habit-hub-app-v24-283")
worker = worker.replace("./sw.js?v=24-282", "./sw.js?v=24-283")
worker = re.sub(
    r"'./script-v24-201\.js\?v=[^']+'",
    "'./script-v24-201.js?v=24-283'",
    worker,
    count=1
)
worker = re.sub(
    r"'./duck-quest/js/quest-v265\.js\?v=[^']+'",
    "'./duck-quest/js/quest-v265.js?v=24-283'",
    worker,
    count=1
)

save("sw-v24-283.js", worker)
save("sw.js", "importScripts('./sw-v24-283.js?v=24-283');\n")

save(
    "UPDATE-v24.283.txt",
    '''Duckie Days v24.283 - Peep Pink Mimic Hard Repair

This fixes the remaining gold Mimic on Peep's main profile.

Root cause:
Duck Quest's Buddy Box reconciliation trusted the older aggregate form key
(mimic:lucky) before the newer individual Buddy instance assignment. That
could replace the pink instance with a Lucky instance before the profile-side
repair from v24.282 ran.

v24.283:
- Runs a one-time migration for Peep Main Buddy:
  mimic:lucky -> an available mimic:base individual instance.
- Updates BOTH assignment records together.
- Stores a migration flag so future intentional Buddy changes are untouched.
- Makes a valid individual Buddy Box instance authoritative during normal
  reconciliation, preventing stale aggregate keys from overwriting it.
- Adds the same one-time repair to the main profile as a fallback, so entering
  Duck Quest first is not required.
- Keeps all v24.281 Mimic portrait artwork unchanged.
'''
)

print("Applied Duckie Days v24.283 Peep pink Mimic hard repair.")

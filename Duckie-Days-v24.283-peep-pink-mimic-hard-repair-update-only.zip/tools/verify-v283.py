from pathlib import Path
import json

ROOT = Path.cwd()

def read(path):
    p = ROOT / path
    assert p.exists(), f"Missing: {path}"
    return p.read_text(encoding="utf-8")

def has(path, needle):
    assert needle in read(path), f"{path} missing: {needle}"

assert json.loads(read("version.json")).get("version") == "24.283"

has("duck-quest/js/quest-v265.js", "if(!box.peepPinkMimicRepairV24283)")
has("duck-quest/js/quest-v265.js", "peepSlots[0]='mimic:base';")
has("duck-quest/js/quest-v265.js", "peepMapped[0]=pink.id;")
has("duck-quest/js/quest-v265.js", "box.peepPinkMimicRepairV24283=true;")
has("duck-quest/js/quest-v265.js", "if(key!==instance.key)")
has("duck-quest/js/quest-v265.js", "slots[i]=instance.key;")

has("script-v24-201.js", "function repairPeepPinkMimicMainV24283()")
has("script-v24-201.js", 'if (!peepSlots || peepSlots[0] !== "mimic:lucky") return false;')
has("script-v24-201.js", 'peepSlots[0] = "mimic:base";')
has("script-v24-201.js", "peepMap[0] = pink.id;")
has("script-v24-201.js", "box.peepPinkMimicRepairV24283 = true;")
has("script-v24-201.js", 'if (characterId === "peep") repairPeepPinkMimicMainV24283();')

# Preserve canonical pink portrait from v24.281.
has("script-v24-201.js", 'base: "duck-quest/assets/enemies/mimic/base/open-1.webp"')
has("duck-quest/js/quest-v265.js", "'mimic:base':'assets/enemies/mimic/base/open-1.webp'")

dq = read("duck-quest/index.html")
assert "quest-v265.js?v=24-283" in dq

root = read("index.html")
assert 'duck-habit-build" content="24.283"' in root
assert "script-v24-201.js?v=24-283" in root
assert 'const DUCK_HUB_BUILD = "24.283";' in root
assert "./sw.js?v=24-283" in root

has("sw.js", "sw-v24-283.js?v=24-283")
sw = read("sw-v24-283.js")
assert "duck-habit-hub-app-v24-283" in sw
assert "./script-v24-201.js?v=24-283" in sw
assert "./duck-quest/js/quest-v265.js?v=24-283" in sw

has("UPDATE-v24.283.txt", "Peep Pink Mimic Hard Repair")
print("VERIFIED: v24.283 Peep pink Mimic hard repair.")

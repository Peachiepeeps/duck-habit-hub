Duckie Days v24.284 - Mimic Key Authority Fix

Upload BOTH:

1) Duckie-Days-v24.284-mimic-key-authority-fix-update-only.zip
   -> repository root

2) install-duckie-days-v24-284-mimic-key-authority-fix.yml
   -> .github/workflows/

This fixes the remaining Peep gold Mimic by treating the Mimic FORM KEY as
absolute truth, rather than allowing stale variant/name/image metadata to
override it.

mimic:base is always pink.
mimic:lucky is always gold.
mimic:healthy is always green.
mimic:shiny is always amethyst.

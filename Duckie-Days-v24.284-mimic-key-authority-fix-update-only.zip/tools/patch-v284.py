from pathlib import Path
import json
import re

ROOT = Path.cwd()
VERSION = "24.284"
QUERY = "24-284"

def load(path):
    p = ROOT / path
    if not p.exists():
        raise RuntimeError(f"Missing required file: {path}")
    return p.read_text(encoding="utf-8")

def save(path, text):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")

def replace_once(path, old, new, label):
    text = load(path)
    if new in text:
        return
    if old not in text:
        raise RuntimeError(f"{label}: expected block not found in {path}")
    save(path, text.replace(old, new, 1))

def regex_once(path, pattern, replacement, label):
    text = load(path)
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.M)
    if count != 1:
        raise RuntimeError(f"{label}: expected 1 match in {path}, found {count}")
    save(path, updated)

version_path = ROOT / "version.json"
current = str(json.loads(version_path.read_text(encoding="utf-8")).get("version", ""))
if current not in {"24.283", VERSION}:
    raise RuntimeError(f"Expected Duckie Days v24.283; found {current!r}.")

# ---------------------------------------------------------------------------
# 1) Duck Quest aggregate collection:
#    For Mimics, the key is authoritative. Canonical catalog metadata replaces
#    stale saved name/variant/image data while preserving quantity/date.
# ---------------------------------------------------------------------------
GAME = "duck-quest/js/game-v96.js"

old_normalize = '''function normalizeBuddyCollection(raw) {
  const collection={};
  if(raw && typeof raw==="object" && !Array.isArray(raw)) {
    for(const [fallbackKey,value] of Object.entries(raw)) {
      if(!value || typeof value!=="object" || Array.isArray(value)) continue;
      const key=String(value.key || fallbackKey || "").trim();
      if(!key) continue;
      collection[key]={
        key,
        enemyId:String(value.enemyId || ""),
        variantId:String(value.variantId || "base"),
        name:String(value.name || "Buddy"),
        image:String(value.image || ""),
        idle:Array.isArray(value.idle) ? value.idle.map(String).filter(Boolean) : [],
        shiny:Boolean(value.shiny),
        boss:Boolean(value.boss),
        quantity:Math.max(1,Math.floor(Number(value.quantity)||1)),
        capturedAt:Math.max(0,Number(value.capturedAt)||0)
      };
    }
  }
  return collection;
}'''

new_normalize = '''function normalizeBuddyCollection(raw) {
  const collection={};
  if(raw && typeof raw==="object" && !Array.isArray(raw)) {
    for(const [fallbackKey,value] of Object.entries(raw)) {
      if(!value || typeof value!=="object" || Array.isArray(value)) continue;
      const key=String(value.key || fallbackKey || "").trim();
      if(!key) continue;

      let normalized={
        key,
        enemyId:String(value.enemyId || ""),
        variantId:String(value.variantId || "base"),
        name:String(value.name || "Buddy"),
        image:String(value.image || ""),
        idle:Array.isArray(value.idle) ? value.idle.map(String).filter(Boolean) : [],
        shiny:Boolean(value.shiny),
        boss:Boolean(value.boss),
        quantity:Math.max(1,Math.floor(Number(value.quantity)||1)),
        capturedAt:Math.max(0,Number(value.capturedAt)||0)
      };

      // v24.284: Mimic key is the source of truth.
      // Old saves can contain key=mimic:base with variantId/name/image left
      // behind from Lucky/Healthy. Never let stale metadata redefine the key.
      if(key.startsWith("mimic:")){
        const catalog=BUDDY_CATALOG_BY_KEY.get(key);
        if(catalog){
          normalized={
            ...normalized,
            enemyId:"mimic",
            variantId:catalog.variantId,
            name:catalog.name,
            image:catalog.image,
            idle:Array.isArray(catalog.idle)?catalog.idle.slice():[],
            shiny:Boolean(catalog.shiny),
            boss:Boolean(catalog.boss)
          };
        }
      }

      collection[key]=normalized;
    }
  }
  return collection;
}'''

replace_once(
    GAME,
    old_normalize,
    new_normalize,
    "Duck Quest Mimic collection canonicalization"
)

# ---------------------------------------------------------------------------
# 2) quest-v270 portrait repair:
#    Exact key first. Only use legacy variant/name clues when key is absent.
# ---------------------------------------------------------------------------
Q270 = "duck-quest/js/quest-v270.js"

old_mimic_art = '''  function mimicArt(entry){
    if(!entry) return null;
    const enemyId=String(entry.enemyId||'').toLowerCase();
    const key=String(entry.key||'').toLowerCase();
    const variant=String(entry.variantId||'').toLowerCase();
    const name=String(entry.name||'').toLowerCase();
    const isMimic=enemyId==='mimic' || key.startsWith('mimic:') || name.includes('mimic');
    if(!isMimic) return null;

    if(key==='mimic:lucky' || variant==='lucky' || name.includes('lucky mimic')){
      return {
        image:'assets/enemies/mimic/lucky/open.webp',
        idle:['assets/enemies/mimic/lucky/idle-1.webp','assets/enemies/mimic/lucky/idle-2.webp']
      };
    }
    if(key==='mimic:healthy' || variant==='healthy' || name.includes('healthy mimic')){
      return {
        image:'assets/enemies/mimic/healthy/open.webp',
        idle:['assets/enemies/mimic/healthy/idle-1.webp','assets/enemies/mimic/healthy/idle-2.webp']
      };
    }
    if(key==='mimic:shiny' || key==='mimic:amethyst' || variant==='amethyst' || variant==='shiny' || name.includes('amethyst mimic')){
      return {
        image:'assets/shinies/amethyst-mimic-idle-1.webp',
        idle:['assets/shinies/amethyst-mimic-idle-1.webp','assets/shinies/amethyst-mimic-idle-2.webp']
      };
    }
    return {
      image:'assets/enemies/mimic/base/open-1.webp',
      idle:['assets/enemies/mimic/base/open-1.webp','assets/enemies/mimic/base/open-2.webp']
    };
  }'''

new_mimic_art = '''  function mimicArt(entry){
    if(!entry) return null;
    const enemyId=String(entry.enemyId||'').toLowerCase();
    const key=String(entry.key||'').toLowerCase();
    const variant=String(entry.variantId||'').toLowerCase();
    const name=String(entry.name||'').toLowerCase();
    const isMimic=enemyId==='mimic' || key.startsWith('mimic:') || name.includes('mimic');
    if(!isMimic) return null;

    // v24.284: exact saved key always wins over stale legacy metadata.
    if(key==='mimic:base'){
      return {
        image:'assets/enemies/mimic/base/open-1.webp',
        idle:['assets/enemies/mimic/base/open-1.webp','assets/enemies/mimic/base/open-2.webp']
      };
    }
    if(key==='mimic:lucky'){
      return {
        image:'assets/enemies/mimic/lucky/open.webp',
        idle:['assets/enemies/mimic/lucky/idle-1.webp','assets/enemies/mimic/lucky/idle-2.webp']
      };
    }
    if(key==='mimic:healthy'){
      return {
        image:'assets/enemies/mimic/healthy/open.webp',
        idle:['assets/enemies/mimic/healthy/idle-1.webp','assets/enemies/mimic/healthy/idle-2.webp']
      };
    }
    if(key==='mimic:shiny' || key==='mimic:amethyst'){
      return {
        image:'assets/shinies/amethyst-mimic-idle-1.webp',
        idle:['assets/shinies/amethyst-mimic-idle-1.webp','assets/shinies/amethyst-mimic-idle-2.webp']
      };
    }

    // Legacy fallback for pre-key saves only.
    if(variant==='lucky' || name.includes('lucky mimic')){
      return {
        image:'assets/enemies/mimic/lucky/open.webp',
        idle:['assets/enemies/mimic/lucky/idle-1.webp','assets/enemies/mimic/lucky/idle-2.webp']
      };
    }
    if(variant==='healthy' || name.includes('healthy mimic')){
      return {
        image:'assets/enemies/mimic/healthy/open.webp',
        idle:['assets/enemies/mimic/healthy/idle-1.webp','assets/enemies/mimic/healthy/idle-2.webp']
      };
    }
    if(variant==='amethyst' || variant==='shiny' || name.includes('amethyst mimic')){
      return {
        image:'assets/shinies/amethyst-mimic-idle-1.webp',
        idle:['assets/shinies/amethyst-mimic-idle-1.webp','assets/shinies/amethyst-mimic-idle-2.webp']
      };
    }
    return {
      image:'assets/enemies/mimic/base/open-1.webp',
      idle:['assets/enemies/mimic/base/open-1.webp','assets/enemies/mimic/base/open-2.webp']
    };
  }'''

replace_once(
    Q270,
    old_mimic_art,
    new_mimic_art,
    "quest-v270 Mimic key authority"
)

# ---------------------------------------------------------------------------
# 3) Main hub saved collection normalization:
#    Canonicalize Mimic metadata by key so profile/book consumers all agree.
# ---------------------------------------------------------------------------
SCRIPT = "script-v24-201.js"

old_root_normalizer = '''function normalizeBuddyRecord(record, fallbackKey = "") {
  if (!record || typeof record !== "object" || Array.isArray(record)) return null;
  const key = String(record.key || fallbackKey || "").trim();
  if (!key) return null;

  const image = String(record.image || "").trim();
  const name = String(record.name || "Buddy").trim() || "Buddy";

  return {
    key,
    enemyId: String(record.enemyId || "").trim(),
    variantId: String(record.variantId || "base").trim() || "base",
    name,
    image,
    shiny: Boolean(record.shiny),
    boss: Boolean(record.boss),
    quantity: Math.max(1, Math.floor(Number(record.quantity) || 1)),
    capturedAt: Math.max(0, Number(record.capturedAt) || 0)
  };
}'''

new_root_normalizer = '''function normalizeBuddyRecord(record, fallbackKey = "") {
  if (!record || typeof record !== "object" || Array.isArray(record)) return null;
  const key = String(record.key || fallbackKey || "").trim();
  if (!key) return null;

  const quantity = Math.max(1, Math.floor(Number(record.quantity) || 1));
  const capturedAt = Math.max(0, Number(record.capturedAt) || 0);

  // v24.284: canonical Mimic identity comes from its key.
  // This strips stale Lucky/Healthy metadata from mimic:base on page load.
  const mimicForms = {
    "mimic:base": {
      enemyId: "mimic",
      variantId: "base",
      name: "Mimic",
      image: "assets/enemies/mimic/base/open-1.webp",
      shiny: false,
      boss: false
    },
    "mimic:lucky": {
      enemyId: "mimic",
      variantId: "lucky",
      name: "Lucky Mimic",
      image: "assets/enemies/mimic/lucky/open.webp",
      shiny: false,
      boss: false
    },
    "mimic:healthy": {
      enemyId: "mimic",
      variantId: "healthy",
      name: "Healthy Mimic",
      image: "assets/enemies/mimic/healthy/open.webp",
      shiny: false,
      boss: false
    },
    "mimic:shiny": {
      enemyId: "mimic",
      variantId: "shiny",
      name: "Amethyst Mimic",
      image: "assets/shinies/amethyst-mimic-idle-1.webp",
      shiny: true,
      boss: false
    },
    "mimic:amethyst": {
      enemyId: "mimic",
      variantId: "shiny",
      name: "Amethyst Mimic",
      image: "assets/shinies/amethyst-mimic-idle-1.webp",
      shiny: true,
      boss: false
    }
  };

  if (mimicForms[key]) {
    return {
      key,
      ...mimicForms[key],
      quantity,
      capturedAt
    };
  }

  const image = String(record.image || "").trim();
  const name = String(record.name || "Buddy").trim() || "Buddy";

  return {
    key,
    enemyId: String(record.enemyId || "").trim(),
    variantId: String(record.variantId || "base").trim() || "base",
    name,
    image,
    shiny: Boolean(record.shiny),
    boss: Boolean(record.boss),
    quantity,
    capturedAt
  };
}'''

replace_once(
    SCRIPT,
    old_root_normalizer,
    new_root_normalizer,
    "root Mimic collection canonicalization"
)

# ---------------------------------------------------------------------------
# 4) Main profile renderer:
#    Exact key first. This alone makes mimic:base pink even if legacy metadata
#    somehow survives elsewhere.
# ---------------------------------------------------------------------------
old_profile_resolver = '''function profileMimicPortraitSource(buddy) {
  if (!buddy) return "";
  const enemyId = String(buddy.enemyId || "").toLowerCase();
  const key = String(buddy.key || "").toLowerCase();
  const variant = String(buddy.variantId || "").toLowerCase();
  const name = String(buddy.name || "").toLowerCase();
  const isMimic = enemyId === "mimic" || key.startsWith("mimic:") || name.includes("mimic");
  if (!isMimic) return "";

  if (key === "mimic:lucky" || variant === "lucky" || name.includes("lucky mimic")) {
    return PROFILE_MIMIC_PORTRAITS.lucky;
  }
  if (key === "mimic:healthy" || variant === "healthy" || name.includes("healthy mimic")) {
    return PROFILE_MIMIC_PORTRAITS.healthy;
  }
  if (
    key === "mimic:shiny" ||
    key === "mimic:amethyst" ||
    variant === "amethyst" ||
    variant === "shiny" ||
    name.includes("amethyst mimic")
  ) {
    return PROFILE_MIMIC_PORTRAITS.amethyst;
  }
  return PROFILE_MIMIC_PORTRAITS.base;
}'''

new_profile_resolver = '''function profileMimicPortraitSource(buddy) {
  if (!buddy) return "";
  const enemyId = String(buddy.enemyId || "").toLowerCase();
  const key = String(buddy.key || "").toLowerCase();
  const variant = String(buddy.variantId || "").toLowerCase();
  const name = String(buddy.name || "").toLowerCase();
  const isMimic = enemyId === "mimic" || key.startsWith("mimic:") || name.includes("mimic");
  if (!isMimic) return "";

  // v24.284: exact form key is authoritative.
  if (key === "mimic:base") return PROFILE_MIMIC_PORTRAITS.base;
  if (key === "mimic:lucky") return PROFILE_MIMIC_PORTRAITS.lucky;
  if (key === "mimic:healthy") return PROFILE_MIMIC_PORTRAITS.healthy;
  if (key === "mimic:shiny" || key === "mimic:amethyst") {
    return PROFILE_MIMIC_PORTRAITS.amethyst;
  }

  // Legacy fallback only if an old record has no recognized key.
  if (variant === "lucky" || name.includes("lucky mimic")) {
    return PROFILE_MIMIC_PORTRAITS.lucky;
  }
  if (variant === "healthy" || name.includes("healthy mimic")) {
    return PROFILE_MIMIC_PORTRAITS.healthy;
  }
  if (
    variant === "amethyst" ||
    variant === "shiny" ||
    name.includes("amethyst mimic")
  ) {
    return PROFILE_MIMIC_PORTRAITS.amethyst;
  }
  return PROFILE_MIMIC_PORTRAITS.base;
}'''

replace_once(
    SCRIPT,
    old_profile_resolver,
    new_profile_resolver,
    "profile Mimic key authority"
)

# ---------------------------------------------------------------------------
# 5) Cache bust all changed consumers.
# ---------------------------------------------------------------------------
DQ_INDEX = "duck-quest/index.html"
for filename in ("game-v96.js", "quest-v270.js"):
    regex_once(
        DQ_INDEX,
        rf'({re.escape(filename)}\?v=)[^"]+',
        rf'\g<1>{QUERY}',
        f"cache bust {filename}"
    )

INDEX = "index.html"
regex_once(
    INDEX,
    r'(<meta name="duck-habit-build" content=")[^"]+(" />)',
    rf'\g<1>{VERSION}\2',
    "root build meta"
)
regex_once(
    INDEX,
    r'(script-v24-201\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "root profile script cache bust"
)
regex_once(
    INDEX,
    r'(const DUCK_HUB_BUILD = ")[^"]+(";\s*)',
    rf'\g<1>{VERSION}\2',
    "DUCK_HUB_BUILD"
)
regex_once(
    INDEX,
    r'(\./sw\.js\?v=)[^"]+',
    rf'\g<1>{QUERY}',
    "service worker registration"
)

version_path.write_text(
    json.dumps({"version": VERSION}, indent=2) + "\n",
    encoding="utf-8"
)

old_worker = ROOT / "sw-v24-283.js"
if not old_worker.exists():
    raise RuntimeError("Missing sw-v24-283.js.")

worker = old_worker.read_text(encoding="utf-8")
worker = worker.replace("duck-habit-hub-app-v24-283", "duck-habit-hub-app-v24-284")
worker = worker.replace("./sw.js?v=24-283", "./sw.js?v=24-284")
worker = re.sub(
    r"'./script-v24-201\.js\?v=[^']+'",
    "'./script-v24-201.js?v=24-284'",
    worker,
    count=1
)
worker = re.sub(
    r"'./duck-quest/js/game-v96\.js\?v=[^']+'",
    "'./duck-quest/js/game-v96.js?v=24-284'",
    worker,
    count=1
)
worker = re.sub(
    r"'./duck-quest/js/quest-v270\.js\?v=[^']+'",
    "'./duck-quest/js/quest-v270.js?v=24-284'",
    worker,
    count=1
)

save("sw-v24-284.js", worker)
save("sw.js", "importScripts('./sw-v24-284.js?v=24-284');\n")

save(
    "UPDATE-v24.284.txt",
    '''Duckie Days v24.284 - Mimic Key Authority Fix

Root cause finally isolated:
Peep's Main Buddy was correctly assigned to mimic:base, but the aggregate
mimic:base record could still contain stale variantId/name/image metadata from
the old Lucky Mimic overwrite bug.

Some portrait/repair code trusted variantId before the key, so:
  key = mimic:base
  stale variantId = lucky
could still render gold.

v24.284 makes the form KEY authoritative everywhere:
- mimic:base    -> pink
- mimic:lucky   -> gold
- mimic:healthy -> green
- mimic:shiny   -> amethyst

It also canonicalizes Mimic aggregate collection records from the catalog on
Duck Quest load and canonicalizes them in the main hub save normalization.
'''
)

print("Applied Duckie Days v24.284 Mimic key-authority fix.")

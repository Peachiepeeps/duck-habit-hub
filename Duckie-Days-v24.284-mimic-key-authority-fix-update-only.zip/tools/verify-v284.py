from pathlib import Path
import json

ROOT = Path.cwd()

def read(path):
    p = ROOT / path
    assert p.exists(), f"Missing: {path}"
    return p.read_text(encoding="utf-8")

def has(path, needle):
    assert needle in read(path), f"{path} missing expected text: {needle}"

assert json.loads(read("version.json")).get("version") == "24.284"

has("duck-quest/js/game-v96.js", 'if(key.startsWith("mimic:"))')
has("duck-quest/js/game-v96.js", "const catalog=BUDDY_CATALOG_BY_KEY.get(key);")
has("duck-quest/js/game-v96.js", "variantId:catalog.variantId")
has("duck-quest/js/game-v96.js", "image:catalog.image")

has("duck-quest/js/quest-v270.js", "if(key==='mimic:base')")
has("duck-quest/js/quest-v270.js", "if(key==='mimic:lucky')")
has("duck-quest/js/quest-v270.js", "if(key==='mimic:healthy')")

has("script-v24-201.js", '"mimic:base": {')
has("script-v24-201.js", 'variantId: "base"')
has("script-v24-201.js", 'image: "assets/enemies/mimic/base/open-1.webp"')
has("script-v24-201.js", 'if (key === "mimic:base") return PROFILE_MIMIC_PORTRAITS.base;')
has("script-v24-201.js", 'if (key === "mimic:lucky") return PROFILE_MIMIC_PORTRAITS.lucky;')

dq = read("duck-quest/index.html")
assert "game-v96.js?v=24-284" in dq
assert "quest-v270.js?v=24-284" in dq

root = read("index.html")
assert 'duck-habit-build" content="24.284"' in root
assert "script-v24-201.js?v=24-284" in root
assert 'const DUCK_HUB_BUILD = "24.284";' in root
assert "./sw.js?v=24-284" in root

has("sw.js", "sw-v24-284.js?v=24-284")
sw = read("sw-v24-284.js")
assert "duck-habit-hub-app-v24-284" in sw
assert "./script-v24-201.js?v=24-284" in sw
assert "./duck-quest/js/game-v96.js?v=24-284" in sw
assert "./duck-quest/js/quest-v270.js?v=24-284" in sw

has("UPDATE-v24.284.txt", "Mimic Key Authority Fix")
print("VERIFIED: v24.284 Mimic key-authority fix.")

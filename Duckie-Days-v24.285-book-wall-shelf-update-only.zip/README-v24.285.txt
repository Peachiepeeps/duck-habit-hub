Duckie Days v24.285 - Book Wall Shelf

This update uses the three shelf images supplied by the user.

What changes:
- Adds Brown, White, and Dark Book Shelf decor.
- Brown is the default.
- All three shelves are free and automatically available in Furniture inventory.
- Choosing another shelf from Inventory swaps the color.
- The shelf cannot be sold or removed because it permanently supports the Book.
- The Duckipedia Book now sits on the shelf above the OC.
- The Book no longer occupies the dresser or Six-Shelf.
- Existing dresser/Six-Shelf duck perches are no longer reserved for the Book.

Upload:
1) Duckie-Days-v24.285-book-wall-shelf-update-only.zip
   -> repository root

2) install-duckie-days-v24-285-book-wall-shelf.yml
   -> .github/workflows/

from pathlib import Path
import json

ROOT = Path.cwd()

def read(path):
    p = ROOT / path
    assert p.exists(), f"Missing required file: {path}"
    return p.read_text(encoding="utf-8")

def has(path, needle):
    assert needle in read(path), f"{path} missing expected text: {needle}"

assert json.loads(read("version.json")).get("version") == "24.285"

for path in (
    "assets/furniture/book-shelves/book-shelf-brown.png",
    "assets/furniture/book-shelves/book-shelf-white.png",
    "assets/furniture/book-shelves/book-shelf-dark.png",
):
    assert (ROOT / path).exists(), f"Missing shelf asset: {path}"

has("index.html", 'id="bookShelfFurnitureDisplay"')
has("index.html", 'hub-v285.css?v=24-285')
has("index.html", 'script-v24-201.js?v=24-285')
has("index.html", 'duck-habit-build" content="24.285"')
has("index.html", 'const DUCK_HUB_BUILD = "24.285";')
has("index.html", './sw.js?v=24-285')

has("script-v24-201.js", '"book-shelf-brown": {')
has("script-v24-201.js", '"book-shelf-white": {')
has("script-v24-201.js", '"book-shelf-dark": {')
has("script-v24-201.js", 'bookShelf: "book-shelf-brown"')
has("script-v24-201.js", "function ensureFreeBookShelves()")
has("script-v24-201.js", 'roomBookImage.classList.add("book-wall-shelf-v285");')
has("script-v24-201.js", 'renderFurnitureOverlay(bookShelfFurnitureDisplay, roomFurniture.bookShelf);')
has("script-v24-201.js", 'placeButton.textContent = isBookShelf')
has("script-v24-201.js", 'placeButton.disabled = Boolean(isBookShelf && isPlaced);')
has("script-v24-201.js", "ensureFreeBookShelves();")

has("hub-v285.css", "#roomBookImage.duckipedia-room-book-v232.book-wall-shelf-v285")
has("hub-v285.css", ".book-shelf-furniture")
has("hub-v285.css", "top:14vw!important;")

has("sw.js", "sw-v24-285.js?v=24-285")
sw = read("sw-v24-285.js")
assert "duck-habit-hub-app-v24-285" in sw
assert "./hub-v285.css?v=24-285" in sw
assert "./script-v24-201.js?v=24-285" in sw
assert "./assets/furniture/book-shelves/book-shelf-brown.png" in sw
assert "./assets/furniture/book-shelves/book-shelf-white.png" in sw
assert "./assets/furniture/book-shelves/book-shelf-dark.png" in sw

has("UPDATE-v24.285.txt", "Book Wall Shelf")

print("VERIFIED: Duckie Days v24.285 Book wall shelf update.")

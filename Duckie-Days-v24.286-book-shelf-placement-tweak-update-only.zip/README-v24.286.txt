Duckie Days v24.286 - Book Shelf Placement Tweak

This is a small tweak update for the new wall shelf.

What changes:
- lowers the wall shelf a good amount
- lowers the Book too
- makes the Book bigger

Upload:
1) Duckie-Days-v24.286-book-shelf-placement-tweak-update-only.zip
   -> repository root

2) install-duckie-days-v24-286-book-shelf-placement-tweak.yml
   -> .github/workflows/

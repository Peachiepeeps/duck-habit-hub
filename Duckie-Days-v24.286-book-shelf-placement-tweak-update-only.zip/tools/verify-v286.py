from pathlib import Path
import json

ROOT = Path.cwd()

def read(path):
    p = ROOT / path
    assert p.exists(), f"Missing required file: {path}"
    return p.read_text(encoding="utf-8")

def has(path, needle):
    assert needle in read(path), f"{path} missing expected text: {needle}"

assert json.loads(read("version.json")).get("version") == "24.286"

for path in (
    "assets/furniture/book-shelves/book-shelf-brown.png",
    "assets/furniture/book-shelves/book-shelf-white.png",
    "assets/furniture/book-shelves/book-shelf-dark.png",
):
    assert (ROOT / path).exists(), f"Missing shelf asset: {path}"

has("index.html", 'hub-v286.css?v=24-286')
has("index.html", 'script-v24-201.js?v=24-286')
has("index.html", 'duck-habit-build" content="24.286"')
has("index.html", 'const DUCK_HUB_BUILD = "24.286";')
has("index.html", './sw.js?v=24-286')

# Shelf logic remains present.
has("script-v24-201.js", '"book-shelf-brown": {')
has("script-v24-201.js", 'bookShelf: "book-shelf-brown"')
has("script-v24-201.js", 'roomBookImage.classList.add("book-wall-shelf-v285");')
has("script-v24-201.js", 'renderFurnitureOverlay(bookShelfFurnitureDisplay, roomFurniture.bookShelf);')
has("script-v24-201.js", "ensureFreeBookShelves();")

# Placement tweaks
has("hub-v286.css", ".book-shelf-furniture")
has("hub-v286.css", "top:3.4%!important;")
has("hub-v286.css", "top:11.4%!important;")
has("hub-v286.css", "width:16.2%!important;")
has("hub-v286.css", "top:25.4vw!important;")
has("hub-v286.css", "width:16.2vw!important;")

has("sw.js", "sw-v24-286.js?v=24-286")
sw = read("sw-v24-286.js")
assert "duck-habit-hub-app-v24-286" in sw
assert "./hub-v286.css?v=24-286" in sw
assert "./script-v24-201.js?v=24-286" in sw
assert "./assets/furniture/book-shelves/book-shelf-brown.png" in sw

has("UPDATE-v24.286.txt", "Book Shelf Placement Tweak")
print("VERIFIED: Duckie Days v24.286 Book shelf placement tweak.")

Duckie Days v24.288 — Gimmick Encounters

Adds the six approved rare encounter families:
Rotten Egg, Lucky Cat, Ghost Girl, Pippa, Artist Friend, and Angy Duck.

This bundle is built specifically on the current consolidated v24.287 repository.

Important:
- hub.css is deliberately NOT included.
- Your current Book / wall-shelf positioning edits are preserved.
- The installer checks the current index + Duck Quest core before applying,
  so it will stop instead of overwriting unexpected newer edits.

Upload:
1) Duckie-Days-v24.288-gimmick-encounters-update-only.zip
   -> repository root

2) install-duckie-days-v24-288-gimmick-encounters.yml
   -> .github/workflows/

The workflow is upload-order-safe. If the YAML arrives first, it waits for
the update ZIP instead of failing.

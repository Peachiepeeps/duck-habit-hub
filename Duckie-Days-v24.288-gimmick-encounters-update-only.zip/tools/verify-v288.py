from pathlib import Path
import json, re

ROOT = Path.cwd()

def read(path):
    p = ROOT / path
    assert p.exists(), f"Missing required file: {path}"
    return p.read_text(encoding="utf-8")

def has(path, needle):
    text = read(path)
    assert needle in text, f"{path} missing expected text: {needle}"

assert json.loads(read("version.json")).get("version") == "24.288"

# Preserve consolidated root loader and add only the new modules.
has("index.html", 'duck-habit-build" content="24.288"')
has("index.html", 'app.css?v=24.288')
has("index.html", 'hub.css?v=24.288')
has("index.html", 'trading-cards-base.js?v=24.288')
has("index.html", 'trading-cards-extra.js?v=24.288')
has("index.html", 'trading-cards-gimmicks-v288.js?v=24.288')
has("index.html", 'app.js?v=24.288')
has("index.html", 'gimmick-hub-v288.js?v=24.288')
has("index.html", 'const DUCK_HUB_BUILD = "24.288";')
has("index.html", './sw.js?v=24-288')
assert "script-v24-201.js" not in read("index.html")

# Duck Quest loader and modified core.
has("duck-quest/index.html", '../trading-cards-base.js?v=24.288')
has("duck-quest/index.html", '../trading-cards-extra.js?v=24.288')
has("duck-quest/index.html", '../trading-cards-gimmicks-v288.js?v=24.288')
has("duck-quest/index.html", 'css/gimmick-encounters-v288.css?v=24-288')
has("duck-quest/index.html", 'js/game-v96.js?v=24-288')
has("duck-quest/index.html", 'js/gimmick-encounters-v288.js?v=24-288')

game = read("duck-quest/js/game-v96.js")
for needle in (
    '"rotten-egg": {',
    '"lucky-cat": {',
    '"angy-duck": {',
    "const GIMMICK_ENEMY_VARIANTS",
    '"angy-duck:base": {name:"Got Beef?!"',
    "used Loud Quack!",
    "const SHINY_EGG_MS=24*60*60*1000;",
    "type==='shiny'?'shiny':x.type==='rare'?'rare':'common'",
    "['common','rare','shiny']",
    "Guaranteed random Shiny Buddy",
):
    assert needle in game, f"game-v96.js missing: {needle}"

enc = read("duck-quest/js/gimmick-encounters-v288.js")
for needle in (
    "const GIMMICK_RATE=.04;",
    "const COOLDOWN_NORMAL_ENCOUNTERS=4;",
    "const PITY=5;",
    '"rotten-egg","lucky-cat","ghost-girl","pippa","artist-friend","angy-duck"',
    "r<.50",
    "r<.94",
    "r<.97",
    "r<.55?10:r<.85?50:r<.99?100:1000",
    "foodCardChance",
    "addInventory(`love-letter-${activeCharacterId}`,1)",
    "75 Coins",
    "SPECIAL_DUCK_NAMES",
):
    assert needle in enc, f"gimmick encounter controller missing: {needle}"

cards = read("trading-cards-gimmicks-v288.js")
expected_uncommon = [f"U-{n:03d}" for n in range(14, 26)]
expected_rare = [f"R-{n:03d}" for n in range(41, 47)]
numbers = re.findall(r'number:"([UR]-\d{3})"', cards)
assert numbers == expected_uncommon + expected_rare, f"Unexpected gimmick card numbering: {numbers}"
assert cards.count('rarity:"uncommon"') == 12
assert cards.count('rarity:"rare"') == 6
for name in ("Ghost Girl","Pippa","Artist Friend","Shiny Rotten Egg","Shiny Lucky Cat","Shiny Angy Duck"):
    assert f'name:"{name}"' in cards

hub = read("gimmick-hub-v288.js")
assert 'assets/gifts/Love-letter.webp' in hub
assert "Love Letter" in hub
assert "addCharacterHappiness(50" in hub
assert 'ITEMS["shiny-egg"]' in hub

asset_root = ROOT / "duck-quest/assets/gimmicks"
assets = sorted(p for p in asset_root.rglob("*") if p.is_file())
assert len(assets) == 55, f"Expected 55 gimmick art files, found {len(assets)}"
for rel in (
    "rotten-egg/shiny/idle-1.png",
    "lucky-cat/shiny/idle-1.png",
    "angy-duck/shiny/idle-1.png",
    "ghost-girl/idle-1.png",
    "pippa/idle-1.png",
    "artist-friend/idle-1.png",
    "shiny-egg.png",
):
    assert (asset_root / rel).exists(), f"Missing gimmick art: {rel}"

sw = read("sw.js")
assert "duck-habit-hub-app-v24-288" in sw
for needle in (
    "./trading-cards-gimmicks-v288.js?v=24.288",
    "./gimmick-hub-v288.js?v=24.288",
    "./duck-quest/css/gimmick-encounters-v288.css?v=24-288",
    "./duck-quest/js/game-v96.js?v=24-288",
    "./duck-quest/js/gimmick-encounters-v288.js?v=24-288",
    "./duck-quest/assets/gimmicks/shiny-egg.png",
    "./assets/gifts/Love-letter.webp",
):
    assert needle in sw, f"sw.js missing cache entry: {needle}"

print("VERIFIED: Duckie Days v24.288 Gimmick Encounters.")

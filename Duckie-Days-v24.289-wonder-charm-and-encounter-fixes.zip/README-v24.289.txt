Duckie Days v24.289 — Wonder Charm + Encounter Fixes

This patch is built for the live v24.288 repository.

Adds:
- Bronze Wonder Charm — 5% rare encounter target — 300 Pink Coins
- Silver Wonder Charm — 6% — 750 Pink Coins
- Gold Wonder Charm — 8% — 1,300 Pink Coins
- Rose-Gold Wonder Charm — 10% — 2,000 Pink Coins

Fixes:
- Mimic battles now start with fresh cooldowns / once-per-battle state.
- Gift Box -> Gift Mimic fully clears the Gift Box UI before battle.
- Gift Mimic capture/defeat no longer leaves the Gift Box layout on the reward screen.
- Rotten Egg / Lucky Cat / Angy Duck battle transitions also receive a fresh battle state.
- Wonder Charm gently raises Gift Box and existing random-event appearances too.

IMPORTANT:
- hub.css is NOT touched.
- Your Book / shelf positioning edits are preserved.
- The installer validates the exact v24.288 files before applying.

Upload:
1) Duckie-Days-v24.289-wonder-charm-and-encounter-fixes.zip
   -> repository root

2) install-v24-289.yml
   -> .github/workflows/

Upload order does not matter. If the workflow arrives first, it waits for the ZIP.

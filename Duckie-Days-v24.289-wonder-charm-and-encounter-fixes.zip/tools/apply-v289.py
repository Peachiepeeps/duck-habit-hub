from pathlib import Path
import json

ROOT=Path.cwd()

def read(path):
    return (ROOT/path).read_text(encoding="utf-8")

def write(path,text):
    p=ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding="utf-8")

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"{path}: expected exactly one match, found {count}\nMATCH: {old[:180]}")
    write(path,text.replace(old,new,1))

# Must be applied to the exact live v24.288 base this patch was built for.
version=json.loads(read("version.json")).get("version")
if version!="24.288":
    raise SystemExit(f"Expected Duckie Days 24.288, found {version!r}")

# ---------------------------
# Wonder Charm definitions
# ---------------------------
replace_once(
    "duck-quest/js/game-v96.js",
    'const CHARM_FAMILY_ORDER = Object.freeze(["shimmer","fortune","best-friend","training","vitality","treasure"]);',
    'const CHARM_FAMILY_ORDER = Object.freeze(["shimmer","fortune","best-friend","training","vitality","treasure","wonder"]);'
)

replace_once(
    "duck-quest/js/game-v96.js",
    '  treasure:{name:"Treasure Charm",description:"Sometimes adds an extra rare-leaning item to a treasure chest.",family:"treasure"}\n});',
    '  treasure:{name:"Treasure Charm",description:"Sometimes adds an extra rare-leaning item to a treasure chest.",family:"treasure"},\n'
    '  wonder:{name:"Wonder Charm",description:"Makes rare and unusual Duck Quest encounters a little easier to find.",family:"wonder"}\n'
    '});'
)

replace_once(
    "duck-quest/js/game-v96.js",
    '  "treasure-gold":{id:"treasure-gold",family:"treasure",tier:"gold",name:"Gold Treasure Charm",price:2750,treasureChance:.50,effect:"50% chance for a bonus rare-leaning chest item"}\n});',
    '  "treasure-gold":{id:"treasure-gold",family:"treasure",tier:"gold",name:"Gold Treasure Charm",price:2750,treasureChance:.50,effect:"50% chance for a bonus rare-leaning chest item"},\n'
    '  "wonder-bronze":{id:"wonder-bronze",family:"wonder",tier:"bronze",name:"Bronze Wonder Charm",price:300,eventRate:.05,effect:"Rare encounter chance: 5%"},\n'
    '  "wonder-silver":{id:"wonder-silver",family:"wonder",tier:"silver",name:"Silver Wonder Charm",price:750,eventRate:.06,effect:"Rare encounter chance: 6%"},\n'
    '  "wonder-gold":{id:"wonder-gold",family:"wonder",tier:"gold",name:"Gold Wonder Charm",price:1300,eventRate:.08,effect:"Rare encounter chance: 8%"},\n'
    '  "wonder-rose-gold":{id:"wonder-rose-gold",family:"wonder",tier:"rose-gold",name:"Rose-Gold Wonder Charm",price:2000,eventRate:.10,effect:"Rare encounter chance: 10%"}\n'
    '});'
)

# ---------------------------
# Gimmick encounter target rate
# ---------------------------
replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    '  const GIMMICK_RATE=.04;\n',
    '  const GIMMICK_RATE=.04;\n'
    '  function currentGimmickRate(){\n'
    '    try{\n'
    '      const wonder=typeof activeCharmByFamily==="function"?activeCharmByFamily("wonder"):null;\n'
    '      return Math.max(GIMMICK_RATE,Math.min(.10,Number(wonder?.eventRate)||GIMMICK_RATE));\n'
    '    }catch(error){return GIMMICK_RATE;}\n'
    '  }\n'
)

replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    "if(Math.random()>=GIMMICK_RATE)return result;",
    "if(Math.random()>=currentGimmickRate())return result;"
)

# ---------------------------
# Duck Quest loader
# ---------------------------
replace_once(
    "duck-quest/index.html",
    '  <link rel="stylesheet" href="css/gimmick-encounters-v288.css?v=24-288">\n',
    '  <link rel="stylesheet" href="css/gimmick-encounters-v288.css?v=24-288">\n'
    '  <link rel="stylesheet" href="css/fixes-v289.css?v=24-289">\n'
)
replace_once(
    "duck-quest/index.html",
    '  <script src="js/game-v96.js?v=24-288"></script>',
    '  <script src="js/game-v96.js?v=24-289"></script>'
)
replace_once(
    "duck-quest/index.html",
    '  <script src="js/gimmick-encounters-v288.js?v=24-288"></script>\n',
    '  <script src="js/gimmick-encounters-v288.js?v=24-289"></script>\n'
    '  <script src="js/fixes-v289.js?v=24-289"></script>\n'
)

# ---------------------------
# Root build/cache bump
# ---------------------------
root=read("index.html")
if 'content="24.288"' not in root or 'const DUCK_HUB_BUILD = "24.288";' not in root:
    raise SystemExit("Root index is not the expected v24.288 loader.")
root=root.replace("24.288","24.289").replace("24-288","24-289")
write("index.html",root)

sw=read("sw.js")
if "duck-habit-hub-app-v24-288" not in sw:
    raise SystemExit("Service worker is not the expected v24.288 cache.")
sw=sw.replace("24.288","24.289").replace("24-288","24-289")
needle=" './duck-quest/css/gimmick-encounters-v288.css?v=24-289',\n"
if needle not in sw:
    raise SystemExit("Could not find Duck Quest gimmick CSS cache entry.")
sw=sw.replace(
    needle,
    needle+" './duck-quest/css/fixes-v289.css?v=24-289',\n",
    1
)
needle=" './duck-quest/js/gimmick-encounters-v288.js?v=24-289',\n"
if needle not in sw:
    raise SystemExit("Could not find Duck Quest gimmick JS cache entry.")
sw=sw.replace(
    needle,
    needle+" './duck-quest/js/fixes-v289.js?v=24-289',\n",
    1
)
write("sw.js",sw)

write("version.json",json.dumps({"version":"24.289"},indent=2)+"\n")
write(
    "CHANGELOG-LATEST.txt",
    """Duckie Days 24.289

Wonder Charm + encounter fixes

- Added Bronze Wonder Charm: 5% rare encounter target (300 Pink Coins)
- Added Silver Wonder Charm: 6% rare encounter target (750 Pink Coins)
- Added Gold Wonder Charm: 8% rare encounter target (1,300 Pink Coins)
- Added Rose-Gold Wonder Charm: 10% rare encounter target (2,000 Pink Coins)
- Wonder also gently raises Gift Box and existing random-event appearances.
- Fixed Miko/other hero cooldown and per-battle state carrying into Mimics.
- The same fresh-battle reset now applies to Gift Mimic, Rotten Egg, Lucky Cat, and Angy Duck battles.
- Fixed Gift Box UI staying visible when it becomes a Mimic.
- Fixed stale Gift Box layout corrupting the reward screen after catching/defeating Gift Mimic.
"""
)

# ---------------------------
# Verification
# ---------------------------
game=read("duck-quest/js/game-v96.js")
assert '"wonder-rose-gold"' in game
assert 'price:2000,eventRate:.10' in game
assert '"wonder-bronze"' in game and 'eventRate:.05' in game
assert '"wonder-silver"' in game and 'eventRate:.06' in game
assert '"wonder-gold"' in game and 'eventRate:.08' in game
assert '"wonder"]' in game

gimmick=read("duck-quest/js/gimmick-encounters-v288.js")
assert "currentGimmickRate()" in gimmick
assert "Math.random()>=currentGimmickRate()" in gimmick

dq=read("duck-quest/index.html")
assert 'css/fixes-v289.css?v=24-289' in dq
assert 'js/game-v96.js?v=24-289' in dq
assert 'js/gimmick-encounters-v288.js?v=24-289' in dq
assert 'js/fixes-v289.js?v=24-289' in dq

root=read("index.html")
assert 'duck-habit-build" content="24.289"' in root
assert 'const DUCK_HUB_BUILD = "24.289";' in root
assert './sw.js?v=24-289' in root

sw=read("sw.js")
assert "duck-habit-hub-app-v24-289" in sw
assert "./duck-quest/css/fixes-v289.css?v=24-289" in sw
assert "./duck-quest/js/fixes-v289.js?v=24-289" in sw
assert "./duck-quest/js/game-v96.js?v=24-289" in sw
assert "./duck-quest/js/gimmick-encounters-v288.js?v=24-289" in sw

assert json.loads(read("version.json"))["version"]=="24.289"

print("VERIFIED: Duckie Days v24.289 Wonder Charm + encounter fixes.")

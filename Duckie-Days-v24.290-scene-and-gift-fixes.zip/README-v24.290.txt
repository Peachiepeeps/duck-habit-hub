Duckie Days v24.290 — Scene + Gift Fixes

Fixes:
- Reward chest hop/sway removed.
- Lucky Gift Box stays closed until clicked, then uses the correct opened-box art.
- Mimic Gift Boxes open first, visibly reveal the Mimic, then start battle.
- ALL 13 current love-interest/reunion scenes use static character positioning.
- Only the ending heart floats, using stepped pixel movement.
- ALL 13 scenes end with the same Obtained! popup + Continue button.

Built for live v24.289.

IMPORTANT:
- hub.css is NOT touched.
- Existing Book/shelf positioning remains untouched.

Upload:
1) Duckie-Days-v24.290-scene-and-gift-fixes.zip
   -> repository root

2) install-v24-290.yml
   -> .github/workflows/

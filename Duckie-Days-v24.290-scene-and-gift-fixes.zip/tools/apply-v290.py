
from pathlib import Path
import json

ROOT=Path.cwd()

def read(path):
    return (ROOT/path).read_text(encoding="utf-8")

def write(path,text):
    p=ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding="utf-8")

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"{path}: expected exactly one match, found {count}\nMATCH:\n{old[:500]}")
    write(path,text.replace(old,new,1))

version=json.loads(read("version.json")).get("version")
if version!="24.289":
    raise SystemExit(f"Expected Duckie Days 24.289, found {version!r}")

replace_once(
    "duck-quest/js/special-encounters-v265.js",
'''    if(style==="lucky"){
      let frame=0; giftTimer=setInterval(()=>{if(!pendingChest||pendingChest.kind!=="gift-box"){stopGiftAnimation();return;} frame=(frame+1)%2;ui.chestSprite.src=GIFT_BASE+`lucky-idle-${frame+1}.png`;},430);
    }''',
'''    // v24.290: Lucky Gift Boxes stay on their closed-box sprite until opened.
    // The lucky idle frames belong to the Mimic presentation, not the unopened gift.''')

replace_once(
    "duck-quest/js/special-encounters-v265.js",
'''    if(info.revealGiftMimic){
      ui.chestCaption.textContent="Oh no… it moved!";setMessage("The Gift Box was a Mimic!");await sleep(360);ui.chestLayer.classList.add("hidden");actionLocked=false;
      startEnemy("gift-mimic",{giftStyle:info.giftStyle,giftReward:info.giftReward});return;
    }''',
'''    if(info.revealGiftMimic){
      ui.chestSprite.src=info.giftStyle==="shiny"?GIFT_BASE+"mimic-shiny-idle-1.png":GIFT_BASE+"mimic-idle-1.png";
      ui.chestCaption.textContent="Oh no… it moved!";
      setMessage("The Gift Box was a Mimic!");
      await sleep(360);
      ui.chestLayer.classList.add("hidden");
      actionLocked=false;
      startEnemy("gift-mimic",{giftStyle:info.giftStyle,giftReward:info.giftReward});
      return;
    }''')

replace_once(
    "duck-quest/js/love-interests-v252.js",
'''  function sceneRewardMessage(scene){
    if (scene.id.includes("-")) return "Both Trading Cards unlocked! ♡";
    if (scene.id === "lukio") return "Lukio Duck, Miko's Lukio outfit, and Lukio's card unlocked! ♡";
    return `${scene.title} Duck and Miko's ${scene.title} outfit unlocked! ♡`;
  }''',
'''  function sceneRewardItems(scene){
    if (scene.id.includes("-")) {
      return scene.title.split(" + ").map(name => `${name} Trading Card`);
    }
    const items=[`${scene.title} Duck`, `Miko's ${scene.title} Outfit`];
    if(scene.id==="lukio") items.push("Lukio Trading Card");
    return items;
  }

  function buildSceneRewardPopup(scene,onContinue){
    const popup=document.createElement("div");
    popup.className="love-interest-reward-popup-v290";
    const label=document.createElement("span");
    label.className="mini-label";
    label.textContent="OBTAINED!";
    const title=document.createElement("h3");
    title.textContent=scene.id.includes("-")?"Reunion Rewards!":`${scene.title} Rewards!`;
    const list=document.createElement("div");
    list.className="love-interest-reward-list-v290";
    sceneRewardItems(scene).forEach(item=>{
      const row=document.createElement("div");
      row.className="love-interest-reward-item-v290";
      row.textContent=item;
      list.append(row);
    });
    const button=document.createElement("button");
    button.type="button";
    button.className="pixel-button primary";
    button.textContent="Continue";
    button.addEventListener("click",onContinue,{once:true});
    popup.append(label,title,list,button);
    return popup;
  }''')

replace_once(
    "duck-quest/js/love-interests-v252.js",
'''      next.addEventListener("click", () => {
        if (!last) {
          index += 1;
          render();
          return;
        }
        next.disabled = true;
        state.heart.classList.remove("hidden");
        scene.reward();
        message.textContent = sceneRewardMessage(scene);
        setTimeout(() => {
          stopSceneAnimation();
          if (state.resizeHandler) window.removeEventListener("resize", state.resizeHandler);
          state.left.onload = null;
          state.right.onload = null;
          state.heart.classList.add("hidden");
          el.classList.add("hidden");
          el.setAttribute("aria-hidden", "true");
          actions.innerHTML = "";
          actions.classList.add("hidden");
          markSceneUi(false);
          open = false;
          if (typeof onFinished === "function") {
            bypassNextRoll = true;
            onFinished();
          }
        }, 1350);
      });''',
'''      next.addEventListener("click", () => {
        if (!last) {
          index += 1;
          render();
          return;
        }
        next.disabled = true;
        stopSceneAnimation();
        state.heart.classList.remove("hidden");
        scene.reward();
        message.classList.add("love-interest-reward-message-hidden-v290");
        actions.innerHTML = "";

        const closeScene = () => {
          if (state.resizeHandler) window.removeEventListener("resize", state.resizeHandler);
          state.left.onload = null;
          state.right.onload = null;
          state.heart.classList.add("hidden");
          el.classList.add("hidden");
          el.setAttribute("aria-hidden", "true");
          actions.innerHTML = "";
          actions.classList.add("hidden");
          message.classList.remove("love-interest-reward-message-hidden-v290");
          markSceneUi(false);
          open = false;
          if (typeof onFinished === "function") {
            bypassNextRoll = true;
            onFinished();
          }
        };

        actions.append(buildSceneRewardPopup(scene,closeScene));
        actions.classList.remove("hidden");
      });''')

replace_once(
    "duck-quest/index.html",
'''  <link rel="stylesheet" href="css/quest-v278.css?v=24-278">
''',
'''  <link rel="stylesheet" href="css/quest-v278.css?v=24-278">
  <link rel="stylesheet" href="css/fixes-v290.css?v=24-290">
''')

replace_once(
    "duck-quest/index.html",
'''  <script src="js/love-interests-v252.js?v=24-255"></script>''',
'''  <script src="js/love-interests-v252.js?v=24-290"></script>''')

replace_once(
    "duck-quest/index.html",
'''  <script src="js/special-encounters-v265.js?v=24-265"></script>''',
'''  <script src="js/special-encounters-v265.js?v=24-290"></script>''')

root=read("index.html")
if 'content="24.289"' not in root or 'const DUCK_HUB_BUILD = "24.289";' not in root:
    raise SystemExit("Root index is not the expected v24.289 loader.")
root=root.replace("24.289","24.290").replace("24-289","24-290")
write("index.html",root)

sw=read("sw.js")
if "duck-habit-hub-app-v24-289" not in sw:
    raise SystemExit("Service worker is not the expected v24.289 cache.")
sw=sw.replace("24.289","24.290").replace("24-289","24-290")
needle=" './duck-quest/css/fixes-v289.css?v=24-290',\n"
if needle not in sw:
    raise SystemExit("Could not find v24.289 fixes CSS cache entry.")
sw=sw.replace(needle,needle+" './duck-quest/css/fixes-v290.css?v=24-290',\n",1)
write("sw.js",sw)

write("version.json",json.dumps({"version":"24.290"},indent=2)+"\n")
write(
    "CHANGELOG-LATEST.txt",
    '''Duckie Days 24.290

Scene + Gift Box polish

- Reward chests no longer hop/sway when opening.
- Lucky Gift Boxes now remain on lucky-closed.png until opened.
- A non-Mimic Lucky Gift Box goes closed -> open -> reward.
- A Mimic Gift Box goes closed -> open -> Mimic reveal -> battle.
- All 13 love-interest/reunion scenes no longer bob the character sprites up and down.
- Only the ending heart floats, using a stepped pixel-style animation.
- Every one of the 13 scenes now ends with the same Obtained! reward popup and an explicit Continue button.
- Individual scenes list their Duck + Miko outfit rewards; Lukio also lists his card.
- Reunion scenes list both Trading Cards.
'''
)

special=read("duck-quest/js/special-encounters-v265.js")
assert "lucky-idle-${frame+1}" not in special
assert 'Lucky Gift Boxes stay on their closed-box sprite' in special
assert 'mimic-shiny-idle-1.png' in special

love=read("duck-quest/js/love-interests-v252.js")
assert "function sceneRewardItems(scene)" in love
assert "function buildSceneRewardPopup(scene,onContinue)" in love
assert 'button.textContent="Continue"' in love
assert "love-interest-reward-message-hidden-v290" in love
show=love[love.index("function showScene"):love.index("function reconcileRecordedRewards")]
assert "setTimeout(() =>" not in show

dq=read("duck-quest/index.html")
assert 'css/fixes-v290.css?v=24-290' in dq
assert 'js/love-interests-v252.js?v=24-290' in dq
assert 'js/special-encounters-v265.js?v=24-290' in dq

sw=read("sw.js")
assert "duck-habit-hub-app-v24-290" in sw
assert "./duck-quest/css/fixes-v290.css?v=24-290" in sw
assert json.loads(read("version.json"))["version"]=="24.290"

print("VERIFIED: Duckie Days v24.290 scene + gift fixes.")

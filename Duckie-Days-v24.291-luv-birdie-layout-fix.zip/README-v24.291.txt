Duckie Days v24.291 — Luv & Birdie Layout Fix

- Luv & Birdie are centered together in the battlefield.
- Miko's normal battle sprite is hidden during this event.
- All 9 love-interest choices are under the event text in the lower cream box.
- Choosing someone updates the result text but keeps Luv & Birdie visible.
- A Continue / Next Floor button appears after the choice.
- Luv & Birdie disappear only when Continue is pressed.

Built for live v24.290.

hub.css is NOT touched.

Upload:
1) Duckie-Days-v24.291-luv-birdie-layout-fix.zip -> repository root
2) install-v24-291.yml -> .github/workflows/

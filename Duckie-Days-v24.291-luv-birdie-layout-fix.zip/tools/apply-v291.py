
from pathlib import Path
import json

ROOT=Path.cwd()

def read(path):
    return (ROOT/path).read_text(encoding="utf-8")

def write(path,text):
    p=ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding="utf-8")

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"{path}: expected exactly one match, found {count}\nMATCH:\n{old[:500]}")
    write(path,text.replace(old,new,1))

version=json.loads(read("version.json")).get("version")
if version!="24.290":
    raise SystemExit(f"Expected Duckie Days 24.290, found {version!r}")

old_show='''  function showLuvBirdie(){
    clearGiftRewardVisual();
    ui.chestLayer?.classList.remove("gift-box-active-v262");
    ui.chestSprite?.classList.remove("gift-box-art-v262");
    pendingChest={kind:"event",eventType:"luv-birdie"};
    ui.chestLayer.classList.remove("hidden");
    ui.chestLayer.classList.add("merchant-active-v197","luv-birdie-active-v262");
    ui.chestSprite.classList.add("event-scene-art","merchant-duck","luv-birdie-art-v262");
    ui.chestSprite.alt="Luv and Birdie"; startLuvAnimation();
    ui.openChest.classList.add("hidden");
    ui.chestCaption.textContent="Luv & Birdie";
    setMessage("Luv and Birdie snuggle together, both chirping sweet chirps to each other. It makes Miko think of someone… but who..?");
    let menu=ui.chestLayer.querySelector("#luvBirdieMenuV262");
    if(!menu){menu=document.createElement("div");menu.id="luvBirdieMenuV262";menu.className="merchant-shop-v197 luv-birdie-menu-v262";ui.chestLayer.appendChild(menu);}
    menu.innerHTML='<div class="luv-birdie-copy-v262"><strong>Who is Miko thinking of?</strong><small>Choose someone to give them a 3× encounter weight for the next 3 eligible character-event rolls.</small></div>';
    const grid=document.createElement("div");grid.className="luv-birdie-grid-v262";
    LUV_IDS.forEach(([id,name])=>{const b=document.createElement("button");b.type="button";b.className="pixel-button luv-birdie-choice-v262";b.textContent=name;b.addEventListener("click",()=>{
      hubSave.luvBirdieFocusV262={characterId:id,name,rollsRemaining:3,weight:3}; persist();
      finishSpecial(`Luv and Birdie chirp happily! ${name} will be much more likely to appear for Miko's next few character encounters.`);
    });grid.appendChild(b);});
    menu.appendChild(grid);
    const leave=document.createElement("button");leave.type="button";leave.className="pixel-button merchant-leave-v197";leave.textContent="Maybe another time";leave.addEventListener("click",()=>finishSpecial("Luv and Birdie cuddle close as Miko continues onward."));menu.appendChild(leave);
  }'''

new_show='''  function clearLuvBirdieSceneV291(){
    stopLuvAnimation();
    ui.battlefield?.classList.remove("luv-birdie-scene-v291");
    ui.battleUi?.classList.remove("luv-birdie-ui-v291");
    ui.chestLayer?.classList.remove("merchant-active-v197","luv-birdie-active-v262");
    ui.chestSprite?.classList.remove("event-scene-art","merchant-duck","luv-birdie-art-v262");
    ui.chestLayer?.querySelector("#luvBirdieMenuV262")?.remove();
    ui.openChest?.classList.add("hidden");
    ui.chestLayer?.classList.add("hidden");
    if(ui.eventChoiceActions){
      ui.eventChoiceActions.innerHTML="";
      ui.eventChoiceActions.classList.add("hidden");
      ui.eventChoiceActions.classList.remove("luv-birdie-choice-panel-v291");
    }
    pendingChest=null;
  }

  function holdLuvBirdieUntilContinueV291(message){
    setMessage(message);
    if(currentRun?.mode==="endless") markEndlessFloorComplete();
    persist();
    actionLocked=true;

    const holder=ui.eventChoiceActions;
    if(!holder)return;
    holder.innerHTML="";
    holder.classList.add("luv-birdie-choice-panel-v291");
    holder.classList.remove("hidden");

    const row=document.createElement("div");
    row.className="luv-birdie-result-v291";
    const next=document.createElement("button");
    next.type="button";
    next.className="pixel-button primary luv-birdie-continue-v291";
    next.textContent=currentRun?.mode==="endless"?"Next Floor":"Continue";
    next.addEventListener("click",()=>{
      next.disabled=true;
      clearLuvBirdieSceneV291();
      actionLocked=false;
      nextEncounter();
    },{once:true});
    row.appendChild(next);
    holder.appendChild(row);
  }

  function showLuvBirdie(){
    clearGiftRewardVisual();
    ui.chestLayer?.classList.remove("gift-box-active-v262","merchant-active-v197");
    ui.chestSprite?.classList.remove("gift-box-art-v262","merchant-duck");
    pendingChest={kind:"event",eventType:"luv-birdie"};

    ui.battlefield?.classList.add("luv-birdie-scene-v291");
    ui.battleUi?.classList.add("luv-birdie-ui-v291");
    ui.postFloorActions?.classList.add("hidden");
    ui.leaveEndlessButton?.classList.add("hidden");

    ui.chestLayer.classList.remove("hidden");
    ui.chestLayer.classList.add("luv-birdie-active-v262");
    ui.chestSprite.classList.add("event-scene-art","luv-birdie-art-v262");
    ui.chestSprite.alt="Luv and Birdie";
    startLuvAnimation();
    ui.openChest.classList.add("hidden");
    ui.chestCaption.textContent="Luv & Birdie";

    setMessage("Luv and Birdie snuggle together, both chirping sweet chirps to each other. It makes Miko think of someone… but who..?");

    const holder=ui.eventChoiceActions;
    if(!holder)return;
    holder.innerHTML="";
    holder.classList.add("luv-birdie-choice-panel-v291");
    holder.classList.remove("hidden");

    const prompt=document.createElement("div");
    prompt.className="luv-birdie-prompt-v291";
    prompt.innerHTML="<strong>Who is Miko thinking of?</strong><small>Choose someone to make them 3× more likely during the next 3 eligible character-event rolls.</small>";
    holder.appendChild(prompt);

    const grid=document.createElement("div");
    grid.className="luv-birdie-grid-v291";
    LUV_IDS.forEach(([id,name])=>{
      const button=document.createElement("button");
      button.type="button";
      button.className="pixel-button luv-birdie-choice-v291";
      button.textContent=name;
      button.addEventListener("click",()=>{
        hubSave.luvBirdieFocusV262={characterId:id,name,rollsRemaining:3,weight:3};
        persist();
        holdLuvBirdieUntilContinueV291(`Luv and Birdie chirp happily! ${name} will be much more likely to appear for Miko's next few character encounters.`);
      },{once:true});
      grid.appendChild(button);
    });
    holder.appendChild(grid);

    const leave=document.createElement("button");
    leave.type="button";
    leave.className="pixel-button luv-birdie-leave-v291";
    leave.textContent="Maybe another time";
    leave.addEventListener("click",()=>{
      holdLuvBirdieUntilContinueV291("Luv and Birdie cuddle close as Miko continues onward.");
    },{once:true});
    holder.appendChild(leave);
  }'''

replace_once("duck-quest/js/special-encounters-v265.js",old_show,new_show)

old_cleanup='''      stopLuvAnimation();stopGiftAnimation();clearGiftRewardVisual();
      ui.chestLayer?.classList.remove("gift-box-active-v262","luv-birdie-active-v262");
      ui.chestSprite?.classList.remove("gift-box-art-v262","luv-birdie-art-v262","event-scene-art","merchant-duck");
      return oldStartEncounterV262();'''

new_cleanup='''      stopLuvAnimation();stopGiftAnimation();clearGiftRewardVisual();
      ui.battlefield?.classList.remove("luv-birdie-scene-v291");
      ui.battleUi?.classList.remove("luv-birdie-ui-v291");
      ui.eventChoiceActions?.classList.remove("luv-birdie-choice-panel-v291");
      ui.chestLayer?.classList.remove("gift-box-active-v262","luv-birdie-active-v262");
      ui.chestSprite?.classList.remove("gift-box-art-v262","luv-birdie-art-v262","event-scene-art","merchant-duck");
      return oldStartEncounterV262();'''

replace_once("duck-quest/js/special-encounters-v265.js",old_cleanup,new_cleanup)

replace_once(
    "duck-quest/index.html",
    '  <link rel="stylesheet" href="css/fixes-v290.css?v=24-290">\n',
    '  <link rel="stylesheet" href="css/fixes-v290.css?v=24-290">\n  <link rel="stylesheet" href="css/fixes-v291.css?v=24-291">\n'
)

replace_once(
    "duck-quest/index.html",
    '  <script src="js/special-encounters-v265.js?v=24-290"></script>',
    '  <script src="js/special-encounters-v265.js?v=24-291"></script>'
)

root=read("index.html")
if 'content="24.290"' not in root or 'const DUCK_HUB_BUILD = "24.290";' not in root:
    raise SystemExit("Root index is not the expected v24.290 loader.")
root=root.replace("24.290","24.291").replace("24-290","24-291")
write("index.html",root)

sw=read("sw.js")
if "duck-habit-hub-app-v24-290" not in sw:
    raise SystemExit("Service worker is not the expected v24.290 cache.")
sw=sw.replace("24.290","24.291").replace("24-290","24-291")
needle=" './duck-quest/css/fixes-v290.css?v=24-291',\n"
if needle not in sw:
    raise SystemExit("Could not find fixes-v290 cache entry.")
sw=sw.replace(needle,needle+" './duck-quest/css/fixes-v291.css?v=24-291',\n",1)
write("sw.js",sw)

write("version.json",json.dumps({"version":"24.291"},indent=2)+"\n")
write(
    "CHANGELOG-LATEST.txt",
    '''Duckie Days 24.291

Luv & Birdie layout fix

- Luv & Birdie are now centered together in the battlefield.
- Miko's battle sprite is hidden while the Luv & Birdie event is active.
- Love-interest choices now live below the event text in the lower cream dialogue box.
- All 9 love-interest buttons are shown in a clean 3x3 grid.
- Selecting a love interest no longer immediately removes Luv & Birdie.
- Luv & Birdie stay visible while the result text is shown.
- A dedicated Continue / Next Floor button appears after the choice.
- The event is only cleaned up when the player presses Continue.
'''
)

special=read("duck-quest/js/special-encounters-v265.js")
assert "function clearLuvBirdieSceneV291()" in special
assert "function holdLuvBirdieUntilContinueV291(message)" in special
assert 'grid.className="luv-birdie-grid-v291"' in special
assert 'ui.battlefield?.classList.add("luv-birdie-scene-v291")' in special
assert 'ui.battleUi?.classList.add("luv-birdie-ui-v291")' in special
assert 'finishSpecial(`Luv and Birdie chirp happily!' not in special

dq=read("duck-quest/index.html")
assert 'css/fixes-v291.css?v=24-291' in dq
assert 'js/special-encounters-v265.js?v=24-291' in dq

sw=read("sw.js")
assert "duck-habit-hub-app-v24-291" in sw
assert "./duck-quest/css/fixes-v291.css?v=24-291" in sw
assert json.loads(read("version.json"))["version"]=="24.291"

print("VERIFIED: Duckie Days v24.291 Luv & Birdie layout fix.")

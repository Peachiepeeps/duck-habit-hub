Duckie Days v24.292 — Gift Box Reward Display Fix

- Gift box reward cards now display much smaller.
- Reward cards and card packs are centered in the middle of the screen.
- Prevents the reward visual from stretching huge across the pink enemy panel.
- Mobile sizing is tightened for a cleaner popup reward look.

Built for live v24.291.

Upload:
1) Duckie-Days-v24.292-gift-reward-display-fix.zip -> repository root
2) install-v24-292.yml -> .github/workflows/

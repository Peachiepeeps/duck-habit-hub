from pathlib import Path
import json

ROOT=Path.cwd()

def read(path):
    return (ROOT/path).read_text(encoding='utf-8')

def write(path,text):
    p=ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding='utf-8')

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"{path}: expected exactly one match, found {count}\nMATCH:\n{old[:400]}")
    write(path,text.replace(old,new,1))

version=json.loads(read('version.json')).get('version')
if version!='24.291':
    raise SystemExit(f"Expected Duckie Days 24.291, found {version!r}")

replace_once(
    'duck-quest/index.html',
    '  <link rel="stylesheet" href="css/fixes-v291.css?v=24-291">\n',
    '  <link rel="stylesheet" href="css/fixes-v291.css?v=24-291">\n  <link rel="stylesheet" href="css/fixes-v292.css?v=24-292">\n'
)

root=read('index.html')
if '24.291' not in root:
    raise SystemExit('Root index is not the expected v24.291 loader.')
root=root.replace('24.291','24.292').replace('24-291','24-292')
write('index.html',root)

sw=read('sw.js')
if '24.291' not in sw or './duck-quest/css/fixes-v291.css?v=24-291' not in sw:
    raise SystemExit('Service worker is not the expected v24.291 base.')
sw=sw.replace('24.291','24.292').replace('24-291','24-292')
needle=" './duck-quest/css/fixes-v291.css?v=24-292',\n"
if needle not in sw:
    raise SystemExit('Could not find fixes-v291 cache entry after version bump.')
sw=sw.replace(needle, needle + " './duck-quest/css/fixes-v292.css?v=24-292',\n", 1)
write('sw.js',sw)

write('version.json', json.dumps({'version':'24.292'}, indent=2) + '\n')
write('CHANGELOG-LATEST.txt', '''Duckie Days 24.292\n\nGift box reward display polish\n\n- Gift box card rewards now render much smaller.\n- Reward cards and card packs are centered in the middle of the battlefield.\n- Card reward visuals no longer stretch across the pink enemy panel.\n- Mobile sizing is tightened so the reward sits like a popup reward.\n''')

# sanity checks
assert 'css/fixes-v292.css?v=24-292' in read('duck-quest/index.html')
assert 'duck-habit-hub-app-v24-292' in read('sw.js')
assert './duck-quest/css/fixes-v292.css?v=24-292' in read('sw.js')
assert json.loads(read('version.json'))['version']=='24.292'
print('VERIFIED: Duckie Days v24.292 gift reward sizing fix.')

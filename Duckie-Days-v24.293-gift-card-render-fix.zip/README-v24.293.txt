Duckie Days v24.293 — Gift Box Card Render Fix

This fixes the actual source of the giant right-shifted card:
Duck Quest loads the Trading Card JavaScript, but not the normal Trading Card CSS.
The outer card wrapper was being made smaller, but the frame/art images inside it
were still rendering at their natural size and overflowing to the right.

v24.293 adds fully scoped Trading Card styling ONLY inside Gift Box rewards.

Expected result:
- single card: tiny complete card centered in the battlefield
- multiple cards: small centered row
- card packs: small centered pack
- no duplicate card-name caption in the battlefield

Built for live v24.292.
hub.css is not touched.

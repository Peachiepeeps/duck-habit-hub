
from pathlib import Path
import json

ROOT=Path.cwd()

def read(path):
    return (ROOT/path).read_text(encoding="utf-8")

def write(path,text):
    p=ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding="utf-8")

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"{path}: expected exactly one match, found {count}")
    write(path,text.replace(old,new,1))

version=json.loads(read("version.json")).get("version")
if version!="24.292":
    raise SystemExit(f"Expected Duckie Days 24.292, found {version!r}")

replace_once(
    "duck-quest/index.html",
    '  <link rel="stylesheet" href="css/fixes-v292.css?v=24-292">\n',
    '  <link rel="stylesheet" href="css/fixes-v292.css?v=24-292">\n  <link rel="stylesheet" href="css/fixes-v293.css?v=24-293">\n'
)

root=read("index.html")
if '24.292' not in root:
    raise SystemExit("Root index is not expected v24.292.")
root=root.replace("24.292","24.293").replace("24-292","24-293")
write("index.html",root)

sw=read("sw.js")
if "duck-habit-hub-app-v24-292" not in sw:
    raise SystemExit("Service worker is not expected v24.292.")
sw=sw.replace("24.292","24.293").replace("24-292","24-293")
needle=" './duck-quest/css/fixes-v292.css?v=24-293',\n"
if needle not in sw:
    raise SystemExit("Could not find v24.292 fixes cache entry.")
sw=sw.replace(needle,needle+" './duck-quest/css/fixes-v293.css?v=24-293',\n",1)
write("sw.js",sw)

write("version.json",json.dumps({"version":"24.293"},indent=2)+"\n")
write(
    "CHANGELOG-LATEST.txt",
    """Duckie Days 24.293

Gift Box trading-card render fix

- Fixed the actual cause of the giant right-shifted Gift Box card.
- Duck Quest was rendering the Trading Card face without the Trading Card stylesheet.
- The card's frame/art images were therefore staying at their natural size and overflowing the small wrapper.
- Gift Box cards now have fully scoped card-face styling and render as a small complete card centered in the battlefield.
- Mobile reward card width is 60px.
- Duplicate reward caption in the battlefield is hidden; the lower message still names the reward.
- Gift Box card-pack rewards use the same small centered layout.
"""
)

dq=read("duck-quest/index.html")
assert 'css/fixes-v293.css?v=24-293' in dq
assert json.loads(read("version.json"))["version"]=="24.293"
assert "duck-habit-hub-app-v24-293" in read("sw.js")
assert "./duck-quest/css/fixes-v293.css?v=24-293" in read("sw.js")
print("VERIFIED: Duckie Days v24.293 Gift Box card render fix.")

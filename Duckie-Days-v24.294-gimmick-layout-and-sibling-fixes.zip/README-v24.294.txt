Duckie Days v24.294 — Gimmick Layout + Sibling Spat Fixes

Fixes from the latest mobile screenshots:
- Strange Egg event options are now reachable.
- ALL six gimmick encounter menus/options live in the lower cream battle panel.
- Their character/egg art stays centered in the battlefield.
- Artist Friend remains visible instead of its menu covering/replacing the scene.
- Dash Carts are excluded from Artist Friend inspiration items.
- Artist Friend lists scroll in the lower panel.
- Miko and Miho no longer bob/floating vertically in Sibling Spat dialogue.

Built for live v24.293.

hub.css is NOT touched.

Upload:
1) Duckie-Days-v24.294-gimmick-layout-and-sibling-fixes.zip -> repository root
2) install-v24-294.yml -> .github/workflows/

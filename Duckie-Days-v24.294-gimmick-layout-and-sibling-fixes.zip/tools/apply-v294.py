
from pathlib import Path
import json

ROOT=Path.cwd()

def read(path):
    return (ROOT/path).read_text(encoding="utf-8")

def write(path,text):
    p=ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding="utf-8")

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"{path}: expected exactly one match, found {count}\nMATCH:\n{old[:500]}")
    write(path,text.replace(old,new,1))

version=json.loads(read("version.json")).get("version")
if version!="24.293":
    raise SystemExit(f"Expected Duckie Days 24.293, found {version!r}")

# ---------------------------------------------------------
# Gimmick encounters: repair scene lifecycle + move choices
# into the lower cream battle panel.
# ---------------------------------------------------------
replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    '  const VERSION="24.288";',
    '  const VERSION="24.294";'
)

replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    """  function clearScene(){if(sceneTimer){clearInterval(sceneTimer);sceneTimer=null;}ui.chestLayer?.querySelector('#gimmickMenuV288')?.remove();ui.chestLayer?.classList.remove('gimmick-active-v288');ui.chestSprite?.classList.remove('gimmick-art-v288');}
  function animateScene(frames,speed=470){clearScene();if(!ui.chestSprite||!frames?.length)return;let i=0;ui.chestSprite.src=frames[0];sceneTimer=setInterval(()=>{i=(i+1)%frames.length;if(ui.chestSprite)ui.chestSprite.src=frames[i];},speed);}""",
    """  function stopSceneAnimation(){if(sceneTimer){clearInterval(sceneTimer);sceneTimer=null;}}
  function clearScene(){
    stopSceneAnimation();
    ui.chestLayer?.querySelector('#gimmickMenuV288')?.remove();
    ui.eventChoiceActions?.querySelector('#gimmickMenuV288')?.remove();
    ui.chestLayer?.classList.remove('gimmick-active-v288');
    ui.chestSprite?.classList.remove('gimmick-art-v288','gimmick-egg-art-v288');
    ui.battlefield?.classList.remove('gimmick-scene-v294');
    ui.battleUi?.classList.remove('gimmick-ui-v294');
    if(ui.eventChoiceActions){
      ui.eventChoiceActions.classList.remove('gimmick-choice-panel-v294');
      ui.eventChoiceActions.innerHTML='';
      ui.eventChoiceActions.classList.add('hidden');
    }
  }
  function animateScene(frames,speed=470){
    stopSceneAnimation();
    if(!ui.chestSprite||!frames?.length)return;
    ui.chestSprite.classList.remove('gimmick-egg-art-v288');
    ui.chestSprite.classList.add('gimmick-art-v288');
    let i=0;
    ui.chestSprite.src=frames[0];
    sceneTimer=setInterval(()=>{i=(i+1)%frames.length;if(ui.chestSprite)ui.chestSprite.src=frames[i];},speed);
  }"""
)

replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    """    ui.chestLayer?.classList.remove('hidden');ui.chestLayer?.classList.add('gimmick-active-v288');ui.chestSprite?.classList.add('gimmick-art-v288');ui.openChest?.classList.add('hidden');ui.postFloorActions?.classList.add('hidden');ui.leaveEndlessButton?.classList.add('hidden');try{setPostFloorLayout(false);}catch{}""",
    """    ui.battlefield?.classList.add('gimmick-scene-v294');ui.battleUi?.classList.add('gimmick-ui-v294');
    ui.chestLayer?.classList.remove('hidden');ui.chestLayer?.classList.add('gimmick-active-v288');ui.chestSprite?.classList.add('gimmick-art-v288');ui.openChest?.classList.add('hidden');ui.postFloorActions?.classList.add('hidden');ui.leaveEndlessButton?.classList.add('hidden');try{setPostFloorLayout(false);}catch{}"""
)

replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    """  function menu(title,copy){let m=ui.chestLayer.querySelector('#gimmickMenuV288');if(m)m.remove();m=document.createElement('div');m.id='gimmickMenuV288';m.className='gimmick-menu-v288';m.innerHTML=`<strong>${title}</strong><p>${copy}</p><div class="gimmick-actions-v288"></div>`;ui.chestLayer.append(m);return m;}""",
    """  function menu(title,copy){
    ui.chestLayer?.querySelector('#gimmickMenuV288')?.remove();
    const holder=ui.eventChoiceActions;
    if(!holder)return document.createElement('div');
    holder.innerHTML='';
    holder.classList.add('gimmick-choice-panel-v294');
    holder.classList.remove('hidden');
    ui.battleUi?.classList.add('gimmick-ui-v294');
    const m=document.createElement('div');
    m.id='gimmickMenuV288';
    m.className='gimmick-menu-v288';
    m.innerHTML=`<strong>${title}</strong><p>${copy}</p><div class="gimmick-actions-v288"></div>`;
    holder.append(m);
    return m;
  }"""
)

# Carts are Shop navigation/gameplay unlocks, not Artist Friend inspiration items.
replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    """m.querySelector('p').textContent='Give Artist Friend one item from the Hub Shop Supplies category for inspiration. They will give you 3 random Paints!';const owned=SUPPLIES.filter(s=>qty(s.id)>0);""",
    """m.querySelector('p').textContent='Give Artist Friend one regular item from the Hub Shop Supplies category for inspiration. Dash Carts are not accepted. They will give you 3 random Paints!';const owned=SUPPLIES.filter(s=>!String(s.id).startsWith('dash-cart-')&&qty(s.id)>0);"""
)

# ---------------------------------------------------------
# Load new CSS last + cache-bust the modified gimmick JS.
# ---------------------------------------------------------
replace_once(
    "duck-quest/index.html",
    '  <link rel="stylesheet" href="css/fixes-v293.css?v=24-293">\n',
    '  <link rel="stylesheet" href="css/fixes-v293.css?v=24-293">\n  <link rel="stylesheet" href="css/fixes-v294.css?v=24-294">\n'
)

replace_once(
    "duck-quest/index.html",
    '  <script src="js/gimmick-encounters-v288.js?v=24-289"></script>',
    '  <script src="js/gimmick-encounters-v288.js?v=24-294"></script>'
)

# Root build bump.
root=read("index.html")
if '24.293' not in root:
    raise SystemExit("Root index is not the expected v24.293 loader.")
root=root.replace("24.293","24.294").replace("24-293","24-294")
write("index.html",root)

# Service-worker bump and new CSS cache entry.
sw=read("sw.js")
if "duck-habit-hub-app-v24-293" not in sw:
    raise SystemExit("Service worker is not the expected v24.293 cache.")
sw=sw.replace("24.293","24.294").replace("24-293","24-294")
needle=" './duck-quest/css/fixes-v293.css?v=24-294',\n"
if needle not in sw:
    raise SystemExit("Could not find fixes-v293 cache entry.")
sw=sw.replace(needle,needle+" './duck-quest/css/fixes-v294.css?v=24-294',\n",1)
write("sw.js",sw)

write("version.json",json.dumps({"version":"24.294"},indent=2)+"\n")
write(
    "CHANGELOG-LATEST.txt",
    """Duckie Days 24.294

Gimmick encounter layout + Sibling Spat fixes

- Fixed the Strange Egg event becoming impossible to use on mobile.
- All six gimmick encounter choices now live in the lower cream battle panel.
- Special encounter artwork stays centered and unobstructed in the battlefield.
- Fixed Artist Friend disappearing when its idle animation started.
- Artist Friend no longer treats Dash Carts as inspiration items.
- Artist Friend supply/recolor lists now scroll in the lower panel instead of covering the battlefield.
- Removed the vertical floating/bobbing from Miko and Miho during Sibling Spat dialogue.
"""
)

# Sanity checks.
g=read("duck-quest/js/gimmick-encounters-v288.js")
assert 'const VERSION="24.294";' in g
assert "function stopSceneAnimation()" in g
assert "ui.eventChoiceActions" in g
assert "gimmick-choice-panel-v294" in g
assert "!String(s.id).startsWith('dash-cart-')" in g
assert "animateScene(frames,speed=470){clearScene()" not in g

dq=read("duck-quest/index.html")
assert 'css/fixes-v294.css?v=24-294' in dq
assert 'js/gimmick-encounters-v288.js?v=24-294' in dq

sw=read("sw.js")
assert "duck-habit-hub-app-v24-294" in sw
assert "./duck-quest/css/fixes-v294.css?v=24-294" in sw
assert "./duck-quest/js/gimmick-encounters-v288.js?v=24-294" in sw
assert json.loads(read("version.json"))["version"]=="24.294"

print("VERIFIED: Duckie Days v24.294 gimmick layout + Sibling Spat fixes.")

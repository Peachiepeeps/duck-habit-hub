Duckie Days v24.295 — Artist Friend + Chest Polish

Changes:
- Artist Friend recolor targets now show Owned: X for every variant.
- Missing target variants show Owned: 0 · Missing.
- The initial Buddy picker also shows quantity owned.
- The 75 Pink Coins button is now large and equal in size to the Paint button.
- Paint buttons show the current paint quantity.
- Added a Back button after opening a Buddy's recolor choices.
- Treasure/reward chest sway/hop is removed in JavaScript and CSS.

Built for live v24.294.

hub.css is NOT touched.

Upload:
1) Duckie-Days-v24.295-artist-friend-and-chest-polish.zip -> repository root
2) install-v24-295.yml -> .github/workflows/

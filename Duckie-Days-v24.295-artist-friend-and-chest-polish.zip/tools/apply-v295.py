
from pathlib import Path
import json

ROOT=Path.cwd()

def read(path):
    return (ROOT/path).read_text(encoding="utf-8")

def write(path,text):
    p=ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding="utf-8")

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"{path}: expected exactly one match, found {count}\nMATCH:\n{old[:500]}")
    write(path,text.replace(old,new,1))

version=json.loads(read("version.json")).get("version")
if version!="24.294":
    raise SystemExit(f"Expected Duckie Days 24.294, found {version!r}")

replace_once(
    "duck-quest/js/game-v96.js",
    '  ui.chestSprite.classList.add("opening");',
    '  ui.chestSprite.classList.remove("opening");'
)
replace_once(
    "duck-quest/js/game-v96.js",
    "    ui.chestSprite.classList.add('opening');",
    "    ui.chestSprite.classList.remove('opening');"
)

replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    '  const VERSION="24.294";',
    '  const VERSION="24.295";'
)

replace_once(
    "duck-quest/js/gimmick-encounters-v288.js",
    """  function paintForVariant(v){const id=String(v||'').toLowerCase();return PAINTS.find(p=>p.id===`${id}-paint`)||null;}""",
    """  function paintForVariant(v){const id=String(v||'').toLowerCase();return PAINTS.find(p=>p.id===`${id}-paint`)||null;}
  function ownedBuddyCount(key){return Math.max(0,Math.floor(Number(hubSave.buddies?.collection?.[key]?.quantity)||0));}"""
)

text=read("duck-quest/js/gimmick-encounters-v288.js")
start=text.index("  function artistRecolor(m){")
end=text.index("  function artistFriend(){",start)

new_func = """  function artistRecolor(m){
    m.querySelector('p').textContent='Artist Friend can recolor one ordinary enemy or boss Buddy. Shinies and special Buddies are never eligible.';
    const entries=eligibleRecolorEntries();
    const a=m.querySelector('.gimmick-actions-v288');
    a.innerHTML='';

    if(!entries.length){
      const n=document.createElement('small');
      n.className='gimmick-empty-v288';
      n.textContent='You do not have an eligible Buddy with another ordinary color available, so Artist Friend offers the inspiration trade instead.';
      a.append(n);
      const swap=document.createElement('button');
      swap.type='button';
      swap.className='pixel-button primary';
      swap.textContent='Trade a Supply for Paint';
      swap.addEventListener('click',()=>artistInspiration(m));
      a.append(swap);
      return;
    }

    const grid=document.createElement('div');
    grid.className='gimmick-item-grid-v288';

    entries.forEach(entry=>{
      const b=document.createElement('button');
      b.type='button';
      b.className='gimmick-item-v288';
      b.innerHTML=`<img src="${entry.image}" alt=""><span>${entry.nickname||entry.name}</span><small>${entry.variantId} · Owned: ${ownedBuddyCount(entry.key)}</small>`;

      b.addEventListener('click',()=>{
        a.innerHTML='';
        const forms=ordinaryRecolorForms(entry.enemyId).filter(f=>f.key!==entry.key);

        forms.forEach(target=>{
          const owned=ownedBuddyCount(target.key);
          const row=document.createElement('div');
          row.className='gimmick-recolor-row-v288';
          if(owned===0)row.classList.add('missing-variant-v295');

          row.innerHTML=`<img src="${target.image}" alt=""><span><strong>${target.name}</strong><small>${target.variantId} · Owned: ${owned}${owned===0?' · Missing':''}</small></span>`;

          const actions=document.createElement('div');
          actions.className='gimmick-recolor-actions-v295';

          const coin=document.createElement('button');
          coin.type='button';
          coin.className='pixel-button small';
          coin.textContent='75 Pink Coins';
          coin.disabled=(Number(hubSave.coins)||0)<75;
          coin.addEventListener('click',()=>{
            if((Number(hubSave.coins)||0)<75)return;
            hubSave.coins-=75;
            if(!recolorInstance(entry,target)){
              hubSave.coins+=75;
              return;
            }
            const card=maybeGrantCard('artist-friend','r-gimmick-artist-friend');
            finish(`Artist Friend recolored your Buddy into ${target.name}!${cardText(card)}`);
          });
          actions.append(coin);

          const paint=paintForVariant(target.variantId);
          if(paint){
            const pb=document.createElement('button');
            pb.type='button';
            pb.className='pixel-button small';
            pb.textContent=`Use ${paint.name} (×${qty(paint.id)})`;
            pb.disabled=qty(paint.id)<1;
            pb.addEventListener('click',()=>{
              if(!removeInventory(paint.id,1))return;
              if(!recolorInstance(entry,target)){
                addInventory(paint.id,1);
                return;
              }
              const card=maybeGrantCard('artist-friend','r-gimmick-artist-friend');
              finish(`Artist Friend used ${paint.name} to recolor your Buddy into ${target.name}!${cardText(card)}`);
            });
            actions.append(pb);
          }else{
            actions.classList.add('single');
          }

          row.append(actions);
          a.append(row);
        });

        const back=document.createElement('button');
        back.type='button';
        back.className='pixel-button';
        back.textContent='Back';
        back.addEventListener('click',()=>artistRecolor(m));
        a.append(back);
      });

      grid.append(b);
    });

    a.append(grid);

    const leave=document.createElement('button');
    leave.type='button';
    leave.className='pixel-button';
    leave.textContent='Leave';
    leave.addEventListener('click',()=>finish('Artist Friend packs up their paints and waves goodbye.'));
    a.append(leave);
  }
"""
text=text[:start]+new_func+text[end:]
write("duck-quest/js/gimmick-encounters-v288.js",text)

replace_once(
    "duck-quest/index.html",
    '  <link rel="stylesheet" href="css/fixes-v294.css?v=24-294">\n',
    '  <link rel="stylesheet" href="css/fixes-v294.css?v=24-294">\n  <link rel="stylesheet" href="css/fixes-v295.css?v=24-295">\n'
)

replace_once(
    "duck-quest/index.html",
    '  <script src="js/game-v96.js?v=24-289"></script>',
    '  <script src="js/game-v96.js?v=24-295"></script>'
)

replace_once(
    "duck-quest/index.html",
    '  <script src="js/gimmick-encounters-v288.js?v=24-294"></script>',
    '  <script src="js/gimmick-encounters-v288.js?v=24-295"></script>'
)

root=read("index.html")
if '24.294' not in root:
    raise SystemExit("Root index is not expected v24.294.")
root=root.replace("24.294","24.295").replace("24-294","24-295")
write("index.html",root)

sw=read("sw.js")
if "duck-habit-hub-app-v24-294" not in sw:
    raise SystemExit("Service worker is not expected v24.294.")
sw=sw.replace("24.294","24.295").replace("24-294","24-295")
needle=" './duck-quest/css/fixes-v294.css?v=24-295',\n"
if needle not in sw:
    raise SystemExit("Could not find fixes-v294 cache entry.")
sw=sw.replace(needle,needle+" './duck-quest/css/fixes-v295.css?v=24-295',\n",1)
write("sw.js",sw)

write("version.json",json.dumps({"version":"24.295"},indent=2)+"\n")
write(
    "CHANGELOG-LATEST.txt",
    """Duckie Days 24.295

Artist Friend + chest polish

- Artist Friend recolor rows now show how many of each Buddy variant are already owned.
- Missing variants are explicitly marked as Owned: 0 · Missing.
- The selected/current Buddy list also shows its owned quantity.
- 75 Pink Coins and Paint payment buttons are now large, equal-width buttons.
- Paint buttons also show how many matching paints are currently owned.
- Added a Back button after choosing a Buddy to recolor.
- Removed the treasure/reward chest opening animation class in JavaScript.
- Added a final CSS safety rule so treasure chests cannot sway/hop even if the opening class is present.
"""
)

g=read("duck-quest/js/gimmick-encounters-v288.js")
assert 'const VERSION="24.295";' in g
assert "function ownedBuddyCount(key)" in g
assert "75 Pink Coins" in g
assert "gimmick-recolor-actions-v295" in g
assert "Use ${paint.name} (×${qty(paint.id)})" in g
assert "back.textContent='Back'" in g

game=read("duck-quest/js/game-v96.js")
assert 'ui.chestSprite.classList.add("opening");' not in game
assert "ui.chestSprite.classList.add('opening');" not in game

dq=read("duck-quest/index.html")
assert 'css/fixes-v295.css?v=24-295' in dq
assert 'js/game-v96.js?v=24-295' in dq
assert 'js/gimmick-encounters-v288.js?v=24-295' in dq

sw=read("sw.js")
assert "duck-habit-hub-app-v24-295" in sw
assert "./duck-quest/css/fixes-v295.css?v=24-295" in sw
assert "./duck-quest/js/game-v96.js?v=24-295" in sw
assert "./duck-quest/js/gimmick-encounters-v288.js?v=24-295" in sw
assert json.loads(read("version.json"))["version"]=="24.295"

print("VERIFIED: Duckie Days v24.295 Artist Friend + chest polish.")

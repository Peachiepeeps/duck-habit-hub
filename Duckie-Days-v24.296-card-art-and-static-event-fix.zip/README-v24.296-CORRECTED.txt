Duckie Days v24.296 — CORRECTED INSTALLER

This replaces the earlier v24.296 ZIP whose installer failed.

The workflow already in GitHub is fine. Only replace/re-upload this MAIN ZIP
to the repository root using the exact same filename.

Fixes:
- Gift Box card artwork layers over the card frame.
- Gift Box opening bounce removed.
- Treasure chests, picnic baskets, fountains and Gift Boxes are static.
- Gift reward cards/packs no longer bump/sway.

Built for live v24.295.
hub.css is NOT touched.

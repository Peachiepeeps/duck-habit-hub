Duckie Days v24.296 — Gift Box Card Art + Static Event Props

Fixes:
- Gift Box card rewards now use the correct card layer order:
  frame behind, sprite/art on top.
- Fixes the blank-looking Mimic/Tulipa/etc reward cards.
- Removes the remaining Gift Box opening bounce.
- Hard-stops chest-layer CSS sway/hop on:
  treasure chests, picnic basket, fountain, Gift Box, etc.
- Gift reward card/pack pop animation is also removed.

Built for live v24.295.
hub.css is NOT touched.

Upload:
1) Duckie-Days-v24.296-card-art-and-static-event-fix.zip -> repository root
2) install-v24-296.yml -> .github/workflows/

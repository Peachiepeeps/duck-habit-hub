
from pathlib import Path
import json

ROOT=Path.cwd()

def read(path):
    return (ROOT/path).read_text(encoding="utf-8")

def write(path,text):
    p=ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding="utf-8")

def replace_once(path,old,new):
    text=read(path)
    count=text.count(old)
    if count!=1:
        raise SystemExit(f"{path}: expected exactly one match, found {count}\nMATCH:\n{old[:500]}")
    write(path,text.replace(old,new,1))

version=json.loads(read("version.json")).get("version")
if version!="24.295":
    raise SystemExit(f"Expected Duckie Days 24.295, found {version!r}")

# Gift Box had its own separate opening bounce path.
replace_once(
    "duck-quest/js/special-encounters-v265.js",
    '    actionLocked=true;ui.openChest.disabled=true;stopGiftAnimation();ui.chestSprite.classList.add("opening");await sleep(260);',
    '    actionLocked=true;ui.openChest.disabled=true;stopGiftAnimation();ui.chestSprite.classList.remove("opening");await sleep(260);'
)

# Load v24.296 CSS last.
replace_once(
    "duck-quest/index.html",
    '  <link rel="stylesheet" href="css/fixes-v295.css?v=24-295">\n',
    '  <link rel="stylesheet" href="css/fixes-v295.css?v=24-295">\n  <link rel="stylesheet" href="css/fixes-v296.css?v=24-296">\n'
)

# Cache-bust the modified special encounter file.
replace_once(
    "duck-quest/index.html",
    '  <script src="js/special-encounters-v265.js?v=24-291"></script>',
    '  <script src="js/special-encounters-v265.js?v=24-296"></script>'
)

root=read("index.html")
if "24.295" not in root:
    raise SystemExit("Root index is not expected v24.295.")
root=root.replace("24.295","24.296").replace("24-295","24-296")
write("index.html",root)

sw=read("sw.js")
if "duck-habit-hub-app-v24-295" not in sw:
    raise SystemExit("Service worker is not expected v24.295.")
sw=sw.replace("24.295","24.296").replace("24-295","24-296")

# Add the new CSS to the app shell.
needle=" './duck-quest/css/fixes-v295.css?v=24-296',\n"
if needle not in sw:
    raise SystemExit("Could not find fixes-v295 cache entry.")
sw=sw.replace(needle,needle+" './duck-quest/css/fixes-v296.css?v=24-296',\n",1)

# special-encounters wasn't previously listed in APP_SHELL, so add it rather
# than trying to replace a nonexistent cache entry.
js_anchor=" './duck-quest/js/task-buddy-boost-v254.js?v=24-255',\n"
if js_anchor not in sw:
    raise SystemExit("Could not find task-buddy cache anchor.")
if "./duck-quest/js/special-encounters-v265.js" not in sw:
    sw=sw.replace(
        js_anchor,
        js_anchor+" './duck-quest/js/special-encounters-v265.js?v=24-296',\n",
        1
    )
else:
    import re
    sw=re.sub(
        r"\./duck-quest/js/special-encounters-v265\.js\?v=[^']+",
        "./duck-quest/js/special-encounters-v265.js?v=24-296",
        sw,
        count=1
    )

write("sw.js",sw)

write("version.json",json.dumps({"version":"24.296"},indent=2)+"\n")
write(
    "CHANGELOG-LATEST.txt",
    """Duckie Days 24.296

Gift Box card art + static chest/event props

- Fixed Gift Box reward card layer order so Buddy/enemy artwork appears over the card frame.
- Correct card layer order now matches the Trading Card book.
- Removed the remaining Gift Box opening bounce class.
- Hard-disabled CSS animation/transition sway on ordinary chest-layer props.
- Treasure chests, picnic baskets, fountains, and Gift Boxes now stay still.
- Gift reward cards and packs no longer bump/sway when they appear.
"""
)

dq=read("duck-quest/index.html")
assert 'css/fixes-v296.css?v=24-296' in dq
assert 'js/special-encounters-v265.js?v=24-296' in dq

special=read("duck-quest/js/special-encounters-v265.js")
gift_block=special[special.index("async function openGiftBox"):special.index("// Start special events")]
assert 'classList.add("opening")' not in gift_block
assert 'classList.remove("opening")' in gift_block

sw=read("sw.js")
assert "duck-habit-hub-app-v24-296" in sw
assert "./duck-quest/css/fixes-v296.css?v=24-296" in sw
assert "./duck-quest/js/special-encounters-v265.js?v=24-296" in sw
assert json.loads(read("version.json"))["version"]=="24.296"

print("VERIFIED: corrected Duckie Days v24.296 installer.")

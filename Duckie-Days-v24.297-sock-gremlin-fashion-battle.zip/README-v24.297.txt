Duckie Days v24.297 — Sock Gremlin Fashion Battle

Built for the attached/current v24.296 repo.

What this adds:
- Sock Gremlin as a rare Miko-only universal-stage gimmick encounter.
- Base/Blue/Pink/Black/Gold/Shiny variants.
- Duck Quest -> Miko Closet -> Sock Gremlin judging -> Continue Duck Quest flow.
- 3 achievable wardrobe prompts generated from currently owned Miko clothing.
- 1–3 heart ratings with progressively better Pink Coin / EXP Candy / card rewards.
- R-047 Sock Gremlin Trading Card.

Porcupin and UFONO are not implemented in this update yet.
hub.css is NOT touched.

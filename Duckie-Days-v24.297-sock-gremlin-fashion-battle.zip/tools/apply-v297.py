from pathlib import Path
import json
ROOT=Path.cwd()
def read(path): return (ROOT/path).read_text(encoding="utf-8")
def write(path,text):
    p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding="utf-8")
def replace_once(path,old,new):
    text=read(path);count=text.count(old)
    if count!=1: raise SystemExit(f"{path}: expected exactly one match, found {count}\n{old[:400]}")
    write(path,text.replace(old,new,1))
version=json.loads(read("version.json")).get("version")
if version!="24.296": raise SystemExit(f"Expected 24.296, found {version!r}")
replace_once("duck-quest/js/gimmick-encounters-v288.js",'  const VERSION="24.295";','  const VERSION="24.297";')
replace_once("duck-quest/js/gimmick-encounters-v288.js",'  const GIMMICKS=["rotten-egg","lucky-cat","ghost-girl","pippa","artist-friend","angy-duck"];','  const GIMMICKS=["rotten-egg","lucky-cat","ghost-girl","pippa","artist-friend","angy-duck","sock-gremlin"];')
replace_once("duck-quest/js/gimmick-encounters-v288.js","  function show(encounter){prep(encounter);const kind=encounter.gimmick;state().stats[kind]=Math.max(0,Number(state().stats[kind])||0)+1;persistAll();if(kind==='rotten-egg')rottenEgg();else if(kind==='lucky-cat')luckyCat();else if(kind==='ghost-girl')ghostGirl();else if(kind==='pippa')pippa();else if(kind==='artist-friend')artistFriend();else angyDuck();}","  function show(encounter){prep(encounter);const kind=encounter.gimmick;state().stats[kind]=Math.max(0,Number(state().stats[kind])||0)+1;persistAll();if(kind==='rotten-egg')rottenEgg();else if(kind==='lucky-cat')luckyCat();else if(kind==='ghost-girl')ghostGirl();else if(kind==='pippa')pippa();else if(kind==='artist-friend')artistFriend();else if(kind==='sock-gremlin')window.DuckieSockGremlinV297?.show?.({animateScene,menu,button,finish});else angyDuck();}")
replace_once("duck-quest/js/gimmick-encounters-v288.js","      const result=oldBuild.apply(this,arguments);if(result?.type!=='enemy')return result;if(generationCooldown>0){generationCooldown--;return result;}if(Math.random()>=currentGimmickRate())return result;generationCooldown=COOLDOWN_NORMAL_ENCOUNTERS;return {type:'gimmick',gimmick:pick(GIMMICKS)};","      const result=oldBuild.apply(this,arguments);if(result?.type!=='enemy')return result;if(generationCooldown>0){generationCooldown--;return result;}if(Math.random()>=currentGimmickRate())return result;generationCooldown=COOLDOWN_NORMAL_ENCOUNTERS;const pool=activeCharacterId==='miko'?GIMMICKS:GIMMICKS.filter(id=>id!=='sock-gremlin');return {type:'gimmick',gimmick:pick(pool)};")
replace_once("index.html",'  <link rel="stylesheet" href="task-reminders.css?v=24.296" />','  <link rel="stylesheet" href="task-reminders.css?v=24.296" />\n  <link rel="stylesheet" href="sock-gremlin-v297.css?v=24.297" />')
replace_once("index.html",'  <script src="trading-cards-gimmicks-v288.js?v=24.296"></script>','  <script src="trading-cards-gimmicks-v288.js?v=24.296"></script>\n  <script src="trading-cards-sock-gremlin-v297.js?v=24.297"></script>')
replace_once("index.html",'  <script src="hub.js?v=24.296"></script>','  <script src="hub.js?v=24.296"></script>\n  <script src="sock-gremlin-fashion-v297.js?v=24.297"></script>')
replace_once("duck-quest/index.html",'  <link rel="stylesheet" href="css/fixes-v296.css?v=24-296">','  <link rel="stylesheet" href="css/fixes-v296.css?v=24-296">\n  <link rel="stylesheet" href="../sock-gremlin-v297.css?v=24.297">')
replace_once("duck-quest/index.html",'  <script src="../trading-cards-gimmicks-v288.js?v=24.288"></script>','  <script src="../trading-cards-gimmicks-v288.js?v=24.288"></script>\n  <script src="../trading-cards-sock-gremlin-v297.js?v=24.297"></script>')
replace_once("duck-quest/index.html",'  <script src="js/gimmick-encounters-v288.js?v=24-295"></script>','  <script src="js/gimmick-encounters-v288.js?v=24-297"></script>\n  <script src="js/sock-gremlin-v297.js?v=24-297"></script>')
root=read("index.html").replace('content="24.296"','content="24.297"').replace('const DUCK_HUB_BUILD = "24.296";','const DUCK_HUB_BUILD = "24.297";').replace('./sw.js?v=24-296','./sw.js?v=24-297');write("index.html",root)
sw=read("sw.js")
if "duck-habit-hub-app-v24-296" not in sw: raise SystemExit("Unexpected SW base")
sw=sw.replace("duck-habit-hub-app-v24-296","duck-habit-hub-app-v24-297")
for anchor,entry in [
(" './task-reminders.css?v=24.296',\n"," './sock-gremlin-v297.css?v=24.297',\n"),
(" './trading-cards-gimmicks-v288.js?v=24.296',\n"," './trading-cards-sock-gremlin-v297.js?v=24.297',\n"),
(" './hub.js?v=24.296',\n"," './sock-gremlin-fashion-v297.js?v=24.297',\n")]:
    if anchor not in sw: raise SystemExit(f"Missing SW anchor {anchor}")
    sw=sw.replace(anchor,anchor+entry,1)
qanchor=" './duck-quest/js/gimmick-encounters-v288.js?v=24-296',\n"
if qanchor not in sw: raise SystemExit("Missing gimmick SW anchor")
sw=sw.replace(qanchor," './duck-quest/js/gimmick-encounters-v288.js?v=24-297',\n './duck-quest/js/sock-gremlin-v297.js?v=24-297',\n",1)
asset_anchor=" './duck-quest/assets/gimmicks/shiny-egg.png'\n"
if asset_anchor not in sw: raise SystemExit("Missing asset anchor")
assets=[]
for variant in ["base","blue","pink","black","gold","shiny"]:
  for file in ["idle-1.png","idle-2.png","hurt.png"]: assets.append(f" './duck-quest/assets/gimmicks/sock-gremlin/{variant}/{file}',")
sw=sw.replace(asset_anchor," './duck-quest/assets/gimmicks/shiny-egg.png',\n"+"\n".join(assets)+"\n",1);write("sw.js",sw)
write("version.json",json.dumps({"version":"24.297"},indent=2)+"\n")
changelog="""Duckie Days 24.297

Sock Gremlin Fashion Battle

- Added Sock Gremlin as a seventh equal-weight gimmick encounter while playing Duck Quest as Miko.
- Sock Gremlin can appear in any normal stage through the existing rare gimmick roll and shared cooldown.
- Added Base, Blue, Pink, Black, Gold, and Shiny Sock Gremlin art.
- Accepting its challenge safely suspends the current Duck Quest run and transports the player to Miko's Closet.
- The challenge generates three basic style prompts only from Miko wardrobe tags that are achievable with currently owned clothing.
- A Done button scores the finished outfit from 1–3 hearts and returns to the exact Duck Quest run.
- Higher ratings grant better Pink Coin rewards, better EXP Candy chances, and better odds for the Sock Gremlin Trading Card.
- The judge screen requires Continue before advancing to the next encounter/floor, so the run is never discarded.
- Added Rare card R-047: Sock Gremlin.
"""
write("CHANGELOG-LATEST.txt",changelog)
assert json.loads(read("version.json"))["version"]=="24.297"
assert 'sock-gremlin-fashion-v297.js?v=24.297' in read("index.html")
assert 'js/sock-gremlin-v297.js?v=24-297' in read("duck-quest/index.html")
g=read("duck-quest/js/gimmick-encounters-v288.js");assert '"sock-gremlin"' in g and "activeCharacterId==='miko'" in g
sw=read("sw.js");assert "duck-habit-hub-app-v24-297" in sw and "./duck-quest/js/sock-gremlin-v297.js?v=24-297" in sw
print("VERIFIED: Duckie Days v24.297 Sock Gremlin Fashion Battle.")

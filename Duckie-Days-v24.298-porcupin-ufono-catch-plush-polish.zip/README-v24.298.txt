Duckie Days v24.298 — Porcupin + UFONO + Catch + Plush Shelf Polish

Built on v24.297.

Adds:
- Porcupin as a universal normal Duck Quest enemy with base/white/black/green/gold/shiny forms.
- Porcupin cozy bonus drops: mostly bonus coins, with rare Warm Blanket, Plush Duck, Knitted Duck, Porcupin card, or Task Shop plush.
- UFONO as a rare gimmick encounter. It randomly beams the player into Memory Match, Duck Sort, or Duck Crane.
- UFONO challenge mode suppresses the minigame's normal reward; finishing the challenge returns to the exact Duck Quest run and gives UFONO's own reward.
- UFONO rewards can be Pink Coins, Small/Large EXP Candy, Alien Duck, Cosmic Duck, or R-049 UFONO card.
- Sock Gremlin and UFONO now offer one Buddy Pon catch attempt after the minigame/reward scene, preserving color/shiny variants.
- Porcupin can already be caught using normal Duck Quest Buddy Pon mechanics.
- R-048 Porcupin and R-049 UFONO cards.
- Task collectible plushes are slightly larger on their shelf.

For now, captured Porcupin / Sock Gremlin / UFONO families are listed in the Meadow Buddy Book tab so they are visible without adding a whole new Universal tab yet.

hub.css is NOT changed.

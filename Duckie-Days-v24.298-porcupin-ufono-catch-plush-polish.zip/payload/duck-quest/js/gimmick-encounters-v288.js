// Duckie Days v24.288 — Rare Gimmick Encounters
(function(){
  "use strict";
  const TC=window.DuckieTradingCards;
  const VERSION="24.298";
  const GIMMICK_RATE=.04;
  function currentGimmickRate(){
    try{
      const wonder=typeof activeCharmByFamily==="function"?activeCharmByFamily("wonder"):null;
      return Math.max(GIMMICK_RATE,Math.min(.10,Number(wonder?.eventRate)||GIMMICK_RATE));
    }catch(error){return GIMMICK_RATE;}
  }
  const COOLDOWN_NORMAL_ENCOUNTERS=4;
  const BASE_CARD_CHANCE=.08;
  const PITY=5;
  const GIMMICKS=["rotten-egg","lucky-cat","ghost-girl","pippa","artist-friend","angy-duck","sock-gremlin","ufono"];
  const FOODS=[{"id":"bread-loaf","name":"Bread Loaf","image":"../assets/food/Bread-loaf.webp","price":60},{"id":"apple","name":"Apple","image":"../assets/food/apple.webp","price":50},{"id":"burger","name":"Burger","image":"../assets/food/Burger.webp","price":75},{"id":"cake-slice","name":"Cake Slice","image":"../assets/food/Cake-slice.webp","price":75},{"id":"cake","name":"Cake","image":"../assets/food/Cake.webp","price":100},{"id":"champagne","name":"Champagne","image":"../assets/food/Champagne.webp","price":125},{"id":"chocolate-brioche","name":"Chocolate Brioche","image":"../assets/food/Chocolate-brioche.webp","price":125},{"id":"concha","name":"Concha","image":"../assets/food/Concha.webp","price":90},{"id":"cookie","name":"Cookie","image":"../assets/food/Cookie.webp","price":50},{"id":"croissant","name":"Croissant","image":"../assets/food/Croissant.webp","price":75},{"id":"cupcake","name":"Cupcake","image":"../assets/food/Cupcake.webp","price":75},{"id":"fancy-milk-tea","name":"Fancy Milk Tea","image":"../assets/food/Fancy-milk-tea.webp","price":90},{"id":"fruit-cup","name":"Fruit Cup","image":"../assets/food/Fruit-cup.webp","price":60},{"id":"fruit-tart","name":"Fruit Tart","image":"../assets/food/Fruit-tart.webp","price":75},{"id":"gummy-bear","name":"Gummy Bear","image":"../assets/food/Gummy-bear.webp","price":50},{"id":"lemon","name":"Lemon","image":"../assets/food/Lemon.webp","price":50},{"id":"lime","name":"Lime","image":"../assets/food/Lime.webp","price":50},{"id":"lollipop","name":"Lollipop","image":"../assets/food/Lollipop.webp","price":50},{"id":"milk-tea","name":"Milk Tea","image":"../assets/food/Milk-tea.webp","price":60},{"id":"milk","name":"Milk","image":"../assets/food/Milk.webp","price":50},{"id":"mushroom","name":"Mushroom","image":"../assets/food/Mushroom.webp","price":60},{"id":"parfait","name":"Parfait","image":"../assets/food/Parfait.webp","price":125},{"id":"pizza","name":"Pizza","image":"../assets/food/Pizza.webp","price":75},{"id":"pudding","name":"Pudding","image":"../assets/food/Pudding.webp","price":60},{"id":"strawberry-shortcake","name":"Strawberry Shortcake","image":"../assets/food/Strawberry-shortcake.webp","price":90},{"id":"strawberry","name":"Strawberry","image":"../assets/food/Strawberry.webp","price":50},{"id":"water","name":"Water","image":"../assets/food/Water.webp","price":50},{"id":"watermelon","name":"Watermelon","image":"../assets/food/Watermelon.webp","price":60},{"id":"wedding-cake","name":"Wedding Cake","image":"../assets/food/Wedding-cake.webp","price":150}];
  const SUPPLIES=[{"id":"standard-duck","name":"Standard Duck","image":"../assets/ducks/Standard-duck.webp"},{"id":"dash-cart-pink","name":"Pink Dash Cart","image":"assets/dash/carts/Duck-car-pink.png"},{"id":"dash-cart-mint","name":"Mint Dash Cart","image":"assets/dash/carts/Duck-car-mint.png"},{"id":"dash-cart-purple","name":"Purple Dash Cart","image":"assets/dash/carts/Duck-car-purple.png"},{"id":"dash-cart-black","name":"Black Dash Cart","image":"assets/dash/carts/Duck-car-black.png"},{"id":"sunglasses","name":"Sunglasses","image":"../assets/gifts/Sunglasses.webp"},{"id":"yarn","name":"Yarn","image":"../assets/ingredients/Yarn.webp"},{"id":"thread","name":"Thread","image":"../assets/ingredients/Thread.webp"},{"id":"party-hat","name":"Party Hat","image":"../assets/gifts/Party-hat.webp"},{"id":"knife","name":"Knife","image":"../assets/gifts/Knife.webp"},{"id":"game-controller","name":"Game Controller","image":"../assets/gifts/Gaming-controller.webp"},{"id":"pill","name":"Pill","image":"../assets/gifts/Pill.webp"},{"id":"ufo","name":"UFO","image":"../assets/gifts/UFO.webp"},{"id":"pocket-monster-ball","name":"Pocket Monster Ball","image":"../assets/gifts/Pocket-monster-ball.webp"},{"id":"jester-bell","name":"Jester Bell","image":"../assets/gifts/Jester-bell.webp"},{"id":"crown","name":"Crown","image":"../assets/gifts/Crown.webp"},{"id":"magical-girl-pendant","name":"Magical Girl Pendant","image":"../assets/gifts/Magical-girl-pendant.webp"},{"id":"bunny-ears","name":"Bunny Ears","image":"../assets/gifts/Bunny-ears.webp"},{"id":"flower","name":"Flower","image":"../assets/gifts/Flower.webp"},{"id":"sleep-mask","name":"Sleep Mask","image":"../assets/gifts/Sleep-mask.webp"},{"id":"paintbrush","name":"Paintbrush","image":"../assets/gifts/Paint-brush.webp"},{"id":"ghost","name":"Ghost","image":"../assets/ingredients/Ghost.webp"},{"id":"demon-wing","name":"Demon Wing","image":"../assets/ingredients/Demon-wing.webp"},{"id":"angel-wing","name":"Angel Wing","image":"../assets/ingredients/Angel-wing.webp"},{"id":"glitter","name":"Glitter","image":"../assets/ingredients/Sparkle.webp"},{"id":"cat-ears","name":"Cat Ears","image":"../assets/gifts/Cat-ears.webp"},{"id":"moon","name":"Moon","image":"../assets/ingredients/Moon.webp"},{"id":"mustache","name":"Mustache","image":"../assets/gifts/Mustache.webp"},{"id":"top-hat","name":"Top Hat","image":"../assets/gifts/Top-hat.webp"},{"id":"bow","name":"Bow","image":"../assets/gifts/Bow.webp"},{"id":"googly-eyes","name":"Googly Eyes","image":"../assets/ingredients/googly-eyes.webp"},{"id":"scarf","name":"Scarf","image":"../assets/ingredients/scarf.webp"},{"id":"skateboard","name":"Skateboard","image":"../assets/ingredients/skateboard.webp"},{"id":"wig","name":"Wig","image":"../assets/ingredients/wig.webp"},{"id":"eyebrows","name":"Eyebrows","image":"../assets/ingredients/eyebrows.webp"},{"id":"vampire-teeth","name":"Vampire Teeth","image":"../assets/ingredients/vampire-teeth.webp"},{"id":"bathtub","name":"Bathtub","image":"../assets/ingredients/bathtub.webp"}];
  const PAINTS=[{"id":"red-paint","name":"Red Paint"},{"id":"dark-red-paint","name":"Dark Red Paint"},{"id":"magenta-paint","name":"Magenta Paint"},{"id":"orange-paint","name":"Orange Paint"},{"id":"peach-paint","name":"Peach Paint"},{"id":"gold-paint","name":"Gold Paint"},{"id":"silver-paint","name":"Silver Paint"},{"id":"bronze-paint","name":"Bronze Paint"},{"id":"green-paint","name":"Green Paint"},{"id":"mint-paint","name":"Mint Paint"},{"id":"aqua-paint","name":"Aqua Paint"},{"id":"sky-blue-paint","name":"Sky Blue Paint"},{"id":"blue-paint","name":"Blue Paint"},{"id":"periwinkle-paint","name":"Periwinkle Paint"},{"id":"purple-paint","name":"Purple Paint"},{"id":"violet-paint","name":"Violet Paint"},{"id":"pink-paint","name":"Pink Paint"},{"id":"white-paint","name":"White Paint"},{"id":"grey-paint","name":"Grey Paint"},{"id":"black-paint","name":"Black Paint"},{"id":"rainbow-paint","name":"Rainbow Paint"}];
  const REGULAR_DUCKS=[["standard-duck","Standard Duck"],["angry-duck","Angry Duck"],["apple-duck","Apple Duck"],["bathtime-duck","Bathtime Duck"],["duck-on-skateboard","Duck on a Skateboard"],["googly-eye-duck","Googly Eye Duck"],["long-hair-duck","Long Hair Duck"],["magenta-duck","Magenta Duck"],["scarf-duck","Scarf Duck"],["vampire-duck","Vampire Duck"],["alien-duck","Alien Duck"],["angel-duck","Angel Duck"],["aqua-duck","Aqua Duck"],["artist-duck","Artist Duck"],["black-duck","Black Duck"],["blue-duck","Blue Duck"],["bow-duck","Bow Duck"],["bronze-duck","Bronze Duck"],["bunny-duck","Bunny Duck"],["burger-duck","Burger Duck"],["cat-duck","Cat Duck"],["cool-duck","Cool Duck"],["cosmic-duck","Cosmic Duck"],["cupcake-duck","Cupcake Duck"],["dark-red-duck","Dark Red Duck"],["demon-duck","Demon Duck"],["doctor-duck","Doctor Duck"],["duck-with-a-knife","Duck with a Knife"],["duckvee","Duckvee"],["fancy-duck","Fancy Duck"],["flower-duck","Flower Duck"],["gamer-duck","Gamer Duck"],["ghost-duck","Ghost Duck"],["glitter-duck","Glitter Duck"],["golden-duck","Golden Duck"],["green-duck","Green Duck"],["grey-duck","Grey Duck"],["gummy-duck","Gummy Duck"],["jester-duck","Jester Duck"],["kidcore-duck","Kidcore Duck"],["king-duck","King Duck"],["knitted-duck","Knitted Duck"],["lemon-duck","Lemon Duck"],["lime-duck","Lime Duck"],["magical-girl-duck","Magical Girl Duck"],["mint-duck","Mint Duck"],["mushroom-duck","Mushroom Duck"],["orange-duck","Orange Duck"],["party-hat-duck","Party Hat Duck"],["peach-duck","Peach Duck"],["periwinkle-duck","Periwinkle Duck"],["pink-duck","Pink Duck"],["pizza-duck","Pizza Duck"],["plush-duck","Plush Duck"],["pompompurin-duck","Pompompurin Duck"],["purple-duck","Purple Duck"],["rainbow-duck","Rainbow Duck"],["red-duck","Red Duck"],["silver-duck","Silver Duck"],["sky-blue-duck","Sky Blue Duck"],["sleepy-time-duck","Sleepy Time Duck"],["strawberry-duck","Strawberry Duck"],["top-hat-duck","Top Hat Duck"],["violet-duck","Violet Duck"],["watermelon-duck","Watermelon Duck"],["white-duck","White Duck"]];
  const SPECIAL_DUCK_NAMES={"quin-duck":"Quin Duck","circe-duck":"Circe Duck","westley-duck":"Westley Duck","yuzuru-duck":"Yuzuru Duck","devlin-duck":"Devlin Duck","hibiki-duck":"Hibiki Duck","cheryln-duck":"Cheryln Duck","shinobu-duck":"Shinobu Duck","lukio-duck":"Lukio Duck","pile-of-tiny-ducks":"Pile of Tiny Ducks","goose":"Goose","miko-duck":"Miko Duck","io-duck":"Io Duck","miho-duck":"Miho Duck","annika-duck":"Annika Duck","peep-duck":"Peep Duck","tiny-duck-stack":"Tiny Duck Stack","tiny-duck":"Tiny Duck"}; const SPECIAL_DUCK_IDS=new Set(Object.keys(SPECIAL_DUCK_NAMES));
  const CHAR_NAMES={peep:"Peep",miko:"Miko",io:"Io",miho:"Miho",annika:"Annika"};
  const NORMAL_VARIANTS={"rotten-egg":["base","rare"],"lucky-cat":["base","blue","green","pink","purple"],"angy-duck":["base","blue","green","pink","purple"]};
  const SPECIAL_BUDDY_IDS=new Set(["mimic","plushbun","gift-mimic","rotten-egg","lucky-cat","angy-duck"]);
  let generationCooldown=0,sceneTimer=null,activeBattle=null;

  function pick(list){return list[Math.floor(Math.random()*list.length)];}
  function randInt(a,b){return Math.floor(a+Math.random()*(b-a+1));}
  function state(){
    if(!hubSave.gimmicksV288||typeof hubSave.gimmicksV288!=="object"||Array.isArray(hubSave.gimmicksV288))hubSave.gimmicksV288={};
    const s=hubSave.gimmicksV288;
    if(!s.cardPity||typeof s.cardPity!=="object")s.cardPity={};
    if(!s.stats||typeof s.stats!=="object")s.stats={};
    return s;
  }
  function addInventory(id,qty=1){if(!hubSave.inventory||typeof hubSave.inventory!=="object")hubSave.inventory={};hubSave.inventory[id]=Math.max(0,Number(hubSave.inventory[id])||0)+Math.max(1,Math.floor(Number(qty)||1));}
  function removeInventory(id,qty=1){const n=Math.max(1,Math.floor(Number(qty)||1)),have=Math.max(0,Number(hubSave.inventory?.[id])||0);if(have<n)return false;const left=have-n;if(left)hubSave.inventory[id]=left;else delete hubSave.inventory[id];return true;}
  function qty(id){return Math.max(0,Math.floor(Number(hubSave.inventory?.[id])||0));}
  function addCoins(amount){const n=Math.max(0,Math.floor(Number(amount)||0));hubSave.coins=Math.max(0,Number(hubSave.coins)||0)+n;if(currentRun)currentRun.coinsEarned=Math.max(0,Number(currentRun.coinsEarned)||0)+n;return n;}
  function addDuck(duckId){
    if(!duckId)return null;if(!Array.isArray(hubSave.unlockedDucks))hubSave.unlockedDucks=[];if(!hubSave.duckCollectionCounts||typeof hubSave.duckCollectionCounts!=="object")hubSave.duckCollectionCounts={};
    if(!hubSave.unlockedDucks.includes(duckId))hubSave.unlockedDucks.push(duckId);
    hubSave.duckCollectionCounts[duckId]=Math.max(0,Number(hubSave.duckCollectionCounts[duckId])||0)+1;return duckId;
  }
  function cardForBattle(enemy){
    if(!enemy)return null;const id=String(enemy.id||""),variant=enemy.shiny?"shiny":String(enemy.gimmickVariant||enemyVariantId(enemy)||"base");
    if(id==="rotten-egg")return variant==="shiny"?"r-gimmick-rotten-egg-shiny":`u-gimmick-rotten-egg-${variant}`;
    if(id==="lucky-cat")return variant==="shiny"?"r-gimmick-lucky-cat-shiny":`u-gimmick-lucky-cat-${variant}`;
    if(id==="angy-duck")return variant==="shiny"?"r-gimmick-angy-duck-shiny":`u-gimmick-angy-duck-${variant}`;
    return null;
  }
  function maybeGrantCard(family,cardId,chance=BASE_CARD_CHANCE){
    if(!TC?.byId?.[cardId])return null;const s=state(),owned=Math.max(0,Number(TC.ensureState(hubSave)?.owned?.[cardId])||0);let counter=Math.max(0,Math.floor(Number(s.cardPity[family])||0))+1;
    const win=Math.random()<Math.max(0,Math.min(1,chance))||counter>=PITY;
    if(!win){s.cardPity[family]=counter;persistAll();return null;}
    const result=TC.grantCard(hubSave,cardId,1);s.cardPity[family]=0;persistAll();return result;
  }
  function cardText(result){return result?` · ${result.isNew?"NEW ":""}${result.card.name} card!`:"";}

  function stopSceneAnimation(){if(sceneTimer){clearInterval(sceneTimer);sceneTimer=null;}}
  function clearScene(){
    stopSceneAnimation();
    ui.chestLayer?.querySelector('#gimmickMenuV288')?.remove();
    ui.eventChoiceActions?.querySelector('#gimmickMenuV288')?.remove();
    ui.chestLayer?.classList.remove('gimmick-active-v288');
    ui.chestSprite?.classList.remove('gimmick-art-v288','gimmick-egg-art-v288');
    ui.battlefield?.classList.remove('gimmick-scene-v294');
    ui.battleUi?.classList.remove('gimmick-ui-v294');
    if(ui.eventChoiceActions){
      ui.eventChoiceActions.classList.remove('gimmick-choice-panel-v294');
      ui.eventChoiceActions.innerHTML='';
      ui.eventChoiceActions.classList.add('hidden');
    }
  }
  function animateScene(frames,speed=470){
    stopSceneAnimation();
    if(!ui.chestSprite||!frames?.length)return;
    ui.chestSprite.classList.remove('gimmick-egg-art-v288');
    ui.chestSprite.classList.add('gimmick-art-v288');
    let i=0;
    ui.chestSprite.src=frames[0];
    sceneTimer=setInterval(()=>{i=(i+1)%frames.length;if(ui.chestSprite)ui.chestSprite.src=frames[i];},speed);
  }
  function prep(encounter){
    try{clearAnimations();}catch{}clearScene();actionLocked=false;pendingChest=null;pendingDefeatedEnemy=null;befriendAttempted=false;
    ui.befriendPanel?.classList.add('hidden');ui.ponPurchasePanel?.classList.add('hidden');try{resetDoubleBattleUi();}catch{}try{hideEventChoices();}catch{}
    ui.enemyCombatant?.classList.add('hidden');ui.enemyCombatant2?.classList.add('hidden');ui.buddyCombatant?.classList.add('hidden');ui.commandGrid?.classList.add('hidden');try{closeCommandWindow();}catch{}
    ui.battlefield?.classList.add('gimmick-scene-v294');ui.battleUi?.classList.add('gimmick-ui-v294');
    ui.chestLayer?.classList.remove('hidden');ui.chestLayer?.classList.add('gimmick-active-v288');ui.chestSprite?.classList.add('gimmick-art-v288');ui.openChest?.classList.add('hidden');ui.postFloorActions?.classList.add('hidden');ui.leaveEndlessButton?.classList.add('hidden');try{setPostFloorLayout(false);}catch{}
    if(currentRun?.mode==='endless'){currentRun.rank=endlessEffectiveRank(currentRun.floor);if(!currentRun.floorBackground)currentRun.floorBackground=chooseEndlessBackground();ui.battleBg.src=currentRun.floorBackground;}else if(currentRun){const cfg=currentAreaConfig();ui.battleBg.src=cfg.backgrounds[currentRun.index];}
    updateEncounterHeader(encounter);if(ui.peepLevelCombat)ui.peepLevelCombat.textContent=`Lv. ${activeHeroProgress().level}`;try{renderPeepHp();startPeepIdle();}catch{}
  }
  function menu(title,copy){
    ui.chestLayer?.querySelector('#gimmickMenuV288')?.remove();
    const holder=ui.eventChoiceActions;
    if(!holder)return document.createElement('div');
    holder.innerHTML='';
    holder.classList.add('gimmick-choice-panel-v294');
    holder.classList.remove('hidden');
    ui.battleUi?.classList.add('gimmick-ui-v294');
    const m=document.createElement('div');
    m.id='gimmickMenuV288';
    m.className='gimmick-menu-v288';
    m.innerHTML=`<strong>${title}</strong><p>${copy}</p><div class="gimmick-actions-v288"></div>`;
    holder.append(m);
    return m;
  }
  function button(parent,label,fn,cls=''){const b=document.createElement('button');b.type='button';b.className=`pixel-button ${cls}`.trim();b.textContent=label;b.addEventListener('click',fn);parent.querySelector('.gimmick-actions-v288')?.append(b);return b;}
  function finish(message){
    clearScene();ui.chestLayer?.classList.add('hidden');ui.openChest?.classList.add('hidden');ui.enemyCombatant?.classList.add('hidden');ui.enemyCombatant2?.classList.add('hidden');ui.buddyCombatant?.classList.add('hidden');ui.commandGrid?.classList.add('hidden');setMessage(message);
    if(currentRun?.mode==='endless')markEndlessFloorComplete();ui.continueButton.textContent=currentRun?.mode==='endless'?"Next Floor":"Continue";ui.postFloorActions?.classList.remove('hidden');ui.leaveEndlessButton?.classList.toggle('hidden',currentRun?.mode!=='endless');try{setPostFloorLayout(true);}catch{}actionLocked=false;activeBattle=null;persistAll();try{renderMeta();renderBuddyHomeCount();refreshFeatureBadges();}catch{}
  }
  function beginBattle(enemyId,variantId,forceShiny,kind){
    clearScene();ui.chestLayer?.classList.add('hidden');activeBattle={kind,enemyId,variantId,forceShiny:Boolean(forceShiny)};startEnemy(enemyId,{gimmickVariant:variantId,forceShiny:Boolean(forceShiny)});
  }

  function grantFriendlyBuddy(){
    const pool=BUDDY_CATALOG.filter(e=>!e.shiny&&!e.boss&&!SPECIAL_BUDDY_IDS.has(e.enemyId));const entry=pick(pool);if(!entry)return null;
    const enemy={id:entry.enemyId,name:entry.name,idle:Array.isArray(entry.idle)?entry.idle.slice():[entry.image],hurt:entry.image,shiny:false,boss:false,gimmickVariant:entry.variantId};
    try{animateBuddyPon(BUDDY_PONS[0]);}catch{}const buddy=captureBuddy(enemy);renderBuddyHomeCount();return {entry,buddy};
  }
  function rottenEgg(){
    ui.chestCaption.textContent='A strange egg is sitting here...';ui.chestSprite.src='assets/eggs/Common-egg.png';ui.chestSprite.classList.remove('gimmick-art-v288');ui.chestSprite.classList.add('gimmick-egg-art-v288');
    setMessage('There is an egg sitting all by itself. It feels... a little suspicious.');const m=menu('A Strange Egg','Do you want to incubate it right now, or leave it alone and take a regular egg with you?');
    button(m,'Incubate it!',async()=>{m.querySelectorAll('button').forEach(b=>b.disabled=true);const r=Math.random();if(r<.50){const got=grantFriendlyBuddy();finish(got?`The egg hatched instantly! ${got.entry.name} popped out in a Basic Buddy Pon and became your Buddy!`:'The egg gave a little wiggle... but nothing happened.');return;}if(r<.94){const variant=Math.random()<.20?'rare':'base';beginBattle('rotten-egg',variant,false,'rotten-egg');return;}if(r<.97){addInventory('shiny-egg',1);finish('The egg glowed brilliantly... You found a Shiny Egg! ✨ It will hatch a guaranteed random Shiny Buddy after 24 hours.');return;}beginBattle('rotten-egg','base',true,'rotten-egg');});
    button(m,'Leave it!',()=>{addInventory('common-egg',1);finish('You decide not to risk it. A Common Egg was safely added to your inventory.');});
  }
  function luckyCat(){
    const shiny=Math.random()<currentShinyRate(),variant=shiny?'shiny':pick(NORMAL_VARIANTS['lucky-cat']);const path=shiny?'shiny':variant;animateScene([`assets/gimmicks/lucky-cat/${path}/idle-1.png`,`assets/gimmicks/lucky-cat/${path}/idle-2.png`]);ui.chestCaption.textContent=shiny?'Shiny Lucky Cat ✨':'Lucky Cat';setMessage('A Lucky Cat blocks the way and jingles a coin at you.');const m=menu(shiny?'A Shiny Lucky Cat!':'Lucky Cat','Battle it for a random coin reward, try to befriend it in battle, or hand over 10 Pink Coins for a luck gamble.');
    button(m,'Battle!',()=>beginBattle('lucky-cat',shiny?'base':variant,shiny,'lucky-cat'));
    const gamble=button(m,'Give 10 Coins',()=>{if((Number(hubSave.coins)||0)<10)return;hubSave.coins-=10;const r=Math.random(),won=r<.55?10:r<.85?50:r<.99?100:1000;addCoins(won);const card=maybeGrantCard('lucky-cat',shiny?'r-gimmick-lucky-cat-shiny':`u-gimmick-lucky-cat-${variant}`);finish(`Lucky Cat accepts your coins... and gives you ${won.toLocaleString()} Pink Coins!${won===1000?' JACKPOT!! ✨':''}${cardText(card)}`);});gamble.disabled=(Number(hubSave.coins)||0)<10;
    button(m,'Leave',()=>finish('Lucky Cat waves its paw as you continue on.'));
  }
  function foodCardChance(food){const p=Number(food?.price)||50;return p>=125?.20:p>=75?.10:.05;}
  function ghostGirl(){
    animateScene(['assets/gimmicks/ghost-girl/idle-1.png','assets/gimmicks/ghost-girl/idle-2.png']);ui.chestCaption.textContent='Hungry Ghost Girl';setMessage('A hungry Ghost Girl drifts closer and stares at your snacks...');const m=menu('Ghost Girl','She looks hungry. Choose any Food item from your inventory to share with her. Better treats have a better chance of earning her Rare card.');const owned=FOODS.filter(f=>qty(f.id)>0);const a=m.querySelector('.gimmick-actions-v288');
    if(!owned.length){const note=document.createElement('small');note.className='gimmick-empty-v288';note.textContent='You do not have any food right now.';a.append(note);}else{const grid=document.createElement('div');grid.className='gimmick-item-grid-v288';owned.forEach(food=>{const b=document.createElement('button');b.type='button';b.className='gimmick-item-v288';b.innerHTML=`<img src="${food.image}" alt=""><span>${food.name}</span><small>×${qty(food.id)}</small>`;b.addEventListener('click',()=>{if(!removeInventory(food.id,1))return;const reward=pick(FOODS);addInventory(reward.id,1);ui.chestSprite.src='assets/gimmicks/ghost-girl/happy.png';const card=maybeGrantCard('ghost-girl','r-gimmick-ghost-girl',foodCardChance(food));finish(`Ghost Girl happily eats the ${food.name}! She gives you ${reward.name} in return.${cardText(card)}`);});grid.append(b);});a.append(grid);}
    button(m,'Leave',()=>finish('Ghost Girl gives a tiny wave as you continue.'));
  }
  function pippa(){
    animateScene(['assets/gimmicks/pippa/idle-1.png','assets/gimmicks/pippa/idle-2.png']);ui.chestCaption.textContent='Pippa';const name=CHAR_NAMES[activeCharacterId]||heroDisplayName();setMessage(`Pippa rushes over with a letter addressed to ${name}!`);const m=menu('Special Delivery! ',`Pippa has brought ${name} a Love Letter. Give it to ${name} back at the Hub for +50 Happiness.`);button(m,'Accept Letter',()=>{addInventory(`love-letter-${activeCharacterId}`,1);ui.chestSprite.src='assets/gimmicks/pippa/delivered.png';const card=maybeGrantCard('pippa','r-gimmick-pippa');finish(`Pippa delivered ${name}'s Love Letter! 💌${cardText(card)}`);},'primary');button(m,'Leave',()=>finish('Pippa keeps the letter safe for another time.'));
  }
  function ordinaryRecolorForms(enemyId){return BUDDY_CATALOG.filter(e=>e.enemyId===enemyId&&!e.shiny&&!SPECIAL_BUDDY_IDS.has(e.enemyId));}
  function boxEntries(){return Array.isArray(hubSave.buddyBoxV265?.entries)?hubSave.buddyBoxV265.entries:[];}
  function eligibleRecolorEntries(){return boxEntries().filter(e=>e&&!e.shiny&&!SPECIAL_BUDDY_IDS.has(e.enemyId)&&ordinaryRecolorForms(e.enemyId).some(f=>f.key!==e.key));}
  function paintForVariant(v){const id=String(v||'').toLowerCase();return PAINTS.find(p=>p.id===`${id}-paint`)||null;}
  function ownedBuddyCount(key){return Math.max(0,Math.floor(Number(hubSave.buddies?.collection?.[key]?.quantity)||0));}
  function recolorInstance(entry,target){
    if(!entry||!target||entry.key===target.key)return false;const oldKey=entry.key;ensureBuddySave();const old=hubSave.buddies.collection?.[oldKey];if(old){old.quantity=Math.max(0,Number(old.quantity)||0)-1;if(old.quantity<=0)delete hubSave.buddies.collection[oldKey];}
    const targetRecord=hubSave.buddies.collection?.[target.key];if(targetRecord)targetRecord.quantity=Math.max(1,Number(targetRecord.quantity)||1)+1;else hubSave.buddies.collection[target.key]={key:target.key,enemyId:target.enemyId,variantId:target.variantId,name:target.name,image:target.image,idle:target.idle.slice(),shiny:false,boss:Boolean(target.boss),quantity:1,capturedAt:Date.now()};
    entry.key=target.key;entry.enemyId=target.enemyId;entry.variantId=target.variantId;entry.name=target.name;entry.image=target.image;entry.idle=target.idle.slice();entry.shiny=false;entry.boss=Boolean(target.boss);
    const eq=hubSave.buddyBoxV265?.equippedInstanceByCharacter||{};for(const [cid,ids] of Object.entries(eq)){if(!Array.isArray(ids))continue;ids.forEach((instanceId,i)=>{if(instanceId===entry.id&&hubSave.buddies?.equippedByCharacter?.[cid])hubSave.buddies.equippedByCharacter[cid][i]=target.key;});}
    persistAll();return true;
  }
  function artistInspiration(m){
    m.querySelector('p').textContent='Give Artist Friend one regular item from the Hub Shop Supplies category for inspiration. Dash Carts are not accepted. They will give you 3 random Paints!';const owned=SUPPLIES.filter(s=>!String(s.id).startsWith('dash-cart-')&&qty(s.id)>0);const a=m.querySelector('.gimmick-actions-v288');a.innerHTML='';if(!owned.length){const n=document.createElement('small');n.className='gimmick-empty-v288';n.textContent='You do not have any Supplies right now.';a.append(n);}else{const grid=document.createElement('div');grid.className='gimmick-item-grid-v288';owned.forEach(s=>{const b=document.createElement('button');b.type='button';b.className='gimmick-item-v288';b.innerHTML=`<img src="${s.image}" alt=""><span>${s.name}</span><small>×${qty(s.id)}</small>`;b.addEventListener('click',()=>{if(!removeInventory(s.id,1))return;const rewards=[pick(PAINTS),pick(PAINTS),pick(PAINTS)];rewards.forEach(p=>addInventory(p.id,1));ui.chestSprite.src='assets/gimmicks/artist-friend/happy.png';const card=maybeGrantCard('artist-friend','r-gimmick-artist-friend');finish(`Artist Friend is inspired! You received ${rewards.map(x=>x.name).join(', ')}.${cardText(card)}`);});grid.append(b);});a.append(grid);}const leave=document.createElement('button');leave.type='button';leave.className='pixel-button';leave.textContent='Leave';leave.addEventListener('click',()=>finish('Artist Friend waves goodbye, still thinking about colors.'));a.append(leave);
  }
  function artistRecolor(m){
    m.querySelector('p').textContent='Artist Friend can recolor one ordinary enemy or boss Buddy. Shinies and special Buddies are never eligible.';
    const entries=eligibleRecolorEntries();
    const a=m.querySelector('.gimmick-actions-v288');
    a.innerHTML='';

    if(!entries.length){
      const n=document.createElement('small');
      n.className='gimmick-empty-v288';
      n.textContent='You do not have an eligible Buddy with another ordinary color available, so Artist Friend offers the inspiration trade instead.';
      a.append(n);
      const swap=document.createElement('button');
      swap.type='button';
      swap.className='pixel-button primary';
      swap.textContent='Trade a Supply for Paint';
      swap.addEventListener('click',()=>artistInspiration(m));
      a.append(swap);
      return;
    }

    const grid=document.createElement('div');
    grid.className='gimmick-item-grid-v288';

    entries.forEach(entry=>{
      const b=document.createElement('button');
      b.type='button';
      b.className='gimmick-item-v288';
      b.innerHTML=`<img src="${entry.image}" alt=""><span>${entry.nickname||entry.name}</span><small>${entry.variantId} · Owned: ${ownedBuddyCount(entry.key)}</small>`;

      b.addEventListener('click',()=>{
        a.innerHTML='';
        const forms=ordinaryRecolorForms(entry.enemyId).filter(f=>f.key!==entry.key);

        forms.forEach(target=>{
          const owned=ownedBuddyCount(target.key);
          const row=document.createElement('div');
          row.className='gimmick-recolor-row-v288';
          if(owned===0)row.classList.add('missing-variant-v295');

          row.innerHTML=`<img src="${target.image}" alt=""><span><strong>${target.name}</strong><small>${target.variantId} · Owned: ${owned}${owned===0?' · Missing':''}</small></span>`;

          const actions=document.createElement('div');
          actions.className='gimmick-recolor-actions-v295';

          const coin=document.createElement('button');
          coin.type='button';
          coin.className='pixel-button small';
          coin.textContent='75 Pink Coins';
          coin.disabled=(Number(hubSave.coins)||0)<75;
          coin.addEventListener('click',()=>{
            if((Number(hubSave.coins)||0)<75)return;
            hubSave.coins-=75;
            if(!recolorInstance(entry,target)){
              hubSave.coins+=75;
              return;
            }
            const card=maybeGrantCard('artist-friend','r-gimmick-artist-friend');
            finish(`Artist Friend recolored your Buddy into ${target.name}!${cardText(card)}`);
          });
          actions.append(coin);

          const paint=paintForVariant(target.variantId);
          if(paint){
            const pb=document.createElement('button');
            pb.type='button';
            pb.className='pixel-button small';
            pb.textContent=`Use ${paint.name} (×${qty(paint.id)})`;
            pb.disabled=qty(paint.id)<1;
            pb.addEventListener('click',()=>{
              if(!removeInventory(paint.id,1))return;
              if(!recolorInstance(entry,target)){
                addInventory(paint.id,1);
                return;
              }
              const card=maybeGrantCard('artist-friend','r-gimmick-artist-friend');
              finish(`Artist Friend used ${paint.name} to recolor your Buddy into ${target.name}!${cardText(card)}`);
            });
            actions.append(pb);
          }else{
            actions.classList.add('single');
          }

          row.append(actions);
          a.append(row);
        });

        const back=document.createElement('button');
        back.type='button';
        back.className='pixel-button';
        back.textContent='Back';
        back.addEventListener('click',()=>artistRecolor(m));
        a.append(back);
      });

      grid.append(b);
    });

    a.append(grid);

    const leave=document.createElement('button');
    leave.type='button';
    leave.className='pixel-button';
    leave.textContent='Leave';
    leave.addEventListener('click',()=>finish('Artist Friend packs up their paints and waves goodbye.'));
    a.append(leave);
  }
  function artistFriend(){animateScene(['assets/gimmicks/artist-friend/idle-1.png','assets/gimmicks/artist-friend/idle-2.png']);ui.chestCaption.textContent='Artist Friend';setMessage('Artist Friend appears with an armful of paints and supplies!');const m=menu('Artist Friend','They have an idea!');const recolor=eligibleRecolorEntries().length>0&&Math.random()<.50;if(recolor)artistRecolor(m);else artistInspiration(m);}
  function angyDuck(){const shiny=Math.random()<currentShinyRate(),variant=shiny?'shiny':pick(NORMAL_VARIANTS['angy-duck']);const path=shiny?'shiny':variant;animateScene([`assets/gimmicks/angy-duck/${path}/idle-1.png`,`assets/gimmicks/angy-duck/${path}/idle-2.png`],360);ui.chestCaption.textContent=shiny?'Shiny Angy Duck ✨':'Angy Duck';setMessage('An extremely angry duck stomps into your path. It wants to fight!');const m=menu(shiny?'A SHINY Angy Duck is furious!':'Angy Duck wants beef!','Defeat it to calm it down and receive a random duck. Or befriend it during battle and keep Angy Duck instead.');button(m,'Bring it on!',()=>beginBattle('angy-duck',shiny?'base':variant,shiny,'angy-duck'),'primary');button(m,'Back away slowly',()=>finish('Angy Duck quacks furiously as you retreat.'));
  }
  function show(encounter){prep(encounter);const kind=encounter.gimmick;state().stats[kind]=Math.max(0,Number(state().stats[kind])||0)+1;persistAll();if(kind==='rotten-egg')rottenEgg();else if(kind==='lucky-cat')luckyCat();else if(kind==='ghost-girl')ghostGirl();else if(kind==='pippa')pippa();else if(kind==='artist-friend')artistFriend();else if(kind==='sock-gremlin')window.DuckieSockGremlinV297?.show?.({animateScene,menu,button,finish});else if(kind==='ufono')window.DuckieUFONOV298?.show?.({animateScene,menu,button,finish});else angyDuck();}

  if(typeof buildEncounterFromPool==='function'){
    const oldBuild=buildEncounterFromPool;buildEncounterFromPool=function(enemyPool,mode='stage'){
      const result=oldBuild.apply(this,arguments);if(result?.type!=='enemy')return result;if(generationCooldown>0){generationCooldown--;return result;}if(Math.random()>=currentGimmickRate())return result;generationCooldown=COOLDOWN_NORMAL_ENCOUNTERS;const pool=activeCharacterId==='miko'?GIMMICKS:GIMMICKS.filter(id=>id!=='sock-gremlin');return {type:'gimmick',gimmick:pick(pool)};
    };
  }
  if(typeof situationTitle==='function'){const old=situationTitle;situationTitle=function(type){if(type==='gimmick')return'Gimmick Encounter';return old.apply(this,arguments);};}
  if(typeof updateEncounterHeader==='function'){const old=updateEncounterHeader;updateEncounterHeader=function(encounter=currentEncounterData()){old.apply(this,arguments);if(encounter?.type==='gimmick')ui.encounterLabel.textContent+=' · SPECIAL ENCOUNTER';};}
  if(typeof startEncounter==='function'){const old=startEncounter;startEncounter=function(){const encounter=currentRun?.mode==='endless'?currentRun?.endlessEncounter:currentRun?.plan?.[currentRun?.index||0];if(encounter?.type==='gimmick'){show(encounter);return;}return old.apply(this,arguments);};}
  if(typeof enemyDefeated==='function'){
    const old=enemyDefeated;enemyDefeated=async function(options={}){if(!activeBattle||!currentEnemy||currentEnemy.id!==activeBattle.enemyId)return old.apply(this,arguments);const defeated=currentEnemy;clearInterval(idleTimer);const refs=enemyUiFor(defeated);defeated._defeated=true;defeated.hpNow=0;refs.combatant?.classList.add('hidden');ui.commandGrid?.classList.add('hidden');try{closeCommandWindow();}catch{}setMessage(options.captured?`${defeated.name}${defeated.shiny?' ✨':''} was befriended!`:`${defeated.name}${defeated.shiny?' ✨':''} was defeated!`);await sleep(options.captured?320:420);let msg='';const cardId=cardForBattle(defeated),family=activeBattle.kind;let card=null;
      if(activeBattle.kind==='lucky-cat'){const coins=addCoins(randInt(20,80));card=maybeGrantCard('lucky-cat',cardId);msg=`Lucky Cat leaves you ${coins} Pink Coins.${cardText(card)}`;}
      else if(activeBattle.kind==='rotten-egg'){const eggId=defeated.shiny?'shiny-egg':String(defeated.gimmickVariant||'base')==='rare'?'rare-egg':'common-egg';addInventory(eggId,1);card=maybeGrantCard('rotten-egg',cardId);msg=`${defeated.name} settles down and leaves you a ${eggId==='shiny-egg'?'Shiny':eggId==='rare-egg'?'Rare':'Common'} Egg.${eggId==='shiny-egg'?' It will hatch a guaranteed Shiny Buddy in 24 hours! ✨':''}${cardText(card)}`;}
      else if(activeBattle.kind==='angy-duck'){card=maybeGrantCard('angy-duck',cardId);if(options.captured){msg=`Angy Duck calms down and joins your Buddy Box!${cardText(card)}`;}else{let pool=[...REGULAR_DUCKS];if(defeated.shiny){const unlockedSpecial=(hubSave.unlockedDucks||[]).filter(id=>SPECIAL_DUCK_IDS.has(id));pool=pool.concat(unlockedSpecial.map(id=>[id,SPECIAL_DUCK_NAMES[id]||id.replaceAll('-',' ')]));}const duck=pick(pool);addDuck(duck[0]);msg=`Angy Duck finally calms down and gives you ${duck[1]}! 🦆${cardText(card)}`;}}
      finish(msg);return true;};
  }
  window.DUCKIE_GIMMICK_ENCOUNTERS_V288=VERSION;
})();

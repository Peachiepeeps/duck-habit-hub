(function(){
  "use strict";

  const SAVE_KEY = "duckHabitHubSave_v1";
  const SHARED_CHANCE = 0.02;
  const HEART_SRC = "assets/love-interests/lukio/Pixel-heart.png";
  const MIKO_IDLE_1 = "assets/characters/miko/base/idle-1.webp";
  const MIKO_IDLE_2 = "assets/characters/miko/base/idle-2.webp";
  const MIKO_SMUG = "assets/characters/miko/base/smug.webp";

  const CHARACTERS = {
    miho: {name:'Miho', sprites:{idle1:'assets/characters/miho/base/idle-1.webp',idle2:'assets/characters/miho/base/idle-2.webp',angry:'assets/characters/miho/base/threaten.webp',fluster:'assets/characters/miho/base/fluster.webp'}},
    ranger: {name:"Ranger",duckId:"ranger-duck",cardId:"r-love-ranger",sprites:{"idle1": "assets/love-interests/ranger/Ranger-idle-1.png", "idle2": "assets/love-interests/ranger/Ranger-idle-2.png", "angry": "assets/love-interests/ranger/Ranger-Angry.png", "smirk": "assets/love-interests/ranger/Ranger-Smirk.png"},outfitIds:["look-ranger-shirt", "look-ranger-boots", "look-ranger-pants", "look-ranger-bow", "look-ranger-sign"]},
    lovell: {name:"Lovell",duckId:"lovell-duck",cardId:"r-love-lovell",sprites:{"idle1": "assets/love-interests/lovell/Lovell-idle-1.png", "idle2": "assets/love-interests/lovell/Lovell-idle-2.png", "drool": "assets/love-interests/lovell/Lovell-drool.png", "gasp": "assets/love-interests/lovell/Lovell-gasp.png"},outfitIds:["look-lovell-hairpins", "look-lovell-hoodie", "look-lovell-skirt", "look-lovell-shoes", "look-lovell-socks", "look-lovell-bow"]},
    collin: {name:"Collin",duckId:"collin-duck",cardId:"r-love-collin",sprites:{"idle1": "assets/love-interests/collin/Collin-idle-1.png", "idle2": "assets/love-interests/collin/Collin-idle-2.png", "angry": "assets/love-interests/collin/Collin-angry.png", "happy": "assets/love-interests/collin/Collin-happy.png"},outfitIds:["look-collin-top", "look-collin-boots", "look-collin-shorts", "look-collin-socks", "look-collin-bow"]},
    beau: {name:"Beau",duckId:"beau-duck",cardId:"r-love-beau",sprites:{"idle1": "assets/love-interests/beau/Beau-idle-1.png", "idle2": "assets/love-interests/beau/Beau-idle-2.png", "happy": "assets/love-interests/beau/Beau-happy.png", "sad": "assets/love-interests/beau/Beau-sad.png"},outfitIds:["look-beau-dress", "look-beau-boots", "look-beau-tights", "look-beau-bow"]},
    ein: {name:"Ein",duckId:"ein-duck",cardId:"r-love-ein",sprites:{"idle1": "assets/love-interests/ein/Ein-idle-1.png", "idle2": "assets/love-interests/ein/Ein-idle-2.png", "pout": "assets/love-interests/ein/Ein-Pout.png", "happy": "assets/love-interests/ein/Ein-Happy.png"},outfitIds:["look-ein-bow", "look-ein-bangs", "look-ein-gloves", "look-ein-jacket", "look-ein-boots", "look-ein-short", "look-ein-stockings"]},
    ideno: {name:"Ideno",duckId:"ideno-duck",cardId:"r-love-ideno",sprites:{"idle1": "assets/love-interests/ideno/Ideno-idle-1.png", "idle2": "assets/love-interests/ideno/Ideno-idle-2.png", "angry": "assets/love-interests/ideno/Ideno-angry.png", "smirk": "assets/love-interests/ideno/Ideno-smirk.png"},outfitIds:["look-ideno-top", "look-ideno-loafers", "look-ideno-skirt", "look-ideno-stockings", "look-ideno-bow"]},
    hinaru: {name:"Hinaru",duckId:"hinaru-duck",cardId:"r-love-hinaru",sprites:{"idle1": "assets/love-interests/hinaru/Hinaru-idle-1.png", "idle2": "assets/love-interests/hinaru/Hinaru-idle-2.png", "amused": "assets/love-interests/hinaru/Hinaru-amused.png", "unhappy": "assets/love-interests/hinaru/Hinaru-unhappy.png"},outfitIds:["look-hinaru-sweater", "look-hinaru-heels", "look-hinaru-skirt", "look-hinaru-bow"]},
    lain:{name:'Lain',duckId:'lain-duck',cardId:'r-love-lain',sprites:{idle1:'assets/love-interests/lain/Lain-idle-1.png',idle2:'assets/love-interests/lain/Lain-idle-2.png',sigh:'assets/love-interests/lain/Lain-sigh.png'},outfitIds:['annika-casual-bow','annika-casual-dress','annika-casual-shoes']},
    tamao:{name:'Tamao',duckId:'tamao-duck',cardId:'r-love-tamao',sprites:{idle1:'assets/love-interests/tamao/Tamao-idle-1.png',idle2:'assets/love-interests/tamao/Tamao-idle-2.png',sigh:'assets/love-interests/tamao/Tamao-sigh.png'},outfitIds:['annika-school-buns','annika-school-socks','annika-school-sneakers','annika-school-uniform','annika-school-hoodie']},
    annika:{name:'Annika',sprites:{idle1:'assets/characters/annika/base/idle-1.webp',idle2:'assets/characters/annika/base/idle-2.webp'}},
    shin:{name:'Shin',duckId:'shin-duck',cardId:'r-love-shin',sprites:{idle1:'assets/love-interests/shin/Shin-idle-1.png',idle2:'assets/love-interests/shin/Shin-idle-2.png',blush:'assets/love-interests/shin/Shin-hurt.png'},outfitIds:['annika-lingerie-stockings','annika-lingerie-bottoms','annika-lingerie-babydoll']},
    bubble:{name:'Bubble',duckId:'bubble-duck',cardId:'r-love-bubble',sprites:{idle1:'assets/love-interests/bubble/Bubble-idle-1.png',idle2:'assets/love-interests/bubble/Bubble-idle-2.png',happy:'assets/love-interests/bubble/Bubble-happy.png'},outfitIds:['annika-date-pigtails','annika-date-stockings','annika-date-heels','annika-date-skirt','annika-date-sweater','annika-date-necklace']},
    miko: {
      name: "Miko",
      sprites: { idle1: MIKO_IDLE_1, idle2: MIKO_IDLE_2, smug: MIKO_SMUG }
    },
    lukio: {
      name: "Lukio",
      duckId: "lukio-duck",
      cardId: "r-love-lukio",
      sprites: {
        idle1: "assets/love-interests/lukio/Lukio-idle-1.png",
        idle2: "assets/love-interests/lukio/Lukio-idle-2.png",
        wink: "assets/love-interests/lukio/Lukio-wink.png"
      },
      outfitIds: ["lukio-hair-streak", "lukio-hoodie", "lukio-shorts", "lukio-socks", "lukio-booties"]
    },
    shinobu: {
      name: "Shinobu",
      duckId: "shinobu-duck",
      cardId: "r-love-shinobu",
      sprites: {
        idle1: "assets/love-interests/shinobu/Shinobu-idle-1.png",
        idle2: "assets/love-interests/shinobu/Shinobu-idle-2.png",
        happy: "assets/love-interests/shinobu/Shinobu-happy.png"
      },
      outfitIds: ["shino-beret", "shino-sweater", "shino-jeans", "shino-boots", "shino-sleeve"]
    },
    cheryln: {
      name: "Cheryln",
      duckId: "cheryln-duck",
      cardId: "r-love-cheryln",
      sprites: {
        idle1: "assets/love-interests/cheryln/Cheryln-idle-1.png",
        idle2: "assets/love-interests/cheryln/Cheryln-idle-2.png",
        happy: "assets/love-interests/cheryln/Cheryln-happy.png"
      },
      outfitIds: ["cheryln-hairpin", "cheryln-sweater", "cheryln-shorts", "cheryln-tights", "cheryln-boots"]
    },
    hibiki: {
      name: "Hibiki",
      duckId: "hibiki-duck",
      cardId: "r-love-hibiki",
      sprites: {
        idle1: "assets/love-interests/hibiki/Hibiki-idle-1.png",
        idle2: "assets/love-interests/hibiki/Hibiki-idle-2.png",
        happy: "assets/love-interests/hibiki/Hibiki-happy.png"
      },
      outfitIds: ["hibiki-ribbon", "hibiki-shirt", "hibiki-coat", "hibiki-back-coat", "hibiki-coat-sleeve", "hibiki-shorts", "hibiki-stockings", "hibiki-boots"]
    },
    devlin: {
      name: "Devlin",
      duckId: "devlin-duck",
      cardId: "r-love-devlin",
      sprites: {
        idle1: "assets/love-interests/devlin/Devlin-idle-1.png",
        idle2: "assets/love-interests/devlin/Devlin-idle-2.png",
        angry: "assets/love-interests/devlin/Devlin-angry.png"
      },
      outfitIds: ["devlin-shirt", "devlin-vest", "devlin-tie", "devlin-pants", "devlin-belt", "devlin-loafers", "devlin-bangs-pinned"]
    },
    yuzuru: {
      name: "Yuzuru",
      duckId: "yuzuru-duck",
      cardId: "r-love-yuzuru",
      sprites: {
        idle1: "assets/love-interests/yuzuru/Yuzuru-idle-1.png",
        idle2: "assets/love-interests/yuzuru/Yuzuru-idle-2.png",
        content: "assets/love-interests/yuzuru/Yuzuru-content.png"
      },
      outfitIds: ["yuzuru-shirt", "yuzuru-shorts", "yuzuru-socks", "yuzuru-shoes", "yuzuru-bracelet"]
    },
    westley: {
      name: "Westley",
      duckId: "westley-duck",
      cardId: "r-love-westley",
      sprites: {
        idle1: "assets/love-interests/westley/Westley-idle-1.png",
        idle2: "assets/love-interests/westley/Westley-idle-2.png",
        happy: "assets/love-interests/westley/Westley-happy.png"
      },
      outfitIds: ["westley-top", "westley-jacket", "westley-sleeve", "westley-pants", "westley-boots", "westley-face-makeup"]
    },
    circe: {
      name: "Circe",
      duckId: "circe-duck",
      cardId: "r-love-circe",
      sprites: {
        idle1: "assets/love-interests/circe/Circe-idle-1.png",
        idle2: "assets/love-interests/circe/Circe-idle-2.png",
        happy: "assets/love-interests/circe/Circe-happy.png"
      },
      outfitIds: ["circe-tank-top", "circe-sweater", "circe-sleeve", "circe-shorts", "circe-stockings", "circe-shoes", "circe-choker"]
    },
    quin: {
      name: "Quin",
      duckId: "quin-duck",
      cardId: "r-love-quin",
      sprites: {
        idle1: "assets/love-interests/quin/Quin-idle-1.png",
        idle2: "assets/love-interests/quin/Quin-idle-2.png",
        threaten: "assets/love-interests/quin/Quin-threaten.png"
      },
      outfitIds: ["quin-shirt", "quin-jacket", "quin-back-jacket", "quin-sleeve", "quin-shorts", "quin-boots", "quin-hairpins"]
    },
kiri: {
      name: "Kiri",
      duckId: "kiri-duck",
      cardId: "r-love-kiri",
      sprites: {
        idle1: "assets/love-interests/kiri/Kiri-idle-1.png",
        idle2: "assets/love-interests/kiri/Kiri-idle-2.png",
        worried: "assets/love-interests/kiri/Kiri-worried.png"
      },
      outfitIds: ["kiri-top", "kiri-sleeve", "kiri-capris", "kiri-socks", "kiri-shoes", "kiri-hairpiece"]
    },
    midori: {
      name: "Midori",
      duckId: "midori-duck",
      cardId: "r-love-midori",
      sprites: {
        idle1: "assets/love-interests/midori/Midori-opened.png",
        idle2: "assets/love-interests/midori/Midori-idle-2.png",
        closed: "assets/love-interests/midori/Midori-closed.png",
        smug: "assets/love-interests/midori/Midori-opened-smug.png"
      },
      outfitIds: ["midori-suit", "midori-sleeve", "midori-shorts", "midori-stockings", "midori-boots", "midori-scarf", "midori-low-ponytail"]
    },
    luka: {
      name: "Luka",
      duckId: "luka-duck",
      cardId: "r-love-luka",
      sprites: {
        idle1: "assets/love-interests/luka/Luka-idle-1.png",
        idle2: "assets/love-interests/luka/Luka-idle-2.png",
        calm: "assets/love-interests/luka/Luka-calm.png"
      },
      outfitIds: ["luka-shirt", "luka-jacket", "luka-jeans", "luka-sneakers", "luka-back-hair", "luka-bangs"]
    },
    cybil: {
      name: "Cybil",
      duckId: "cybil-duck",
      cardId: "r-love-cybil",
      sprites: {
        idle1: "assets/love-interests/cybil/Cybil-idle-1.png",
        idle2: "assets/love-interests/cybil/Cybil-idle-2.png",
        worried: "assets/love-interests/cybil/Cybil-worried.png"
      },
      outfitIds: ["cybil-shirt", "cybil-vest", "cybil-sleeve", "cybil-shorts", "cybil-stockings", "cybil-boots", "cybil-ponytail"]
    },
    nico: {
      name: "Nico",
      duckId: "nico-duck",
      cardId: "r-love-nico",
      sprites: {
        idle1: "assets/love-interests/nico/Nico-idle-1.png",
        idle2: "assets/love-interests/nico/Nico-idle-2.png",
        happy: "assets/love-interests/nico/Nico-happy.png"
      },
      outfitIds: ["nico-shirt", "nico-jacket", "nico-sleeve", "nico-shorts", "nico-socks", "nico-shoes", "nico-hat", "nico-back-bow"]
    },
    nene: {
      name: "Nene",
      duckId: "nene-duck",
      cardId: "r-love-nene",
      sprites: {
        idle1: "assets/love-interests/nene/Nene-idle-1.png",
        idle2: "assets/love-interests/nene/Nene-idle-2.png",
        happy: "assets/love-interests/nene/Nene-happy.png"
      },
      outfitIds: ["nene-shirt", "nene-shirt-sleeve", "nene-sweater", "nene-sweater-sleeve", "nene-pants", "nene-shoes", "nene-glasses"]
    },
    moriko: {
      name: "Moriko",
      duckId: "moriko-duck",
      cardId: "r-love-moriko",
      sprites: {
        idle1: "assets/love-interests/moriko/Moriko-idle-1.png",
        idle2: "assets/love-interests/moriko/Moriko-idle-2.png",
        chill: "assets/love-interests/moriko/Moriko-chill.png"
      },
      outfitIds: ["moriko-hoodie", "moriko-sleeve", "moriko-pants", "moriko-shoes", "moriko-necklace", "moriko-hair", "moriko-bangs"]
    },
    jenson: {
      name: "Jenson",
      duckId: "jenson-duck",
      cardId: "r-love-jenson",
      sprites: {
        idle1: "assets/love-interests/jenson/Jenson-Sprite-idle-1.png",
        idle2: "assets/love-interests/jenson/Jenson-Sprite-idle-2.png",
        happy: "assets/love-interests/jenson/Jenson-Sprite-happy.png"
      },
      outfitIds: ["jenson-top", "jenson-pants", "jenson-shoes", "jenson-glasses"]
    }
  };

  const SCENES = {
    ranger: {id:'ranger',title:'Ranger',kicker:'MIHO LOVE INTEREST',leftId:'miho',rightId:'ranger',dialogue:[
      {speaker:"Ranger",text:"Oh, hi there, Majo!",rightPose:"idle"},
      {speaker:"Miho",text:"Ugh, that’s not my name. And did you follow me?",leftPose:"idle"},
      {speaker:"Ranger",text:"Yeah, I was bored. You left me alone.",rightPose:"idle"},
      {speaker:"Miho",text:"Ughhh, I can’t babysit you all damn day.",leftPose:"angry"},
      {speaker:"Ranger",text:"You don’t have to. I’ll just follow you.",rightPose:"idle"},
      {speaker:"Miho",text:"Great. Love that.",leftPose:"idle"},
      {speaker:"Ranger",text:"I know you do!",rightPose:"idle"},
      {speaker:"Miho",text:"I was being sarcastic!!",leftPose:"idle"},
      {speaker:"Ranger",text:"Hehe, oh right! I got you a gift! People do that, right?",rightPose:"smirk"},
      {speaker:"Miho",text:"I guess, but if it’s something gross, I’ll kill you.",leftPose:"angry"},
      {speaker:"Ranger",text:"Not this time! Look!",rightPose:"idle"},
      {speaker:"Miho",text:"….This… This is fine, whatever, I’ll take it.",leftPose:"idle"},
      {speaker:"Ranger",text:"I chose right?!",rightPose:"idle"},
      {speaker:"Miho",text:"Shut up! Let’s just go home, damn it.",leftPose:"angry"},
      {speaker:"Ranger",text:"Got it, Majo!",rightPose:"idle"},
      {speaker:"Miho",text:"Still not my name!!",leftPose:"idle"}
    ],reward(){const data=load();const first=!Boolean(data.loveInterests?.ranger?.encountered);unlockCharacter(data,'ranger',{grantCard:false,grantDuck:true,grantOutfit:first});save(data);notifyUnlock('ranger');}},
    lovell: {id:'lovell',title:'Lovell',kicker:'MIHO LOVE INTEREST',leftId:'miho',rightId:'lovell',dialogue:[
      {speaker:"Lovell",text:"*not paying attention* Hehehehe…. That guy was so cute…",rightPose:"gasp"},
      {speaker:"Miho",text:"Oi. What are you doing?",leftPose:"idle"},
      {speaker:"Lovell",text:"EEK! Miho! Hello!",rightPose:"idle"},
      {speaker:"Miho",text:"I asked a question. Don’t you dare add any more damn men to this stupid group.",leftPose:"angry"},
      {speaker:"Lovell",text:"Calm down! I can look, but I won’t touch. I got enough hot dudes.",rightPose:"idle"},
      {speaker:"Miho",text:"You can have them.",leftPose:"idle"},
      {speaker:"Lovell",text:"Aww, that doesn’t mean I don’t love you! My pretty girlie~",rightPose:"gasp"},
      {speaker:"Miho",text:"S-shut up, you little brat!!",leftPose:"angry"},
      {speaker:"Lovell",text:"Hehehe, oops. Sorry, didn’t mean to fluster you.",rightPose:"gasp"},
      {speaker:"Miho",text:"You’re lucky I don’t kill animals and you resemble one too much.",leftPose:"angry"},
      {speaker:"Lovell",text:"That’s the reason?! Not love!?",rightPose:"gasp"},
      {speaker:"Miho",text:"Nope.",leftPose:"idle"},
      {speaker:"Lovell",text:"Ruddeee… And I got you a gift too. Here.",rightPose:"gasp"},
      {speaker:"Miho",text:"…Fine. Thank you…. I don’t mind this.",leftPose:"fluster"},
      {speaker:"Lovell",text:"Awww, I’m so glad!!",rightPose:"idle"},
      {speaker:"Miho",text:"Whatever, let’s just go home…",leftPose:"idle"},
      {speaker:"Lovell",text:"Okie dokie!",rightPose:"idle"}
    ],reward(){const data=load();const first=!Boolean(data.loveInterests?.lovell?.encountered);unlockCharacter(data,'lovell',{grantCard:false,grantDuck:true,grantOutfit:first});save(data);notifyUnlock('lovell');}},
    collin: {id:'collin',title:'Collin',kicker:'MIHO LOVE INTEREST',leftId:'miho',rightId:'collin',dialogue:[
      {speaker:"Collin",text:"Oh, hey, Miho.",rightPose:"idle"},
      {speaker:"Miho",text:"What are you doing here?",leftPose:"idle"},
      {speaker:"Collin",text:"Lookin’ for ya. Wanna go somewhere together?",rightPose:"idle"},
      {speaker:"Miho",text:"Absolutely not.",leftPose:"idle"},
      {speaker:"Collin",text:"Oh, I guess I’ll tell my dad you can’t make it.",rightPose:"idle"},
      {speaker:"Miho",text:"What!? ugh, I thought you meant something weird. If it’s visiting your father, I guess I don’t mind.",leftPose:"angry"},
      {speaker:"Collin",text:"Yeah, I know. Just wanted to get you to react.",rightPose:"idle"},
      {speaker:"Miho",text:"You’re fucking stupid.",leftPose:"angry"},
      {speaker:"Collin",text:"How hurtful. Common, let’s go.",rightPose:"idle"},
      {speaker:"Miho",text:"Whatever, I just don’t mind your father. He has taste, unlike you.",leftPose:"idle"},
      {speaker:"Collin",text:"Love you too, babe. Oh, here.",rightPose:"happy"},
      {speaker:"Miho",text:"….Why would I want this?",leftPose:"idle"},
      {speaker:"Collin",text:"You can just say thank you.",rightPose:"idle"},
      {speaker:"Miho",text:"ugh… Thank you, I guess…its not terrible…",leftPose:"fluster"}
    ],reward(){const data=load();const first=!Boolean(data.loveInterests?.collin?.encountered);unlockCharacter(data,'collin',{grantCard:false,grantDuck:true,grantOutfit:first});save(data);notifyUnlock('collin');}},
    beau: {id:'beau',title:'Beau',kicker:'MIHO LOVE INTEREST',leftId:'miho',rightId:'beau',dialogue:[
      {speaker:"Beau",text:"Oh, hello, Miho…",rightPose:"idle"},
      {speaker:"Miho",text:"Beau…hello.",leftPose:"idle"},
      {speaker:"Beau",text:"What brings you here? I was walking home from a modelling job.",rightPose:"idle"},
      {speaker:"Miho",text:"Just wandering, I guess. Can I…accompany you?",leftPose:"idle"},
      {speaker:"Beau",text:"Of course, I’d like that. Shall we?",rightPose:"idle"},
      {speaker:"Miho",text:"Y-Yeah…",leftPose:"idle"},
      {speaker:"Beau",text:"You look lovely today.",rightPose:"happy"},
      {speaker:"Miho",text:"I-I uh… Thanks…",leftPose:"fluster"},
      {speaker:"Beau",text:"You don’t have to be nervous, you know.",rightPose:"idle"},
      {speaker:"Miho",text:"Nervous? I’m not nervous!",leftPose:"fluster"},
      {speaker:"Beau",text:"Ahhh, my apologies. Don’t worry so much, okay?",rightPose:"idle"},
      {speaker:"Miho",text:"I…Sorry, I just…am not used to genuine kindness that isn’t people trying to fluster me on purpose.",leftPose:"idle"},
      {speaker:"Beau",text:"That’s completely understandable. Here, have this.",rightPose:"idle"},
      {speaker:"Miho",text:"Oh. Thank you, This is…nice.",leftPose:"fluster"},
      {speaker:"Beau",text:"You’re very welcome. Hopefully it brings you some comfort. Now, shall we head home?",rightPose:"idle"},
      {speaker:"Miho",text:"…Yeah, thanks…",leftPose:"fluster"}
    ],reward(){const data=load();const first=!Boolean(data.loveInterests?.beau?.encountered);unlockCharacter(data,'beau',{grantCard:false,grantDuck:true,grantOutfit:first});save(data);notifyUnlock('beau');}},
    ein: {id:'ein',title:'Ein',kicker:'MIHO LOVE INTEREST',leftId:'miho',rightId:'ein',dialogue:[
      {speaker:"Miho",text:"What are you doing here?",leftPose:"idle"},
      {speaker:"Ein",text:"Eh? I was looking for some of the guys. Mainly Beau.",rightPose:"idle"},
      {speaker:"Miho",text:"He’s probably working. He has better things to do.",leftPose:"idle"},
      {speaker:"Ein",text:"Common, don’t be so mean.",rightPose:"idle"},
      {speaker:"Miho",text:"Why? There’s no reason to be nice.",leftPose:"idle"},
      {speaker:"Ein",text:"Well, I can distract the guys to give you time to rest!",rightPose:"idle"},
      {speaker:"Miho",text:"Hm… I GUESS that’s useful.",leftPose:"idle"},
      {speaker:"Ein",text:"See? I’ll happily take that sacrifice!",rightPose:"idle"},
      {speaker:"Miho",text:"I think you just want to be surrounded by hot dudes.",leftPose:"idle"},
      {speaker:"Ein",text:"You admit they’re hot?",rightPose:"happy"},
      {speaker:"Miho",text:"Shut up.",leftPose:"angry"},
      {speaker:"Ein",text:"Yeah, yeah. Oh, here. This will look good on you.",rightPose:"idle"},
      {speaker:"Miho",text:"Oh… Thanks, I guess.",leftPose:"fluster"},
      {speaker:"Ein",text:"You’re very welcome. Now common!",rightPose:"idle"},
      {speaker:"Miho",text:"H-hey, where are you dragging me to?!",leftPose:"idle"}
    ],reward(){const data=load();const first=!Boolean(data.loveInterests?.ein?.encountered);unlockCharacter(data,'ein',{grantCard:false,grantDuck:true,grantOutfit:first});save(data);notifyUnlock('ein');}},
    ideno: {id:'ideno',title:'Ideno',kicker:'MIHO LOVE INTEREST',leftId:'miho',rightId:'ideno',dialogue:[
      {speaker:"Ideno",text:"Oh, you. Why are you here?",rightPose:"idle"},
      {speaker:"Miho",text:"I don’t need a damn reason. I do what I want.",leftPose:"angry"},
      {speaker:"Ideno",text:"Yeah, yeah. Do I need to escort you home?",rightPose:"idle"},
      {speaker:"Miho",text:"Shut it, I don’t need anything from you!",leftPose:"angry"},
      {speaker:"Ideno",text:"Big words from a girl flustered by sweet words.",rightPose:"smirk"},
      {speaker:"Miho",text:"I swear to god, I will kill you.",leftPose:"angry"},
      {speaker:"Ideno",text:"Heh. Try me. You’d bring me back.",rightPose:"idle"},
      {speaker:"Miho",text:"I… Shut up!!!!!",leftPose:"angry"},
      {speaker:"Ideno",text:"Common, Princess, I’ll walk you home.",rightPose:"idle"},
      {speaker:"Miho",text:"Oh, shut it. I’ve had enough of your annoying words.",leftPose:"angry"},
      {speaker:"Ideno",text:"Didn’t say that last night.",rightPose:"idle"},
      {speaker:"Miho",text:"I will smack you.",leftPose:"angry"},
      {speaker:"Ideno",text:"Oh nooo… Here you go, I suppose I’ll make it better with a gift.",rightPose:"smirk"},
      {speaker:"Miho",text:"Ugh, whatever, I’ll take it.",leftPose:"idle"},
      {speaker:"Ideno",text:"You sure? I can take it back.",rightPose:"idle"},
      {speaker:"Miho",text:"Just start walking!!",leftPose:"idle"}
    ],reward(){const data=load();const first=!Boolean(data.loveInterests?.ideno?.encountered);unlockCharacter(data,'ideno',{grantCard:false,grantDuck:true,grantOutfit:first});save(data);notifyUnlock('ideno');}},
    hinaru: {id:'hinaru',title:'Hinaru',kicker:'MIHO LOVE INTEREST',leftId:'miho',rightId:'hinaru',dialogue:[
      {speaker:"Miho",text:"… Yo, wake up. Why are you sleeping outside?",leftPose:"idle"},
      {speaker:"Hinaru",text:"Oh… Sup?",rightPose:"idle"},
      {speaker:"Miho",text:"Sup? What do you mean, sup? You’re outside, dumbass.",leftPose:"angry"},
      {speaker:"Hinaru",text:"It’s just such nice weather… I couldn’t help myself.",rightPose:"idle"},
      {speaker:"Miho",text:"Jeez, do I have to carry you home?",leftPose:"idle"},
      {speaker:"Hinaru",text:"Will ya? I wouldn’t mind.",rightPose:"idle"},
      {speaker:"Miho",text:"I…ugh, I’ll call Ideno to come get you.",leftPose:"idle"},
      {speaker:"Hinaru",text:"Nah, I was joking. I’ll just come with you.",rightPose:"idle"},
      {speaker:"Miho",text:"You’re way too relaxed. Don’t you have any concern?",leftPose:"idle"},
      {speaker:"Hinaru",text:"Not really. I’m a fox demon, I can defend myself if needed.",rightPose:"idle"},
      {speaker:"Miho",text:"Hm. Guess you’re right. Fine, if you turn into a fox, I’ll carry you.",leftPose:"idle"},
      {speaker:"Hinaru",text:"Sweet, I’ll take ya up on that. Here, I was holding this and figured you’d like it.",rightPose:"amused"},
      {speaker:"Miho",text:"Oh. Thanks…",leftPose:"fluster"},
      {speaker:"Hinaru",text:"Eh, it’s payment for carrying me. Now, let’s go.",rightPose:"idle"}
    ],reward(){const data=load();const first=!Boolean(data.loveInterests?.hinaru?.encountered);unlockCharacter(data,'hinaru',{grantCard:false,grantDuck:true,grantOutfit:first});save(data);notifyUnlock('hinaru');}},
    lain:{id:'lain',title:'Lain',kicker:'ANNIKA LOVE INTEREST',leftId:'annika',rightId:'lain',kitties:true,dialogue:[
      {speaker:'Annika',text:'L-Lain, are you okay?'},
      {speaker:'Lain',text:'Oh. Yeah. I just met some little kitties… I think they need a home.',rightPose:'idle'},
      {speaker:'Annika',text:'Awww, they really like you! That’s so sweet.'},
      {speaker:'Lain',text:'You’re not bothered when I bring home animals?',rightPose:'sigh'},
      {speaker:'Annika',text:'Not at all. I mean, you make enough to house them, and you do get them to loving homes. I think it’s sweet.'},
      {speaker:'Lain',text:'Thank you. That makes me feel much better.',rightPose:'idle'},
      {speaker:'Annika',text:'Not a problem at all! Can I help name them?'},
      {speaker:'Lain',text:'Sure, let’s head home and we can name them there. Oh, here… for you.'},
      {speaker:'Annika',text:'Oh! Thank you!!'}
    ],reward(){const data=load();unlockCharacter(data,'lain',{grantCard:false,grantDuck:true,grantOutfit:true});save(data);notifyUnlock('lain');}},
    tamao:{id:'tamao',title:'Tamao',kicker:'ANNIKA LOVE INTEREST',leftId:'annika',rightId:'tamao',dialogue:[
      {speaker:'Tamao',text:'Oh, there you are. Hello.'},
      {speaker:'Annika',text:'Tamao! What was with the gift you gave Shin to give me?!'},
      {speaker:'Tamao',text:'I thought it’d look good on you.'},
      {speaker:'Annika',text:'And why didn’t you just give it to me yourself?'},
      {speaker:'Tamao',text:'Because he irritated me, so I knew it would get him to react. Besides, I assume you used it soooo, what’s the issue?'},
      {speaker:'Annika',text:'Jeez, Tamao, you need to stop fighting with him. I nearly had a panic attack!'},
      {speaker:'Tamao',text:'Sorry, sorry. It’s fine, it’s fine! I just can’t stand that jerk…',rightPose:'sigh'},
      {speaker:'Annika',text:'You two…'},
      {speaker:'Tamao',text:'Here, a nicer gift. I promise it’s not the same as the other.',rightPose:'idle'},
      {speaker:'Annika',text:'Oh? Thank you… Oh, thank goodness, it’s actually cute and sweet… I appreciate this, Tamao.'},
      {speaker:'Tamao',text:'No problem. Let’s go home.'},
      {speaker:'Annika',text:'Alright!'}
    ],reward(){const data=load();unlockCharacter(data,'tamao',{grantCard:false,grantDuck:true,grantOutfit:true});save(data);notifyUnlock('tamao');}},
    'shin-tamao':{id:'shin-tamao',title:'Shin + Tamao',kicker:'LOVERS REUNITE',leftId:'shin',rightId:'tamao',dialogue:[
      {speaker:'Shin',text:'YOU!',leftPose:'blush'},
      {speaker:'Tamao',text:'Oho, someone looks angry…'},
      {speaker:'Shin',text:'I swear to god, Tamao, you did that on purpose!',leftPose:'blush'},
      {speaker:'Tamao',text:'I don’t know what you’re talking about.',rightPose:'idle'},
      {speaker:'Shin',text:'You know what you did! That… That gift you gave me to give to Annika!'},
      {speaker:'Tamao',text:'Did you not like it?'},
      {speaker:'Shin',text:'I… That’s beside the point! You KNEW that would fluster me!',leftPose:'blush'},
      {speaker:'Tamao',text:'I did, I never said otherwise.'},
      {speaker:'Shin',text:'You… You are horrible.'},
      {speaker:'Tamao',text:'Good. Suffer.'},
      {speaker:'Shin',text:'UGH. Let’s just go home.'},
      {speaker:'Tamao',text:'Oh, okay, buy me a drink on the way back.'},
      {speaker:'Shin',text:'Jeez, fine.'}
    ],reward(){const data=load(),root=ensureAll(data);unlockCardsOnly(data,['shin','tamao']);root.pairScenes.shinTamao={seen:true,cardsGranted:true};save(data);notifyUnlock('shin-tamao');}},
    'bubble-lain':{id:'bubble-lain',title:'Bubble + Lain',kicker:'LOVERS REUNITE',leftId:'bubble',rightId:'lain',dialogue:[
      {speaker:'Bubble',text:'Laiiinnn! Hello, my love.',leftPose:'happy'},
      {speaker:'Lain',text:'Oh, hello Bubble… Were you looking for me?'},
      {speaker:'Bubble',text:'Yeah, I missed you.'},
      {speaker:'Lain',text:'Oh, I’m sorry. I was busy at work…',rightPose:'sigh'},
      {speaker:'Bubble',text:'It’s okay! It’s time to take a break though.'},
      {speaker:'Lain',text:'I suppose…'},
      {speaker:'Bubble',text:'Yes, I insist! You overwork yourself if not!'},
      {speaker:'Lain',text:'Thank you. You always worry so much for me, I feel bad.'},
      {speaker:'Bubble',text:'Please don’t. I love taking care of you. You’re my soulmate. It is never an inconvenience.',leftPose:'happy'},
      {speaker:'Lain',text:'I appreciate it… I love you.',rightPose:'idle'},
      {speaker:'Bubble',text:'I love you too, hun!',leftPose:'happy'},
      {speaker:'Lain',text:'Let’s go home… I want a nap.',rightPose:'sigh'},
      {speaker:'Bubble',text:'Yes, sir! Hehe…',leftPose:'happy'}
    ],reward(){const data=load(),root=ensureAll(data);unlockCardsOnly(data,['bubble','lain']);root.pairScenes.bubbleLain={seen:true,cardsGranted:true};save(data);notifyUnlock('bubble-lain');}},
    shin:{id:'shin',title:'Shin',kicker:'ANNIKA LOVE INTEREST',leftId:'annika',rightId:'shin',dialogue:[
      {speaker:'Annika',text:'Oh, hello, Shin!',rightPose:'idle'},
      {speaker:'Shin',text:'Ah! There you are. Uh, Tamao wanted me to give this to you.',rightPose:'idle'},
      {speaker:'Annika',text:'Me? Oh, thank you.',rightPose:'idle'},
      {speaker:'Narrator',text:'Annika opens the box.',rightPose:'idle'},
      {speaker:'Annika',text:'Oh my!',rightPose:'idle'},
      {speaker:'Shin',text:'What is it…?',rightPose:'idle'},
      {speaker:'Narrator',text:'He peeks over her shoulder.',rightPose:'blush'},
      {speaker:'Shin',text:'DAMN IT, TAMAO!',rightPose:'blush'},
      {speaker:'Annika',text:'I… uh, I like it.',rightPose:'blush'},
      {speaker:'Shin',text:'I mean… It’s… It’s not bad… S-Should we head home?',rightPose:'blush'},
      {speaker:'Annika',text:'Yes, please!',rightPose:'blush'}
    ],reward(){const data=load();unlockCharacter(data,'shin',{grantCard:false,grantDuck:true,grantOutfit:true});save(data);notifyUnlock('shin');}},
    bubble:{id:'bubble',title:'Bubble',kicker:'ANNIKA LOVE INTEREST',leftId:'annika',rightId:'bubble',dialogue:[
      {speaker:'Annika',text:'Oh, Bubble, hello!',rightPose:'idle'},
      {speaker:'Bubble',text:'Hello, my queen. It’s dangerous being out alone. Would you like me to escort you home?',rightPose:'idle'},
      {speaker:'Annika',text:'How sweet of you. Sure, I wouldn’t mind that.',rightPose:'idle'},
      {speaker:'Bubble',text:'My pleasure. I couldn’t possibly let you get hurt here.',rightPose:'idle'},
      {speaker:'Annika',text:'I appreciate it. What were you doing out here?',rightPose:'idle'},
      {speaker:'Bubble',text:'Oh, I was just… on a walk. That’s all.',rightPose:'idle'},
      {speaker:'Annika',text:'Best not to dig further…',rightPose:'idle'},
      {speaker:'Annika',text:'I see. Ahh, I ripped my sweater a bit…',rightPose:'idle'},
      {speaker:'Bubble',text:'Oh, I can fix that. I know, I’ll get you a cute new outfit! We can go on a date!',rightPose:'happy'},
      {speaker:'Annika',text:'You’re too sweet, Bubble. Sure, I won’t say no to that.',rightPose:'happy'},
      {speaker:'Bubble',text:'Okay, let’s go!',rightPose:'happy'}
    ],reward(){const data=load();unlockCharacter(data,'bubble',{grantCard:false,grantDuck:true,grantOutfit:true});save(data);notifyUnlock('bubble');}},
    lukio: {
      id: "lukio",
      title: "Lukio",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "lukio",
      dialogue: [
        { speaker: "Miko", text: "Lukio! There you are!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Lukio", text: "Hey babe! What are you doing here?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Just finding cute buddies and exploring. Have you seen the others?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Lukio", text: "Hmm, I’ve seen some here or there. I bet most are home. Wanna head back with me?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Yeah! Let’s hold hands!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Lukio", text: "(Winks) Alright. Then here, I found these.", leftPose: "idle", rightPose: "wink" },
        { speaker: "Miko", text: "(smug) A gift? For me? You’re too sweet!", leftPose: "smug", rightPose: "idle1" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "lukio", { grantCard: true, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("lukio");
      }
    },
    shinobu: {
      id: "shinobu",
      title: "Shinobu",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "shinobu",
      dialogue: [
        { speaker: "Miko", text: "Shinobu! What are you doing here?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Shinobu", text: "Oh, Hello, Miko. I’m just coming back from work. Are you heading home as well?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Yeah! Wanna walk together?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Shinobu", text: "Yes. I’d like that.", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Hey, have you seen Midori?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Shinobu", text: "Oh. Yeah, Lukio threw him into a dumpster for tampering with his hair dye. He’s been gone ever since.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Ehhhhh?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Shinobu", text: "Oh, right. I found this. You can have it, I suppose.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Oh! Thanks, Shino!", leftPose: "smug", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "shinobu", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("shinobu");
      }
    },
    cheryln: {
      id: "cheryln",
      title: "Cheryln",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "cheryln",
      dialogue: [
        { speaker: "Miko", text: "Oh, hey Chery! Looking for Shinobu?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Cheryln", text: "Yup! They wandered away from me again.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "I can help you find them! I wouldn’t mind some Shino and Chery time!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Cheryln", text: "That’d be sweet! Thank you! Think maybe Midori kidnapped them?", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Hmm, I don’t think so, but it’s possible.", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Cheryln", text: "*happy* It’s cool, Shino can handle themselves if need be. Nee, I found this! You can have it!", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Ohhh, thank you, Chery!!!", leftPose: "smug", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "cheryln", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("cheryln");
      }
    },
    hibiki: {
      id: "hibiki",
      title: "Hibiki",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "hibiki",
      dialogue: [
        { speaker: "Miko", text: "Hey Biki! What cha doing out here?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Hibiki", text: "Eek… You scared me. I was looking for herbs to use for my experiments…", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Oops, sorry, Sweetie. You want some help?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Hibiki", text: "*happy* Oh, would you? I’d love some help. I’m looking for this flower. It’s orange.", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Hmm.. Okay, let’s look around!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Hibiki", text: "*Happy* Yeah! Thanks, Miko!", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "No problem. Wait, does Devlin know where you went?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Hibiki", text: "Oh I…Oh no. I forgot. I got so excited that I just went out. He’s probably worried.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Let’s grab that flower and head back, mmkay?", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Hibiki", text: "Yes please!!", leftPose: "smug", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "hibiki", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("hibiki");
      }
    },
    devlin: {
      id: "devlin",
      title: "Devlin",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "devlin",
      dialogue: [
        { speaker: "Miko", text: "Devlin! Whats up?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Devlin", text: "*Angry* …Where is he?", leftPose: "idle", rightPose: "angry" },
        { speaker: "Miko", text: "Just gonna assume you mean your wifey. Biki’s in the backyard now. I brought him home.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Devlin", text: "Oh… Thank god. I thought he may fall off a cliff or something looking for materials.", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Miko", text: "*smug* Ehehe… Yeah, that sounds like him. Common, let’s head back. I know you get grumpy without your wifey.", leftPose: "smug", rightPose: "idle2" },
        { speaker: "Devlin", text: "*angry* Shut it…", leftPose: "smug", rightPose: "angry" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "devlin", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("devlin");
      }
    },
    yuzuru: {
      id: "yuzuru",
      title: "Yuzuru",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "yuzuru",
      dialogue: [
        { speaker: "Miko", text: "Yuzu! Yo! What are you doing here?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Yuzuru", text: "Cybil sent me to find Westley. He got distracted and wandered away and she finished his new coat.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "That so? I’ll help you find him then!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Yuzuru", text: "Thanks. I don’t mind the company. I’m kinda sleepy. Can I hold your arm?", leftPose: "idle", rightPose: "content" },
        { speaker: "Miko", text: "Of course, love.", leftPose: "smug", rightPose: "content" },
        { speaker: "Yuzuru", text: "*content* Thanks… Oh, uh, here. I found this and I don’t need it.", leftPose: "smug", rightPose: "content" },
        { speaker: "Miko", text: "Aww, thanks!", leftPose: "smug", rightPose: "idle1" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "yuzuru", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("yuzuru");
      }
    },
    westley: {
      id: "westley",
      title: "Westley",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "westley",
      dialogue: [
        { speaker: "Miko", text: "There you are! Yuzu’s looking for you, silly!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Westley", text: "Oh, oops! I better go find her! I think I am lost though. Hehe.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "*smug* Silly boy. Alright, alright, I’ll take care of ya.", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Westley", text: "Thanks! Oh, I gotta practice later! Wanna come listen?", leftPose: "smug", rightPose: "happy" },
        { speaker: "Miko", text: "Oh, sounds fun! I’ll cheer ya on!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Westley", text: "*Happy* Thanks! Oh oh oh, Here! A gift for you!!", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Thank you, Wes! This is so cute!", leftPose: "smug", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "westley", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("westley");
      }
    },
    circe: {
      id: "circe",
      title: "Circe",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "circe",
      dialogue: [
        { speaker: "Miko", text: "Circe! What’s up?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Circe", text: "Hey Meeks! What’s up?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Just wandering around, having fun!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Circe", text: "*Happy* Same here! Wanna go cause trouble together?", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "*smug* Hell yea! Who are we gonna mess with?", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Circe", text: "I dunno, let’s see where the day takes us!", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Woooo!", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Circe", text: "Oh, and here! It’s so cute, I thought of you! Take it!", leftPose: "smug", rightPose: "happy" },
        { speaker: "Miko", text: "Thanks, Circ! This is great!", leftPose: "smug", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "circe", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("circe");
      }
    },
    quin: {
      id: "quin",
      title: "Quin",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "quin",
      dialogue: [
        { speaker: "Miko", text: "Oh, Quin! Hey there, handsome. You…doing something I shouldn’t see orrr…?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Quin", text: "Hm? Oh, no. The girls wanted some sweets. I was going to go get some for them.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Oh! That’s so sweet, papa bear. Can I come?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Quin", text: "Is that so you can get something sweet?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Hehehe… guilty.", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Narrator", text: "*Loud crash*", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Quin", text: "*threaten* This better not be a threat.", leftPose: "idle", rightPose: "threaten" },
        { speaker: "Miko", text: "Eh?! It was just a random enemy! Nothing too scary!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Quin", text: "Oh. Alright then. Maybe I could tame one for my girls.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Uh, yeah, good idea.", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Miko", text: "*Thinking* Scary…", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Quin", text: "Also, I found this. I figured I’d give it to you so the girls don’t bicker over it. Here you go!", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Thanks! This is cute!", leftPose: "smug", rightPose: "idle1" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "quin", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("quin");
      }
    },
kiri: {
      id: "kiri",
      title: "Kiri",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "kiri",
      dialogue: [
        { speaker: "Miko", text: "Kiri! Hi!!!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Kiri", text: "Oh um, hey Miko. Have you seen Midori…? Anytime he’s gone for more than an hour I worry.", leftPose: "idle", rightPose: "worried" },
        { speaker: "Miko", text: "Oh, yeah! Lukio threw him in the dumpster.", leftPose: "idle", rightPose: "worried" },
        { speaker: "Kiri", text: "A-Again?!", leftPose: "idle", rightPose: "worried" },
        { speaker: "Miko", text: "This happened before?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Kiri", text: "Unfortunately… I should go find him. Thank you for letting me know, Miko!", leftPose: "idle", rightPose: "worried" },
        { speaker: "Miko", text: "No problem, Kiri!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Kiri", text: "Here, I found this. I think you should have it. It’ll just get messy when I get him out of there anyways.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Hehe, thanks. I appreciate it!", leftPose: "smug", rightPose: "idle1" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "kiri", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("kiri");
      }
    },
    midori: {
      id: "midori",
      title: "Midori",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "midori",
      dialogue: [
        { speaker: "Miko", text: "Lalalalala…", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Midori", text: "Hello, Miko!", leftPose: "idle", rightPose: "smug" },
        { speaker: "Miko", text: "EEK! Midori!!! Don’t scare me!!", leftPose: "idle", rightPose: "smug" },
        { speaker: "Midori", text: "Apologies, I couldn’t help it.", leftPose: "idle", rightPose: "smug" },
        { speaker: "Miko", text: "What happened? Why are you in there?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Midori", text: "Oh, I tested Lukio. He was not happy.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "He… oh??", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Midori", text: "Here you go! I found this!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Miko", text: "In the trash…?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Midori", text: "No, silly. I was thrown in here with it.", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Miko", text: "Oh, in that case, thanks! Need help out of there?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Midori", text: "No thank you, I’ll wait for Kiri. I like watching her reactions.", leftPose: "idle", rightPose: "smug" },
        { speaker: "Miko", text: "Oh… Have fun?", leftPose: "idle", rightPose: "smug" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "midori", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("midori");
      }
    },
    luka: {
      id: "luka",
      title: "Luka",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "luka",
      dialogue: [
        { speaker: "Miko", text: "Lukkkaaa… Hi there, handsome.", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Luka", text: "Oh, hello, Miko. You’re so sweet. What brings you here?", leftPose: "smug", rightPose: "calm" },
        { speaker: "Miko", text: "Just wandering around! What about you?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Luka", text: "Just finding inspiration for a new song. This area is such a lovely muse.", leftPose: "idle", rightPose: "calm" },
        { speaker: "Miko", text: "Ohh, I can’t wait to hear. I love hearing your songs.", leftPose: "smug", rightPose: "calm" },
        { speaker: "Luka", text: "And you, too, are a muse to me. Such lively and playful music I think of when I see you.", leftPose: "smug", rightPose: "calm" },
        { speaker: "Miko", text: "Ahhhhhhh, so cute…", leftPose: "smug", rightPose: "calm" },
        { speaker: "Luka", text: "Thank you. Also, I found these. Please accept them.", leftPose: "smug", rightPose: "idle2" },
        { speaker: "Miko", text: "Ohhh, thank you!!!", leftPose: "smug", rightPose: "calm" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "luka", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("luka");
      }
    },
    cybil: {
      id: "cybil",
      title: "Cybil",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "cybil",
      dialogue: [
        { speaker: "Miko", text: "Hey, Cyb. What cha doing out here?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Cybil", text: "Oh, I was looking for some of my siblings. My father sent me to go give them some new clothing pieces.", leftPose: "idle", rightPose: "worried" },
        { speaker: "Miko", text: "Oohhh, let me help you with those.", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Cybil", text: "Thank you, Miko. I appreciate it.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Anytime, my love.", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Cybil", text: "My father is working on some jackets for you and Lukio.", leftPose: "smug", rightPose: "idle2" },
        { speaker: "Miko", text: "Awww, really?! That’s so nice of papa bear!", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Cybil", text: "I suppose it is… I’m glad he accepts my lifestyle.", leftPose: "idle", rightPose: "worried" },
        { speaker: "Miko", text: "Same here!", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Cybil", text: "Oh, you can take this, by the way. I have no need for it.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Ohhh, thank you!", leftPose: "smug", rightPose: "idle1" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "cybil", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("cybil");
      }
    },
    nico: {
      id: "nico",
      title: "Nico",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "nico",
      dialogue: [
        { speaker: "Miko", text: "Nicooo! Hows it going?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Nico", text: "Hello, Miko! Going well, just going on a walk before we set up the carnival.", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Ooohhh, mind if I join ya?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Nico", text: "Please do, I’d love some company.", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Yayyy! Nee, I saw Annika doing stretches earlier. Does one have to be born that flexible, or can one learn it?", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Nico", text: "Are you wanting to become more flexible?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Miko", text: "Hehe, it’d be useful.", leftPose: "smug", rightPose: "idle2" },
        { speaker: "Nico", text: "I can train you, but you may regret it.", leftPose: "smug", rightPose: "happy" },
        { speaker: "Miko", text: "…I’m more interested.", leftPose: "smug", rightPose: "happy" },
        { speaker: "Nico", text: "How cute. Oh, here you go. I found this.", leftPose: "smug", rightPose: "happy" },
        { speaker: "Miko", text: "Ohhh, thank you!!", leftPose: "smug", rightPose: "happy" },
        { speaker: "Nico", text: "You’re very welcome. Shall we?", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "We shall!", leftPose: "idle", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "nico", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("nico");
      }
    },
    nene: {
      id: "nene",
      title: "Nene",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "nene",
      dialogue: [
        { speaker: "Miko", text: "Nene! Are you okay?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Nene", text: "Hm? Miko? Oh, yeah! I’m just lost in thought. I have a few more tickets for the carnival to sell. But I’m not sure where I should go to sell them.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Oh, need help? I’ll be happy to work for you and Nico!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Nene", text: "You will? Oh. Thank you, Darlin’! You’re so sweet!", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Hehehe, Anytime!", leftPose: "smug", rightPose: "happy" },
        { speaker: "Nene", text: "I have 10 more tickets… Think we can sell them? I’d love to tell Nico I sold out the show.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Of course! You got a super cute guy with you! I’ll be eye candy! People will be begging for tickets!", leftPose: "smug", rightPose: "idle1" },
        { speaker: "Nene", text: "Hehe, you’re right. Oh, here’s some payment for the help! Ain’t it cute?", leftPose: "smug", rightPose: "happy" },
        { speaker: "Miko", text: "Ohhh, thanks, Nene!", leftPose: "smug", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "nene", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("nene");
      }
    },
    moriko: {
      id: "moriko",
      title: "Moriko",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "moriko",
      dialogue: [
        { speaker: "Miko", text: "Morriiii!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Moriko", text: "Oh, hey Miko. Sup?", leftPose: "idle", rightPose: "chill" },
        { speaker: "Miko", text: "Not much! Just wandering around! What about you?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Moriko", text: "I visited some of my family, now I figured I’d head home and relax.", leftPose: "idle", rightPose: "chill" },
        { speaker: "Miko", text: "Oh, I adore your family! They’re all so fun!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Moriko", text: "Yeah, they like you as well.", leftPose: "idle", rightPose: "chill" },
        { speaker: "Miko", text: "I like hearing that! We should visit your parents soon too.", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Moriko", text: "I’d like that. I’m sure dad is missing us.", leftPose: "idle", rightPose: "chill" },
        { speaker: "Miko", text: "Your dad is so much better than mine… Sighhh.", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Moriko", text: "*thinking* They’re like, literally the exact same personality but okayyy…", leftPose: "idle", rightPose: "chill" },
        { speaker: "Moriko", text: "Oh, right. Found this. Here ya go~", leftPose: "idle", rightPose: "chill" },
        { speaker: "Miko", text: "Yayyy gifts!!! Thank you!", leftPose: "smug", rightPose: "chill" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "moriko", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("moriko");
      }
    },
    jenson: {
      id: "jenson",
      title: "Jenson",
      kicker: "LOVE INTEREST ENCOUNTER",
      leftId: "miko",
      rightId: "jenson",
      dialogue: [
        { speaker: "Miko", text: "Jenson? What are you doing here?", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Jenson", text: "Oh, hey Miko. I’m playing hide and seek with the kids.", leftPose: "idle", rightPose: "idle2" },
        { speaker: "Miko", text: "Ohhh, can I help?!", leftPose: "idle", rightPose: "idle1" },
        { speaker: "Jenson", text: "Yeah, I’m sure they’ll love that. Help me find them, they’re really good.", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Will do! Come here, my babbiess!!!", leftPose: "idle", rightPose: "happy" },
        { speaker: "Jenson", text: "*chuckles*", leftPose: "idle", rightPose: "happy" },
        { speaker: "Miko", text: "Let’s see… Can I get a reward?", leftPose: "smug", rightPose: "happy" },
        { speaker: "Jenson", text: "Sure! You can have this!", leftPose: "smug", rightPose: "happy" },
        { speaker: "Miko", text: "*Thinking* I was thinking a kiss, but that’s damn cute.", leftPose: "smug", rightPose: "happy" },
        { speaker: "Miko", text: "Thanks! I love it!", leftPose: "smug", rightPose: "happy" },
        { speaker: "Jenson", text: "Now common, let’s find them.", leftPose: "idle", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        unlockCharacter(data, "jenson", { grantCard: false, grantDuck: true, grantOutfit: true });
        save(data);
        notifyUnlock("jenson");
      }
    },
    "kiri-midori": {
      id: "kiri-midori",
      title: "Kiri + Midori",
      kicker: "LOVERS REUNITE",
      leftId: "kiri",
      rightId: "midori",
      dialogue: [
        { speaker: "Kiri", text: "W…which dumpster…?", leftPose: "worried", rightPose: "idle1" },
        { speaker: "Midori", text: "*pops out* Hello!", leftPose: "worried", rightPose: "smug" },
        { speaker: "Kiri", text: "AHHHH!!! MIDORI!", leftPose: "worried", rightPose: "smug" },
        { speaker: "Midori", text: "Hehe.. I’m here.", leftPose: "worried", rightPose: "smug" },
        { speaker: "Kiri", text: "Don’t scare me!", leftPose: "worried", rightPose: "idle1" },
        { speaker: "Midori", text: "I thought you liked horror.", leftPose: "worried", rightPose: "smug" },
        { speaker: "Kiri", text: "Shock is not horror, dummy!!", leftPose: "worried", rightPose: "smug" },
        { speaker: "Midori", text: "Either way.", leftPose: "idle2", rightPose: "idle2" },
        { speaker: "Kiri", text: "Ughhhhh, just… let me help you get out of there.", leftPose: "worried", rightPose: "idle1" },
        { speaker: "Midori", text: "Ahh, thank you!", leftPose: "idle2", rightPose: "smug" },
        { speaker: "Kiri", text: "W..whatever…", leftPose: "worried", rightPose: "smug" }
      ],
      reward() {
        const data = load();
        const root = ensureAll(data);
        unlockCardsOnly(data, ["kiri", "midori"]);
        root.pairScenes.kiriMidori = root.pairScenes.kiriMidori || {};
        root.pairScenes.kiriMidori.seen = true;
        root.pairScenes.kiriMidori.cardsGranted = true;
        save(data);
        notifyUnlock("kiri-midori");
      }
    },
    "luka-cybil": {
      id: "luka-cybil",
      title: "Luka + Cybil",
      kicker: "LOVERS REUNITE",
      leftId: "cybil",
      rightId: "luka",
      dialogue: [
        { speaker: "Cybil", text: "Oh, Luka… Hello.", leftPose: "idle1", rightPose: "idle1" },
        { speaker: "Luka", text: "I can see that you look stressed. Would you like to take a walk with me?", leftPose: "worried", rightPose: "calm" },
        { speaker: "Cybil", text: "Oh, how can you tell?", leftPose: "worried", rightPose: "calm" },
        { speaker: "Luka", text: "I just can. Your inner song isn’t in harmony.", leftPose: "worried", rightPose: "calm" },
        { speaker: "Cybil", text: "I see… I suppose, a walk would help.", leftPose: "worried", rightPose: "calm" },
        { speaker: "Luka", text: "I’d be happy to listen if you need.", leftPose: "worried", rightPose: "calm" },
        { speaker: "Cybil", text: "I…suppose I am just worried. My sister keeps running off, and I worry she could get hurt.", leftPose: "worried", rightPose: "calm" },
        { speaker: "Luka", text: "That’s very sweet to worry. But I think you should give her some trust. She’s a tough little girl. But it’s understandable why you’d be concerned.", leftPose: "worried", rightPose: "calm" }
      ],
      reward() {
        const data = load();
        const root = ensureAll(data);
        unlockCardsOnly(data, ["luka", "cybil"]);
        root.pairScenes.lukaCybil = root.pairScenes.lukaCybil || {};
        root.pairScenes.lukaCybil.seen = true;
        root.pairScenes.lukaCybil.cardsGranted = true;
        save(data);
        notifyUnlock("luka-cybil");
      }
    },
    "nico-nene": {
      id: "nico-nene",
      title: "Nico + Nene",
      kicker: "LOVERS REUNITE",
      leftId: "nico",
      rightId: "nene",
      dialogue: [
        { speaker: "Nico", text: "Oh, Nene, there you are, dear.", leftPose: "happy", rightPose: "idle1" },
        { speaker: "Nene", text: "Sorry, it took me a bit long, but I sold all the tickets for Tonight’s show with Miko!", leftPose: "happy", rightPose: "happy" },
        { speaker: "Nico", text: "Is that so? Thank you so much. I’ll thank Miko later as well. I appreciate how you’re always helping the carnival.", leftPose: "happy", rightPose: "happy" },
        { speaker: "Nene", text: "Of course! It’s my baby just as much as yours at this point. Hehe!", leftPose: "happy", rightPose: "happy" },
        { speaker: "Nico", text: "That’s true. My siblings appreciate it as well. Annika said she was going to bring some cookies.", leftPose: "happy", rightPose: "happy" },
        { speaker: "Nene", text: "Yayyy! That’s wonderful. She’s such a sweetie.", leftPose: "happy", rightPose: "happy" },
        { speaker: "Nico", text: "Shall we head home?", leftPose: "happy", rightPose: "happy" },
        { speaker: "Nene", text: "Yes, let’s go!", leftPose: "happy", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        const root = ensureAll(data);
        unlockCardsOnly(data, ["nico", "nene"]);
        root.pairScenes.nicoNene = root.pairScenes.nicoNene || {};
        root.pairScenes.nicoNene.seen = true;
        root.pairScenes.nicoNene.cardsGranted = true;
        save(data);
        notifyUnlock("nico-nene");
      }
    },
    "moriko-jenson": {
      id: "moriko-jenson",
      title: "Moriko + Jenson",
      kicker: "LOVERS REUNITE",
      leftId: "moriko",
      rightId: "jenson",
      dialogue: [
        { speaker: "Moriko", text: "Jenson, there you are. What’s up?", leftPose: "chill", rightPose: "idle1" },
        { speaker: "Jenson", text: "Oh, I just got done playing with Miko and the kids.", leftPose: "chill", rightPose: "happy" },
        { speaker: "Moriko", text: "Oh, sounds fun. Probably gotta get some rest after all that.", leftPose: "chill", rightPose: "happy" },
        { speaker: "Jenson", text: "That does sound nice, but I should grade some paperwork..", leftPose: "chill", rightPose: "idle2" },
        { speaker: "Moriko", text: "Hmm, I’ll make some tea. I’ll help ya so you can rest up sooner.", leftPose: "chill", rightPose: "idle2" },
        { speaker: "Jenson", text: "That is so sweet of you. Thank you, I will accept your help.", leftPose: "chill", rightPose: "happy" },
        { speaker: "Moriko", text: "I appreciate your dedication to teaching the kids. There’s no harm in taking pride in your work. Just make sure you rest as well.", leftPose: "chill", rightPose: "happy" },
        { speaker: "Jenson", text: "I will. Thank you, I don’t know where I’d be without you.", leftPose: "chill", rightPose: "happy" },
        { speaker: "Moriko", text: "Common, let’s go.", leftPose: "chill", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        const root = ensureAll(data);
        unlockCardsOnly(data, ["moriko", "jenson"]);
        root.pairScenes.morikoJenson = root.pairScenes.morikoJenson || {};
        root.pairScenes.morikoJenson.seen = true;
        root.pairScenes.morikoJenson.cardsGranted = true;
        save(data);
        notifyUnlock("moriko-jenson");
      }
    },
    "circe-quin": {
      id: "circe-quin",
      title: "Circe + Quin",
      kicker: "LOVERS REUNITE",
      leftId: "quin",
      rightId: "circe",
      dialogue: [
        { speaker: "Quin", text: "*threaten* That should take care of that….", leftPose: "threaten", rightPose: "idle1" },
        { speaker: "Circe", text: "Quin! There you are! Oh, you busy?", leftPose: "idle1", rightPose: "idle2" },
        { speaker: "Quin", text: "Not anymore. What’s up?", leftPose: "idle2", rightPose: "idle1" },
        { speaker: "Circe", text: "*happy* I was bored. Awww, you got some blood on your cheek! Let me get that for ya.", leftPose: "idle1", rightPose: "happy" },
        { speaker: "Quin", text: "Thank you, Circe.", leftPose: "idle2", rightPose: "idle1" },
        { speaker: "Circe", text: "No problem at all! Can’t have ya scaring the girlies. Speaking of which, they begged me to make them that soup I made the other day. Wanna come with me to get the ingredients?", leftPose: "idle1", rightPose: "happy" },
        { speaker: "Quin", text: "Of course. Thanks for indulging them.", leftPose: "idle2", rightPose: "idle1" },
        { speaker: "Circe", text: "*Happy* No problem! They’re my daughters too now.", leftPose: "idle1", rightPose: "happy" },
        { speaker: "Quin", text: "Yeah, you’re right. I’m glad.", leftPose: "idle2", rightPose: "idle1" }
      ],
      reward() {
        const data = load();
        const root = ensureAll(data);
        unlockCardsOnly(data, ["circe", "quin"]);
        root.pairScenes.circeQuin = root.pairScenes.circeQuin || {};
        root.pairScenes.circeQuin.seen = true;
        root.pairScenes.circeQuin.cardsGranted = true;
        save(data);
        notifyUnlock("circe-quin");
      }
    },
    "shinobu-cheryln": {
      id: "shinobu-cheryln",
      title: "Shinobu + Cheryln",
      kicker: "LOVERS REUNITE",
      leftId: "cheryln",
      rightId: "shinobu",
      dialogue: [
        { speaker: "Cheryln", text: "*Happy* There you are!", leftPose: "happy", rightPose: "idle1" },
        { speaker: "Shinobu", text: "Oh, sorry, were you looking for me?", leftPose: "happy", rightPose: "idle2" },
        { speaker: "Cheryln", text: "Yeah, but it’s cool! Miko helped me!", leftPose: "happy", rightPose: "idle1" },
        { speaker: "Shinobu", text: "Ahhh, I saw Miko too. But it’s okay, I was just working.", leftPose: "happy", rightPose: "idle2" },
        { speaker: "Cheryln", text: "Oh, I forgot you covered a shift! Oops!", leftPose: "happy", rightPose: "idle1" },
        { speaker: "Shinobu", text: "It’s okay… I appreciate you coming to find me. *Happy*", leftPose: "happy", rightPose: "happy" },
        { speaker: "Cheryln", text: "*Happy* Anytime, my love! Now, let’s go back to the others!", leftPose: "happy", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        const root = ensureAll(data);
        unlockCardsOnly(data, ["shinobu", "cheryln"]);
        root.pairScenes.shinobuCheryln = root.pairScenes.shinobuCheryln || {};
        root.pairScenes.shinobuCheryln.seen = true;
        root.pairScenes.shinobuCheryln.cardsGranted = true;
        save(data);
        notifyUnlock("shinobu-cheryln");
      }
    },
    "devlin-hibiki": {
      id: "devlin-hibiki",
      title: "Devlin + Hibiki",
      kicker: "LOVERS REUNITE",
      leftId: "devlin",
      rightId: "hibiki",
      dialogue: [
        { speaker: "Devlin", text: "There you are! Stop running off on me.", leftPose: "angry", rightPose: "idle1" },
        { speaker: "Hibiki", text: "Oh, sorry, hon… I just got so excited…", leftPose: "idle1", rightPose: "idle2" },
        { speaker: "Devlin", text: "Ugh… It’s fine. I was just worried. Did you find good stuff?", leftPose: "idle2", rightPose: "idle1" },
        { speaker: "Hibiki", text: "*happy* Yeah! This flower Miko helped me find is a super great find! It creates a calming smell.", leftPose: "idle1", rightPose: "happy" },
        { speaker: "Hibiki", text: "*Happy* I thought I could make it into an oil to blend into your embalming stuff so you’ll be nice and calm during work.", leftPose: "idle1", rightPose: "happy" },
        { speaker: "Devlin", text: "Is that so…? Thank you, Hibiki. Let’s go back to work, okay? Take my hand.", leftPose: "idle2", rightPose: "idle1" },
        { speaker: "Hibiki", text: "Okay! Hehe…", leftPose: "idle2", rightPose: "happy" }
      ],
      reward() {
        const data = load();
        const root = ensureAll(data);
        unlockCardsOnly(data, ["hibiki", "devlin"]);
        root.pairScenes.devlinHibiki = root.pairScenes.devlinHibiki || {};
        root.pairScenes.devlinHibiki.seen = true;
        root.pairScenes.devlinHibiki.cardsGranted = true;
        save(data);
        notifyUnlock("devlin-hibiki");
      }
    },
    "westley-yuzuru": {
      id: "westley-yuzuru",
      title: "Westley + Yuzuru",
      kicker: "LOVERS REUNITE",
      leftId: "westley",
      rightId: "yuzuru",
      dialogue: [
        { speaker: "Westley", text: "*Happy* Yuzuruuuuu!!!", leftPose: "happy", rightPose: "idle1" },
        { speaker: "Yuzuru", text: "Oh. There you are. Cybil wants ya. And I’m sleepy. You should carry me home.", leftPose: "idle1", rightPose: "idle2" },
        { speaker: "Westley", text: "Sure, love love!", leftPose: "happy", rightPose: "content" },
        { speaker: "Yuzuru", text: "*content* I would like to listen to you practice today… It’s comforting… I can nap to that.", leftPose: "idle2", rightPose: "content" },
        { speaker: "Westley", text: "Heck yeah! I should invite everyone! Cuddle pile after practice!", leftPose: "happy", rightPose: "idle1" },
        { speaker: "Yuzuru", text: "*content* Cuddle pile…sounds nice…", leftPose: "idle1", rightPose: "content" }
      ],
      reward() {
        const data = load();
        const root = ensureAll(data);
        unlockCardsOnly(data, ["yuzuru", "westley"]);
        root.pairScenes.westleyYuzuru = root.pairScenes.westleyYuzuru || {};
        root.pairScenes.westleyYuzuru.seen = true;
        root.pairScenes.westleyYuzuru.cardsGranted = true;
        save(data);
        notifyUnlock("westley-yuzuru");
      }
    }
  };

  let open = false;
  let bypassNextRoll = false;

  function load(){
    try { return JSON.parse(localStorage.getItem(SAVE_KEY) || "{}"); }
    catch (_) { return {}; }
  }

  function save(data){
    if (typeof window.DuckieQuestLoveRewardSync === "function") {
      try {
        if (window.DuckieQuestLoveRewardSync(data)) return;
      } catch (_) {}
    }
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  }

  function ensureAll(data){
    data.loveInterests = data.loveInterests && typeof data.loveInterests === "object" ? data.loveInterests : {};
    data.characterUnlockedItems = data.characterUnlockedItems && typeof data.characterUnlockedItems === "object" ? data.characterUnlockedItems : {};
    if (!Array.isArray(data.characterUnlockedItems.miko)) data.characterUnlockedItems.miko = [];
    if (!Array.isArray(data.characterUnlockedItems.annika)) data.characterUnlockedItems.annika = [];
    if (!Array.isArray(data.unlockedDucks)) data.unlockedDucks = [];
    data.duckCollectionCounts = data.duckCollectionCounts && typeof data.duckCollectionCounts === "object" ? data.duckCollectionCounts : {};
    data.tradingCards = data.tradingCards && typeof data.tradingCards === "object" ? data.tradingCards : {};
    data.tradingCards.owned = data.tradingCards.owned && typeof data.tradingCards.owned === "object" ? data.tradingCards.owned : {};
    data.tradingCards.unseen = Array.isArray(data.tradingCards.unseen) ? data.tradingCards.unseen : [];
    data.loveInterestPairs = data.loveInterestPairs && typeof data.loveInterestPairs === "object" ? data.loveInterestPairs : {};
    data.loveInterestPairs.shinTamao = data.loveInterestPairs.shinTamao && typeof data.loveInterestPairs.shinTamao === "object" ? data.loveInterestPairs.shinTamao : {};
    data.loveInterestPairs.bubbleLain = data.loveInterestPairs.bubbleLain && typeof data.loveInterestPairs.bubbleLain === "object" ? data.loveInterestPairs.bubbleLain : {};
    data.loveInterestPairs.shinobuCheryln = data.loveInterestPairs.shinobuCheryln && typeof data.loveInterestPairs.shinobuCheryln === "object" ? data.loveInterestPairs.shinobuCheryln : {};
    data.loveInterestPairs.devlinHibiki = data.loveInterestPairs.devlinHibiki && typeof data.loveInterestPairs.devlinHibiki === "object" ? data.loveInterestPairs.devlinHibiki : {};
    data.loveInterestPairs.westleyYuzuru = data.loveInterestPairs.westleyYuzuru && typeof data.loveInterestPairs.westleyYuzuru === "object" ? data.loveInterestPairs.westleyYuzuru : {};
    data.loveInterestPairs.circeQuin = data.loveInterestPairs.circeQuin && typeof data.loveInterestPairs.circeQuin === "object" ? data.loveInterestPairs.circeQuin : {};
    data.loveInterestPairs.kiriMidori = data.loveInterestPairs.kiriMidori && typeof data.loveInterestPairs.kiriMidori === "object" ? data.loveInterestPairs.kiriMidori : {};
    data.loveInterestPairs.lukaCybil = data.loveInterestPairs.lukaCybil && typeof data.loveInterestPairs.lukaCybil === "object" ? data.loveInterestPairs.lukaCybil : {};
    data.loveInterestPairs.nicoNene = data.loveInterestPairs.nicoNene && typeof data.loveInterestPairs.nicoNene === "object" ? data.loveInterestPairs.nicoNene : {};
    data.loveInterestPairs.morikoJenson = data.loveInterestPairs.morikoJenson && typeof data.loveInterestPairs.morikoJenson === "object" ? data.loveInterestPairs.morikoJenson : {};

    for (const key of ["lukio", "shinobu", "cheryln", "hibiki", "devlin", "yuzuru", "westley", "circe", "quin", "kiri", "midori", "luka", "cybil", "nico", "nene", "moriko", "jenson", "shin", "bubble", "lain", "tamao", "ranger", "lovell", "collin", "beau", "ein", "ideno", "hinaru"]) {
      data.loveInterests[key] = data.loveInterests[key] && typeof data.loveInterests[key] === "object" ? data.loveInterests[key] : {};
    }
    return {
      loveInterests: data.loveInterests,
      pairScenes: data.loveInterestPairs
    };
  }

  function activeCharacterId(){
    const data = load();
    return String(data?.duckQuest?.activeCharacter || data?.selectedCharacter || "").trim().toLowerCase();
  }

  function isMiko(){
    return activeCharacterId() === "miko";
  }

  function notifyUnlock(id){
    window.dispatchEvent(new CustomEvent("duckie-love-interest-unlocked", { detail: { id } }));
  }

  function grantCard(data, cardId, amount){
    if (window.DuckieTradingCards?.grantCard) {
      window.DuckieTradingCards.grantCard(data, cardId, amount || 1);
      return;
    }
    data.tradingCards = data.tradingCards && typeof data.tradingCards === "object" ? data.tradingCards : {};
    data.tradingCards.owned = data.tradingCards.owned && typeof data.tradingCards.owned === "object" ? data.tradingCards.owned : {};
    data.tradingCards.unseen = Array.isArray(data.tradingCards.unseen) ? data.tradingCards.unseen : [];
    const before = Math.max(0, Number(data.tradingCards.owned[cardId] || 0));
    data.tradingCards.owned[cardId] = before + (amount || 1);
    if (before === 0 && !data.tradingCards.unseen.includes(cardId)) {
      data.tradingCards.unseen.push(cardId);
    }
  }

  function unlockCharacter(data, key, options){
    const cfg = CHARACTERS[key];
    const state = ensureAll(data).loveInterests[key];
    state.encountered = true;
    state.spritesUnlocked = true;
    if (options.grantDuck) {
      state.duckUnlocked = true;
      if (!data.unlockedDucks.includes(cfg.duckId)) data.unlockedDucks.push(cfg.duckId);
      data.duckCollectionCounts[cfg.duckId] = Math.max(1, Number(data.duckCollectionCounts[cfg.duckId] || 0));
    }
    if (options.grantOutfit) {
      state.outfitUnlocked = true;
      for (const piece of cfg.outfitIds) {
        const target=['shin','bubble','lain','tamao'].includes(key)?data.characterUnlockedItems.annika:data.characterUnlockedItems.miko;
        if (!target.includes(piece)) target.push(piece);
      }
    }
    if (options.grantCard) {
      state.cardUnlocked = true;
      const owned = Math.max(0, Number(data.tradingCards?.owned?.[cfg.cardId] || 0));
      if (owned < 1) grantCard(data, cfg.cardId, 1);
    }
    if (!state.unlockedAt) state.unlockedAt = Date.now();
  }

  function unlockCardsOnly(data, keys){
    const root = ensureAll(data);
    for (const key of keys) {
      const cfg = CHARACTERS[key];
      const state = root.loveInterests[key];
      state.cardUnlocked = true;
      const owned = Math.max(0, Number(data.tradingCards?.owned?.[cfg.cardId] || 0));
      if (owned < 1) grantCard(data, cfg.cardId, 1);
    }
  }

  let sceneFrameTimer = null;
  let sceneFrameIndex = 0;

  function cleanDialogueText(value){
    return String(value || "")
      .replace(/\*(?:happy|content|threaten|angry|smug|thinking|worried|calm|chill)\*\s*/gi, "")
      .replace(/^\((?:winks?|smug)\)\s*/i, "")
      .replace(/\s+\*(?:happy|content|threaten|angry|smug|thinking|worried|calm|chill)\*$/gi, "")
      .trim();
  }

  function spriteFrames(charId, pose){
    const cfg = CHARACTERS[charId];
    if (!cfg) return [];
    const p = String(pose || (charId === "miko" ? "idle" : "idle1")).toLowerCase();
    const idle = [cfg.sprites.idle1, cfg.sprites.idle2].filter(Boolean);
    if (p === "idle" || p === "idle1" || p === "idle2" || p === "neutral") {
      return idle.length ? idle : Object.values(cfg.sprites).filter(Boolean).slice(0, 1);
    }
    const special = cfg.sprites[p] || cfg.sprites[pose];
    return special ? [special] : (idle.length ? idle : []);
  }

  function stopSceneAnimation(){
    if (sceneFrameTimer) clearInterval(sceneFrameTimer);
    sceneFrameTimer = null;
  }

  function sceneLayer(){
    const battlefield = document.querySelector("#battlefield");
    if (!battlefield) return null;
    let el = battlefield.querySelector(".love-interest-battle-scene");
    if (el) return el;
    el = document.createElement("div");
    el.className = "love-interest-battle-scene hidden";
    el.setAttribute("aria-hidden", "true");
    el.innerHTML = `
      <img class="love-interest-battle-sprite love-interest-battle-left" src="" alt="">
      <span class="love-interest-battle-heart hidden"><img src="${HEART_SRC}" alt=""></span>
      <img class="love-interest-battle-sprite love-interest-battle-right" src="" alt="">`;
    battlefield.append(el);
    return el;
  }

  function sizeSceneSprite(img){
    const battlefield = document.querySelector("#battlefield");
    if (!img || !battlefield || !img.naturalWidth || !img.naturalHeight) return;
    // All battle portraits were drawn pixel-for-pixel against Miko's source
    // sprite. Scale one source pixel by the same amount for every character so
    // taller/shorter source canvases keep their intended height differences.
    const referenceHeight = 96;
    const referenceDisplayHeight = Math.max(120, battlefield.clientHeight * 0.76);
    const sourcePixelScale = referenceDisplayHeight / referenceHeight;
    img.style.width = `${Math.round(img.naturalWidth * sourcePixelScale)}px`;
    img.style.height = `${Math.round(img.naturalHeight * sourcePixelScale)}px`;
  }

  function setSceneSpriteSource(img, src){
    if (!img || !src) return;
    if (img.getAttribute("src") === src) {
      if (img.complete) sizeSceneSprite(img);
      return;
    }
    if(!img.getAttribute("src"))img.style.visibility="hidden";
    img.onload=()=>{sizeSceneSprite(img);img.style.visibility="visible";};
    setQuestSpriteFrame(img,src);
    if(img.complete && img.naturalWidth){sizeSceneSprite(img);img.style.visibility="visible";}
  }

  function sceneSpriteFrame(charId, pose, step){
    const frames = spriteFrames(charId, pose);
    if (!frames.length) return "";
    const normalized = String(pose || (charId === "miko" ? "idle" : "idle1")).toLowerCase();
    if (charId === "midori" && ["idle", "idle1", "idle2", "neutral"].includes(normalized)) {
      const opened = CHARACTERS.midori?.sprites?.idle1 || frames[0];
      const closed = CHARACTERS.midori?.sprites?.idle2 || frames[frames.length - 1] || frames[0];
      return opened; // Midori stays visible after the initial surprise.
    }
    return frames[step % frames.length];
  }

  function updateSceneSprites(state){
    if (!state?.el) return;
    const step = Math.max(0, Number(sceneFrameIndex) || 0);
    const leftSrc = sceneSpriteFrame(state.scene.leftId, state.leftPose, step);
    const rightSrc = sceneSpriteFrame(state.scene.rightId, state.rightPose, step);
    if (leftSrc) setSceneSpriteSource(state.left, leftSrc);
    if (rightSrc) setSceneSpriteSource(state.right, rightSrc);
  }

  function startSceneAnimation(state){
    stopSceneAnimation();
    sceneFrameIndex = 0;
    updateSceneSprites(state);
    const hasMidori = state?.scene?.leftId === "midori" || state?.scene?.rightId === "midori";
    const interval = hasMidori ? 700 : 520;
    sceneFrameTimer = setInterval(() => {
      sceneFrameIndex += 1;
      updateSceneSprites(state);
    }, interval);
  }

  function sceneRewardItems(scene,isRepeat=false){
    if(isRepeat && !scene.id.includes("-")) return [`${scene.title} Duck ×1`, `${scene.title} Trading Card ×1`];
    if (scene.id.includes("-")) {
      return scene.title.split(" + ").map(name => `${name} Trading Card`);
    }
    const outfit=['ranger','lovell','collin','beau','ein','ideno','hinaru'].includes(scene.id)?`Miho’s ${scene.title} Outfit`:scene.id==='shin'?'Annika’s Lingerie Outfit':scene.id==='bubble'?'Annika’s Date Outfit':scene.id==='lain'?'Annika’s Casual Cute Outfit':scene.id==='tamao'?'Annika’s School Outfit':`Miko’s ${scene.title} Outfit`;
    const items=[`${scene.title} Duck`,outfit];
    if(scene.id==="lukio") items.push("Lukio Trading Card");
    return items;
  }

  function buildSceneRewardPopup(scene,onContinue,isRepeat=false){
    const popup=document.createElement("div");
    popup.className="love-interest-reward-popup-v290";
    const label=document.createElement("span");
    label.className="mini-label";
    label.textContent="OBTAINED!";
    const title=document.createElement("h3");
    title.textContent=scene.id.includes("-")?"Reunion Rewards!":`${scene.title} Rewards!`;
    const list=document.createElement("div");
    list.className="love-interest-reward-list-v290";
    sceneRewardItems(scene,isRepeat).forEach(item=>{
      const row=document.createElement("div");
      row.className="love-interest-reward-item-v290";
      row.textContent=item;
      list.append(row);
    });
    const button=document.createElement("button");
    button.type="button";
    button.className="pixel-button primary";
    button.textContent="Continue";
    button.addEventListener("click",onContinue,{once:true});
    popup.append(label,title,list,button);
    return popup;
  }

  function markSceneUi(active){
    // Hide the entire normal battle layer while the scene portraits are on the
    // battlefield. In particular, hiding the whole commandStage removes the
    // giant empty mobile command area and guarantees there is only ONE Miko.
    const selectors = ["#battlefield > .peep-combatant", "#enemyCombatant", "#enemyCombatant2", "#buddyCombatant", "#chestLayer", "#commandStage", "#postFloorActions", "#questCardRewardV311"];
    selectors.forEach(selector => {
      const node = document.querySelector(selector);
      if (!node) return;
      node.classList.toggle("love-interest-scene-hidden", active);
      if (active) {
        if (!node.dataset.loveInterestPreviousDisplay) node.dataset.loveInterestPreviousDisplay = node.style.display || "__empty__";
        node.style.setProperty("display", "none", "important");
      } else {
        const previous = node.dataset.loveInterestPreviousDisplay;
        node.style.removeProperty("display");
        if (previous && previous !== "__empty__") node.style.display = previous;
        delete node.dataset.loveInterestPreviousDisplay;
      }
    });
    document.querySelector("#battlefield")?.classList.toggle("love-interest-scene-active", active);
    document.querySelector("#battleScreen .battle-ui")?.classList.toggle("love-interest-dialogue-active", active);
  }

  function sceneKitties(state){
    state.el.querySelectorAll('.lain-rescue-kitty-v359').forEach(node=>node.remove());
    if(!state.scene.kitties)return;
    const area=String((typeof currentRun!=='undefined'&&currentRun?.area)|| (typeof selectedArea!=='undefined'?selectedArea:'meadow'));
    const pool={
      meadow:['assets/enemies/cat-slime/base/idle-1-neutral.webp','assets/enemies/cat-slime/base/Green-idle-1-neutral.webp','assets/enemies/cat-slime/base/Strawberry-idle-1-neutral.webp'],
      ocean:['assets/enemies/catfish/base/idle-1.webp','assets/enemies/catfish/base/Orange-idle-1.webp','assets/enemies/catfish/base/Brown-idle-1.webp'],
      spooky:['assets/enemies/pumpkitty/base/idle-1.webp','assets/enemies/pumpkitty/base/pink-idle-1.webp','assets/enemies/pumpkitty/base/gold-idle-1.webp'],
      city:['assets/enemies/trashcat/base/idle-1.webp','assets/enemies/trashcat/base/blue-idle-1.webp','assets/enemies/trashcat/base/orange-idle-1.webp'],
      candy:['assets/enemies/jellybeanie/base/idle-1.webp','assets/enemies/jellybeanie/base/lime-idle-1.webp','assets/enemies/jellybeanie/base/grape-idle-1.webp'],
      cloud:['assets/enemies/whispurr/base/idle-1.webp','assets/enemies/whispurr/base/pink-idle-1.webp','assets/enemies/whispurr/base/purple-idle-1.webp']
    };
    const options=[...(pool[area]||pool.meadow)].sort(()=>Math.random()-.5);
    if(Math.random()<.16)options[Math.floor(Math.random()*3)]='assets/enemies/mimic/base/open-1.webp';
    options.slice(0,3).forEach((src,i)=>{
      const img=document.createElement('img');img.className='lain-rescue-kitty-v359';img.alt='One of Lain’s rescued kittens';img.src=src;
      img.style.setProperty('--kitty-index',i);img.style.left=`${33+i*9}%`;
      state.el.insertBefore(img,state.right);
    });
  }

  function showScene(sceneId, onFinished){
    const scene = SCENES[sceneId];
    if (!scene || open) return false;
    document.querySelector("#questCardRewardV311")?.remove();
    const el = sceneLayer();
    const message = document.querySelector("#battleMessage");
    const actions = document.querySelector("#eventChoiceActions");
    if (!el || !message || !actions) return false;

    open = true;
    markSceneUi(true);
    const encounterLabel = document.querySelector("#encounterLabel");
    if (encounterLabel) encounterLabel.textContent = `${scene.kicker || "LOVE INTEREST"} · ${scene.title}`;

    const state = {
      scene,
      el,
      left: el.querySelector(".love-interest-battle-left"),
      right: el.querySelector(".love-interest-battle-right"),
      heart: el.querySelector(".love-interest-battle-heart"),
      leftPose: scene.leftId === "miko" ? "idle" : "idle1",
      rightPose: scene.rightId === "miko" ? "idle" : "idle1"
    };
    state.left.alt = CHARACTERS[scene.leftId]?.name || scene.leftId;
    state.right.alt = CHARACTERS[scene.rightId]?.name || scene.rightId;
    // The layer persists across encounters: discard the previous lover immediately.
    state.left.removeAttribute("src"); state.right.removeAttribute("src");
    state.left.style.visibility="hidden"; state.right.style.visibility="hidden";
    state.left.onload = () => sizeSceneSprite(state.left);
    state.right.onload = () => sizeSceneSprite(state.right);
    sceneKitties(state);

    let index = 0;
    const render = () => {
      const step = scene.dialogue[index];
      state.leftPose = step.leftPose || state.leftPose;
      state.rightPose = step.rightPose || state.rightPose;
      if(scene.id === "midori"){
        state.rightPose = index===0 ? "closed" : (state.rightPose==="idle2" ? "idle1" : state.rightPose);
      }
      updateSceneSprites(state);
      const clean = cleanDialogueText(step.text);
      message.textContent = step.speaker === "Narrator" ? clean : `${step.speaker}: ${clean}`;
      actions.innerHTML = "";
      const row = document.createElement("div");
      row.className = "love-interest-dialogue-actions";
      const next = document.createElement("button");
      next.type = "button";
      next.className = "pixel-button primary";
      const last = index >= scene.dialogue.length - 1;
      next.textContent = last ? "Finish" : "Next";
      next.addEventListener("click", () => {
        if (!last) {
          index += 1;
          render();
          return;
        }
        next.disabled = true;
        stopSceneAnimation();
        state.heart.classList.remove("hidden");
        const isRepeat = !scene.id.includes("-") && Boolean(load().loveInterests?.[scene.id]?.encountered);
        scene.reward();
        if(isRepeat){
          const cfg=CHARACTERS[scene.id], data=load();
          if(cfg){
            ensureAll(data);
            data.duckCollectionCounts[cfg.duckId]=Math.max(1,Math.floor(Number(data.duckCollectionCounts[cfg.duckId])||1))+1;
            grantCard(data,cfg.cardId,1);
            save(data);
          }
        }
        message.classList.add("love-interest-reward-message-hidden-v290");
        actions.innerHTML = "";

        const closeScene = () => {
          if (state.resizeHandler) window.removeEventListener("resize", state.resizeHandler);
          state.left.onload = null;
          state.right.onload = null;
          state.heart.classList.add("hidden");
          el.querySelectorAll(".lain-rescue-kitty-v359").forEach(node=>node.remove());
          el.classList.add("hidden");
          el.setAttribute("aria-hidden", "true");
          actions.innerHTML = "";
          actions.classList.add("hidden");
          message.classList.remove("love-interest-reward-message-hidden-v290");
          markSceneUi(false);
          open = false;
          if (typeof onFinished === "function") {
            bypassNextRoll = true;
            onFinished();
          }
        };

        actions.append(buildSceneRewardPopup(scene,closeScene,isRepeat));
        actions.classList.remove("hidden");
      });
      row.append(next);
      actions.append(row);
      actions.classList.remove("hidden");
    };

    el.classList.remove("hidden");
    el.setAttribute("aria-hidden", "false");
    state.resizeHandler = () => { sizeSceneSprite(state.left); sizeSceneSprite(state.right); };
    window.addEventListener("resize", state.resizeHandler);
    render();
    startSceneAnimation(state);
    return true;
  }

  function reconcileRecordedRewards(){
    const data = load();
    const root = ensureAll(data);
    let shouldSave = false;
    for (const key of ["lukio", "shinobu", "cheryln", "hibiki", "devlin", "yuzuru", "westley", "circe", "quin", "kiri", "midori", "luka", "cybil", "nico", "nene", "moriko", "jenson", "shin", "bubble", "lain", "tamao", "ranger", "lovell", "collin", "beau", "ein", "ideno", "hinaru"]) {
      if (!root.loveInterests[key]?.encountered) continue;
      unlockCharacter(data, key, { grantCard: key === "lukio", grantDuck: true, grantOutfit: true });
      shouldSave = true;
    }
    const pairChecks = [
      ["shinobuCheryln", ["shinobu", "cheryln"]],
      ["devlinHibiki", ["hibiki", "devlin"]],
      ["westleyYuzuru", ["yuzuru", "westley"]],
      ["circeQuin", ["circe", "quin"]],
      ["kiriMidori", ["kiri", "midori"]],
      ["lukaCybil", ["luka", "cybil"]],
      ["nicoNene", ["nico", "nene"]],
      ["morikoJenson", ["moriko", "jenson"]],
      ["shinTamao", ["shin", "tamao"]],
      ["bubbleLain", ["bubble", "lain"]]
    ];
    for (const [pairKey, keys] of pairChecks) {
      if (!root.pairScenes[pairKey]?.cardsGranted) continue;
      unlockCardsOnly(data, keys);
      shouldSave = true;
    }
    if (shouldSave) save(data);
  }

  // LUV_BIRDIE_FOCUS_V262: Luv & Birdie can temporarily weight one Miko love interest.
  function luvBirdieFocus(data){
    const focus=data?.luvBirdieFocusV262;
    if(!focus || !focus.characterId || Number(focus.rollsRemaining)<=0) return null;
    return focus;
  }

  function eligibleScenes(){
    const data = load();
    const root = ensureAll(data);
    const ids = [];
    if(activeCharacterId()==='miho'){
      const mihoIds=['ranger','lovell','collin','beau','ein','ideno','hinaru'];
      const unseen=mihoIds.filter(id=>!root.loveInterests[id].encountered);
      return unseen.length?unseen:mihoIds;
    }
    if(activeCharacterId()==='annika'){
      for(const name of ['shin','bubble','lain','tamao'])if(!root.loveInterests[name].encountered)ids.push(name);
      if(root.loveInterests.shin.encountered&&root.loveInterests.tamao.encountered&&!root.pairScenes.shinTamao.cardsGranted)ids.push('shin-tamao');
      if(root.loveInterests.bubble.encountered&&root.loveInterests.lain.encountered&&!root.pairScenes.bubbleLain.cardsGranted)ids.push('bubble-lain');
      return ids.length?ids:['shin','bubble','lain','tamao']; // Repeat encounters: duck + card, never reaward outfit.
    }

    if (!root.loveInterests.lukio.encountered) ids.push("lukio");
    if (!root.loveInterests.shinobu.encountered) ids.push("shinobu");
    if (!root.loveInterests.cheryln.encountered) ids.push("cheryln");
    if (!root.loveInterests.hibiki.encountered) ids.push("hibiki");
    if (!root.loveInterests.devlin.encountered) ids.push("devlin");
    if (!root.loveInterests.yuzuru.encountered) ids.push("yuzuru");
    if (!root.loveInterests.westley.encountered) ids.push("westley");
    if (!root.loveInterests.circe.encountered) ids.push("circe");
    if (!root.loveInterests.quin.encountered) ids.push("quin");
    if (!root.loveInterests.kiri.encountered) ids.push("kiri");
    if (!root.loveInterests.midori.encountered) ids.push("midori");
    if (!root.loveInterests.luka.encountered) ids.push("luka");
    if (!root.loveInterests.cybil.encountered) ids.push("cybil");
    if (!root.loveInterests.nico.encountered) ids.push("nico");
    if (!root.loveInterests.nene.encountered) ids.push("nene");
    if (!root.loveInterests.moriko.encountered) ids.push("moriko");
    if (!root.loveInterests.jenson.encountered) ids.push("jenson");

    const focus=luvBirdieFocus(data);
    if(focus && CHARACTERS[focus.characterId] && !ids.includes(focus.characterId)) ids.push(focus.characterId);

    if (root.loveInterests.shinobu.encountered && root.loveInterests.cheryln.encountered && !root.pairScenes.shinobuCheryln.cardsGranted) ids.push("shinobu-cheryln");
    if (root.loveInterests.hibiki.encountered && root.loveInterests.devlin.encountered && !root.pairScenes.devlinHibiki.cardsGranted) ids.push("devlin-hibiki");
    if (root.loveInterests.yuzuru.encountered && root.loveInterests.westley.encountered && !root.pairScenes.westleyYuzuru.cardsGranted) ids.push("westley-yuzuru");
    if (root.loveInterests.circe.encountered && root.loveInterests.quin.encountered && !root.pairScenes.circeQuin.cardsGranted) ids.push("circe-quin");
    if (root.loveInterests.kiri.encountered && root.loveInterests.midori.encountered && !root.pairScenes.kiriMidori.cardsGranted) ids.push("kiri-midori");
    if (root.loveInterests.luka.encountered && root.loveInterests.cybil.encountered && !root.pairScenes.lukaCybil.cardsGranted) ids.push("luka-cybil");
    if (root.loveInterests.nico.encountered && root.loveInterests.nene.encountered && !root.pairScenes.nicoNene.cardsGranted) ids.push("nico-nene");
    if (root.loveInterests.moriko.encountered && root.loveInterests.jenson.encountered && !root.pairScenes.morikoJenson.cardsGranted) ids.push("moriko-jenson");
    return ids;
  }

  function chooseScene(ids, data){
    const focus=luvBirdieFocus(data);
    if(focus && ids.includes(focus.characterId)){
      const weighted=[];
      ids.forEach(id=>{const weight=id===focus.characterId?Math.max(1,Number(focus.weight)||3):1;for(let i=0;i<weight;i++)weighted.push(id);});
      return weighted[Math.floor(Math.random()*weighted.length)];
    }
    const pairScenes = ids.filter(id => id.includes("-"));
    if (pairScenes.length) return pairScenes[Math.floor(Math.random() * pairScenes.length)];
    return ids[Math.floor(Math.random() * ids.length)];
  }

  function maybeBeforeNextEncounter(continueFn){
    if (bypassNextRoll) { bypassNextRoll = false; return false; }
    if (open || !(isMiko() || activeCharacterId()==='annika')) return false;

    const data=load();
    const ids = eligibleScenes();
    if (!ids.length) return false;
    if (Math.random() >= SHARED_CHANCE) return false;

    const chosen=chooseScene(ids,data);
    const focus=luvBirdieFocus(data);
    if(focus){
      focus.rollsRemaining=Math.max(0,Number(focus.rollsRemaining)-1);
      if(chosen===focus.characterId || focus.rollsRemaining<=0) delete data.luvBirdieFocusV262;
      save(data);
    }
    return showScene(chosen, continueFn);
  }

  reconcileRecordedRewards();

  window.DuckieLoveInterests = window.DuckieLoveInterests || {};
  window.DuckieLoveInterests.activeCharacterId = activeCharacterId;
  window.DuckieLoveInterests.chance = SHARED_CHANCE;
  window.DuckieLoveInterests.maybeBeforeNextEncounter = maybeBeforeNextEncounter;
  window.DuckieLoveInterests.trigger = showScene;
  window.triggerRangerEncounter = function(){return showScene('ranger');};
  window.triggerLovellEncounter = function(){return showScene('lovell');};
  window.triggerCollinEncounter = function(){return showScene('collin');};
  window.triggerBeauEncounter = function(){return showScene('beau');};
  window.triggerEinEncounter = function(){return showScene('ein');};
  window.triggerIdenoEncounter = function(){return showScene('ideno');};
  window.triggerHinaruEncounter = function(){return showScene('hinaru');};
  window.triggerLainEncounter = function(){return showScene('lain');};
  window.triggerTamaoEncounter = function(){return showScene('tamao');};
  window.triggerShinTamaoCutscene = function(){return showScene('shin-tamao');};
  window.triggerBubbleLainCutscene = function(){return showScene('bubble-lain');};
  window.triggerShinEncounter = function(){return showScene('shin');};
  window.triggerBubbleEncounter = function(){return showScene('bubble');};
  window.triggerLukioEncounter = function(){ return showScene("lukio"); };
  window.triggerShinobuEncounter = function(){ return showScene("shinobu"); };
  window.triggerCherylnEncounter = function(){ return showScene("cheryln"); };
  window.triggerHibikiEncounter = function(){ return showScene("hibiki"); };
  window.triggerDevlinEncounter = function(){ return showScene("devlin"); };
  window.triggerYuzuruEncounter = function(){ return showScene("yuzuru"); };
  window.triggerWestleyEncounter = function(){ return showScene("westley"); };
  window.triggerCirceEncounter = function(){ return showScene("circe"); };
  window.triggerQuinEncounter = function(){ return showScene("quin"); };
  window.triggerKiriEncounter = function(){ return showScene("kiri"); };
  window.triggerMidoriEncounter = function(){ return showScene("midori"); };
  window.triggerLukaEncounter = function(){ return showScene("luka"); };
  window.triggerCybilEncounter = function(){ return showScene("cybil"); };
  window.triggerNicoEncounter = function(){ return showScene("nico"); };
  window.triggerNeneEncounter = function(){ return showScene("nene"); };
  window.triggerMorikoEncounter = function(){ return showScene("moriko"); };
  window.triggerJensonEncounter = function(){ return showScene("jenson"); };
  window.triggerShinobuCherylnCutscene = function(){ return showScene("shinobu-cheryln"); };
  window.triggerDevlinHibikiCutscene = function(){ return showScene("devlin-hibiki"); };
  window.triggerWestleyYuzuruCutscene = function(){ return showScene("westley-yuzuru"); };
  window.triggerCirceQuinCutscene = function(){ return showScene("circe-quin"); };
  window.triggerKiriMidoriCutscene = function(){ return showScene("kiri-midori"); };
  window.triggerLukaCybilCutscene = function(){ return showScene("luka-cybil"); };
  window.triggerNicoNeneCutscene = function(){ return showScene("nico-nene"); };
  window.triggerMorikoJensonCutscene = function(){ return showScene("moriko-jenson"); };
})();

// Duckie Days v24.299 — Bao Cafe rare NPC encounters + minigame return
(function(){
  'use strict';
  const VERSION='24.299',KEY='baoCafeChallengeV299',TC=window.DuckieTradingCards;
  const BEARS=['cheese','parfait','frappe','hime','melrose','pickle'];
  const INFO={
    cheese:{name:'Cheese',mode:'Combo scoring',copy:'Cheese rewards accuracy! Keep a perfect streak to build a bigger score multiplier.',card:'r-bao-cheese',food:'cupcake'},
    parfait:{name:'Parfait',mode:'Time boosts',copy:'Parfait adds time every 3 perfect orders. Stay accurate and keep the cafe moving!',card:'r-bao-parfait',food:'parfait'},
    frappe:{name:'Frappe',mode:'Double orders',copy:'Frappe loves upselling. Some customers will ask for two drinks instead of one!',card:'r-bao-frappe',food:'fancy-milk-tea'},
    hime:{name:'Hime',mode:'Special rewards',copy:'Hime would love your help at Bao Café! Complete a drink to receive one of her special presents.',card:'r-bao-hime',food:'chocolate-brioche'},
    melrose:{name:'Mel Rose',mode:'Special rewards',copy:'Mel Rose has cozy prizes and card packs to share. Help her make a delicious drink!',card:'r-bao-melrose',food:'fruit-tart'},
    pickle:{name:'Pickle',mode:'Special rewards',copy:'Pickle has treats, EXP candies, and eggs to share. Help with her café order!',card:'r-bao-pickle',food:'burger'}
  };
  let cooldown=0,animTimer=null;
  const pick=a=>a[Math.floor(Math.random()*a.length)];
  function sprite(b,f=1){return `assets/gimmicks/bao-cafe/${b}/idle-${f}.png`;}
  function challenge(){return hubSave?.[KEY];}
  function setChallenge(c){hubSave[KEY]=c;persistAll();}
  function clearAnim(){if(animTimer){clearInterval(animTimer);animTimer=null;}}
  function animateBear(b){clearAnim();let f=1;[1,2].forEach(n=>warmQuestImage(sprite(b,n)));setQuestSpriteFrame(ui.chestSprite,sprite(b,1));animTimer=setInterval(()=>{f=f===1?2:1;if(ui.chestSprite)setQuestSpriteFrame(ui.chestSprite,sprite(b,f));},480);}
  function prep(encounter){try{clearAnimations();}catch{}clearAnim();actionLocked=false;pendingChest=null;pendingDefeatedEnemy=null;befriendAttempted=false;ui.befriendPanel?.classList.add('hidden');ui.ponPurchasePanel?.classList.add('hidden');try{resetDoubleBattleUi();hideEventChoices();closeCommandWindow();}catch{}ui.enemyCombatant?.classList.add('hidden');ui.enemyCombatant2?.classList.add('hidden');ui.buddyCombatant?.classList.add('hidden');ui.commandGrid?.classList.add('hidden');ui.postFloorActions?.classList.add('hidden');ui.leaveEndlessButton?.classList.add('hidden');try{setPostFloorLayout(false);}catch{}ui.battlefield?.classList.add('bao-cafe-scene-v299');ui.chestLayer?.classList.remove('hidden');ui.chestSprite?.classList.add('gimmick-art-v288');ui.openChest?.classList.add('hidden');if(currentRun?.mode==='endless'){currentRun.rank=endlessEffectiveRank(currentRun.floor);ui.battleBg.src=currentRun.floorBackground||chooseEndlessBackground();}else if(currentRun){const cfg=currentAreaConfig();ui.battleBg.src=cfg.backgrounds[currentRun.index];}updateEncounterHeader(encounter);try{renderPeepHp();startPeepIdle();}catch{}}
  function menu(title,copy){const holder=ui.eventChoiceActions;holder.innerHTML='';holder.classList.remove('hidden');const m=document.createElement('div');m.className='gimmick-menu-v288';m.innerHTML=`<strong>${title}</strong><p>${copy}</p><div class="gimmick-actions-v288"></div>`;holder.append(m);return m;}
  function button(m,label,fn,cls=''){const b=document.createElement('button');b.type='button';b.className=`pixel-button ${cls}`.trim();b.textContent=label;b.addEventListener('click',fn);m.querySelector('.gimmick-actions-v288').append(b);return b;}
  function finishPlain(message){clearAnim();ui.battlefield?.classList.remove('bao-cafe-scene-v299');ui.chestLayer?.classList.add('hidden');ui.eventChoiceActions?.classList.add('hidden');ui.eventChoiceActions.innerHTML='';setMessage(message);if(currentRun?.mode==='endless')markEndlessFloorComplete();ui.continueButton.textContent=currentRun?.mode==='endless'?'Next Floor':'Continue';ui.postFloorActions?.classList.remove('hidden');ui.leaveEndlessButton?.classList.toggle('hidden',currentRun?.mode!=='endless');try{setPostFloorLayout(true);}catch{}actionLocked=false;persistAll();}
  function launch(bear){const info=INFO[bear];setChallenge({version:VERSION,status:'minigame',createdAt:Date.now(),bear,activeCharacterId,run:JSON.parse(JSON.stringify(currentRun))});location.href=`../bao-cafe/?duckquest=1&bear=${bear}&v=24-299`;}
  function show(encounter){const bear=encounter.bear||pick(BEARS),info=INFO[bear];prep(encounter);animateBear(bear);ui.chestCaption.textContent=info.name;setMessage(`${info.name} waves you over to help with a busy Bao Cafe shift!`);const m=menu(`${info.name} · Bao Cafe`,`${info.copy} Clear the short cafe challenge and return to this exact Duck Quest run.`);button(m,'Help at the Cafe!',()=>launch(bear),'primary');button(m,'Maybe next time',()=>finishPlain(`${info.name} waves goodbye and heads back to the cafe.`));}
  function addCoins(n){n=Math.max(0,Math.floor(Number(n)||0));hubSave.coins=Math.max(0,Number(hubSave.coins)||0)+n;if(currentRun)currentRun.coinsEarned=Math.max(0,Number(currentRun.coinsEarned)||0)+n;return n;}
  function addInventory(id,qty=1){if(!hubSave.inventory||typeof hubSave.inventory!=='object')hubSave.inventory={};hubSave.inventory[id]=Math.max(0,Number(hubSave.inventory[id])||0)+qty;if(currentRun?.itemsEarned){const e=currentRun.itemsEarned.find(x=>x.id===id);if(e)e.qty+=qty;else currentRun.itemsEarned.push({id,qty});}}
  function reward(c){
    if(c.rewardGranted&&c.reward)return c.reward;
    // The updated stand-alone Bao Café already grants the bear's random
    // prize(s) into the shared hub save, for perfect AND imperfect drinks.
    if(c.bearRewardsGranted){
      c.reward={coins:Math.max(0,Number(c.bearRewardCoins)||0),extras:Array.isArray(c.bearRewardNames)?c.bearRewardNames:[]};
      c.rewardGranted=true;
      c.run=JSON.parse(JSON.stringify(currentRun));
      setChallenge(c);return c.reward;
    }
    const info=INFO[c.bear]||INFO.cheese;const coins=addCoins(35+Math.floor(Math.random()*31));let extras=[];if(Math.random()<.55){addInventory(info.food,1);extras.push(info.food==='cupcake'?'Cupcake':info.food==='parfait'?'Parfait':'Fancy Milk Tea');}let card=null;if(Math.random()<.20&&TC?.byId?.[info.card]){card=TC.grantCard(hubSave,info.card,1);extras.push(`${card?.isNew?'NEW ':''}${info.name} Rare Card`);}c.reward={coins,extras};c.rewardGranted=true;c.run=JSON.parse(JSON.stringify(currentRun));setChallenge(c);return c.reward;}
  function restore(){const p=new URLSearchParams(location.search),c=challenge();if(p.get('bao-cafe-return')!=='1'||!c||c.status!=='return'||!c.run)return;currentRun=JSON.parse(JSON.stringify(c.run));activeCharacterId=c.activeCharacterId||activeCharacterId;questSave.activeCharacter=activeCharacterId;if(currentRun?.area&&AREA_CONFIG[currentRun.area])selectedArea=currentRun.area;if(currentRun?.rank)selectedRank=currentRun.rank;showScreen('battle');const bear=c.bear||'cheese',info=INFO[bear];prep(currentRun?.mode==='endless'?currentRun.endlessEncounter:currentRun?.plan?.[currentRun?.index||0]);animateBear(bear);ui.chestCaption.textContent=info.name;const holder=ui.eventChoiceActions;holder.innerHTML='';holder.classList.remove('hidden');const box=document.createElement('div');box.className='bao-cafe-result-v299';holder.append(box);if(c.cleared){const r=reward(c);setMessage(`Bao Cafe challenge clear! ${info.name} is thrilled with your help.`);box.innerHTML=`<strong>Shift Complete! ♡</strong><small>${c.orders||0} orders · ${Number(c.score||0).toLocaleString()} points</small><p>Reward: ${r.coins} Pink Coins${r.extras.length?' · '+r.extras.join(' · '):''}</p>`;}else{
      setMessage('The shift was not perfect, but your Duck Quest run is safe.');
      if(c.bearRewardsGranted){
        const r=reward(c);
        box.innerHTML=`<strong>Shift Finished ♡</strong><small>${c.bear||'Your bear'} shared a thank-you prize!</small><p>${r.extras.join(' · ')||'A special café reward'} · Return to Duck Quest anytime.</p>`;
      }else{
        box.innerHTML='<strong>Safe Return</strong><small>No encounter reward this time.</small><p>You can keep going in Duck Quest.</p>';
      }
    }
    const b=document.createElement('button');b.type='button';b.className='pixel-button primary';b.textContent='Continue';b.addEventListener('click',()=>{clearAnim();ui.battlefield?.classList.remove('bao-cafe-scene-v299');ui.chestLayer?.classList.add('hidden');ui.eventChoiceActions?.classList.add('hidden');ui.eventChoiceActions.innerHTML='';delete hubSave[KEY];persistAll();actionLocked=false;nextEncounter();});box.append(b);actionLocked=true;
  }
  if(typeof buildEncounter==='function'){const old=buildEncounter;buildEncounter=function(){const result=old.apply(this,arguments);if(result?.type!=='enemy')return result;if(cooldown>0){cooldown--;return result;}if(Math.random()>=.015)return result;cooldown=7;return{type:'bao-cafe',bear:pick(BEARS)};};}
  if(typeof situationTitle==='function'){const old=situationTitle;situationTitle=function(type){if(type==='bao-cafe')return'Bao Cafe';return old.apply(this,arguments);};}
  if(typeof updateEncounterHeader==='function'){const old=updateEncounterHeader;updateEncounterHeader=function(encounter=currentEncounterData()){old.apply(this,arguments);if(encounter?.type==='bao-cafe')ui.encounterLabel.textContent+=' · RARE NPC';};}
  if(typeof startEncounter==='function'){const old=startEncounter;startEncounter=function(){const e=currentRun?.mode==='endless'?currentRun?.endlessEncounter:currentRun?.plan?.[currentRun?.index||0];if(e?.type==='bao-cafe'){show(e);return;}return old.apply(this,arguments);};}
  window.DuckieBaoCafeV299={show,version:VERSION};window.DUCKIE_BAO_CAFE_V299=VERSION;setTimeout(restore,0);
})();

// Duck Quest game-v67 — polished battle UI + six-Lil Guy battle switching
const HUB_SAVE_KEY = "duckHabitHubSave_v1";
window.DUCKIE_DAYS_QUEST_FLOW='24.225-next-level-and-start-picker';
const MAX_LEVEL = 999;
const AREA_CONFIG = Object.freeze({
  meadow: {
    id:"meadow",
    name:"Meadow",
    label:"MEADOW PATH",
    maxRank:40,
    backgrounds:[
      "assets/backgrounds/meadow/stage-1-tree.webp",
      "assets/backgrounds/meadow/stage-2-bushes.webp",
      "assets/backgrounds/meadow/stage-3-flowers.webp",
      "assets/backgrounds/meadow/stage-4-boss.webp"
    ],
    stageNames:["Meadow Path","Bush Trail","Flower Field","Boss Clearing"],
    resultTitle:"The Meadow is Clear!"
  },
  ocean: {
    id:"ocean",
    name:"Ocean",
    label:"OCEAN ROUTE",
    maxRank:80,
    backgrounds:[
      "assets/backgrounds/ocean/shore.webp",
      "assets/backgrounds/ocean/surface.webp",
      "assets/backgrounds/ocean/deep.webp",
      "assets/backgrounds/ocean/floor.webp"
    ],
    stageNames:["Shore","Ocean Surface","Ocean Deep","Ocean Floor"],
    resultTitle:"The Ocean Route is Clear!"
  },
  candy: {
    id:"candy",
    name:"Candyland",
    label:"CANDYLAND",
    maxRank:120,
    backgrounds:[
      "assets/backgrounds/candyland/lollipop-lane.webp",
      "assets/backgrounds/candyland/gumdrop-path.webp",
      "assets/backgrounds/candyland/candycane-bridge.webp",
      "assets/backgrounds/candyland/chocolate-lake.webp"
    ],
    stageNames:["Lollipop Lane","Gumdrop Path","Candycane Bridge","Chocolate Lake"],
    resultTitle:"Candyland is Clear!"
  },
  cloud: {
    id:"cloud",
    name:"Cloud Garden",
    label:"CLOUD GARDEN",
    maxRank:160,
    backgrounds:[
      "assets/backgrounds/cloud/stage-1-stairs.png",
      "assets/backgrounds/cloud/stage-2-pillar.png",
      "assets/backgrounds/cloud/stage-3-top.png",
      "assets/backgrounds/cloud/stage-4-star-boss.png"
    ],
    stageNames:["Cloud Stairs","Pillar Garden","Cloud Top","Star Sanctuary"],
    resultTitle:"The Cloud Garden is Clear!"
  },
  city: {
    id:"city",name:"City Streets",label:"CITY STREETS",maxRank:200,
    backgrounds:[
      "assets/backgrounds/city/stage-1.png",
      "assets/backgrounds/city/stage-2.png",
      "assets/backgrounds/city/stage-3.png",
      "assets/backgrounds/city/stage-boss.png"
    ],
    stageNames:["Neighborhood Lane","Apartment Row","Corner Store","City Crossroads"],
    resultTitle:"City Streets is Clear!"
  },
  spooky: {
    id:"spooky",name:"Spooky Forest",label:"SPOOKY FOREST",maxRank:240,
    backgrounds:[
      "assets/backgrounds/spooky/stage-1.webp",
      "assets/backgrounds/spooky/stage-2.webp",
      "assets/backgrounds/spooky/stage-3.webp",
      "assets/backgrounds/spooky/stage-4.webp"
    ],
    stageNames:["Whispering Woods","Graveyard Trail","Pumpkin Path","Haunted Manor"],
    resultTitle:"Spooky Forest is Clear!"
  }
});

function getAreaConfig(areaId){
  return AREA_CONFIG[areaId] || AREA_CONFIG.meadow;
}


// v24.154 — Stitched borders use a crisp assist outline only for light colors; Sakura/Sparkle stay clean.
// Internal save keys still use the legacy area/rank names so existing player progress remains compatible.
const QUEST_NPC_HEROES = Object.freeze({"lukio":{"name":"Lukio","idle":["assets/love-interests/lukio/Lukio-idle-1.png","assets/love-interests/lukio/Lukio-idle-2.png"]},"shinobu":{"name":"Shinobu","idle":["assets/love-interests/shinobu/Shinobu-idle-1.png","assets/love-interests/shinobu/Shinobu-idle-2.png"]},"cheryln":{"name":"Cheryln","idle":["assets/love-interests/cheryln/Cheryln-idle-1.png","assets/love-interests/cheryln/Cheryln-idle-2.png"]},"hibiki":{"name":"Hibiki","idle":["assets/love-interests/hibiki/Hibiki-idle-1.png","assets/love-interests/hibiki/Hibiki-idle-2.png"]},"devlin":{"name":"Devlin","idle":["assets/love-interests/devlin/Devlin-idle-1.png","assets/love-interests/devlin/Devlin-idle-2.png"]},"yuzuru":{"name":"Yuzuru","idle":["assets/love-interests/yuzuru/Yuzuru-idle-1.png","assets/love-interests/yuzuru/Yuzuru-idle-2.png"]},"westley":{"name":"Westley","idle":["assets/love-interests/westley/Westley-idle-1.png","assets/love-interests/westley/Westley-idle-2.png"]},"circe":{"name":"Circe","idle":["assets/love-interests/circe/Circe-idle-1.png","assets/love-interests/circe/Circe-idle-2.png"]},"quin":{"name":"Quin","idle":["assets/love-interests/quin/Quin-idle-1.png","assets/love-interests/quin/Quin-idle-2.png"]},"kiri":{"name":"Kiri","idle":["assets/love-interests/kiri/Kiri-idle-1.png","assets/love-interests/kiri/Kiri-idle-2.png"]},"midori":{"name":"Midori","idle":["assets/love-interests/midori/Midori-opened.png","assets/love-interests/midori/Midori-opened.png"]},"luka":{"name":"Luka","idle":["assets/love-interests/luka/Luka-idle-1.png","assets/love-interests/luka/Luka-idle-2.png"]},"cybil":{"name":"Cybil","idle":["assets/love-interests/cybil/Cybil-idle-1.png","assets/love-interests/cybil/Cybil-idle-2.png"]},"nico":{"name":"Nico","idle":["assets/love-interests/nico/Nico-idle-1.png","assets/love-interests/nico/Nico-idle-2.png"]},"nene":{"name":"Nene","idle":["assets/love-interests/nene/Nene-idle-1.png","assets/love-interests/nene/Nene-idle-2.png"]},"moriko":{"name":"Moriko","idle":["assets/love-interests/moriko/Moriko-idle-1.png","assets/love-interests/moriko/Moriko-idle-2.png"]},"jenson":{"name":"Jenson","idle":["assets/love-interests/jenson/Jenson-Sprite-idle-1.png","assets/love-interests/jenson/Jenson-Sprite-idle-2.png"]},"shin":{"name":"Shin","idle":["assets/love-interests/shin/Shin-idle-1.png","assets/love-interests/shin/Shin-idle-2.png"]},"bubble":{"name":"Bubble","idle":["assets/love-interests/bubble/Bubble-idle-1.png","assets/love-interests/bubble/Bubble-idle-2.png"]},"lain":{"name":"Lain","idle":["assets/love-interests/lain/Lain-idle-1.png","assets/love-interests/lain/Lain-idle-2.png"]},"tamao":{"name":"Tamao","idle":["assets/love-interests/tamao/Tamao-idle-1.png","assets/love-interests/tamao/Tamao-idle-2.png"]},"ranger":{"name":"Ranger","idle":["assets/love-interests/ranger/Ranger-idle-1.png","assets/love-interests/ranger/Ranger-idle-2.png"]},"lovell":{"name":"Lovell","idle":["assets/love-interests/lovell/Lovell-idle-1.png","assets/love-interests/lovell/Lovell-idle-2.png"]},"collin":{"name":"Collin","idle":["assets/love-interests/collin/Collin-idle-1.png","assets/love-interests/collin/Collin-idle-2.png"]},"beau":{"name":"Beau","idle":["assets/love-interests/beau/Beau-idle-1.png","assets/love-interests/beau/Beau-idle-2.png"]},"ein":{"name":"Ein","idle":["assets/love-interests/ein/Ein-idle-1.png","assets/love-interests/ein/Ein-idle-2.png"]},"ideno":{"name":"Ideno","idle":["assets/love-interests/ideno/Ideno-idle-1.png","assets/love-interests/ideno/Ideno-idle-2.png"]},"hinaru":{"name":"Hinaru","idle":["assets/love-interests/hinaru/Hinaru-idle-1.png","assets/love-interests/hinaru/Hinaru-idle-2.png"]},"yukine":{"name":"Yukine","idle":["assets/love-interests/yukine/Yukine-idle-1.png","assets/love-interests/yukine/Yukine-idle-2.png"]},"demon":{"name":"Demon","idle":["assets/encounters/demon/Demon-sprite-idle-1.png","assets/encounters/demon/Demon-sprite-idle-2.png"]}});
const QUEST_NPC_IDS = Object.freeze(Object.keys(QUEST_NPC_HEROES));
function npcQuestEncounterCount(id){return id==="demon"?Math.max(0,Number(hubSave?.angelDemonReunion?.totalEncounters)||0):Math.max(0,Number(hubSave?.loveInterests?.[id]?.duckQuestEncountersV412)||0);}
function npcQuestUnlocked(id){return Boolean(QUEST_NPC_HEROES[id] && npcQuestEncounterCount(id)>=10);}
function taskBuddyHappiness(id){try{return Math.max(0,Math.min(100,Number(JSON.parse(localStorage.getItem('duckieTaskBuddyRoom_v7')||'{}')?.buddyProgress?.[id]?.happiness)||0));}catch(_){return 0;}}
const QUEST_CHARACTER_IDS = Object.freeze(["peep","miko","io","miho","annika","shiyu","angel",...QUEST_NPC_IDS]);
const QUEST_CHARACTER_NAMES = Object.freeze({peep:"Peep",miko:"Miko",io:"Io",miho:"Miho",annika:"Annika",shiyu:"Shiyu",angel:"Angel",...Object.fromEntries(Object.entries(QUEST_NPC_HEROES).map(([id,v])=>[id,v.name]))});
window.DUCKIE_UI_THEME_CORE='24.211-expanded-theme-catalog';
const QUEST_UI_THEMES = Object.freeze([
  {
    id:"classic-cream", name:"Classic Cream",
    description:"The original cozy cream-and-pink Duck Quest look.",
    swatches:["#fff7e5","#f4a7c1","#8c625d"], themeColor:"#f6c6d6", requirement:null
  },
  {
    id:"peep-picnic", name:"Peep Picnic",
    description:"Blush pink, mint, and strawberry cream.",
    swatches:["#fff9f4","#e991b2","#9ed8cb"], themeColor:"#f4c6d6",
    requirement:{stage:"meadow",level:10,character:"peep"}
  },
  {
    id:"miko-moonlight", name:"Miko Teal Moonlight",
    description:"Deep teal, ink black, ivory cream, and warm gold.",
    swatches:["#f8f3e3","#3f958e","#20292a","#d6bd72"], themeColor:"#4b9e97",
    requirement:{stage:"meadow",level:10,character:"miko"}
  },
  {
    id:"io-sweetheart", name:"Io Sweetheart",
    description:"Rose pink, berry accents, and soft candy cream.",
    swatches:["#fff7fb","#e9619b","#f4b5c9"], themeColor:"#f4bfd1",
    requirement:{stage:"meadow",level:10,character:"io"}
  },
  {
    id:"miho-tea-room", name:"Miho Silent Space",
    description:"Charcoal, wine red, dusty rose, and moonlit cream.",
    swatches:["#20191e","#99495d","#f7eef0","#d7c0c7"], themeColor:"#6f3948",
    requirement:{stage:"meadow",level:10,character:"miho"}
  },
  {
    id:"annika-crimson", name:"Annika Crimson",
    description:"Cherry red with softer cream highlights for easier reading.",
    swatches:["#fff7f4","#b14b60","#f4d6dc"], themeColor:"#b14b60",
    requirement:{stage:"meadow",level:10,character:"annika"}
  },
  {
    id:"meadow-bloom", name:"Meadow Bloom",
    description:"Fresh clover, petal pink, and sunny cream.",
    swatches:["#f8f5d9","#89bd7e","#e6a9be"], themeColor:"#d8e7c3",
    requirement:{stage:"meadow",level:20}
  },
  {
    id:"ocean-breeze", name:"Ocean Breeze",
    description:"Sea-glass blue, foam, and a soft coral accent.",
    swatches:["#f3fbff","#83bfd9","#e8a9af"], themeColor:"#c9e5ef",
    requirement:{stage:"ocean",level:40}
  },
  {
    id:"candy-pop", name:"Candy Pop",
    description:"Bubblegum pink, lavender, and sherbet yellow.",
    swatches:["#fff7fc","#ed8fbc","#c9a9ec"], themeColor:"#f4c8e1",
    requirement:{stage:"candy",level:60}
  },
  {
    id:"cloud-dream", name:"Cloud Dream",
    description:"Sky blue, lilac, and starlight gold.",
    swatches:["#f7fbff","#a9c9ee","#c6b4e8"], themeColor:"#d9e8f5",
    requirement:{stage:"cloud",level:80}
  },
  {
    id:"matcha-cream", name:"Matcha Cream",
    description:"Soft sage, matcha green, warm cream, and a touch of gold.",
    swatches:["#fbf7e8","#88aa78","#465044","#c9dbae"], themeColor:"#a8c59c",
    requirement:{stage:"meadow",level:30}
  },
  {
    id:"seafoam-pearl", name:"Seafoam Pearl",
    description:"Seafoam teal, pearl white, and a tiny champagne-gold accent.",
    swatches:["#f8fffc","#61b5ad","#385653","#eadbb1"], themeColor:"#a9d8d1",
    requirement:{stage:"ocean",level:60}
  },
  {
    id:"strawberry-milk", name:"Strawberry Milk",
    description:"Strawberry pink, milk cream, and a soft berry outline.",
    swatches:["#fff8f4","#df788d","#cc6279","#f3c2ca"], themeColor:"#efb0bc",
    requirement:{stage:"candy",level:90}
  },
  {
    id:"lavender-starlight", name:"Lavender Starlight",
    description:"Dreamy lavender, soft plum, moon cream, and pale starlight gold.",
    swatches:["#fbf9ff","#a38bd3","#504862","#ead7a9"], themeColor:"#cdbce8",
    requirement:{stage:"cloud",level:140}
  },
  {
    id:"rose-arcade", name:"Rose Arcade",
    description:"Retro rosy pink, cream, and berry accents.",
    swatches:["#fff6fa","#d95f91","#7d5266"], themeColor:"#eaa2bd",
    requirement:{endlessRuns:20}
  },
  {
    id:"mint-circuit", name:"Mint Circuit",
    description:"Cool mint, aqua, and clean graphite details.",
    swatches:["#f5fffb","#4faaa0","#344e4a"], themeColor:"#a8ded2",
    requirement:{endlessRuns:40}
  },
  {
    id:"midnight-pixel", name:"Midnight Pixel",
    description:"Deep navy, soft indigo, and moonlit white.",
    swatches:["#1c203d","#7d83d6","#f2f2ff"], themeColor:"#262b52",
    requirement:{endlessRuns:60}
  },
  {
    id:"peach-sunset", name:"Peach Sunset",
    description:"Warm peach, dusty coral, and soft mauve cream.",
    swatches:["#fff8f3","#df826f","#efb6ad"], themeColor:"#eead98",
    requirement:{endlessRuns:80}
  },
  {
    id:"rose-gold-royale", name:"Rose-Gold Royale",
    description:"Ivory, rose gold, and elegant wine accents.",
    swatches:["#fff8f2","#b96e77","#e2b7aa"], themeColor:"#b56b78",
    requirement:{endlessRuns:100}
  }
]);
const QUEST_UI_THEME_IDS = new Set(QUEST_UI_THEMES.map(theme=>theme.id));

function questUiThemeById(id){ return QUEST_UI_THEMES.find(theme=>theme.id===id) || QUEST_UI_THEMES[0]; }
function questCharacterName(id){ return QUEST_CHARACTER_NAMES[id] || "OC"; }
function questThemeRequirementText(theme){
  const req=theme?.requirement;
  if(!req) return "Always available";
  if(req.endlessRuns){
    const current=Math.max(0,Math.floor(Number(questSave?.endlessRunsCompleted)||0));
    return `Finish ${req.endlessRuns} Endless Runs (${Math.min(current,req.endlessRuns)}/${req.endlessRuns})`;
  }
  const stage=getAreaConfig(req.stage).name;
  return req.character
    ? `Clear ${stage} Level ${req.level} with ${questCharacterName(req.character)}`
    : `Clear ${stage} Level ${req.level}`;
}

const ICON_BACKGROUND_COLORS = Object.freeze([
  // Starter
  {id:"white",label:"White",value:"#fffaf3",rarity:"starter",source:"starter"},

  // Guaranteed level-up colors
  {id:"pink",label:"Pink",value:"#f2b4ca",rarity:"level",source:"level"},
  {id:"sky-blue",label:"Sky Blue",value:"#b7dbf3",rarity:"level",source:"level"},
  {id:"mint",label:"Mint",value:"#b9e2cb",rarity:"level",source:"level"},
  {id:"lavender",label:"Lavender",value:"#d7c4ef",rarity:"level",source:"level"},
  {id:"periwinkle",label:"Periwinkle",value:"#b9c2ef",rarity:"level",source:"level"},
  {id:"peach",label:"Peach",value:"#f5c1a8",rarity:"level",source:"level"},
  {id:"lilac",label:"Lilac",value:"#e3c7ee",rarity:"level",source:"level"},
  {id:"aqua",label:"Aqua",value:"#a9dfe3",rarity:"level",source:"level"},

  // Chest colors
  {id:"buttercream",label:"Buttercream",value:"#f8e9ae",rarity:"common",source:"chest",weight:10},
  {id:"blush",label:"Blush",value:"#f5ccd7",rarity:"common",source:"chest",weight:10},
  {id:"rose",label:"Rose Pink",value:"#eaa6bb",rarity:"common",source:"chest",weight:9},
  {id:"baby-blue",label:"Baby Blue",value:"#c7e1f5",rarity:"common",source:"chest",weight:9},
  {id:"seafoam",label:"Seafoam",value:"#c2e5d8",rarity:"common",source:"chest",weight:9},
  {id:"soft-coral",label:"Soft Coral",value:"#f2b1a4",rarity:"common",source:"chest",weight:8},
  {id:"sage",label:"Sage",value:"#c8d8b5",rarity:"common",source:"chest",weight:8},

  // Patterned chest backgrounds — pure CSS, no image files needed.
  {id:"pink-gingham",label:"Pink Gingham",rarity:"uncommon",source:"chest",weight:5,value:"linear-gradient(90deg,rgba(255,255,255,.45) 50%,transparent 50%),linear-gradient(rgba(255,255,255,.45) 50%,transparent 50%),#efb8ca",size:"24px 24px"},
  {id:"lavender-gingham",label:"Lavender Gingham",rarity:"uncommon",source:"chest",weight:5,value:"linear-gradient(90deg,rgba(255,255,255,.42) 50%,transparent 50%),linear-gradient(rgba(255,255,255,.42) 50%,transparent 50%),#cdb8eb",size:"24px 24px"},
  {id:"mint-gingham",label:"Mint Gingham",rarity:"uncommon",source:"chest",weight:5,value:"linear-gradient(90deg,rgba(255,255,255,.42) 50%,transparent 50%),linear-gradient(rgba(255,255,255,.42) 50%,transparent 50%),#afd9c2",size:"24px 24px"},
  {id:"periwinkle-gingham",label:"Periwinkle Gingham",rarity:"uncommon",source:"chest",weight:5,value:"linear-gradient(90deg,rgba(255,255,255,.4) 50%,transparent 50%),linear-gradient(rgba(255,255,255,.4) 50%,transparent 50%),#adb8ea",size:"24px 24px"},
  {id:"pink-polka",label:"Pink Polka Dots",rarity:"uncommon",source:"chest",weight:4,value:"radial-gradient(circle at 7px 7px,#fff7fb 0 3px,transparent 3.5px),#ecabc3",size:"22px 22px"},
  {id:"tiny-hearts",label:"Tiny Hearts",rarity:"rare",source:"chest",weight:2,value:"radial-gradient(circle at 25% 35%,#fff 0 3px,transparent 3.5px),radial-gradient(circle at 75% 65%,#fff 0 3px,transparent 3.5px),linear-gradient(135deg,#f4b7cb,#e6c1ef)",size:"28px 28px"},
  {id:"pink-glitter",label:"Pink Glitter",rarity:"rare",source:"chest",weight:1.8,value:"radial-gradient(circle at 15% 20%,#fff 0 1.5px,transparent 2px),radial-gradient(circle at 72% 28%,#ffe9a8 0 1.3px,transparent 1.8px),radial-gradient(circle at 38% 75%,#fff 0 1px,transparent 1.7px),linear-gradient(135deg,#eda9c4,#d995c1)",size:"22px 22px,28px 28px,18px 18px,auto"},
  {id:"lavender-glitter",label:"Lavender Glitter",rarity:"rare",source:"chest",weight:1.8,value:"radial-gradient(circle at 20% 22%,#fff 0 1.5px,transparent 2px),radial-gradient(circle at 68% 40%,#fff0b8 0 1.2px,transparent 1.8px),radial-gradient(circle at 42% 78%,#fff 0 1px,transparent 1.7px),linear-gradient(135deg,#c6b1ea,#aa95d9)",size:"22px 22px,30px 30px,18px 18px,auto"},
  {id:"starry-periwinkle",label:"Starry Periwinkle",rarity:"rare",source:"chest",weight:1.5,value:"radial-gradient(circle at 18% 22%,#fff9cf 0 2px,transparent 2.5px),radial-gradient(circle at 72% 34%,#fff 0 1.5px,transparent 2px),radial-gradient(circle at 48% 78%,#fff9cf 0 1.5px,transparent 2px),linear-gradient(160deg,#9da9df,#c1b1e5)",size:"30px 30px,26px 26px,34px 34px,auto"},
  {id:"gold-glitter",label:"Gold Glitter",rarity:"rare",source:"chest",weight:1.2,value:"radial-gradient(circle at 18% 20%,#fff8d7 0 1.5px,transparent 2px),radial-gradient(circle at 70% 28%,#fff 0 1px,transparent 1.7px),radial-gradient(circle at 45% 78%,#f7c75e 0 1.5px,transparent 2px),linear-gradient(135deg,#edd38a,#cda654)",size:"20px 20px,26px 26px,30px 30px,auto"},

  // Special pastel chest backgrounds — intentionally harder to find.
  {id:"strawberry-milk-sparkle",label:"Strawberry Milk Sparkle",rarity:"rare",source:"chest",weight:.70,value:"radial-gradient(circle at 16% 18%,#fff 0 1.5px,transparent 2px),radial-gradient(circle at 72% 34%,#ffe8a8 0 1.2px,transparent 1.8px),radial-gradient(circle at 40% 78%,#fff 0 1px,transparent 1.7px),linear-gradient(145deg,#f8c3d4,#f4dce4,#fff4ed)",size:"21px 21px,29px 29px,18px 18px,auto"},
  {id:"peach-soda-bubbles",label:"Peach Soda Bubbles",rarity:"rare",source:"chest",weight:.58,value:"radial-gradient(circle at 18% 24%,rgba(255,255,255,.92) 0 3px,transparent 3.7px),radial-gradient(circle at 70% 58%,rgba(255,255,255,.75) 0 2px,transparent 2.8px),radial-gradient(circle at 42% 82%,rgba(255,247,221,.85) 0 1.5px,transparent 2.2px),linear-gradient(145deg,#f7bda7,#f8d5bf,#fff0dc)",size:"34px 34px,27px 27px,23px 23px,auto"},
  {id:"mint-candy-stars",label:"Mint Candy Stars",rarity:"rare",source:"chest",weight:.48,value:"radial-gradient(circle at 20% 25%,#fff3b8 0 2px,transparent 2.6px),radial-gradient(circle at 72% 35%,#e7c9f4 0 2px,transparent 2.6px),radial-gradient(circle at 42% 78%,#f6b9cf 0 1.8px,transparent 2.4px),linear-gradient(135deg,#bce7cf,#d8f0dc)",size:"28px 28px,34px 34px,24px 24px,auto"},
  {id:"cotton-candy-clouds",label:"Cotton Candy Clouds",rarity:"rare",source:"chest",weight:.40,value:"radial-gradient(ellipse at 20% 35%,rgba(255,255,255,.62) 0 8px,transparent 9px),radial-gradient(ellipse at 74% 62%,rgba(255,255,255,.52) 0 9px,transparent 10px),linear-gradient(145deg,#bedef5,#f5c3d9 52%,#d9c7f1)",size:"48px 34px,52px 38px,auto"},
  {id:"sakura-mist",label:"Sakura Mist",rarity:"rare",source:"chest",weight:.32,value:"radial-gradient(ellipse at 18% 24%,#fff2f6 0 3px,transparent 3.8px),radial-gradient(ellipse at 72% 42%,#f6b6cb 0 2.5px,transparent 3.3px),radial-gradient(ellipse at 42% 78%,#fff6f0 0 2px,transparent 2.8px),linear-gradient(145deg,#f4c8d7,#e6d1ef,#f9e6ea)",size:"31px 25px,37px 29px,27px 23px,auto"},

  // Extra ultra-rare special drops.
  {id:"lavender-moonlight",label:"Lavender Moonlight",rarity:"ultra",source:"chest",weight:.10,value:"radial-gradient(circle at 22% 25%,#fff7c9 0 2px,transparent 2.6px),radial-gradient(circle at 72% 34%,#fff 0 1.4px,transparent 2px),radial-gradient(circle at 45% 78%,#fff7c9 0 1.2px,transparent 1.8px),linear-gradient(155deg,#aeb4e8,#c9b8ec,#e3ccef)",size:"34px 34px,27px 27px,39px 39px,auto"},
  {id:"angel-ribbon",label:"Angel Ribbon",rarity:"ultra",source:"chest",weight:.08,value:"repeating-linear-gradient(135deg,rgba(255,255,255,.48) 0 7px,transparent 7px 19px),linear-gradient(135deg,#cbe5f6,#fff3df 48%,#f4c7d9)",size:"34px 34px,auto"},
  {id:"dreamy-hearts",label:"Dreamy Hearts",rarity:"ultra",source:"chest",weight:.065,value:"radial-gradient(circle at 20% 28%,#fff 0 2.4px,transparent 3px),radial-gradient(circle at 72% 38%,#ffe4ef 0 2.4px,transparent 3px),radial-gradient(circle at 44% 78%,#fff5bf 0 1.8px,transparent 2.5px),linear-gradient(145deg,#efb7d0,#d4c1ef,#bfe0ef)",size:"29px 29px,35px 35px,24px 24px,auto"},
  {id:"pastel-confetti",label:"Pastel Confetti",rarity:"ultra",source:"chest",weight:.05,value:"radial-gradient(circle at 16% 22%,#f0a9c5 0 1.8px,transparent 2.4px),radial-gradient(circle at 70% 28%,#a9d9ed 0 1.8px,transparent 2.4px),radial-gradient(circle at 42% 76%,#bde0bf 0 1.8px,transparent 2.4px),radial-gradient(circle at 82% 82%,#d2b9ec 0 1.8px,transparent 2.4px),#fff7e8",size:"24px 24px,31px 31px,28px 28px,35px 35px,auto"},
  {id:"holographic-pastel",label:"Holographic Pastel",rarity:"ultra",source:"chest",weight:.035,value:"radial-gradient(circle at 18% 22%,rgba(255,255,255,.9) 0 1.5px,transparent 2px),radial-gradient(circle at 72% 68%,rgba(255,255,255,.8) 0 1.2px,transparent 1.8px),conic-gradient(from 35deg,#f4b7cf,#c3e2f5,#d8c5f0,#c7ead5,#fff0b8,#f4b7cf)",size:"26px 26px,33px 33px,auto"},
  {id:"sweetheart-rainbow",label:"Sweetheart Rainbow",rarity:"ultra",source:"chest",weight:.02,value:"radial-gradient(circle at 15% 20%,#fff 0 1.7px,transparent 2.2px),radial-gradient(circle at 72% 32%,#fff7ba 0 1.5px,transparent 2px),radial-gradient(circle at 44% 78%,#fff 0 1.3px,transparent 2px),linear-gradient(135deg,#f5a9c3,#f7c999,#d5e5aa,#b6dff0,#c9b8ef,#ecb8dd)",size:"22px 22px,29px 29px,34px 34px,auto"},


  // v39 — extra CSS-only chest backgrounds.
  {id:"lemon-cream-dots",label:"Lemon Cream Dots",rarity:"uncommon",source:"chest",weight:4.2,value:"radial-gradient(circle at 7px 7px,#fffaf0 0 3px,transparent 3.6px),#f4dda0",size:"22px 22px"},
  {id:"peach-checker",label:"Peach Checker",rarity:"uncommon",source:"chest",weight:4,value:"conic-gradient(#f8d2c5 25%,#efb6a7 0 50%,#f8d2c5 0 75%,#efb6a7 0)",size:"22px 22px"},
  {id:"mint-heart-confetti",label:"Mint Heart Confetti",rarity:"rare",source:"chest",weight:1.6,value:"radial-gradient(circle at 18% 25%,#fff 0 2.5px,transparent 3.1px),radial-gradient(circle at 72% 38%,#f6b8cf 0 2.3px,transparent 3px),radial-gradient(circle at 45% 78%,#d1b8ec 0 1.9px,transparent 2.6px),linear-gradient(145deg,#bce5ce,#dff2e5)",size:"29px 29px,35px 35px,25px 25px,auto"},
  {id:"blueberry-stardust",label:"Blueberry Stardust",rarity:"rare",source:"chest",weight:1.25,value:"radial-gradient(circle at 17% 21%,#fff5bd 0 1.8px,transparent 2.4px),radial-gradient(circle at 71% 33%,#fff 0 1.4px,transparent 2px),radial-gradient(circle at 43% 77%,#d9c8ff 0 1.7px,transparent 2.3px),linear-gradient(155deg,#6f78ba,#8d91ce,#b1a7dc)",size:"27px 27px,34px 34px,23px 23px,auto"},
  {id:"lilac-bubbles",label:"Lilac Bubbles",rarity:"rare",source:"chest",weight:1.1,value:"radial-gradient(circle at 18% 24%,rgba(255,255,255,.88) 0 3px,rgba(255,255,255,.25) 3.2px 4.5px,transparent 4.8px),radial-gradient(circle at 70% 62%,rgba(255,255,255,.7) 0 2px,rgba(255,255,255,.18) 2.2px 3.5px,transparent 3.8px),linear-gradient(145deg,#d5bce9,#ead9f2)",size:"36px 36px,29px 29px,auto"},
  {id:"rose-gold-sparkle",label:"Rose Gold Sparkle",rarity:"rare",source:"chest",weight:.9,value:"radial-gradient(circle at 15% 20%,#fff7e8 0 1.6px,transparent 2.1px),radial-gradient(circle at 71% 31%,#f8dcae 0 1.4px,transparent 2px),radial-gradient(circle at 43% 78%,#fff 0 1.2px,transparent 1.8px),linear-gradient(135deg,#d89a9c,#e5b7ac,#c99a80)",size:"21px 21px,28px 28px,32px 32px,auto"},
  {id:"cherry-blossom-glow",label:"Cherry Blossom Glow",rarity:"rare",source:"chest",weight:.7,value:"radial-gradient(circle at 20% 27%,rgba(255,255,255,.9) 0 2.5px,transparent 3.2px),radial-gradient(circle at 74% 43%,#f2a8c2 0 2.7px,transparent 3.5px),radial-gradient(circle at 43% 79%,#fff2f6 0 2px,transparent 2.8px),linear-gradient(145deg,#f1b7c9,#f8d9df,#f4c6d8)",size:"32px 32px,38px 38px,27px 27px,auto"},
  {id:"midnight-hearts",label:"Midnight Hearts",rarity:"ultra",source:"chest",weight:.12,value:"radial-gradient(circle at 18% 26%,#f8bfdc 0 2.5px,transparent 3.1px),radial-gradient(circle at 72% 39%,#d5c2ff 0 2.4px,transparent 3px),radial-gradient(circle at 44% 79%,#fff3b9 0 1.7px,transparent 2.4px),linear-gradient(150deg,#34355f,#545083,#735a91)",size:"29px 29px,36px 36px,24px 24px,auto"},

  // Ultra-rare chest prizes
  {id:"rainbow",label:"Rainbow",rarity:"ultra",source:"chest",weight:.45,value:"linear-gradient(135deg,#ed9baa,#f1c781,#b7daa0,#9dcfe2,#b7a6e4,#e2abd8)"},
  {id:"rainbow-gingham",label:"Rainbow Gingham",rarity:"ultra",source:"chest",weight:.28,value:"linear-gradient(90deg,rgba(255,255,255,.38) 50%,transparent 50%),linear-gradient(rgba(255,255,255,.38) 50%,transparent 50%),linear-gradient(135deg,#ef9cac,#f4d18d,#b6dda2,#9fd4e6,#b8a9e6,#e7add8)",size:"24px 24px,24px 24px,auto"},
  {id:"rainbow-glitter",label:"Rainbow Glitter",rarity:"ultra",source:"chest",weight:.16,value:"radial-gradient(circle at 14% 20%,#fff 0 1.7px,transparent 2.2px),radial-gradient(circle at 72% 30%,#fff9bd 0 1.5px,transparent 2px),radial-gradient(circle at 42% 76%,#fff 0 1.3px,transparent 2px),linear-gradient(135deg,#ee9dac,#f0c982,#b5dca0,#9fd2e4,#b6a6e2,#e3acd7)",size:"20px 20px,27px 27px,31px 31px,auto"}
]);

const LEVEL_ICON_BACKGROUND_REWARDS = Object.freeze({
  3:"pink",
  5:"sky-blue",
  10:"mint",
  15:"lavender",
  20:"periwinkle",
  30:"peach",
  40:"lilac",
  60:"aqua"
});

function iconBackgroundById(id){ return ICON_BACKGROUND_COLORS.find(color=>color.id===id) || ICON_BACKGROUND_COLORS[0]; }

const ICON_BORDER_STYLES = Object.freeze([
  {id:"none",label:"No Border",source:"starter",rarity:"starter",file:""},
  {id:"stitched",label:"Stitched Border",source:"chest",rarity:"common",weight:10,file:"../assets/ui/profile-borders/Stitched-border.png"},
  {id:"sparkle",label:"Sparkle Border",source:"chest",rarity:"uncommon",weight:6,file:"../assets/ui/profile-borders/Sparkle-border.png"},
  {id:"sakura",label:"Sakura Border",source:"chest",rarity:"rare",weight:3.2,file:"../assets/ui/profile-borders/Sakura-border.png"}
]);

const ICON_BORDER_COLORS = Object.freeze([
  {id:"white",label:"White",value:"#fffaf3",source:"starter",rarity:"starter"},
  {id:"cream",label:"Cream",value:"#f7ead2",source:"chest",rarity:"common",weight:10},
  {id:"blush",label:"Blush",value:"#f4c8d5",source:"chest",rarity:"common",weight:10},
  {id:"baby-blue",label:"Baby Blue",value:"#c8e1f6",source:"chest",rarity:"common",weight:9},
  {id:"mint",label:"Mint",value:"#bde3cf",source:"chest",rarity:"common",weight:9},
  {id:"peach",label:"Peach",value:"#f3c3ae",source:"chest",rarity:"common",weight:8.5},
  {id:"lavender",label:"Lavender",value:"#d6c5ef",source:"chest",rarity:"common",weight:8.5},
  {id:"rose",label:"Rose",value:"#e5a5bb",source:"chest",rarity:"uncommon",weight:6},
  {id:"sage",label:"Sage",value:"#c8d7b7",source:"chest",rarity:"uncommon",weight:5.5},
  {id:"periwinkle",label:"Periwinkle",value:"#b8c1ef",source:"chest",rarity:"uncommon",weight:5.5},
  {id:"berry",label:"Berry",value:"#bf7797",source:"chest",rarity:"uncommon",weight:4.2},
  {id:"gold",label:"Gold",value:"#d7ba65",source:"chest",rarity:"rare",weight:2.4},
  {id:"crimson",label:"Crimson",value:"#bb5c74",source:"chest",rarity:"rare",weight:1.9},
  {id:"black",label:"Black",value:"#43343b",source:"chest",rarity:"rare",weight:1.4},
  {id:"rose-gold",label:"Rose Gold",value:"#c98d89",source:"chest",rarity:"rare",weight:1.15}
]);

function iconBorderStyleById(id){ return ICON_BORDER_STYLES.find(style=>style.id===id) || ICON_BORDER_STYLES[0]; }
function iconBorderColorById(id){ return ICON_BORDER_COLORS.find(color=>color.id===id) || ICON_BORDER_COLORS[0]; }

function questIconBorderSelectionForCharacter(characterId){
  const raw=questSave?.[characterId] && typeof questSave[characterId]==="object" ? questSave[characterId] : {};
  const styleId=ICON_BORDER_STYLES.some(style=>style.id===raw.iconBorderStyle) ? raw.iconBorderStyle : "none";
  const colorId=ICON_BORDER_COLORS.some(color=>color.id===raw.iconBorderColor) ? raw.iconBorderColor : "white";
  return {styleId,colorId};
}

const QUEST_ICON_BORDER_TINT_CACHE = new Map();

function questBorderHexToRgb(hex){
  const safe=String(hex||"").trim().replace(/^#/,"");
  if(safe.length!==6) return {r:255,g:250,b:243};
  return {
    r:parseInt(safe.slice(0,2),16),
    g:parseInt(safe.slice(2,4),16),
    b:parseInt(safe.slice(4,6),16)
  };
}

function questBorderRgbToHex(r,g,b){
  const clamp=value=>Math.max(0,Math.min(255,Math.round(value||0)));
  return `#${[clamp(r),clamp(g),clamp(b)].map(value=>value.toString(16).padStart(2,"0")).join("")}`;
}

function questBorderRelativeLuminance(hex){
  const {r,g,b}=questBorderHexToRgb(hex);
  return ((0.2126*r)+(0.7152*g)+(0.0722*b))/255;
}

function isLightQuestBorderColor(hex){
  return questBorderRelativeLuminance(hex) >= 0.72;
}

function makeQuestBorderAssistColor(hex){
  const {r,g,b}=questBorderHexToRgb(hex);
  return questBorderRgbToHex(r*0.68,g*0.68,b*0.68);
}

function tintQuestBorderSource(source, fillColor){
  const canvas=document.createElement("canvas");
  canvas.width=source.naturalWidth||512;
  canvas.height=source.naturalHeight||512;
  const ctx=canvas.getContext("2d");
  if(!ctx) return null;
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.drawImage(source,0,0,canvas.width,canvas.height);
  ctx.globalCompositeOperation="source-in";
  ctx.fillStyle=fillColor||"#fffaf3";
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.globalCompositeOperation="source-over";
  return canvas;
}

function questIconBorderTintedSrc(file,colorValue,styleId){
  if(!file) return Promise.resolve("");
  const safeStyleId=styleId||"none";
  const key=`${file}|${colorValue}|${safeStyleId}`;
  if(QUEST_ICON_BORDER_TINT_CACHE.has(key)) return QUEST_ICON_BORDER_TINT_CACHE.get(key);

  const promise=new Promise(resolve=>{
    const source=new Image();
    source.decoding="async";
    source.onload=()=>{
      try{
        const base=tintQuestBorderSource(source,colorValue||"#fffaf3");
        if(!base){ resolve(file); return; }

        const output=document.createElement("canvas");
        output.width=base.width;
        output.height=base.height;
        const outCtx=output.getContext("2d");
        if(!outCtx){ resolve(file); return; }

        const wantsLightStitchOutline=safeStyleId==="stitched" && isLightQuestBorderColor(colorValue||"#fffaf3");
        if(wantsLightStitchOutline){
          // v24.157: make the light Stitched outline visibly readable at phone size.
          // The source art is 512px, so a 1px source offset was barely visible after scaling.
          // This uses a symmetric 4px source-space contour: crisp outline, no drop shadow.
          const outline=tintQuestBorderSource(source,makeQuestBorderAssistColor(colorValue||"#fffaf3"));
          if(outline){
            const outlineOffsets=[
              [-4,0],[4,0],[0,-4],[0,4],
              [-3,-3],[3,-3],[-3,3],[3,3],
              [-4,-2],[-4,2],[4,-2],[4,2],
              [-2,-4],[2,-4],[-2,4],[2,4]
            ];
            for(const [dx,dy] of outlineOffsets){
              outCtx.drawImage(outline,dx,dy,outline.width,outline.height);
            }
          }

          // Thicken the actual selected stitch color too, so it stays dominant over the outline.
          const stitchOffsets=[
            [-2,0],[2,0],[0,-2],[0,2],
            [-1,-1],[1,-1],[-1,1],[1,1]
          ];
          for(const [dx,dy] of stitchOffsets){
            outCtx.drawImage(base,dx,dy,base.width,base.height);
          }
        }

        outCtx.drawImage(base,0,0,base.width,base.height);
        resolve(output.toDataURL("image/png"));
      }catch(error){
        console.warn("Duck Quest icon border tint fallback:",error);
        resolve(file);
      }
    };
    source.onerror=()=>resolve(file);
    source.src=file;
  });

  QUEST_ICON_BORDER_TINT_CACHE.set(key,promise);
  return promise;
}

function applyQuestIconBorder(element, characterId){
  if(!element) return;
  const selection=questIconBorderSelectionForCharacter(characterId);
  const style=iconBorderStyleById(selection.styleId);
  const color=iconBorderColorById(selection.colorId);

  let layer=element.querySelector(":scope > .quest-icon-border-layer");
  if(style.id==="none"){
    if(layer) layer.remove();
    element.classList.remove("has-quest-icon-border");
    return;
  }

  // v24.155: use a real transparent PNG overlay; light Stitched gets same-color thickness only.
  // This is much more reliable on Android Chrome/PWA while still allowing
  // each border to be recolored to the selected border color.
  if(!layer || layer.tagName!=="IMG"){
    if(layer) layer.remove();
    layer=document.createElement("img");
    layer.className="quest-icon-border-layer";
    layer.alt="";
    layer.setAttribute("aria-hidden","true");
    layer.decoding="async";
    element.appendChild(layer);
  }

  element.classList.add("has-quest-icon-border");
  const renderToken=`${style.id}|${color.id}`;
  layer.dataset.borderToken=renderToken;

  // Show the source art immediately, then swap to the tinted PNG as soon as it is ready.
  layer.src=style.file;
  questIconBorderTintedSrc(style.file,color.value,style.id).then(src=>{
    if(layer.isConnected && layer.dataset.borderToken===renderToken && src){
      layer.src=src;
    }
  });
}

function questCharacterIconPreviewSrc(characterId){
  if(QUEST_NPC_HEROES[characterId])return QUEST_NPC_HEROES[characterId].idle[0];
  if(characterId === "miko") return MikoIdle?.[0] || "assets/characters/miko/base/idle-1.webp";
  if(characterId === "io") return IoIdle?.[0] || "assets/characters/io/base/idle-1.webp";
  if(characterId === "miho") return MihoIdle?.[0] || "assets/characters/miho/base/hurt.webp";
  if(characterId === "annika") return AnnikaIdle?.[0] || "assets/characters/annika/base/hurt.webp";
  if(characterId === "shiyu") return "assets/characters/shiyu/base/Shiyu-idle-1.png";
  if(characterId === "angel") return "assets/characters/angel/base/Angel-sprite-idle-1.png";
  return "assets/characters/peep/base/idle-1.webp";
}

const QUEST_WALLPAPERS = Object.freeze([
  {id:"starry-night-wallpaper",label:"Starry Night",rarity:"rare",weight:1.8,value:"radial-gradient(circle at 18% 22%,#fff6bf 0 2px,transparent 2.6px),radial-gradient(circle at 72% 34%,#fff 0 1.5px,transparent 2px),radial-gradient(circle at 48% 78%,#fff6bf 0 1.5px,transparent 2px),linear-gradient(160deg,#8d97d7,#b9b1ea)",size:"30px 30px,26px 26px,34px 34px,auto"},
  {id:"petal-dream-wallpaper",label:"Petal Dream",rarity:"rare",weight:1.05,value:"radial-gradient(circle at 24% 30%,rgba(255,245,252,.92) 0 3px,transparent 3.7px),radial-gradient(circle at 70% 68%,rgba(255,229,239,.9) 0 3px,transparent 3.7px),linear-gradient(145deg,#f0bfd2,#edd7f6)",size:"32px 32px,28px 28px,auto"},
  {id:"magical-sparkle-wallpaper",label:"Magical Sparkle",rarity:"rare",weight:1.2,value:"radial-gradient(circle at 15% 20%,#fff 0 1.5px,transparent 2px),radial-gradient(circle at 72% 28%,#ffe9a8 0 1.3px,transparent 1.8px),radial-gradient(circle at 38% 75%,#fff 0 1px,transparent 1.7px),linear-gradient(135deg,#eda9c4,#d995c1,#c5b0ea)",size:"22px 22px,28px 28px,18px 18px,auto"},
  {id:"rainbow-dream-wallpaper",label:"Rainbow Dream",rarity:"ultra",weight:.7,value:"linear-gradient(90deg,rgba(255,255,255,.36) 50%,transparent 50%),linear-gradient(rgba(255,255,255,.36) 50%,transparent 50%),linear-gradient(135deg,#f1adc4,#f6d299,#cfe4af,#b7ddf1,#cab6ef,#ecbddf)",size:"26px 26px,26px 26px,auto"},
  {id:"moonlit-hearts-wallpaper",label:"Moonlit Hearts",rarity:"ultra",weight:.45,value:"radial-gradient(circle at 18% 26%,#f8bfdc 0 2.5px,transparent 3.1px),radial-gradient(circle at 72% 39%,#d5c2ff 0 2.4px,transparent 3px),radial-gradient(circle at 44% 79%,#fff3b9 0 1.7px,transparent 2.4px),linear-gradient(150deg,#53538c,#715d9a,#a693d4)",size:"29px 29px,36px 36px,24px 24px,auto"},
  {id:"royal-celestial-wallpaper",label:"Royal Celestial",rarity:"ultra",weight:.38,value:"radial-gradient(circle at 16% 24%,#fff4bc 0 2px,transparent 2.7px),radial-gradient(circle at 76% 28%,#fff 0 1.6px,transparent 2.2px),radial-gradient(circle at 46% 76%,#ffd7ea 0 1.9px,transparent 2.6px),linear-gradient(150deg,#6a5e9f,#8a76bb,#c8b7e9)",size:"26px 26px,34px 34px,30px 30px,auto"}
]);

function questWallpaperById(id){ return QUEST_WALLPAPERS.find(wallpaper=>wallpaper.id===id) || null; }


const DUCK_LIBRARY = [{"id":"angry-duck","name":"Angry Duck","file":"angry-duck.webp"},{"id":"apple-duck","name":"Apple Duck","file":"apple-duck.webp"},{"id":"bathtime-duck","name":"Bathtime Duck","file":"bathtime-duck.webp"},{"id":"duck-on-skateboard","name":"Duck on a Skateboard","file":"duck-on-skateboard.webp"},{"id":"googly-eye-duck","name":"Googly Eye Duck","file":"googly-eye-duck.webp"},{"id":"long-hair-duck","name":"Long Hair Duck","file":"long-hair-duck.webp"},{"id":"magenta-duck","name":"Magenta Duck","file":"magenta-duck.webp"},{"id":"pile-of-tiny-ducks","name":"Pile of Tiny Ducks","file":"pile-of-tiny-ducks.webp"},{"id":"scarf-duck","name":"Scarf Duck","file":"scarf-duck.webp"},{"id":"vampire-duck","name":"Vampire Duck","file":"vampire-duck.webp"},{"id":"alien-duck","name":"Alien Duck","file":"Alien-duck.webp"},{"id":"angel-duck","name":"Heavenly Duck","file":"Angel-duck.webp"},{"id":"aqua-duck","name":"Aqua Duck","file":"Aqua-duck.webp"},{"id":"artist-duck","name":"Artist Duck","file":"Artist-duck.webp"},{"id":"black-duck","name":"Black Duck","file":"Black-duck.webp"},{"id":"blue-duck","name":"Blue Duck","file":"Blue-duck.webp"},{"id":"bow-duck","name":"Bow Duck","file":"Bow-duck.webp"},{"id":"bronze-duck","name":"Bronze Duck","file":"Bronze-duck.webp"},{"id":"bunny-duck","name":"Bunny Duck","file":"Bunny-duck.webp"},{"id":"burger-duck","name":"Burger Duck","file":"Burger-duck.webp"},{"id":"cat-duck","name":"Cat Duck","file":"Cat-duck.webp"},{"id":"cool-duck","name":"Cool Duck","file":"Cool-duck.webp"},{"id":"cosmic-duck","name":"Cosmic Duck","file":"Cosmic-duck.webp"},{"id":"cupcake-duck","name":"Cupcake Duck","file":"Cupcake-duck.webp"},{"id":"dark-red-duck","name":"Dark Red Duck","file":"Dark-red-duck.webp"},{"id":"demon-duck","name":"Devilish Duck","file":"Demon-duck.webp"},{"id":"doctor-duck","name":"Doctor Duck","file":"Doctor-duck.webp"},{"id":"duck-with-a-knife","name":"Duck with a Knife","file":"Duck-with-a-knife.webp"},{"id":"duckvee","name":"Duckvee","file":"Duckvee.webp"},{"id":"fancy-duck","name":"Fancy Duck","file":"Fancy-duck.webp"},{"id":"flower-duck","name":"Flower Duck","file":"Flower-duck.webp"},{"id":"gamer-duck","name":"Gamer Duck","file":"Gamer-duck.webp"},{"id":"ghost-duck","name":"Ghost Duck","file":"Ghost-duck.webp"},{"id":"glitter-duck","name":"Glitter Duck","file":"Glitter-duck.webp"},{"id":"golden-duck","name":"Golden Duck","file":"Golden-duck.webp"},{"id":"goose","name":"Goose","file":"Goose.webp"},{"id":"green-duck","name":"Green Duck","file":"Green-duck.webp"},{"id":"grey-duck","name":"Grey Duck","file":"Grey-duck.webp"},{"id":"gummy-duck","name":"Gummy Duck","file":"Gummy-duck.webp"},{"id":"jester-duck","name":"Jester Duck","file":"Jester-duck.webp"},{"id":"kidcore-duck","name":"Kidcore Duck","file":"Kidcore-duck.webp"},{"id":"king-duck","name":"King Duck","file":"King-duck.webp"},{"id":"knitted-duck","name":"Knitted Duck","file":"Knitted-duck.webp"},{"id":"lemon-duck","name":"Lemon Duck","file":"Lemon-duck.webp"},{"id":"lime-duck","name":"Lime Duck","file":"Lime-duck.webp"},{"id":"magical-girl-duck","name":"Magical Girl Duck","file":"Magical-girl-duck.webp"},{"id":"mint-duck","name":"Mint Duck","file":"Mint-duck.webp"},{"id":"mushroom-duck","name":"Mushroom Duck","file":"Mushroom-duck.webp"},{"id":"miko-duck","name":"Miko Duck","file":"miko-duck.webp"},{"id":"io-duck","name":"Io Duck","file":"io-duck.webp"},{"id":"miho-duck","name":"Miho Duck","file":"miho-duck.webp"},{"id":"annika-duck","name":"Annika Duck","file":"annika-duck.png"},{"id":"angel-character-duck","name":"Angel Duck","file":"angel-character-duck.png"},{"id":"demon-character-duck","name":"Demon Duck","file":"demon-character-duck.png"},{"id":"orange-duck","name":"Orange Duck","file":"Orange-duck.webp"},{"id":"party-hat-duck","name":"Party Hat Duck","file":"Party-hat-duck.webp"},{"id":"peach-duck","name":"Peach Duck","file":"Peach-duck.webp"},{"id":"peep-duck","name":"Peep Duck","file":"peep-duck.webp"},{"id":"periwinkle-duck","name":"Periwinkle Duck","file":"Periwinkle-duck.webp"},{"id":"pink-duck","name":"Pink Duck","file":"Pink-duck.webp"},{"id":"pizza-duck","name":"Pizza Duck","file":"Pizza-duck.webp"},{"id":"plush-duck","name":"Plush Duck","file":"Plush-duck.webp"},{"id":"pompompurin-duck","name":"Pompompurin Duck","file":"Pompompurin-duck.webp"},{"id":"purple-duck","name":"Purple Duck","file":"Purple-duck.webp"},{"id":"rainbow-duck","name":"Rainbow Duck","file":"Rainbow-duck.webp"},{"id":"red-duck","name":"Red Duck","file":"Red-duck.webp"},{"id":"silver-duck","name":"Silver Duck","file":"Silver-duck.webp"},{"id":"sky-blue-duck","name":"Sky Blue Duck","file":"Sky-blue-duck.webp"},{"id":"sleepy-time-duck","name":"Sleepy Time Duck","file":"Sleepy-time-duck.webp"},{"id":"standard-duck","name":"Standard Duck","file":"Standard-duck.webp"},{"id":"strawberry-duck","name":"Strawberry Duck","file":"Strawberry-duck.webp"},{"id":"tiny-duck-stack","name":"Tiny Duck Stack","file":"Tiny-duck-stack.webp"},{"id":"tiny-duck","name":"Tiny Duck","file":"Tiny-duck.webp"},{"id":"top-hat-duck","name":"Top Hat Duck","file":"Top-hat-duck.webp"},{"id":"violet-duck","name":"Violet Duck","file":"Violet-duck.webp"},{"id":"watermelon-duck","name":"Watermelon Duck","file":"Watermelon-duck.webp"},{"id":"white-duck","name":"White Duck","file":"White-duck.webp"}];

const PEEP_SKILLS = [
  {
    id: "heart-pop",
    name: "Heart Pop!",
    unlock: 1,
    type: "damage",
    multiplier: 1.0,
    sprite: "assets/characters/peep/base/attack.webp",
    description: "A dependable little heart attack!"
  },
  {
    id: "magical-wish",
    name: "Magical Wish!",
    unlock: 10,
    type: "heal",
    healPercent: 0.42,
    cooldown: 3,
    sprite: "assets/characters/peep/base/heal.webp",
    description: "Restore 42% of Peep's max HP."
  },
  {
    id: "duck-throw",
    name: "Duck Throw!",
    unlock: 25,
    type: "damage",
    multiplier: 1.65,
    cooldown: 2,
    sprite: "assets/characters/peep/base/duck-throw.webp",
    description: "Throw a random unlocked duck. Obviously."
  },
  {
    id: "heart-barrage",
    name: "Heart Barrage!",
    unlock: 40,
    type: "multi-hit",
    multiplier: 1.45,
    hits: 3,
    cooldown: 2,
    sprite: "assets/characters/peep/base/attack.webp",
    description: "Three rapid heart hits for 1.45× total damage."
  },
  {
    id: "peep-apocalypse",
    name: "Peep Apocalypse!",
    unlock: 50,
    type: "damage",
    multiplier: 3.0,
    hitsAll: true,
    oncePerBattle: true,
    sprite: "assets/characters/peep/base/final-move.webp",
    description: "Peep has had enough. Hits all enemies in Double Trouble."
  },
  {
    id: "activate-zoomies",
    name: "Activate Zoomies!",
    unlock: 50,
    type: "buff",
    attackBoost: 0.50,
    duration: 3,
    sprite: "assets/characters/peep/base/final-move.webp",
    description: "Peep gets the zoomies! Raise Attack by 50% for 3 turns."
  },
  {
    id: "just-a-smack",
    name: "Just a smack!",
    unlock: 1,
    type: "safe-chip",
    sprite: "assets/characters/peep/base/attack.webp",
    description: "Deals normal basic-attack damage, but can never knock an enemy below 1 HP. Perfect for catching!"
  }
];

const MIKO_SKILLS = [
  {
    id: "mock",
    name: "Mock",
    unlock: 1,
    type: "damage",
    multiplier: 1.0,
    sprite: "assets/characters/miko/base/mock.webp",
    description: "A cutting little comment that actually hurts."
  },
  {
    id: "smug",
    name: "Smug",
    unlock: 10,
    type: "buff",
    attackBoost: 0.30,
    duration: 3,
    sprite: "assets/characters/miko/base/smug.webp",
    description: "Raise Miko's Attack by 30% for 3 turns."
  },
  {
    id: "failed-spell",
    name: "Failed Spell",
    unlock: 25,
    type: "damage",
    multiplier: 1.85,
    hitsAll: true,
    cooldown: 2,
    sprite: "assets/characters/miko/base/failed-spell.webp",
    description: "A chaotic gamble! Usually 1.85× to all enemies, with a 15% chance for a huge 4.25× blast and a tiny 1% chance to backfire on Miko."
  },
  {
    id: "hexed-heckle",
    name: "Hexed Heckle",
    unlock: 40,
    type: "damage",
    multiplier: 1.55,
    cooldown: 2,
    sprite: "assets/characters/miko/base/failed-spell.webp",
    description: "A magically rude heckle for 1.55× damage."
  },
  {
    id: "gun",
    name: "He has a gun!",
    unlock: 50,
    type: "multi-hit",
    multiplier: 1.50,
    hits: 4,
    sprite: "assets/characters/miko/base/gun.webp",
    description: "Four quick shots for 1.50× total damage."
  },
  {
    id: "thoughts-of-lovers",
    name: "Thoughts of Lovers!",
    unlock: 50,
    type: "full-heal-buff",
    attackBoost: 0.50,
    duration: 4,
    oncePerBattle: true,
    sprite: "assets/characters/miko/base/smug.webp",
    description: "Fully heal Miko and raise Attack by 50% for 4 turns. Once per battle."
  },
  {
    id: "just-a-smack",
    name: "Just a smack!",
    unlock: 1,
    type: "safe-chip",
    sprite: "assets/characters/miko/base/mock.webp",
    description: "Deals normal basic-attack damage, but can never knock an enemy below 1 HP. Perfect for catching!"
  }
];

const IO_SKILLS = [
  {
    id:"heart-ray", name:"Heart Ray", unlock:1, type:"damage", multiplier:1.0, boostedMultiplier:1.8,
    sprite:"assets/characters/io/base/heart-ray.webp",
    description:"A heart-shaped beam. Every 5th use is boosted!"
  },
  {
    id:"magic-juice", name:"Magic Juice Drink", unlock:10, type:"buff", attackBoost:0.40, duration:4,
    sprite:"assets/characters/io/base/magic-juice.webp",
    description:"Raise Io's Attack by 40% for 4 turns. Does not stack."
  },
  {
    id:"sparkle-shot", name:"Sparkle Shot", unlock:25, type:"multi-hit", multiplier:1.35, hits:3,
    sprite:"assets/characters/io/base/sparkle-shot.webp",
    description:"Three little star hits from one sparkling beam."
  },
  {
    id:"star-shower", name:"Star Shower", unlock:40, type:"multi-hit", multiplier:1.55, hits:4, cooldown:2, hitsAll:true,
    sprite:"assets/characters/io/base/sparkle-shot.webp",
    description:"Four falling stars for 1.55× total damage. Hits all enemies in Double Trouble."
  },
  {
    id:"rainbow-check", name:"Rainbow Check", unlock:50, type:"full-heal", maxUses:2,
    sprite:"assets/characters/io/base/rainbow-check.webp",
    description:"Fully restore Io's HP. Can be used twice per battle."
  },
  {
    id:"magic-hangover", name:"Magic Hangover!", unlock:50, type:"self-damage-buff",
    selfDamage:10, attackBoost:0.50, duration:4,
    sprite:"assets/characters/io/base/magic-juice.webp",
    description:"Lose up to 10 HP, but raise Io's Attack by 50% for 4 turns. Cannot knock Io out."
  },
  {
    id:"just-a-smack", name:"Just a smack!", unlock:1, type:"safe-chip",
    sprite:"assets/characters/io/base/heart-ray.webp",
    description:"Deals normal basic-attack damage, but can never knock an enemy below 1 HP. Perfect for catching!"
  }
];

const MIHO_SKILLS = [
  {
    id:"threaten", name:"Threaten", unlock:1, type:"damage", multiplier:1.0,
    sprite:"assets/characters/miho/base/threaten.webp",
    description:"Miho smacks! Deals normal damage."
  },
  {
    id:"magic", name:"Magic", unlock:10, type:"damage-burn", multiplier:1.0, burnChance:1, burnDamagePercent:0.08, burnTurns:99, hitsAll:true,
    sprite:"assets/characters/miho/base/spell.webp",
    description:"A strong magic spell! Hits all enemies in Double Trouble and burns them, causing HP loss at the end of their turns."
  },
  {
    id:"fluster", name:"Fluster", unlock:25, type:"buff", attackBoost:0.60, duration:4, missChance:0.20,
    sprite:"assets/characters/miho/base/fluster.webp",
    description:"The enemy flusters Miho. Her Attack goes up a lot, but while flustered she has a 20% chance to miss."
  },
  {
    id:"stab", name:"Stab", unlock:40, type:"multi-hit", multiplier:3.0, hits:3,
    sprite:"assets/characters/miho/base/stab.webp",
    description:"Miho stabs 3 times, causing normal damage 3 times in a row."
  },
  {
    id:"just-a-smack", name:"Just a smack!", unlock:1, type:"safe-chip",
    sprite:"assets/characters/miho/base/threaten.webp",
    description:"Deals normal basic-attack damage, but can never knock an enemy below 1 HP. Perfect for catching!"
  }
];

const ANNIKA_SKILLS = [
  {
    id:"scold", name:"Scold", unlock:1, type:"damage", multiplier:1.0, hitsAll:true,
    sprite:"assets/characters/annika/base/scold.webp",
    description:"A sharp scolding that deals normal damage. In Double Trouble, Annika scolds everybody."
  },
  {
    id:"stop", name:"Stop!", unlock:10, type:"stun", duration:2, cooldown:4,
    sprite:"assets/characters/annika/base/stop.webp",
    description:"Freeze the enemy so it cannot act for 2 turns."
  },
  {
    id:"flustered", name:"Flustered", unlock:25, type:"buff", attackBoost:0.65, duration:4, missChance:0.10,
    sprite:"assets/characters/annika/base/flustered.webp",
    description:"Annika gets flustered! Attack spikes by 65% for 4 turns, with a small 10% chance to miss."
  },
  {
    id:"high-kick", name:"High Kick!", unlock:50, type:"damage", multiplier:1.75, cooldown:2,
    sprite:"assets/characters/annika/base/high-kick.webp",
    description:"A powerful kick that deals much more damage than Scold."
  },
  {
    id:"just-a-smack", name:"Just a smack!", unlock:1, type:"safe-chip",
    sprite:"assets/characters/annika/base/stop.webp",
    description:"Deals normal basic-attack damage, but can never knock an enemy below 1 HP. Perfect for catching!"
  }
];

const SHIYU_SKILLS = [
  {id:"shiyu-stab",name:"Stab!",unlock:1,type:"damage",multiplier:1,
   sprite:"assets/characters/shiyu/base/Shiyu-Knife.png",description:"A quick stab dealing normal damage."},
  {id:"shiyu-frenzy",name:"Knife Frenzy",unlock:10,type:"multi-hit",multiplier:1.8,hits:3,
   sprite:"assets/characters/shiyu/base/Shiyu-Knife.png",description:"Three rapid strikes dealing 60% damage each (180% total)."},
  {id:"shiyu-glitch-assault",name:"Glitch Assault",unlock:25,type:"shiyu-glitch",multiplier:1,bonusChance:0.40,
   sprite:"assets/characters/shiyu/base/Shiyu-Knife.png",description:"A normal hit, with a 40% chance for two more full-strength hits."},
  {id:"shiyu-final-warning",name:"Final Warning",unlock:40,type:"damage",multiplier:1.75,finishMultiplier:1.75,
   sprite:"assets/characters/shiyu/base/Shiyu-Knife.png",description:"175% damage; +75% if the enemy starts below 40% HP (306.25%)."},
  {id:"shiyu-dont-touch",name:"Don't Touch My Love!",unlock:50,type:"damage",multiplier:4,hitsAll:true,oncePerBattle:true,
   sprite:"assets/characters/shiyu/base/Shiyu-Anger.png",description:"Once per battle: 400% damage to every enemy. No split damage."}
];


const ANGEL_SKILLS = [
 {id:"angel-heart-spark",name:"Heart Spark ♡",unlock:1,type:"damage",multiplier:1,
  sprite:"assets/characters/angel/base/Angel-sprite-magic-heart.png",description:"100% magic damage to one enemy."},
 {id:"angel-celestial-comet",name:"Celestial Comet ✨",unlock:10,type:"damage",multiplier:1.7,splashChance:.25,splashMultiplier:.40,
  sprite:"assets/characters/angel/base/Angel-sprite-magic-heart.png",description:"170% damage to one enemy; 25% chance to splash 40% to another."},
 {id:"angel-heavenly-judgment",name:"Heavenly Judgment 🖤",unlock:25,type:"damage",multiplier:2.3,attackDownChance:.30,
  sprite:"assets/characters/angel/base/Angel-sprite-angry.png",description:"230% damage; 30% chance to reduce enemy Attack by 20% for 2 turns."},
 {id:"angel-heavenly-sanctuary",name:"Heavenly Sanctuary ♡",unlock:40,type:"damage",multiplier:2.4,shieldPercent:.20,shieldDuration:2,
  sprite:"assets/characters/angel/base/Angel-sprite-angel.png",description:"240% damage and a shield worth 20% of Angel's max HP for 2 turns."},
 {id:"angel-last-wish",name:"Heaven’s Last Wish ♡",unlock:50,type:"damage",multiplier:2.8,hitsAll:true,oncePerBattle:true,shieldPercent:.15,shieldDuration:2,
  sprite:"assets/characters/angel/base/Angel-sprite-angel.png",description:"Once per battle: 280% damage to every enemy; shield all allies for 15% Angel max HP for 2 turns."}
];

const NPC_HERO_SKILLS = [
 {id:'npc-quick-strike',name:'Quick Strike!',unlock:1,type:'damage',multiplier:1.0,description:'A reliable opening attack.'},
 {id:'npc-recover',name:'Catch Your Breath!',unlock:10,type:'heal',healPercent:.42,cooldown:3,description:'Restore 42% of your maximum HP.'},
 {id:'npc-duck-toss',name:'Duck Toss!',unlock:25,type:'damage',multiplier:1.65,cooldown:2,description:'A powerful duck-powered attack.'},
 {id:'npc-heart-flurry',name:'Heart Flurry!',unlock:40,type:'multi-hit',multiplier:1.35,hits:3,cooldown:3,description:'Strike three times in a row.'}
];
function activeSkills(){
  if(QUEST_NPC_HEROES[activeCharacterId])return NPC_HERO_SKILLS.map(s=>({...s,sprite:heroIdleFrames()[0]}));
  if(activeCharacterId === "miko") return MIKO_SKILLS;
  if(activeCharacterId === "io") return IO_SKILLS;
  if(activeCharacterId === "miho") return MIHO_SKILLS;
  if(activeCharacterId === "annika") return ANNIKA_SKILLS;
  if(activeCharacterId === "shiyu") return SHIYU_SKILLS;
  if(activeCharacterId === "angel") return ANGEL_SKILLS;
  return PEEP_SKILLS;
}

function skillTypeGroup(skill){
  if(!skill) return 9;
  if(["damage","damage-burn","multi-hit","shiyu-glitch","safe-chip"].includes(skill.type)) return 0;
  if(["buff","full-heal-buff","self-damage-buff","stun"].includes(skill.type)) return 1;
  if(["heal","full-heal"].includes(skill.type)) return 2;
  return 1;
}

function sortedActiveSkills(){
  return activeSkills()
    .map((skill,index)=>({skill,index}))
    .sort((a,b)=>skillTypeGroup(a.skill)-skillTypeGroup(b.skill) || a.index-b.index)
    .map(entry=>entry.skill);
}

function isStatusSkill(skill){
  return Boolean(skill && ["buff","full-heal-buff","self-damage-buff","stun"].includes(skill.type));
}

const ENEMIES = {
  "cat-slime": {
    name: "Cat Slime",
    hp: 20,
    attack: 3,
    exp: 18,
    coinMin: 5,
    coinMax: 9,
    idle: [
      "assets/enemies/cat-slime/base/idle-1-neutral.webp",
      "assets/enemies/cat-slime/base/idle-2-squish.webp",
      "assets/enemies/cat-slime/base/idle-3-bounce.webp",
      "assets/enemies/cat-slime/base/idle-2-squish.webp"
    ],
    hurt: "assets/enemies/cat-slime/base/idle-1-neutral.webp",
    speed: 310
  },
  "bee": {
    name: "Bee",
    hp: 17,
    attack: 4,
    exp: 20,
    coinMin: 5,
    coinMax: 10,
    idle: [
      "assets/enemies/bee/base/idle-1-high.webp",
      "assets/enemies/bee/base/idle-2-low.webp"
    ],
    hurt: "assets/enemies/bee/base/hurt.webp",
    speed: 360
  },
  "flower": {
    name: "Flower",
    hp: 23,
    attack: 4,
    exp: 22,
    coinMin: 6,
    coinMax: 11,
    idle: [
      "assets/enemies/flower/base/idle-1.webp",
      "assets/enemies/flower/base/idle-2.webp"
    ],
    hurt: "assets/enemies/flower/base/hurt.webp",
    speed: 390
  },
  "cool-seagull": {
    name: "Cool Seagull", hp: 26, attack: 5, exp: 28, coinMin: 8, coinMax: 13,
    idle: ["assets/enemies/cool-seagull/base/idle-1.webp","assets/enemies/cool-seagull/base/idle-2.webp"],
    hurt: "assets/enemies/cool-seagull/base/hurt.webp", speed: 370
  },
  "sea-turtle": {
    name: "Sea Turtle", hp: 34, attack: 5, exp: 31, coinMin: 9, coinMax: 14,
    idle: ["assets/enemies/sea-turtle/base/idle-1.webp","assets/enemies/sea-turtle/base/idle-2.webp"],
    hurt: "assets/enemies/sea-turtle/base/hurt.webp", speed: 430
  },
  "catfish": {
    name: "Cat-Fish", hp: 29, attack: 7, exp: 34, coinMin: 10, coinMax: 16,
    idle: ["assets/enemies/catfish/base/idle-1.webp","assets/enemies/catfish/base/idle-2.webp"],
    hurt: "assets/enemies/catfish/base/hurt.webp", speed: 360
  },
  "vampire-squid": {
    name: "Vampire Squid", hp: 66, attack: 8, exp: 70, coinMin: 24, coinMax: 36,
    idle: ["assets/bosses/vampire-squid/base/idle-1.webp","assets/bosses/vampire-squid/base/idle-2.webp"],
    hurt: "assets/bosses/vampire-squid/base/hurt.webp", speed: 410, boss: true
  },
  "mimic": {
    name: "Mimic",
    hp: 31,
    attack: 6,
    exp: 34,
    coinMin: 18,
    coinMax: 28,
    portrait: "assets/enemies/mimic/base/open-1.webp",
    idle: [
      "assets/enemies/mimic/base/open-1.webp",
      "assets/enemies/mimic/base/open-2.webp"
    ],
    hurt: "assets/items/chests/treasure/closed.webp",
    speed: 700
  },
  "rotten-egg": {
    name:"Rotten Egg", hp:28, attack:5, exp:34, coinMin:8, coinMax:14,
    idle:["assets/gimmicks/rotten-egg/base/idle-1.png","assets/gimmicks/rotten-egg/base/idle-2.png"],
    hurt:"assets/gimmicks/rotten-egg/base/hurt.png", speed:420
  },
  "lucky-cat": {
    name:"Lucky Cat", hp:30, attack:5, exp:34, coinMin:0, coinMax:0,
    idle:["assets/gimmicks/lucky-cat/base/idle-1.png","assets/gimmicks/lucky-cat/base/idle-2.png"],
    hurt:"assets/gimmicks/lucky-cat/base/hurt.png", speed:390
  },
  "angy-duck": {
    name:"Angy Duck", hp:34, attack:7, exp:38, coinMin:0, coinMax:0,
    idle:["assets/gimmicks/angy-duck/base/idle-1.png","assets/gimmicks/angy-duck/base/idle-2.png"],
    hurt:"assets/gimmicks/angy-duck/base/hurt.png", speed:330
  },
  "porcupin": {
    name:"Porcupin", hp:27, attack:5, exp:30, coinMin:8, coinMax:14,
    idle:["assets/enemies/porcupin/base/idle-1.png","assets/enemies/porcupin/base/idle-2.png"],
    hurt:"assets/enemies/porcupin/base/hurt.png", speed:380
  },
  "mushroom-cat": {
    name: "Big Mushroom Cat",
    hp: 48,
    attack: 5,
    exp: 48,
    coinMin: 16,
    coinMax: 24,
    idle: [
      "assets/bosses/mushroom-cat/base/idle-1.webp",
      "assets/bosses/mushroom-cat/base/idle-2.webp"
    ],
    hurt: "assets/bosses/mushroom-cat/base/hurt.webp",
    speed: 430,
    boss: true
  },
  "acorn-mouse": {
    name: "Acorn Mouse", hp: 19, attack: 4, exp: 21, coinMin: 5, coinMax: 10,
    idle:["assets/enemies/acorn-mouse/base/acorn-mouse-idle-1.webp","assets/enemies/acorn-mouse/base/acorn-mouse-idle-2.webp"],
    hurt:"assets/enemies/acorn-mouse/base/acorn-mouse-hurt.webp", speed:335
  },
  "seaunicorn": {
    name: "Seaunicorn", hp: 30, attack: 6, exp: 33, coinMin: 9, coinMax: 15,
    idle:["assets/enemies/seaunicorn/base/seaunicorn-idle-1.webp","assets/enemies/seaunicorn/base/seaunicorn-idle-2.webp"],
    hurt:"assets/enemies/seaunicorn/base/seaunicorn-hurt.webp", speed:385
  },
  "tree-squirrel": {
    name: "Tree Squirrel", hp: 56, attack: 6, exp: 58, coinMin: 19, coinMax: 29,
    idle:["assets/bosses/tree-squirrel/base/tree-squirrel-idle-1.webp","assets/bosses/tree-squirrel/base/tree-squirrel-idle-2.webp"],
    hurt:"assets/bosses/tree-squirrel/base/tree-squirrel-hurt.webp", speed:430, boss:true
  },
  "jellybun": {
    name: "Jellybun", hp: 72, attack: 8, exp: 76, coinMin: 26, coinMax: 40,
    idle:["assets/bosses/jellybun/base/jellybun-idle-1.webp","assets/bosses/jellybun/base/jellybun-idle-2.webp"],
    hurt:"assets/bosses/jellybun/base/jellybun-hurt.webp", speed:405, boss:true
  },
  "catterpillar": {
    name:"Catterpillar", hp:21, attack:4, exp:22, coinMin:6, coinMax:11,
    idle:["assets/enemies/catterpillar/base/idle-1.png","assets/enemies/catterpillar/base/idle-2.png"],
    hurt:"assets/enemies/catterpillar/base/hurt.png", speed:360
  },
  "sea-star": {
    name:"Sea Star", hp:31, attack:6, exp:34, coinMin:10, coinMax:16,
    idle:["assets/enemies/sea-star/base/idle-1.png","assets/enemies/sea-star/base/idle-2.png"],
    hurt:"assets/enemies/sea-star/base/hurt.png", speed:390
  },
  "star-mouse": {
    name:"Star Mouse", hp:34, attack:6, exp:36, coinMin:10, coinMax:17,
    idle:["assets/enemies/star-mouse/base/idle-1.png","assets/enemies/star-mouse/base/idle-2.png"],
    hurt:"assets/enemies/star-mouse/base/hurt.png", speed:340
  },
  "puff-fairy": {
    name:"Puff Fairy", hp:36, attack:7, exp:38, coinMin:11, coinMax:18,
    idle:["assets/enemies/puff-fairy/base/idle-1.png","assets/enemies/puff-fairy/base/idle-2.png"],
    hurt:"assets/enemies/puff-fairy/base/hurt.png", speed:360
  },
  "tulipa": {
    name:"Tulipa", hp:40, attack:7, exp:42, coinMin:12, coinMax:19,
    idle:["assets/enemies/tulipa/base/idle-1.png","assets/enemies/tulipa/base/idle-2.png"],
    hurt:"assets/enemies/tulipa/base/hurt.png", speed:380
  },
  "snoud": {
    name:"Snoud", hp:43, attack:8, exp:45, coinMin:13, coinMax:20,
    idle:["assets/enemies/snoud/base/idle-1.png","assets/enemies/snoud/base/idle-2.png"],
    hurt:"assets/enemies/snoud/base/hurt.png", speed:410
  },
  "cloud-bunny": {
    name:"Cloud Bunny", hp:48, attack:9, exp:50, coinMin:15, coinMax:23,
    idle:["assets/enemies/cloud-bunny/base/idle-1.png","assets/enemies/cloud-bunny/base/idle-2.png"],
    hurt:"assets/enemies/cloud-bunny/base/hurt.png", speed:355
  },
  "lunar-moth": {
    name:"Lunar Moth", hp:46, attack:9, exp:52, coinMin:15, coinMax:24,
    idle:["assets/enemies/lunar-moth/base/idle-1.png","assets/enemies/lunar-moth/base/idle-2.png"],
    hurt:"assets/enemies/lunar-moth/base/hurt.png", speed:330
  },
  "aries": {
    name:"Aries", hp:98, attack:11, exp:105, coinMin:36, coinMax:54,
    idle:["assets/bosses/aries/base/idle-1.png","assets/bosses/aries/base/idle-2.png"],
    hurt:"assets/bosses/aries/base/hurt.png", speed:410, boss:true
  },
  "cherub-duck": {
    name:"Cherub Duck", hp:104, attack:10, exp:110, coinMin:38, coinMax:56,
    idle:["assets/bosses/cherub-duck/base/idle-1.png","assets/bosses/cherub-duck/base/idle-2.png"],
    hurt:"assets/bosses/cherub-duck/base/hurt.png", speed:395, boss:true
  },
  "apple-baby": {
    name:"Apple Baby", hp:39, attack:7, exp:42, coinMin:12, coinMax:19,
    idle:["assets/enemies/apple-baby/base/idle-1.webp","assets/enemies/apple-baby/base/idle-2.webp"],
    hurt:"assets/enemies/apple-baby/base/hurt.webp", speed:350
  },
  "gummy-worm": {
    name:"Gummy Worm", hp:42, attack:8, exp:45, coinMin:13, coinMax:20,
    idle:["assets/enemies/gummy-worm/base/idle-1.webp","assets/enemies/gummy-worm/base/idle-2.webp"],
    hurt:"assets/enemies/gummy-worm/base/hurt.webp", speed:330
  },
  "pudding-pig": {
    name:"Pudding Pig", hp:47, attack:8, exp:49, coinMin:14, coinMax:22,
    idle:["assets/enemies/pudding-pig/base/idle-1.webp","assets/enemies/pudding-pig/base/idle-2.webp"],
    hurt:"assets/enemies/pudding-pig/base/hurt.webp", speed:390
  },
  "gingerlolly": {
    name:"Gingerlolly", hp:45, attack:9, exp:50, coinMin:15, coinMax:23,
    idle:["assets/enemies/gingerlolly/base/idle-1.webp","assets/enemies/gingerlolly/base/idle-2.webp"],
    hurt:"assets/enemies/gingerlolly/base/hurt.webp", speed:365
  },
  "candycane-deer": {
    name:"Candycane Deer", hp:53, attack:10, exp:56, coinMin:17, coinMax:26,
    idle:["assets/enemies/candycane-deer/base/idle-1.webp","assets/enemies/candycane-deer/base/idle-2.webp"],
    hurt:"assets/enemies/candycane-deer/base/hurt.webp", speed:385
  },
  "gummy-shark": {
    name:"Gummy Shark", hp:91, attack:11, exp:98, coinMin:33, coinMax:50,
    idle:["assets/bosses/gummy-shark/base/idle-1.webp","assets/bosses/gummy-shark/base/idle-2.webp"],
    hurt:"assets/bosses/gummy-shark/base/hurt.webp", speed:390, boss:true
  },
  "cream-fox": {
    name:"Cream Fox", hp:95, attack:10, exp:102, coinMin:35, coinMax:52,
    idle:["assets/bosses/cream-fox/base/idle-1.webp","assets/bosses/cream-fox/base/idle-2.webp"],
    hurt:"assets/bosses/cream-fox/base/hurt.webp", speed:405, boss:true
  }
};






function weightedOceanVariant(rank, ids) {
  const r=Math.max(1,Number(rank)||1);
  let weights;
  if(r<=12) weights=[100,0,0,0,0];
  else if(r<=24) weights=[60,40,0,0,0];
  else if(r<=38) weights=[20,50,30,0,0];
  else if(r<=56) weights=[0,25,35,40,0];
  else if(r<=70) weights=[0,0,25,50,25];
  else weights=[0,0,0,40,60];
  const total=weights.reduce((a,b)=>a+b,0);
  let roll=Math.random()*total;
  for(let i=0;i<ids.length;i++){ roll-=weights[i]; if(roll<=0) return ids[i]; }
  return ids[0];
}

const SEAGULL_VARIANTS=Object.freeze({
  grey:{id:"grey",name:"Cool Seagull",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/cool-seagull/base/idle-1.webp","assets/enemies/cool-seagull/base/idle-2.webp"],hurt:"assets/enemies/cool-seagull/base/hurt.webp"},
  pink:{id:"pink",name:"Pink Cool Seagull",hp:1.2,atk:1.1,exp:1.15,coin:1.15,idle:["assets/enemies/cool-seagull/base/Pink-idle-1.webp","assets/enemies/cool-seagull/base/Pink-idle-2.webp"],hurt:"assets/enemies/cool-seagull/base/Pink-hurt.webp"},
  blue:{id:"blue",name:"Blue Cool Seagull",hp:1.2,atk:1.1,exp:1.2,coin:1.2,healPercent:.18,maxHeals:2,healChance:.32,healMoveName:"Fish Snack!",idle:["assets/enemies/cool-seagull/base/Blue-idle-1.webp","assets/enemies/cool-seagull/base/Blue-idle-2.webp"],hurt:"assets/enemies/cool-seagull/base/Blue-hurt.webp"},
  yellow:{id:"yellow",name:"Yellow Cool Seagull",hp:1.4,atk:1.2,exp:1.35,coin:1.35,idle:["assets/enemies/cool-seagull/base/Yellow-idle-1.webp","assets/enemies/cool-seagull/base/Yellow-idle-2.webp"],hurt:"assets/enemies/cool-seagull/base/Yellow-hurt.webp"},
  black:{id:"black",name:"Black Cool Seagull",hp:1.7,atk:1.3,exp:1.5,coin:1.6,elite:true,idle:["assets/enemies/cool-seagull/base/Black-idle-1.webp","assets/enemies/cool-seagull/base/Black-idle-2.webp"],hurt:"assets/enemies/cool-seagull/base/Black-hurt.webp"}
});
const TURTLE_VARIANTS=Object.freeze({
  green:{id:"green",name:"Sea Turtle",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/sea-turtle/base/idle-1.webp","assets/enemies/sea-turtle/base/idle-2.webp"],hurt:"assets/enemies/sea-turtle/base/hurt.webp"},
  blue:{id:"blue",name:"Blue Sea Turtle",hp:1.2,atk:1.1,exp:1.15,coin:1.15,idle:["assets/enemies/sea-turtle/base/Blue-idle-1.webp","assets/enemies/sea-turtle/base/Blue-idle-2.webp"],hurt:"assets/enemies/sea-turtle/base/Blue-hurt.webp"},
  pink:{id:"pink",name:"Pink Sea Turtle",hp:1.2,atk:1.1,exp:1.2,coin:1.2,specialType:"harden-shell",specialChance:.30,maxSpecialUses:2,idle:["assets/enemies/sea-turtle/base/Pink-idle-1.webp","assets/enemies/sea-turtle/base/Pink-idle-2.webp"],hurt:"assets/enemies/sea-turtle/base/Pink-hurt.webp"},
  purple:{id:"purple",name:"Purple Sea Turtle",hp:1.4,atk:1.2,exp:1.35,coin:1.35,idle:["assets/enemies/sea-turtle/base/Purple-idle-1.webp","assets/enemies/sea-turtle/base/Purple-idle-2.webp"],hurt:"assets/enemies/sea-turtle/base/Purple-hurt.webp"},
  gold:{id:"gold",name:"Gold Sea Turtle",hp:1.7,atk:1.3,exp:1.5,coin:1.6,elite:true,idle:["assets/enemies/sea-turtle/base/Gold-idle-1.webp","assets/enemies/sea-turtle/base/Gold-idle-2.webp"],hurt:"assets/enemies/sea-turtle/base/Gold-hurt.webp"}
});
const CATFISH_VARIANTS=Object.freeze({
  grey:{id:"grey",name:"Cat-Fish",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/catfish/base/idle-1.webp","assets/enemies/catfish/base/idle-2.webp"],hurt:"assets/enemies/catfish/base/hurt.webp"},
  brown:{id:"brown",name:"Brown Cat-Fish",hp:1.2,atk:1.1,exp:1.15,coin:1.15,idle:["assets/enemies/catfish/base/Brown-idle-1.webp","assets/enemies/catfish/base/Brown-idle-2.webp"],hurt:"assets/enemies/catfish/base/Brown-hurt.webp"},
  orange:{id:"orange",name:"Orange Cat-Fish",hp:1.2,atk:1.1,exp:1.2,coin:1.2,specialType:"zoomies",specialChance:.30,maxSpecialUses:2,idle:["assets/enemies/catfish/base/Orange-idle-1.webp","assets/enemies/catfish/base/Orange-idle-2.webp"],hurt:"assets/enemies/catfish/base/Orange-hurt.webp"},
  navy:{id:"navy",name:"Navy Cat-Fish",hp:1.4,atk:1.2,exp:1.35,coin:1.35,idle:["assets/enemies/catfish/base/Navy-idle-1.webp","assets/enemies/catfish/base/Navy-idle-2.webp"],hurt:"assets/enemies/catfish/base/Navy-hurt.webp"},
  black:{id:"black",name:"Tuxedo Catfish",hp:1.7,atk:1.3,exp:1.5,coin:1.6,elite:true,idle:["assets/enemies/catfish/base/Black-idle-1.webp","assets/enemies/catfish/base/Black-idle-2.webp"],hurt:"assets/enemies/catfish/base/Black-hurt.webp"}
});
const SQUID_VARIANTS=Object.freeze({
  green:{id:"green",name:"Vampire Squid",hp:1,atk:1,exp:1,coin:1,idle:["assets/bosses/vampire-squid/base/idle-1.webp","assets/bosses/vampire-squid/base/idle-2.webp"],hurt:"assets/bosses/vampire-squid/base/hurt.webp"},
  purple:{id:"purple",name:"Purple Vampire Squid",hp:1.2,atk:1.1,exp:1.15,coin:1.15,idle:["assets/bosses/vampire-squid/base/Purple-idle-1.webp","assets/bosses/vampire-squid/base/Purple-idle-2.webp"],hurt:"assets/bosses/vampire-squid/base/Purple-hurt.webp"},
  coral:{id:"coral",name:"Coral Vampire Squid",hp:1.3,atk:1.15,exp:1.25,coin:1.25,idle:["assets/bosses/vampire-squid/base/Coral-idle-1.webp","assets/bosses/vampire-squid/base/Coral-idle-2.webp"],hurt:"assets/bosses/vampire-squid/base/Coral-hurt.webp"},
  blue:{id:"blue",name:"Blue Vampire Squid",hp:1.4,atk:1.2,exp:1.4,coin:1.4,idle:["assets/bosses/vampire-squid/base/Blue-idle-1.webp","assets/bosses/vampire-squid/base/Blue-idle-2.webp"],hurt:"assets/bosses/vampire-squid/base/Blue-hurt.webp"},
  pink:{id:"pink",name:"Pink Vampire Squid",hp:1.7,atk:1.3,exp:1.75,coin:1.8,elite:true,idle:["assets/bosses/vampire-squid/base/Pink-idle-1.webp","assets/bosses/vampire-squid/base/Pink-idle-2.webp"],hurt:"assets/bosses/vampire-squid/base/Pink-hurt.webp"}
});

function applyOceanVariant(template, table, ids, rank, extra={}){
  const id=weightedOceanVariant(rank,ids);
  const v=table[id]||table[ids[0]];
  return {
    ...template,
    ...extra,
    name:v.name,idle:v.idle,hurt:v.hurt,
    hp:Math.max(1,Math.round(template.hp*v.hp)),
    attack:Math.max(1,Math.round(template.attack*v.atk)),
    exp:Math.max(1,Math.round(template.exp*v.exp)),
    coinMin:Math.max(1,Math.round(template.coinMin*v.coin)),
    coinMax:Math.max(1,Math.round(template.coinMax*v.coin)),
    oceanVariant:v.id,eliteVariant:Boolean(v.elite),
    healPercent:Number(v.healPercent)||0,maxHeals:Number(v.maxHeals)||0,healChance:Number(v.healChance)||0,healMoveName:v.healMoveName||"",
    specialType:v.specialType||"",specialChance:Number(v.specialChance)||0,maxSpecialUses:Number(v.maxSpecialUses)||0
  };
}
function applySeagullVariant(t,r){return applyOceanVariant(t,SEAGULL_VARIANTS,["grey","pink","blue","yellow","black"],r);}
function applyTurtleVariant(t,r){return applyOceanVariant(t,TURTLE_VARIANTS,["green","blue","pink","purple","gold"],r);}
function applyCatfishVariant(t,r){return applyOceanVariant(t,CATFISH_VARIANTS,["grey","brown","orange","navy","black"],r);}
function applySquidVariant(t,r){
  return applyOceanVariant(t,SQUID_VARIANTS,["green","purple","coral","blue","pink"],r,{
    lifeDrain:true,lifeDrainChance:.30,maxLifeDrains:2,lifeDrainDamage:.75,lifeDrainHeal:.65
  });
}

const MIMIC_PROFILES = Object.freeze({
  easy: {
    id: "easy",
    hpMultiplier: 0.75,
    attackMultiplier: 0.80,
    expMultiplier: 0.90,
    coinMultiplier: 1.00
  },
  normal: {
    id: "normal",
    hpMultiplier: 1.00,
    attackMultiplier: 1.00,
    expMultiplier: 1.00,
    coinMultiplier: 1.00
  },
  tough: {
    id: "tough",
    hpMultiplier: 1.25,
    attackMultiplier: 1.15,
    expMultiplier: 1.25,
    coinMultiplier: 1.30
  },
  brutal: {
    id: "brutal",
    hpMultiplier: 1.50,
    attackMultiplier: 1.30,
    expMultiplier: 1.50,
    coinMultiplier: 1.60
  },
  jackpot: {
    id: "jackpot",
    hpMultiplier: 1.85,
    attackMultiplier: 1.45,
    expMultiplier: 2.00,
    coinMultiplier: 2.20
  }
});

function chooseMimicProfile(rank) {
  const r = Math.max(1, Number(rank) || 1);

  // Mimics are intentionally unpredictable. Higher ranks only lean a little
  // harder toward dangerous versions; an easy one can still appear late.
  let pool;
  if (r <= 4) {
    pool = [["easy", 30], ["normal", 45], ["tough", 20], ["brutal", 4], ["jackpot", 1]];
  } else if (r <= 9) {
    pool = [["easy", 20], ["normal", 35], ["tough", 30], ["brutal", 12], ["jackpot", 3]];
  } else {
    pool = [["easy", 12], ["normal", 28], ["tough", 32], ["brutal", 22], ["jackpot", 6]];
  }

  const total = pool.reduce((sum, entry) => sum + entry[1], 0);
  let roll = Math.random() * total;

  for (const [id, weight] of pool) {
    roll -= weight;
    if (roll <= 0) return id;
  }
  return "normal";
}

function applyMimicProfile(template, rank) {
  const profile = MIMIC_PROFILES[chooseMimicProfile(rank)] || MIMIC_PROFILES.normal;

  return {
    ...template,
    hp: Math.max(1, Math.round(template.hp * profile.hpMultiplier)),
    attack: Math.max(1, Math.round(template.attack * profile.attackMultiplier)),
    exp: Math.max(1, Math.round(template.exp * profile.expMultiplier)),
    coinMin: Math.max(1, Math.round(template.coinMin * profile.coinMultiplier)),
    coinMax: Math.max(1, Math.round(template.coinMax * profile.coinMultiplier)),
    mimicProfile: profile.id
  };
}


const FLOWER_VARIANTS = Object.freeze({
  white: {
    id: "white",
    name: "White Flower",
    hpMultiplier: 1.00,
    attackMultiplier: 1.00,
    expMultiplier: 1.00,
    coinMultiplier: 1.00,
    idle: [
      "assets/enemies/flower/base/idle-1.webp",
      "assets/enemies/flower/base/idle-2.webp"
    ],
    hurt: "assets/enemies/flower/base/hurt.webp"
  },

  pink: {
    id: "pink",
    name: "Pink Flower",
    hpMultiplier: 1.20,
    attackMultiplier: 1.10,
    expMultiplier: 1.15,
    coinMultiplier: 1.15,
    idle: [
      "assets/enemies/flower/base/Pink-idle-1.webp",
      "assets/enemies/flower/base/Pink-idle-2.webp"
    ],
    hurt: "assets/enemies/flower/base/Pink-hurt.webp"
  },

  orange: {
    id: "orange",
    name: "Orange Flower",
    hpMultiplier: 1.20,
    attackMultiplier: 1.10,
    expMultiplier: 1.20,
    coinMultiplier: 1.20,
    healPercent: 0.18,
    maxHeals: 2,
    healChance: 0.32,
    healMoveName: "Sunny Day!",
    idle: [
      "assets/enemies/flower/base/Orange-idle-1.webp",
      "assets/enemies/flower/base/Orange-idle-2.webp"
    ],
    hurt: "assets/enemies/flower/base/Orange-hurt.webp"
  },

  blue: {
    id: "blue",
    name: "Blue Flower",
    hpMultiplier: 1.40,
    attackMultiplier: 1.20,
    expMultiplier: 1.35,
    coinMultiplier: 1.35,
    idle: [
      "assets/enemies/flower/base/Blue-idle-1.webp",
      "assets/enemies/flower/base/Blue-idle-2.webp"
    ],
    hurt: "assets/enemies/flower/base/Blue-hurt.webp"
  },

  rainbow: {
    id: "rainbow",
    name: "Rainbow Flower",
    hpMultiplier: 1.70,
    attackMultiplier: 1.30,
    expMultiplier: 1.50,
    coinMultiplier: 1.60,
    idle: [
      "assets/enemies/flower/base/Rainbow-idle-1.webp",
      "assets/enemies/flower/base/Rainbow-idle-2.webp"
    ],
    hurt: "assets/enemies/flower/base/Rainbow-hurt.webp"
  }
});

function weightedFlowerVariant(rank) {
  const r = Math.max(1, Number(rank) || 1);
  let pool;

  if (r <=4) {
    pool = [["white", 100]];
  } else if (r <=8) {
    pool = [["white", 60], ["pink", 40]];
  } else if (r <=12) {
    pool = [["white", 20], ["pink", 50], ["orange", 30]];
  } else if (r <=18) {
    pool = [["pink", 25], ["orange", 35], ["blue", 40]];
  } else if (r <=26) {
    pool = [["orange", 25], ["blue", 50], ["rainbow", 25]];
  } else {
    pool = [["blue", 40], ["rainbow", 60]];
  }

  const total = pool.reduce((sum, entry) => sum + entry[1], 0);
  let roll = Math.random() * total;

  for (const [id, weight] of pool) {
    roll -= weight;
    if (roll <= 0) return id;
  }
  return pool[0][0];
}

function applyFlowerVariant(template, rank) {
  const variant = FLOWER_VARIANTS[weightedFlowerVariant(rank)] || FLOWER_VARIANTS.white;

  return {
    ...template,
    name: variant.name,
    idle: variant.idle,
    hurt: variant.hurt,
    hp: Math.max(1, Math.round(template.hp * variant.hpMultiplier)),
    attack: Math.max(1, Math.round(template.attack * variant.attackMultiplier)),
    exp: Math.max(1, Math.round(template.exp * variant.expMultiplier)),
    coinMin: Math.max(1, Math.round(template.coinMin * variant.coinMultiplier)),
    coinMax: Math.max(1, Math.round(template.coinMax * variant.coinMultiplier)),
    flowerVariant: variant.id,
    healPercent: Number(variant.healPercent) || 0,
    maxHeals: Math.max(0, Number(variant.maxHeals) || 0),
    healChance: Math.max(0, Math.min(1, Number(variant.healChance) || 0)),
    healMoveName: variant.healMoveName || ""
  };
}

const CAT_SLIME_VARIANTS = Object.freeze({
  pink: {
    id: "pink",
    name: "Pink Cat Slime",
    hpMultiplier: 1.00,
    attackMultiplier: 1.00,
    expMultiplier: 1.00,
    coinMultiplier: 1.00,
    idle: [
      "assets/enemies/cat-slime/base/idle-1-neutral.webp",
      "assets/enemies/cat-slime/base/idle-2-squish.webp",
      "assets/enemies/cat-slime/base/idle-3-bounce.webp",
      "assets/enemies/cat-slime/base/idle-2-squish.webp"
    ],
    hurt: "assets/enemies/cat-slime/base/idle-1-neutral.webp"
  },

  purple: {
    id: "purple",
    name: "Purple Cat Slime",
    hpMultiplier: 1.20,
    attackMultiplier: 1.10,
    expMultiplier: 1.15,
    coinMultiplier: 1.15,
    idle: [
      "assets/enemies/cat-slime/base/Purple-idle-1-neutral.webp",
      "assets/enemies/cat-slime/base/Purple-idle-2-squish.webp",
      "assets/enemies/cat-slime/base/Purple-idle-3-bounce.webp",
      "assets/enemies/cat-slime/base/Purple-idle-2-squish.webp"
    ],
    hurt: "assets/enemies/cat-slime/base/Purple-idle-1-neutral.webp"
  },

  green: {
    id: "green",
    name: "Green Cat Slime",
    hpMultiplier: 1.20,
    attackMultiplier: 1.10,
    expMultiplier: 1.20,
    coinMultiplier: 1.20,
    healPercent: 0.18,
    maxHeals: 2,
    healChance: 0.32,
    healMoveName: "Super Squish!",
    idle: [
      "assets/enemies/cat-slime/base/Green-idle-1-neutral.webp",
      "assets/enemies/cat-slime/base/Green-idle-2-squish.webp",
      "assets/enemies/cat-slime/base/Green-idle-3-bounce.webp",
      "assets/enemies/cat-slime/base/Green-idle-2-squish.webp"
    ],
    hurt: "assets/enemies/cat-slime/base/Green-idle-1-neutral.webp"
  },

  teal: {
    id: "teal",
    name: "Teal Cat Slime",
    hpMultiplier: 1.40,
    attackMultiplier: 1.20,
    expMultiplier: 1.35,
    coinMultiplier: 1.35,
    idle: [
      "assets/enemies/cat-slime/base/Teal-idle-1-neutral.webp",
      "assets/enemies/cat-slime/base/Teal-idle-2-squish.webp",
      "assets/enemies/cat-slime/base/Teal-idle-3-bounce.webp",
      "assets/enemies/cat-slime/base/Teal-idle-2-squish.webp"
    ],
    hurt: "assets/enemies/cat-slime/base/Teal-idle-1-neutral.webp"
  },

  strawberry: {
    id: "strawberry",
    name: "Strawberry Cat Slime",
    hpMultiplier: 1.70,
    attackMultiplier: 1.30,
    expMultiplier: 1.50,
    coinMultiplier: 1.60,
    idle: [
      "assets/enemies/cat-slime/base/Strawberry-idle-1-neutral.webp",
      "assets/enemies/cat-slime/base/Strawberry-idle-2-squish.webp",
      "assets/enemies/cat-slime/base/Strawberry-idle-3-bounce.webp",
      "assets/enemies/cat-slime/base/Strawberry-idle-2-squish.webp"
    ],
    hurt: "assets/enemies/cat-slime/base/Strawberry-idle-1-neutral.webp"
  }
});

function weightedCatSlimeVariant(rank) {
  const r = Math.max(1, Number(rank) || 1);
  let pool;

  if (r <=4) {
    pool = [["pink", 100]];
  } else if (r <=8) {
    pool = [["pink", 60], ["purple", 40]];
  } else if (r <=12) {
    pool = [["pink", 20], ["purple", 50], ["green", 30]];
  } else if (r <=18) {
    pool = [["purple", 25], ["green", 35], ["teal", 40]];
  } else if (r <=26) {
    pool = [["green", 25], ["teal", 50], ["strawberry", 25]];
  } else {
    pool = [["teal", 40], ["strawberry", 60]];
  }

  const total = pool.reduce((sum, entry) => sum + entry[1], 0);
  let roll = Math.random() * total;

  for (const [id, weight] of pool) {
    roll -= weight;
    if (roll <= 0) return id;
  }
  return pool[0][0];
}

function applyCatSlimeVariant(template, rank) {
  const variant = CAT_SLIME_VARIANTS[weightedCatSlimeVariant(rank)] || CAT_SLIME_VARIANTS.pink;

  return {
    ...template,
    name: variant.name,
    idle: variant.idle,
    hurt: variant.hurt,
    hp: Math.max(1, Math.round(template.hp * variant.hpMultiplier)),
    attack: Math.max(1, Math.round(template.attack * variant.attackMultiplier)),
    exp: Math.max(1, Math.round(template.exp * variant.expMultiplier)),
    coinMin: Math.max(1, Math.round(template.coinMin * variant.coinMultiplier)),
    coinMax: Math.max(1, Math.round(template.coinMax * variant.coinMultiplier)),
    catSlimeVariant: variant.id,
    healPercent: Number(variant.healPercent) || 0,
    maxHeals: Math.max(0, Number(variant.maxHeals) || 0),
    healChance: Math.max(0, Math.min(1, Number(variant.healChance) || 0)),
    healMoveName: variant.healMoveName || ""
  };
}

const BEE_VARIANTS = Object.freeze({
  yellow: {
    id: "yellow",
    name: "Yellow Bee",
    hpMultiplier: 1.00,
    attackMultiplier: 1.00,
    expMultiplier: 1.00,
    coinMultiplier: 1.00,
    idle: [
      "assets/enemies/bee/base/idle-1-high.webp",
      "assets/enemies/bee/base/idle-2-low.webp"
    ],
    hurt: "assets/enemies/bee/base/hurt.webp"
  },

  purple: {
    id: "purple",
    name: "Purple Bee",
    hpMultiplier: 1.20,
    attackMultiplier: 1.10,
    expMultiplier: 1.15,
    coinMultiplier: 1.15,
    idle: [
      "assets/enemies/bee/base/Purple-idle-1-high.webp",
      "assets/enemies/bee/base/Purple-idle-2-low.webp"
    ],
    hurt: "assets/enemies/bee/base/Purple-hurt.webp"
  },

  blue: {
    id: "blue",
    name: "Blue Bee",
    hpMultiplier: 1.20,
    attackMultiplier: 1.10,
    expMultiplier: 1.20,
    coinMultiplier: 1.20,
    healPercent: 0.18,
    maxHeals: 2,
    healChance: 0.32,
    healMoveName: "Honey Snack!",
    idle: [
      "assets/enemies/bee/base/Blue-idle-1-high.webp",
      "assets/enemies/bee/base/Blue-idle-2-low.webp"
    ],
    hurt: "assets/enemies/bee/base/Blue-hurt.webp"
  },

  pink: {
    id: "pink",
    name: "Pink Bee",
    hpMultiplier: 1.40,
    attackMultiplier: 1.20,
    expMultiplier: 1.35,
    coinMultiplier: 1.35,
    idle: [
      "assets/enemies/bee/base/Pink-idle-1-high.webp",
      "assets/enemies/bee/base/Pink-idle-2-low.webp"
    ],
    hurt: "assets/enemies/bee/base/Pink-hurt.webp"
  },

  queen: {
    id: "queen",
    name: "Queen Bee",
    hpMultiplier: 1.70,
    attackMultiplier: 1.30,
    expMultiplier: 1.50,
    coinMultiplier: 1.60,
    idle: [
      "assets/enemies/bee/base/Queen-idle-1-high.webp",
      "assets/enemies/bee/base/Queen-idle-2-low.webp"
    ],
    hurt: "assets/enemies/bee/base/Queen-hurt.webp"
  }
});

function weightedBeeVariant(rank) {
  const r = Math.max(1, Number(rank) || 1);
  let pool;

  if (r <=4) {
    pool = [["yellow", 100]];
  } else if (r <=8) {
    pool = [["yellow", 60], ["purple", 40]];
  } else if (r <=12) {
    pool = [["yellow", 20], ["purple", 50], ["blue", 30]];
  } else if (r <=18) {
    pool = [["purple", 25], ["blue", 35], ["pink", 40]];
  } else if (r <=26) {
    pool = [["blue", 25], ["pink", 50], ["queen", 25]];
  } else {
    pool = [["pink", 40], ["queen", 60]];
  }

  const total = pool.reduce((sum, entry) => sum + entry[1], 0);
  let roll = Math.random() * total;

  for (const [id, weight] of pool) {
    roll -= weight;
    if (roll <= 0) return id;
  }
  return pool[0][0];
}

function applyBeeVariant(template, rank) {
  const variant = BEE_VARIANTS[weightedBeeVariant(rank)] || BEE_VARIANTS.yellow;

  return {
    ...template,
    name: variant.name,
    idle: variant.idle,
    hurt: variant.hurt,
    hp: Math.max(1, Math.round(template.hp * variant.hpMultiplier)),
    attack: Math.max(1, Math.round(template.attack * variant.attackMultiplier)),
    exp: Math.max(1, Math.round(template.exp * variant.expMultiplier)),
    coinMin: Math.max(1, Math.round(template.coinMin * variant.coinMultiplier)),
    coinMax: Math.max(1, Math.round(template.coinMax * variant.coinMultiplier)),
    beeVariant: variant.id,
    healPercent: Number(variant.healPercent) || 0,
    maxHeals: Math.max(0, Number(variant.maxHeals) || 0),
    healChance: Math.max(0, Math.min(1, Number(variant.healChance) || 0)),
    healMoveName: variant.healMoveName || ""
  };
}

const MUSHROOM_CAT_VARIANTS = Object.freeze({
  red:{id:"red",name:"Red Mushroom Cat",hpMultiplier:1,attackMultiplier:1,expMultiplier:1,coinMultiplier:1,idle:["assets/bosses/mushroom-cat/base/idle-1.webp","assets/bosses/mushroom-cat/base/idle-2.webp"],hurt:"assets/bosses/mushroom-cat/base/hurt.webp"},
  purple:{id:"purple",name:"Purple Mushroom Cat",hpMultiplier:1.20,attackMultiplier:1.10,expMultiplier:1.15,coinMultiplier:1.15,idle:["assets/bosses/mushroom-cat/base/Purple-idle-1.webp","assets/bosses/mushroom-cat/base/Purple-idle-2.webp"],hurt:"assets/bosses/mushroom-cat/base/Purple-hurt.webp"},
  green:{id:"green",name:"Green Mushroom Cat",hpMultiplier:1.20,attackMultiplier:1.10,expMultiplier:1.20,coinMultiplier:1.20,healPercent:.18,maxHeals:2,healChance:.32,healMoveName:"Forest Snack!",idle:["assets/bosses/mushroom-cat/base/Green-idle-1.webp","assets/bosses/mushroom-cat/base/Green-idle-2.webp"],hurt:"assets/bosses/mushroom-cat/base/Green-hurt.webp"},
  grey:{id:"grey",name:"Grey Mushroom Cat",hpMultiplier:1.40,attackMultiplier:1.20,expMultiplier:1.35,coinMultiplier:1.35,idle:["assets/bosses/mushroom-cat/base/Grey-idle-1.webp","assets/bosses/mushroom-cat/base/Grey-idle-2.webp"],hurt:"assets/bosses/mushroom-cat/base/Grey-hurt.webp"},
  gold:{id:"gold",name:"Gold Mushroom Cat",hpMultiplier:1.70,attackMultiplier:1.30,expMultiplier:1.75,coinMultiplier:1.80,idle:["assets/bosses/mushroom-cat/base/Gold-idle-1.webp","assets/bosses/mushroom-cat/base/Gold-idle-2.webp"],hurt:"assets/bosses/mushroom-cat/base/Gold-hurt.webp"}
});
function weightedBossVariant(rank){
  const r=Math.max(1,Number(rank)||1); let pool;
  if(r<=4) pool=[["red",100]];
  else if(r<=8) pool=[["red",60],["purple",40]];
  else if(r<=12) pool=[["red",20],["purple",50],["green",30]];
  else if(r<=18) pool=[["purple",25],["green",35],["grey",40]];
  else if(r<=26) pool=[["green",25],["grey",50],["gold",25]];
  else pool=[["grey",40],["gold",60]];
  let roll=Math.random()*pool.reduce((s,x)=>s+x[1],0);
  for(const [id,w] of pool){roll-=w;if(roll<=0)return id;} return pool[0][0];
}
function applyMushroomVariant(template,rank){
  const v=MUSHROOM_CAT_VARIANTS[weightedBossVariant(rank)]||MUSHROOM_CAT_VARIANTS.red;
  return {...template,name:v.name,idle:v.idle,hurt:v.hurt,hp:Math.round(template.hp*v.hpMultiplier),attack:Math.round(template.attack*v.attackMultiplier),exp:Math.round(template.exp*v.expMultiplier),coinMin:Math.round(template.coinMin*v.coinMultiplier),coinMax:Math.round(template.coinMax*v.coinMultiplier),mushroomVariant:v.id,healPercent:Number(v.healPercent)||0,maxHeals:Number(v.maxHeals)||0,healChance:Number(v.healChance)||0,healMoveName:v.healMoveName||""};
}

function weightedMeadowFamilyVariant(rank, ids){
  const r=Math.max(1,Number(rank)||1); let weights;
  if(r<=4) weights=[100,0,0,0,0];
  else if(r<=8) weights=[60,40,0,0,0];
  else if(r<=12) weights=[20,50,30,0,0];
  else if(r<=18) weights=[0,25,35,40,0];
  else if(r<=26) weights=[0,0,25,50,25];
  else weights=[0,0,0,40,60];
  let roll=Math.random()*weights.reduce((a,b)=>a+b,0);
  for(let i=0;i<ids.length;i++){roll-=weights[i];if(roll<=0)return ids[i];}
  return ids[0];
}

function applyFamilyVariant(template, table, ids, rank, variantProperty, ocean=false){
  const id=ocean ? weightedOceanVariant(rank,ids) : weightedMeadowFamilyVariant(rank,ids);
  const v=table[id]||table[ids[0]];
  return {
    ...template,
    name:v.name,idle:v.idle,hurt:v.hurt,
    hp:Math.max(1,Math.round(template.hp*(v.hp||1))),
    attack:Math.max(1,Math.round(template.attack*(v.atk||1))),
    exp:Math.max(1,Math.round(template.exp*(v.exp||1))),
    coinMin:Math.max(1,Math.round(template.coinMin*(v.coin||1))),
    coinMax:Math.max(1,Math.round(template.coinMax*(v.coin||1))),
    [variantProperty]:v.id,
    eliteVariant:Boolean(v.elite)
  };
}

const PORCUPIN_VARIANTS=Object.freeze({
  base:{id:"base",name:"Porcupin",idle:["assets/enemies/porcupin/base/idle-1.png","assets/enemies/porcupin/base/idle-2.png"],hurt:"assets/enemies/porcupin/base/hurt.png"},
  white:{id:"white",name:"White Porcupin",idle:["assets/enemies/porcupin/white/idle-1.png","assets/enemies/porcupin/white/idle-2.png"],hurt:"assets/enemies/porcupin/white/hurt.png"},
  black:{id:"black",name:"Black Porcupin",idle:["assets/enemies/porcupin/black/idle-1.png","assets/enemies/porcupin/black/idle-2.png"],hurt:"assets/enemies/porcupin/black/hurt.png"},
  green:{id:"green",name:"Green Porcupin",idle:["assets/enemies/porcupin/green/idle-1.png","assets/enemies/porcupin/green/idle-2.png"],hurt:"assets/enemies/porcupin/green/hurt.png"},
  gold:{id:"gold",name:"Gold Porcupin",idle:["assets/enemies/porcupin/gold/idle-1.png","assets/enemies/porcupin/gold/idle-2.png"],hurt:"assets/enemies/porcupin/gold/hurt.png"}
});
function applyPorcupinVariant(template){
  const r=Math.random();
  const id=r<.45?"base":r<.65?"white":r<.80?"black":r<.93?"green":"gold";
  const v=PORCUPIN_VARIANTS[id];
  return {...template,name:v.name,idle:v.idle.slice(),hurt:v.hurt,porcupinVariant:id};
}

const ACORN_MOUSE_VARIANTS=Object.freeze({
  base:{id:"base",name:"Acorn Mouse",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/acorn-mouse/base/acorn-mouse-idle-1.webp","assets/enemies/acorn-mouse/base/acorn-mouse-idle-2.webp"],hurt:"assets/enemies/acorn-mouse/base/acorn-mouse-hurt.webp"},
  blue:{id:"blue",name:"Blue Acorn Mouse",hp:1.15,atk:1.08,exp:1.15,coin:1.15,idle:["assets/enemies/acorn-mouse/base/blue-idle-1.webp","assets/enemies/acorn-mouse/base/blue-idle-2.webp"],hurt:"assets/enemies/acorn-mouse/base/blue-hurt.webp"},
  green:{id:"green",name:"Green Acorn Mouse",hp:1.25,atk:1.10,exp:1.22,coin:1.22,idle:["assets/enemies/acorn-mouse/base/green-idle-1.webp","assets/enemies/acorn-mouse/base/green-idle-2.webp"],hurt:"assets/enemies/acorn-mouse/base/green-hurt.webp"},
  purple:{id:"purple",name:"Purple Acorn Mouse",hp:1.4,atk:1.2,exp:1.35,coin:1.35,idle:["assets/enemies/acorn-mouse/base/purple-idle-1.webp","assets/enemies/acorn-mouse/base/purple-idle-2.webp"],hurt:"assets/enemies/acorn-mouse/base/purple-hurt.webp"},
  pink:{id:"pink",name:"Pink Acorn Mouse",hp:1.65,atk:1.28,exp:1.5,coin:1.58,elite:true,idle:["assets/enemies/acorn-mouse/base/pink-idle-1.webp","assets/enemies/acorn-mouse/base/pink-idle-2.webp"],hurt:"assets/enemies/acorn-mouse/base/pink-hurt.webp"}
});
function applyAcornMouseVariant(t,r){return applyFamilyVariant(t,ACORN_MOUSE_VARIANTS,["base","blue","green","purple","pink"],r,"acornMouseVariant",false);}

const SEAUNICORN_VARIANTS=Object.freeze({
  base:{id:"base",name:"Seaunicorn",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/seaunicorn/base/seaunicorn-idle-1.webp","assets/enemies/seaunicorn/base/seaunicorn-idle-2.webp"],hurt:"assets/enemies/seaunicorn/base/seaunicorn-hurt.webp"},
  orange:{id:"orange",name:"Orange Seaunicorn",hp:1.18,atk:1.08,exp:1.15,coin:1.15,idle:["assets/enemies/seaunicorn/base/orange-idle-1.webp","assets/enemies/seaunicorn/base/orange-idle-2.webp"],hurt:"assets/enemies/seaunicorn/base/orange-hurt.webp"},
  dark:{id:"dark",name:"Dark Seaunicorn",hp:1.25,atk:1.13,exp:1.24,coin:1.24,idle:["assets/enemies/seaunicorn/base/dark-idle-1.webp","assets/enemies/seaunicorn/base/dark-idle-2.webp"],hurt:"assets/enemies/seaunicorn/base/dark-hurt.webp"},
  pink:{id:"pink",name:"Pink Seaunicorn",hp:1.4,atk:1.2,exp:1.38,coin:1.38,idle:["assets/enemies/seaunicorn/base/pink-idle-1.webp","assets/enemies/seaunicorn/base/pink-idle-2.webp"],hurt:"assets/enemies/seaunicorn/base/pink-hurt.webp"},
  blue:{id:"blue",name:"Blue Seaunicorn",hp:1.68,atk:1.3,exp:1.55,coin:1.62,elite:true,idle:["assets/enemies/seaunicorn/base/blue-idle-1.webp","assets/enemies/seaunicorn/base/blue-idle-2.webp"],hurt:"assets/enemies/seaunicorn/base/blue-hurt.webp"}
});
function applySeaunicornVariant(t,r){return applyFamilyVariant(t,SEAUNICORN_VARIANTS,["base","orange","dark","pink","blue"],r,"seaunicornVariant",true);}

const TREE_SQUIRREL_VARIANTS=Object.freeze({
  base:{id:"base",name:"Tree Squirrel",hp:1,atk:1,exp:1,coin:1,idle:["assets/bosses/tree-squirrel/base/tree-squirrel-idle-1.webp","assets/bosses/tree-squirrel/base/tree-squirrel-idle-2.webp"],hurt:"assets/bosses/tree-squirrel/base/tree-squirrel-hurt.webp"},
  green:{id:"green",name:"Green Tree Squirrel",hp:1.15,atk:1.08,exp:1.15,coin:1.15,idle:["assets/bosses/tree-squirrel/base/green-idle-1.webp","assets/bosses/tree-squirrel/base/green-idle-2.webp"],hurt:"assets/bosses/tree-squirrel/base/green-hurt.webp"},
  yellow:{id:"yellow",name:"Yellow Tree Squirrel",hp:1.25,atk:1.12,exp:1.24,coin:1.24,idle:["assets/bosses/tree-squirrel/base/yellow-idle-1.webp","assets/bosses/tree-squirrel/base/yellow-idle-2.webp"],hurt:"assets/bosses/tree-squirrel/base/yellow-hurt.webp"},
  pink:{id:"pink",name:"Pink Tree Squirrel",hp:1.42,atk:1.2,exp:1.4,coin:1.4,idle:["assets/bosses/tree-squirrel/base/pink-idle-1.webp","assets/bosses/tree-squirrel/base/pink-idle-2.webp"],hurt:"assets/bosses/tree-squirrel/base/pink-hurt.webp"},
  peach:{id:"peach",name:"Peach Tree Squirrel",hp:1.7,atk:1.3,exp:1.7,coin:1.75,elite:true,idle:["assets/bosses/tree-squirrel/base/peach-idle-1.webp","assets/bosses/tree-squirrel/base/peach-idle-2.webp"],hurt:"assets/bosses/tree-squirrel/base/peach-hurt.webp"}
});
function applyTreeSquirrelVariant(t,r){return applyFamilyVariant(t,TREE_SQUIRREL_VARIANTS,["base","green","yellow","pink","peach"],r,"treeSquirrelVariant",false);}

const JELLYBUN_VARIANTS=Object.freeze({
  base:{id:"base",name:"Jellybun",hp:1,atk:1,exp:1,coin:1,idle:["assets/bosses/jellybun/base/jellybun-idle-1.webp","assets/bosses/jellybun/base/jellybun-idle-2.webp"],hurt:"assets/bosses/jellybun/base/jellybun-hurt.webp"},
  pink:{id:"pink",name:"Pink Jellybun",hp:1.18,atk:1.08,exp:1.15,coin:1.15,idle:["assets/bosses/jellybun/base/pink-idle-1.webp","assets/bosses/jellybun/base/pink-idle-2.webp"],hurt:"assets/bosses/jellybun/base/pink-hurt.webp"},
  green:{id:"green",name:"Green Jellybun",hp:1.28,atk:1.13,exp:1.25,coin:1.25,idle:["assets/bosses/jellybun/base/green-idle-1.webp","assets/bosses/jellybun/base/green-idle-2.webp"],hurt:"assets/bosses/jellybun/base/green-hurt.webp"},
  grey:{id:"grey",name:"Grey Jellybun",hp:1.45,atk:1.2,exp:1.42,coin:1.42,idle:["assets/bosses/jellybun/base/grey-idle-1.webp","assets/bosses/jellybun/base/grey-idle-2.webp"],hurt:"assets/bosses/jellybun/base/grey-hurt.webp"},
  gold:{id:"gold",name:"Gold Jellybun",hp:1.72,atk:1.3,exp:1.75,coin:1.8,elite:true,idle:["assets/bosses/jellybun/base/gold-idle-1.webp","assets/bosses/jellybun/base/gold-idle-2.webp"],hurt:"assets/bosses/jellybun/base/gold-hurt.webp"}
});
function applyJellybunVariant(t,r){return applyFamilyVariant(t,JELLYBUN_VARIANTS,["base","pink","green","grey","gold"],r,"jellybunVariant",true);}

function weightedProgressVariant(rank, ids, maxRank){
  const r=Math.max(1,Number(rank)||1);
  if(r<=1 || ids.length<=1) return ids[0];
  const progress=Math.max(0,Math.min(1,(r-1)/Math.max(1,(Number(maxRank)||1)-1)));
  const target=progress*(ids.length-1);
  const weights=ids.map((_,index)=>{
    const distance=Math.abs(index-target);
    if(distance>=2) return 0;
    return Math.max(2,Math.round(100*(1-distance/2)));
  });
  let roll=Math.random()*weights.reduce((sum,value)=>sum+value,0);
  for(let i=0;i<ids.length;i++){ roll-=weights[i]; if(roll<=0) return ids[i]; }
  return ids[Math.min(ids.length-1,Math.round(target))];
}

function applyProgressVariant(template, table, ids, rank, variantProperty, maxRank){
  const id=weightedProgressVariant(rank,ids,maxRank);
  const v=table[id]||table[ids[0]];
  return {
    ...template,
    name:v.name,idle:v.idle,hurt:v.hurt,
    hp:Math.max(1,Math.round(template.hp*(v.hp||1))),
    attack:Math.max(1,Math.round(template.attack*(v.atk||1))),
    exp:Math.max(1,Math.round(template.exp*(v.exp||1))),
    coinMin:Math.max(1,Math.round(template.coinMin*(v.coin||1))),
    coinMax:Math.max(1,Math.round(template.coinMax*(v.coin||1))),
    [variantProperty]:v.id,
    eliteVariant:Boolean(v.elite)
  };
}

const CATTERPILLAR_VARIANTS=Object.freeze({
  base:{id:"base",name:"Catterpillar",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/catterpillar/base/idle-1.png","assets/enemies/catterpillar/base/idle-2.png"],hurt:"assets/enemies/catterpillar/base/hurt.png"},
  blue:{id:"blue",name:"Blue Catterpillar",hp:1.14,atk:1.07,exp:1.14,coin:1.14,idle:["assets/enemies/catterpillar/base/blue-idle-1.png","assets/enemies/catterpillar/base/blue-idle-2.png"],hurt:"assets/enemies/catterpillar/base/blue-hurt.png"},
  orange:{id:"orange",name:"Orange Catterpillar",hp:1.24,atk:1.11,exp:1.22,coin:1.22,idle:["assets/enemies/catterpillar/base/orange-idle-1.png","assets/enemies/catterpillar/base/orange-idle-2.png"],hurt:"assets/enemies/catterpillar/base/orange-hurt.png"},
  pink:{id:"pink",name:"Pink Catterpillar",hp:1.40,atk:1.19,exp:1.36,coin:1.36,idle:["assets/enemies/catterpillar/base/pink-idle-1.png","assets/enemies/catterpillar/base/pink-idle-2.png"],hurt:"assets/enemies/catterpillar/base/pink-hurt.png"},
  purple:{id:"purple",name:"Purple Catterpillar",hp:1.65,atk:1.28,exp:1.55,coin:1.58,elite:true,idle:["assets/enemies/catterpillar/base/purple-idle-1.png","assets/enemies/catterpillar/base/purple-idle-2.png"],hurt:"assets/enemies/catterpillar/base/purple-hurt.png"}
});
function applyCatterpillarVariant(t,r){return applyProgressVariant(t,CATTERPILLAR_VARIANTS,["base","blue","orange","pink","purple"],r,"catterpillarVariant",40);}

const SEA_STAR_VARIANTS=Object.freeze({
  base:{id:"base",name:"Sea Star",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/sea-star/base/idle-1.png","assets/enemies/sea-star/base/idle-2.png"],hurt:"assets/enemies/sea-star/base/hurt.png"},
  blue:{id:"blue",name:"Blue Sea Star",hp:1.14,atk:1.07,exp:1.14,coin:1.14,idle:["assets/enemies/sea-star/base/blue-idle-1.png","assets/enemies/sea-star/base/blue-idle-2.png"],hurt:"assets/enemies/sea-star/base/blue-hurt.png"},
  green:{id:"green",name:"Green Sea Star",hp:1.24,atk:1.11,exp:1.22,coin:1.22,idle:["assets/enemies/sea-star/base/green-idle-1.png","assets/enemies/sea-star/base/green-idle-2.png"],hurt:"assets/enemies/sea-star/base/green-hurt.png"},
  pink:{id:"pink",name:"Pink Sea Star",hp:1.40,atk:1.19,exp:1.36,coin:1.36,idle:["assets/enemies/sea-star/base/pink-idle-1.png","assets/enemies/sea-star/base/pink-idle-2.png"],hurt:"assets/enemies/sea-star/base/pink-hurt.png"},
  purple:{id:"purple",name:"Purple Sea Star",hp:1.65,atk:1.28,exp:1.55,coin:1.58,elite:true,idle:["assets/enemies/sea-star/base/purple-idle-1.png","assets/enemies/sea-star/base/purple-idle-2.png"],hurt:"assets/enemies/sea-star/base/purple-hurt.png"}
});
function applySeaStarVariant(t,r){return applyProgressVariant(t,SEA_STAR_VARIANTS,["base","blue","green","pink","purple"],r,"seaStarVariant",80);}

const STAR_MOUSE_VARIANTS=Object.freeze({
  base:{id:"base",name:"Star Mouse",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/star-mouse/base/idle-1.png","assets/enemies/star-mouse/base/idle-2.png"],hurt:"assets/enemies/star-mouse/base/hurt.png"},
  blue:{id:"blue",name:"Blue Star Mouse",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/star-mouse/base/blue-idle-1.png","assets/enemies/star-mouse/base/blue-idle-2.png"],hurt:"assets/enemies/star-mouse/base/blue-hurt.png"},
  mint:{id:"mint",name:"Mint Star Mouse",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/star-mouse/base/mint-idle-1.png","assets/enemies/star-mouse/base/mint-idle-2.png"],hurt:"assets/enemies/star-mouse/base/mint-hurt.png"},
  pink:{id:"pink",name:"Pink Star Mouse",hp:1.40,atk:1.19,exp:1.38,coin:1.38,idle:["assets/enemies/star-mouse/base/pink-idle-1.png","assets/enemies/star-mouse/base/pink-idle-2.png"],hurt:"assets/enemies/star-mouse/base/pink-hurt.png"},
  purple:{id:"purple",name:"Purple Star Mouse",hp:1.66,atk:1.28,exp:1.58,coin:1.60,elite:true,idle:["assets/enemies/star-mouse/base/purple-idle-1.png","assets/enemies/star-mouse/base/purple-idle-2.png"],hurt:"assets/enemies/star-mouse/base/purple-hurt.png"}
});
function applyStarMouseVariant(t,r){return applyProgressVariant(t,STAR_MOUSE_VARIANTS,["base","blue","mint","pink","purple"],r,"starMouseVariant",160);}

const PUFF_FAIRY_VARIANTS=Object.freeze({
  base:{id:"base",name:"Puff Fairy",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/puff-fairy/base/idle-1.png","assets/enemies/puff-fairy/base/idle-2.png"],hurt:"assets/enemies/puff-fairy/base/hurt.png"},
  pink:{id:"pink",name:"Pink Puff Fairy",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/puff-fairy/base/pink-idle-1.png","assets/enemies/puff-fairy/base/pink-idle-2.png"],hurt:"assets/enemies/puff-fairy/base/pink-hurt.png"},
  purple:{id:"purple",name:"Purple Puff Fairy",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/puff-fairy/base/purple-idle-1.png","assets/enemies/puff-fairy/base/purple-idle-2.png"],hurt:"assets/enemies/puff-fairy/base/purple-hurt.png"},
  gold:{id:"gold",name:"Gold Puff Fairy",hp:1.40,atk:1.19,exp:1.38,coin:1.42,idle:["assets/enemies/puff-fairy/base/gold-idle-1.png","assets/enemies/puff-fairy/base/gold-idle-2.png"],hurt:"assets/enemies/puff-fairy/base/gold-hurt.png"},
  dark:{id:"dark",name:"Dark Puff Fairy",hp:1.66,atk:1.28,exp:1.58,coin:1.62,elite:true,idle:["assets/enemies/puff-fairy/base/dark-idle-1.png","assets/enemies/puff-fairy/base/dark-idle-2.png"],hurt:"assets/enemies/puff-fairy/base/dark-hurt.png"}
});
function applyPuffFairyVariant(t,r){return applyProgressVariant(t,PUFF_FAIRY_VARIANTS,["base","pink","purple","gold","dark"],r,"puffFairyVariant",160);}

const TULIPA_VARIANTS=Object.freeze({
  base:{id:"base",name:"Tulipa",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/tulipa/base/idle-1.png","assets/enemies/tulipa/base/idle-2.png"],hurt:"assets/enemies/tulipa/base/hurt.png"},
  yellow:{id:"yellow",name:"Yellow Tulipa",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/tulipa/base/yellow-idle-1.png","assets/enemies/tulipa/base/yellow-idle-2.png"],hurt:"assets/enemies/tulipa/base/yellow-hurt.png"},
  orange:{id:"orange",name:"Orange Tulipa",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/tulipa/base/orange-idle-1.png","assets/enemies/tulipa/base/orange-idle-2.png"],hurt:"assets/enemies/tulipa/base/orange-hurt.png"},
  purple:{id:"purple",name:"Purple Tulipa",hp:1.40,atk:1.19,exp:1.38,coin:1.38,idle:["assets/enemies/tulipa/base/purple-idle-1.png","assets/enemies/tulipa/base/purple-idle-2.png"],hurt:"assets/enemies/tulipa/base/purple-hurt.png"},
  dark:{id:"dark",name:"Dark Tulipa",hp:1.66,atk:1.28,exp:1.58,coin:1.60,elite:true,idle:["assets/enemies/tulipa/base/dark-idle-1.png","assets/enemies/tulipa/base/dark-idle-2.png"],hurt:"assets/enemies/tulipa/base/dark-hurt.png"}
});
function applyTulipaVariant(t,r){return applyProgressVariant(t,TULIPA_VARIANTS,["base","yellow","orange","purple","dark"],r,"tulipaVariant",160);}

const SNOUD_VARIANTS=Object.freeze({
  base:{id:"base",name:"Snoud",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/snoud/base/idle-1.png","assets/enemies/snoud/base/idle-2.png"],hurt:"assets/enemies/snoud/base/hurt.png"},
  green:{id:"green",name:"Green Snoud",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/snoud/base/green-idle-1.png","assets/enemies/snoud/base/green-idle-2.png"],hurt:"assets/enemies/snoud/base/green-hurt.png"},
  grey:{id:"grey",name:"Grey Snoud",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/snoud/base/grey-idle-1.png","assets/enemies/snoud/base/grey-idle-2.png"],hurt:"assets/enemies/snoud/base/grey-hurt.png"},
  purple:{id:"purple",name:"Purple Snoud",hp:1.40,atk:1.19,exp:1.38,coin:1.38,idle:["assets/enemies/snoud/base/purple-idle-1.png","assets/enemies/snoud/base/purple-idle-2.png"],hurt:"assets/enemies/snoud/base/purple-hurt.png"},
  gold:{id:"gold",name:"Gold Snoud",hp:1.66,atk:1.28,exp:1.58,coin:1.65,elite:true,idle:["assets/enemies/snoud/base/gold-idle-1.png","assets/enemies/snoud/base/gold-idle-2.png"],hurt:"assets/enemies/snoud/base/gold-hurt.png"}
});
function applySnoudVariant(t,r){return applyProgressVariant(t,SNOUD_VARIANTS,["base","green","grey","purple","gold"],r,"snoudVariant",160);}

const CLOUD_BUNNY_VARIANTS=Object.freeze({
  base:{id:"base",name:"Cloud Bunny",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/cloud-bunny/base/idle-1.png","assets/enemies/cloud-bunny/base/idle-2.png"],hurt:"assets/enemies/cloud-bunny/base/hurt.png"},
  grey:{id:"grey",name:"Grey Cloud Bunny",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/cloud-bunny/base/grey-idle-1.png","assets/enemies/cloud-bunny/base/grey-idle-2.png"],hurt:"assets/enemies/cloud-bunny/base/grey-hurt.png"},
  blue:{id:"blue",name:"Blue Cloud Bunny",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/cloud-bunny/base/blue-idle-1.png","assets/enemies/cloud-bunny/base/blue-idle-2.png"],hurt:"assets/enemies/cloud-bunny/base/blue-hurt.png"},
  pink:{id:"pink",name:"Pink Cloud Bunny",hp:1.40,atk:1.19,exp:1.38,coin:1.38,idle:["assets/enemies/cloud-bunny/base/pink-idle-1.png","assets/enemies/cloud-bunny/base/pink-idle-2.png"],hurt:"assets/enemies/cloud-bunny/base/pink-hurt.png"},
  black:{id:"black",name:"Black Cloud Bunny",hp:1.66,atk:1.28,exp:1.58,coin:1.60,elite:true,idle:["assets/enemies/cloud-bunny/base/black-idle-1.png","assets/enemies/cloud-bunny/base/black-idle-2.png"],hurt:"assets/enemies/cloud-bunny/base/black-hurt.png"}
});
function applyCloudBunnyVariant(t,r){return applyProgressVariant(t,CLOUD_BUNNY_VARIANTS,["base","grey","blue","pink","black"],r,"cloudBunnyVariant",160);}

const LUNAR_MOTH_VARIANTS=Object.freeze({
  base:{id:"base",name:"Lunar Moth",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/lunar-moth/base/idle-1.png","assets/enemies/lunar-moth/base/idle-2.png"],hurt:"assets/enemies/lunar-moth/base/hurt.png"},
  blue:{id:"blue",name:"Blue Lunar Moth",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/lunar-moth/base/blue-idle-1.png","assets/enemies/lunar-moth/base/blue-idle-2.png"],hurt:"assets/enemies/lunar-moth/base/blue-hurt.png"},
  mint:{id:"mint",name:"Mint Lunar Moth",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/lunar-moth/base/mint-idle-1.png","assets/enemies/lunar-moth/base/mint-idle-2.png"],hurt:"assets/enemies/lunar-moth/base/mint-hurt.png"},
  pink:{id:"pink",name:"Pink Lunar Moth",hp:1.40,atk:1.19,exp:1.38,coin:1.38,idle:["assets/enemies/lunar-moth/base/pink-idle-1.png","assets/enemies/lunar-moth/base/pink-idle-2.png"],hurt:"assets/enemies/lunar-moth/base/pink-hurt.png"},
  golden:{id:"golden",name:"Golden Lunar Moth",hp:1.66,atk:1.28,exp:1.58,coin:1.65,elite:true,idle:["assets/enemies/lunar-moth/base/golden-idle-1.png","assets/enemies/lunar-moth/base/golden-idle-2.png"],hurt:"assets/enemies/lunar-moth/base/golden-hurt.png"}
});
function applyLunarMothVariant(t,r){return applyProgressVariant(t,LUNAR_MOTH_VARIANTS,["base","blue","mint","pink","golden"],r,"lunarMothVariant",160);}

const ARIES_VARIANTS=Object.freeze({
  base:{id:"base",name:"Aries",hp:1,atk:1,exp:1,coin:1,idle:["assets/bosses/aries/base/idle-1.png","assets/bosses/aries/base/idle-2.png"],hurt:"assets/bosses/aries/base/hurt.png"},
  blue:{id:"blue",name:"Blue Aries",hp:1.11,atk:1.06,exp:1.12,coin:1.12,idle:["assets/bosses/aries/base/blue-idle-1.png","assets/bosses/aries/base/blue-idle-2.png"],hurt:"assets/bosses/aries/base/blue-hurt.png"},
  pink:{id:"pink",name:"Pink Aries",hp:1.22,atk:1.10,exp:1.22,coin:1.22,idle:["assets/bosses/aries/base/pink-idle-1.png","assets/bosses/aries/base/pink-idle-2.png"],hurt:"assets/bosses/aries/base/pink-hurt.png"},
  purple:{id:"purple",name:"Purple Aries",hp:1.36,atk:1.16,exp:1.34,coin:1.34,idle:["assets/bosses/aries/base/purple-idle-1.png","assets/bosses/aries/base/purple-idle-2.png"],hurt:"assets/bosses/aries/base/purple-hurt.png"},
  gold:{id:"gold",name:"Gold Aries",hp:1.52,atk:1.23,exp:1.49,coin:1.52,idle:["assets/bosses/aries/base/gold-idle-1.png","assets/bosses/aries/base/gold-idle-2.png"],hurt:"assets/bosses/aries/base/gold-hurt.png"},
  galaxy:{id:"galaxy",name:"Galaxy Aries",hp:1.74,atk:1.31,exp:1.70,coin:1.78,elite:true,idle:["assets/bosses/aries/base/galaxy-idle-1.png","assets/bosses/aries/base/galaxy-idle-2.png"],hurt:"assets/bosses/aries/base/galaxy-hurt.png"}
});
function applyAriesVariant(t,r){return applyProgressVariant(t,ARIES_VARIANTS,["base","blue","pink","purple","gold","galaxy"],r,"ariesVariant",160);}

const CHERUB_DUCK_VARIANTS=Object.freeze({
  base:{id:"base",name:"Cherub Duck",hp:1,atk:1,exp:1,coin:1,idle:["assets/bosses/cherub-duck/base/idle-1.png","assets/bosses/cherub-duck/base/idle-2.png"],hurt:"assets/bosses/cherub-duck/base/hurt.png"},
  aqua:{id:"aqua",name:"Aqua Cherub Duck",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/bosses/cherub-duck/base/aqua-idle-1.png","assets/bosses/cherub-duck/base/aqua-idle-2.png"],hurt:"assets/bosses/cherub-duck/base/aqua-hurt.png"},
  mint:{id:"mint",name:"Mint Cherub Duck",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/bosses/cherub-duck/base/mint-idle-1.png","assets/bosses/cherub-duck/base/mint-idle-2.png"],hurt:"assets/bosses/cherub-duck/base/mint-hurt.png"},
  pink:{id:"pink",name:"Pink Cherub Duck",hp:1.42,atk:1.19,exp:1.39,coin:1.39,idle:["assets/bosses/cherub-duck/base/pink-idle-1.png","assets/bosses/cherub-duck/base/pink-idle-2.png"],hurt:"assets/bosses/cherub-duck/base/pink-hurt.png"},
  purple:{id:"purple",name:"Purple Cherub Duck",hp:1.70,atk:1.29,exp:1.64,coin:1.68,elite:true,idle:["assets/bosses/cherub-duck/base/purple-idle-1.png","assets/bosses/cherub-duck/base/purple-idle-2.png"],hurt:"assets/bosses/cherub-duck/base/purple-hurt.png"}
});
function applyCherubDuckVariant(t,r){return applyProgressVariant(t,CHERUB_DUCK_VARIANTS,["base","aqua","mint","pink","purple"],r,"cherubDuckVariant",160);}

const APPLE_BABY_VARIANTS=Object.freeze({
  base:{id:"base",name:"Apple Baby",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/apple-baby/base/idle-1.webp","assets/enemies/apple-baby/base/idle-2.webp"],hurt:"assets/enemies/apple-baby/base/hurt.webp"},
  pink:{id:"pink",name:"Pink Apple Baby",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/apple-baby/base/pink-idle-1.webp","assets/enemies/apple-baby/base/pink-idle-2.webp"],hurt:"assets/enemies/apple-baby/base/pink-hurt.webp"},
  green:{id:"green",name:"Green Apple Baby",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/apple-baby/base/green-idle-1.webp","assets/enemies/apple-baby/base/green-idle-2.webp"],hurt:"assets/enemies/apple-baby/base/green-hurt.webp"},
  gold:{id:"gold",name:"Gold Apple Baby",hp:1.40,atk:1.19,exp:1.38,coin:1.40,idle:["assets/enemies/apple-baby/base/gold-idle-1.webp","assets/enemies/apple-baby/base/gold-idle-2.webp"],hurt:"assets/enemies/apple-baby/base/gold-hurt.webp"},
  brown:{id:"brown",name:"Caramel Apple Baby",hp:1.66,atk:1.28,exp:1.58,coin:1.62,elite:true,idle:["assets/enemies/apple-baby/base/brown-idle-1.webp","assets/enemies/apple-baby/base/brown-idle-2.webp"],hurt:"assets/enemies/apple-baby/base/brown-hurt.webp"}
});
function applyAppleBabyVariant(t,r){return applyProgressVariant(t,APPLE_BABY_VARIANTS,["base","pink","green","gold","brown"],r,"appleBabyVariant",120);}

const GUMMY_WORM_VARIANTS=Object.freeze({
  base:{id:"base",name:"Gummy Worm",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/gummy-worm/base/idle-1.webp","assets/enemies/gummy-worm/base/idle-2.webp"],hurt:"assets/enemies/gummy-worm/base/hurt.webp"},
  orange:{id:"orange",name:"Orange Gummy Worm",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/gummy-worm/base/orange-idle-1.webp","assets/enemies/gummy-worm/base/orange-idle-2.webp"],hurt:"assets/enemies/gummy-worm/base/orange-hurt.webp"},
  red:{id:"red",name:"Red Gummy Worm",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/gummy-worm/base/red-idle-1.webp","assets/enemies/gummy-worm/base/red-idle-2.webp"],hurt:"assets/enemies/gummy-worm/base/red-hurt.webp"},
  purple:{id:"purple",name:"Purple Gummy Worm",hp:1.40,atk:1.19,exp:1.38,coin:1.40,idle:["assets/enemies/gummy-worm/base/purple-idle-1.webp","assets/enemies/gummy-worm/base/purple-idle-2.webp"],hurt:"assets/enemies/gummy-worm/base/purple-hurt.webp"},
  white:{id:"white",name:"White Gummy Worm",hp:1.66,atk:1.28,exp:1.58,coin:1.62,elite:true,idle:["assets/enemies/gummy-worm/base/white-idle-1.webp","assets/enemies/gummy-worm/base/white-idle-2.webp"],hurt:"assets/enemies/gummy-worm/base/white-hurt.webp"}
});
function applyGummyWormVariant(t,r){return applyProgressVariant(t,GUMMY_WORM_VARIANTS,["base","orange","red","purple","white"],r,"gummyWormVariant",120);}

const PUDDING_PIG_VARIANTS=Object.freeze({
  base:{id:"base",name:"Pudding Pig",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/pudding-pig/base/idle-1.webp","assets/enemies/pudding-pig/base/idle-2.webp"],hurt:"assets/enemies/pudding-pig/base/hurt.webp"},
  pink:{id:"pink",name:"Pink Pudding Pig",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/pudding-pig/base/pink-idle-1.webp","assets/enemies/pudding-pig/base/pink-idle-2.webp"],hurt:"assets/enemies/pudding-pig/base/pink-hurt.webp"},
  choco:{id:"choco",name:"Chocolate Pudding Pig",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/pudding-pig/base/choco-idle-1.webp","assets/enemies/pudding-pig/base/choco-idle-2.webp"],hurt:"assets/enemies/pudding-pig/base/choco-hurt.webp"},
  mint:{id:"mint",name:"Mint Pudding Pig",hp:1.40,atk:1.19,exp:1.38,coin:1.40,idle:["assets/enemies/pudding-pig/base/mint-idle-1.webp","assets/enemies/pudding-pig/base/mint-idle-2.webp"],hurt:"assets/enemies/pudding-pig/base/mint-hurt.webp"},
  blueberry:{id:"blueberry",name:"Blueberry Pudding Pig",hp:1.66,atk:1.28,exp:1.58,coin:1.62,elite:true,idle:["assets/enemies/pudding-pig/base/blueberry-idle-1.webp","assets/enemies/pudding-pig/base/blueberry-idle-2.webp"],hurt:"assets/enemies/pudding-pig/base/blueberry-hurt.webp"}
});
function applyPuddingPigVariant(t,r){return applyProgressVariant(t,PUDDING_PIG_VARIANTS,["base","pink","choco","mint","blueberry"],r,"puddingPigVariant",120);}

const GINGERLOLLY_VARIANTS=Object.freeze({
  base:{id:"base",name:"Gingerlolly",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/gingerlolly/base/idle-1.webp","assets/enemies/gingerlolly/base/idle-2.webp"],hurt:"assets/enemies/gingerlolly/base/hurt.webp"},
  green:{id:"green",name:"Green Gingerlolly",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/gingerlolly/base/green-idle-1.webp","assets/enemies/gingerlolly/base/green-idle-2.webp"],hurt:"assets/enemies/gingerlolly/base/green-hurt.webp"},
  yellow:{id:"yellow",name:"Yellow Gingerlolly",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/gingerlolly/base/yellow-idle-1.webp","assets/enemies/gingerlolly/base/yellow-idle-2.webp"],hurt:"assets/enemies/gingerlolly/base/yellow-hurt.webp"},
  purple:{id:"purple",name:"Purple Gingerlolly",hp:1.40,atk:1.19,exp:1.38,coin:1.40,idle:["assets/enemies/gingerlolly/base/purple-idle-1.webp","assets/enemies/gingerlolly/base/purple-idle-2.webp"],hurt:"assets/enemies/gingerlolly/base/purple-hurt.webp"},
  blue:{id:"blue",name:"Blue Gingerlolly",hp:1.66,atk:1.28,exp:1.58,coin:1.62,elite:true,idle:["assets/enemies/gingerlolly/base/blue-idle-1.webp","assets/enemies/gingerlolly/base/blue-idle-2.webp"],hurt:"assets/enemies/gingerlolly/base/blue-hurt.webp"}
});
function applyGingerlollyVariant(t,r){return applyProgressVariant(t,GINGERLOLLY_VARIANTS,["base","green","yellow","purple","blue"],r,"gingerlollyVariant",120);}

const CANDYCANE_DEER_VARIANTS=Object.freeze({
  base:{id:"base",name:"Candycane Deer",hp:1,atk:1,exp:1,coin:1,idle:["assets/enemies/candycane-deer/base/idle-1.webp","assets/enemies/candycane-deer/base/idle-2.webp"],hurt:"assets/enemies/candycane-deer/base/hurt.webp"},
  mintchoco:{id:"mintchoco",name:"Mint Choco Candycane Deer",hp:1.12,atk:1.06,exp:1.12,coin:1.12,idle:["assets/enemies/candycane-deer/base/mintchoco-idle-1.webp","assets/enemies/candycane-deer/base/mintchoco-idle-2.webp"],hurt:"assets/enemies/candycane-deer/base/mintchoco-hurt.webp"},
  bubblegum:{id:"bubblegum",name:"Bubblegum Candycane Deer",hp:1.24,atk:1.11,exp:1.23,coin:1.23,idle:["assets/enemies/candycane-deer/base/bubblegum-idle-1.webp","assets/enemies/candycane-deer/base/bubblegum-idle-2.webp"],hurt:"assets/enemies/candycane-deer/base/bubblegum-hurt.webp"},
  xmas:{id:"xmas",name:"Christmas Candycane Deer",hp:1.40,atk:1.19,exp:1.38,coin:1.40,idle:["assets/enemies/candycane-deer/base/xmas-idle-1.webp","assets/enemies/candycane-deer/base/xmas-idle-2.webp"],hurt:"assets/enemies/candycane-deer/base/xmas-hurt.webp"},
  yellow:{id:"yellow",name:"Yellow Candycane Deer",hp:1.66,atk:1.28,exp:1.58,coin:1.62,elite:true,idle:["assets/enemies/candycane-deer/base/yellow-idle-1.webp","assets/enemies/candycane-deer/base/yellow-idle-2.webp"],hurt:"assets/enemies/candycane-deer/base/yellow-hurt.webp"}
});
function applyCandycaneDeerVariant(t,r){return applyProgressVariant(t,CANDYCANE_DEER_VARIANTS,["base","mintchoco","bubblegum","xmas","yellow"],r,"candycaneDeerVariant",120);}

const GUMMY_SHARK_VARIANTS=Object.freeze({
  base:{id:"base",name:"Gummy Shark",hp:1,atk:1,exp:1,coin:1,idle:["assets/bosses/gummy-shark/base/idle-1.webp","assets/bosses/gummy-shark/base/idle-2.webp"],hurt:"assets/bosses/gummy-shark/base/hurt.webp"},
  lemon:{id:"lemon",name:"Lemon Gummy Shark",hp:1.11,atk:1.06,exp:1.12,coin:1.12,idle:["assets/bosses/gummy-shark/base/lemon-idle-1.webp","assets/bosses/gummy-shark/base/lemon-idle-2.webp"],hurt:"assets/bosses/gummy-shark/base/lemon-hurt.webp"},
  orange:{id:"orange",name:"Orange Gummy Shark",hp:1.22,atk:1.10,exp:1.22,coin:1.22,idle:["assets/bosses/gummy-shark/base/orange-idle-1.webp","assets/bosses/gummy-shark/base/orange-idle-2.webp"],hurt:"assets/bosses/gummy-shark/base/orange-hurt.webp"},
  lime:{id:"lime",name:"Lime Gummy Shark",hp:1.36,atk:1.16,exp:1.34,coin:1.34,idle:["assets/bosses/gummy-shark/base/lime-idle-1.webp","assets/bosses/gummy-shark/base/lime-idle-2.webp"],hurt:"assets/bosses/gummy-shark/base/lime-hurt.webp"},
  strawberry:{id:"strawberry",name:"Strawberry Gummy Shark",hp:1.62,atk:1.28,exp:1.62,coin:1.68,elite:true,idle:["assets/bosses/gummy-shark/base/strawberry-idle-1.webp","assets/bosses/gummy-shark/base/strawberry-idle-2.webp"],hurt:"assets/bosses/gummy-shark/base/strawberry-hurt.webp"}
});
function applyGummySharkVariant(t,r){return applyProgressVariant(t,GUMMY_SHARK_VARIANTS,["base","lemon","orange","lime","strawberry"],r,"gummySharkVariant",120);}

const CREAM_FOX_VARIANTS=Object.freeze({
  base:{id:"base",name:"Cream Fox",hp:1,atk:1,exp:1,coin:1,idle:["assets/bosses/cream-fox/base/idle-1.webp","assets/bosses/cream-fox/base/idle-2.webp"],hurt:"assets/bosses/cream-fox/base/hurt.webp"},
  choco:{id:"choco",name:"Chocolate Cream Fox",hp:1.11,atk:1.06,exp:1.12,coin:1.12,idle:["assets/bosses/cream-fox/base/choco-idle-1.webp","assets/bosses/cream-fox/base/choco-idle-2.webp"],hurt:"assets/bosses/cream-fox/base/choco-hurt.webp"},
  strawberry:{id:"strawberry",name:"Strawberry Cream Fox",hp:1.22,atk:1.10,exp:1.22,coin:1.22,idle:["assets/bosses/cream-fox/base/strawberry-idle-1.webp","assets/bosses/cream-fox/base/strawberry-idle-2.webp"],hurt:"assets/bosses/cream-fox/base/strawberry-hurt.webp"},
  lemon:{id:"lemon",name:"Lemon Cream Fox",hp:1.36,atk:1.16,exp:1.34,coin:1.34,idle:["assets/bosses/cream-fox/base/lemon-idle-1.webp","assets/bosses/cream-fox/base/lemon-idle-2.webp"],hurt:"assets/bosses/cream-fox/base/lemon-hurt.webp"},
  chocomint:{id:"chocomint",name:"Choco Mint Cream Fox",hp:1.62,atk:1.28,exp:1.62,coin:1.68,elite:true,idle:["assets/bosses/cream-fox/base/chocomint-idle-1.webp","assets/bosses/cream-fox/base/chocomint-idle-2.webp"],hurt:"assets/bosses/cream-fox/base/chocomint-hurt.webp"}
});
function applyCreamFoxVariant(t,r){return applyProgressVariant(t,CREAM_FOX_VARIANTS,["base","choco","strawberry","lemon","chocomint"],r,"creamFoxVariant",120);}

const BASE_SHINY_RATE = 1 / 500; // audited v56: exactly one normal shiny roll per encountered enemy
const MYSTERY_CHEST_RATE = 1 / 50;
const AMETHYST_MIMIC_RATE = 1 / 40; // 2.5% per purple Mystery Chest; intentionally rarer

function weightedPick(entries){
  const total=entries.reduce((sum,entry)=>sum+Math.max(0,Number(entry.weight)||0),0);
  if(total<=0) return entries[0]?.value ?? null;
  let roll=Math.random()*total;
  for(const entry of entries){
    roll-=Math.max(0,Number(entry.weight)||0);
    if(roll<=0) return entry.value;
  }
  return entries[entries.length-1]?.value ?? null;
}

function currentEncounterData(){
  return currentRun?.mode==="endless"
    ? currentRun?.endlessEncounter || null
    : currentRun?.plan?.[currentRun?.index || 0] || null;
}

function pickEncounterEnemy(enemyPool){
  return enemyPool[randInt(0,enemyPool.length-1)];
}

function pickEncounterEnemies(enemyPool,count=2){
  const source=Array.isArray(enemyPool)?enemyPool.filter(Boolean):[];
  if(!source.length) return [];
  const picks=[];
  const available=[...new Set(source)];
  while(picks.length<count){
    const pool=(available.length>=count)?available.filter(id=>!picks.includes(id)):source;
    picks.push(pool[randInt(0,pool.length-1)]);
  }
  return picks;
}

function pickSituationType(mode="stage"){
  return weightedPick(mode==="endless"
    ? [{value:"lucky-picnic",weight:5},{value:"wishing-fountain",weight:4}]
    : [{value:"lucky-picnic",weight:6},{value:"wishing-fountain",weight:4}]
  );
}

function buildEncounterFromPool(enemyPool,mode="stage"){
  if(Math.random()<MYSTERY_CHEST_RATE) return {type:"mystery-chest"};
  const roll=Math.random();
  if(mode==="endless"){
    if(roll<.09) return {type:"rare-chest"};
    if(roll<.15) return {type:"mimic"};
    if(roll<.25) return {type:"double-enemy",enemyIds:pickEncounterEnemies(ENDLESS_NORMAL_ENEMIES,2),waveIndex:0,defeatedEnemies:[]};
    if(roll<.33) return {type:pickSituationType("endless")};
    return {type:"enemy",enemyId:pickEncounterEnemy(ENDLESS_NORMAL_ENEMIES)};
  }
  if(roll<.12) return {type:"rare-chest"};
  if(roll<.20) return {type:"mimic"};
  if(roll<.28) return {type:"double-enemy",enemyIds:pickEncounterEnemies(enemyPool,2),waveIndex:0,defeatedEnemies:[]};
  if(roll<.36) return {type:pickSituationType("stage")};
  return {type:"enemy",enemyId:pickEncounterEnemy(enemyPool)};
}

function situationTitle(type){
  if(type==="lucky-picnic") return "Lucky Picnic";
  if(type==="wishing-fountain") return "Wishing Fountain";
  return "Special Event";
}

function updateEncounterHeader(encounter=currentEncounterData()){
  if(!ui.encounterLabel) return;
  if(currentRun?.mode==="endless"){
    ui.encounterLabel.textContent=`FLOOR ${currentRun.floor}${currentRun.floor%5===0?" · BOSS":""}`;
    ui.rankBattleLabel.textContent=`Endless · Record ${endlessProgress().record}`;
  } else {
    const cfg=currentAreaConfig();
    ui.encounterLabel.textContent=`${cfg.stageNames[currentRun.index].toUpperCase()} · ${currentRun.index+1} / 4`;
    ui.rankBattleLabel.textContent=`${cfg.name} · Level ${currentRun.rank}`;
  }
  if(!encounter) return;
  if(encounter.type==="double-enemy"){
    ui.encounterLabel.textContent += ` · DOUBLE BATTLE`;
  } else if(encounter.type==="lucky-picnic"){
    ui.encounterLabel.textContent += ' · PICNIC';
  } else if(encounter.type==="wishing-fountain"){
    ui.encounterLabel.textContent += ' · FOUNTAIN';
  }
}

const CHARM_SLOT_LIMIT = 3;
const CURRENT_DUCKIPEDIA_TOTAL = 75;
const CHARM_FAMILY_ORDER = Object.freeze(["shimmer","fortune","best-friend","training","vitality","treasure","wonder"]);
const CHARM_FAMILIES = Object.freeze({
  shimmer:{name:"Shimmer Charm",description:"Raises Shiny odds above the normal 1 / 500 rate.",family:"shimmer"},
  fortune:{name:"Fortune Charm",description:"Earn more Pink Coins and improve ordinary item quality.",family:"fortune"},
  "best-friend":{name:"Best Friend Charm",description:"Adds percentage points to compatible Lil Pon catch chances.",family:"best-friend"},
  training:{name:"Training Charm",description:"Earn more EXP from Duck Quest rewards.",family:"training"},
  vitality:{name:"Vitality Charm",description:"Raises this OC's maximum HP for the entire run.",family:"vitality"},
  treasure:{name:"Treasure Charm",description:"Sometimes adds an extra rare-leaning item to a treasure chest.",family:"treasure"},
  wonder:{name:"Wonder Charm",description:"Makes rare and unusual Duck Quest encounters a little easier to find.",family:"wonder"}
});
const CHARM_DEFS = Object.freeze({
  "shimmer-bronze":{id:"shimmer-bronze",family:"shimmer",tier:"bronze",name:"Bronze Shimmer Charm",price:350,shinyRate:1/400,effect:"Shiny chance: 1 / 400"},
  "shimmer-silver":{id:"shimmer-silver",family:"shimmer",tier:"silver",name:"Silver Shimmer Charm",price:1100,shinyRate:1/300,effect:"Shiny chance: 1 / 300"},
  "shimmer-gold":{id:"shimmer-gold",family:"shimmer",tier:"gold",name:"Gold Shimmer Charm",price:3500,shinyRate:1/200,effect:"Shiny chance: 1 / 200"},
  "shimmer-rose-gold":{id:"shimmer-rose-gold",family:"shimmer",tier:"rose-gold",name:"Rose-Gold Shimmer Charm",price:null,shinyRate:1/100,effect:"Shiny chance: 1 / 100",special:true},
  "fortune-bronze":{id:"fortune-bronze",family:"fortune",tier:"bronze",name:"Bronze Fortune Charm",price:250,coinBonus:.10,itemLuck:.10,effect:"+10% coins · Small rare-item luck boost"},
  "fortune-silver":{id:"fortune-silver",family:"fortune",tier:"silver",name:"Silver Fortune Charm",price:750,coinBonus:.20,itemLuck:.20,effect:"+20% coins · Medium rare-item luck boost"},
  "fortune-gold":{id:"fortune-gold",family:"fortune",tier:"gold",name:"Gold Fortune Charm",price:2500,coinBonus:.35,itemLuck:.35,effect:"+35% coins · Strong rare-item luck boost"},
  "best-friend-bronze":{id:"best-friend-bronze",family:"best-friend",tier:"bronze",name:"Bronze Best Friend Charm",price:175,catchBonus:.05,effect:"+5 percentage points to compatible catches"},
  "best-friend-silver":{id:"best-friend-silver",family:"best-friend",tier:"silver",name:"Silver Best Friend Charm",price:600,catchBonus:.10,effect:"+10 percentage points to compatible catches"},
  "best-friend-gold":{id:"best-friend-gold",family:"best-friend",tier:"gold",name:"Gold Best Friend Charm",price:2000,catchBonus:.20,effect:"+20 percentage points to compatible catches"},
  "training-bronze":{id:"training-bronze",family:"training",tier:"bronze",name:"Bronze Training Charm",price:200,expBonus:.15,effect:"+15% EXP"},
  "training-silver":{id:"training-silver",family:"training",tier:"silver",name:"Silver Training Charm",price:600,expBonus:.30,effect:"+30% EXP"},
  "training-gold":{id:"training-gold",family:"training",tier:"gold",name:"Gold Training Charm",price:1800,expBonus:.50,effect:"+50% EXP"},
  "vitality-bronze":{id:"vitality-bronze",family:"vitality",tier:"bronze",name:"Bronze Vitality Charm",price:225,hpBonus:.10,effect:"+10% Max HP"},
  "vitality-silver":{id:"vitality-silver",family:"vitality",tier:"silver",name:"Silver Vitality Charm",price:700,hpBonus:.20,effect:"+20% Max HP"},
  "vitality-gold":{id:"vitality-gold",family:"vitality",tier:"gold",name:"Gold Vitality Charm",price:2200,hpBonus:.35,effect:"+35% Max HP"},
  "treasure-bronze":{id:"treasure-bronze",family:"treasure",tier:"bronze",name:"Bronze Treasure Charm",price:275,treasureChance:.15,effect:"15% chance for a bonus rare-leaning chest item"},
  "treasure-silver":{id:"treasure-silver",family:"treasure",tier:"silver",name:"Silver Treasure Charm",price:850,treasureChance:.30,effect:"30% chance for a bonus rare-leaning chest item"},
  "treasure-gold":{id:"treasure-gold",family:"treasure",tier:"gold",name:"Gold Treasure Charm",price:2750,treasureChance:.50,effect:"50% chance for a bonus rare-leaning chest item"},
  "wonder-bronze":{id:"wonder-bronze",family:"wonder",tier:"bronze",name:"Bronze Wonder Charm",price:300,eventRate:.05,effect:"Rare encounter chance: 5%"},
  "wonder-silver":{id:"wonder-silver",family:"wonder",tier:"silver",name:"Silver Wonder Charm",price:750,eventRate:.06,effect:"Rare encounter chance: 6%"},
  "wonder-gold":{id:"wonder-gold",family:"wonder",tier:"gold",name:"Gold Wonder Charm",price:1300,eventRate:.08,effect:"Rare encounter chance: 8%"},
  "wonder-rose-gold":{id:"wonder-rose-gold",family:"wonder",tier:"rose-gold",name:"Rose-Gold Wonder Charm",price:2000,eventRate:.10,effect:"Rare encounter chance: 10%"}
});

function defaultCharmSave(){
  return {owned:{},equippedByCharacter:{peep:[],miko:[],io:[],miho:[],annika:[],shiyu:[]}};
}
function normalizeCharmSave(raw){
  const source=raw&&typeof raw==="object"?raw:{};
  const owned={};
  for(const id of Object.keys(CHARM_DEFS)) if(source.owned?.[id]) owned[id]=true;
  const equippedByCharacter={};
  for(const characterId of ["peep","miko","io","miho","annika","shiyu","angel"]){
    const incoming=Array.isArray(source.equippedByCharacter?.[characterId])?source.equippedByCharacter[characterId]:[];
    const seenFamilies=new Set();
    equippedByCharacter[characterId]=[];
    for(const id of incoming){
      const def=CHARM_DEFS[id];
      if(!def||!owned[id]||seenFamilies.has(def.family)) continue;
      seenFamilies.add(def.family);
      equippedByCharacter[characterId].push(id);
      if(equippedByCharacter[characterId].length>=CHARM_SLOT_LIMIT) break;
    }
  }
  return {owned,equippedByCharacter};
}

const GIMMICK_ENEMY_VARIANTS=Object.freeze({
  "rotten-egg":Object.freeze({
    base:{id:"base",name:"Rotten Egg",idle:["assets/gimmicks/rotten-egg/base/idle-1.png","assets/gimmicks/rotten-egg/base/idle-2.png"],hurt:"assets/gimmicks/rotten-egg/base/hurt.png"},
    rare:{id:"rare",name:"Rare Rotten Egg",idle:["assets/gimmicks/rotten-egg/rare/idle-1.png","assets/gimmicks/rotten-egg/rare/idle-2.png"],hurt:"assets/gimmicks/rotten-egg/rare/hurt.png"}
  }),
  "lucky-cat":Object.freeze({
    base:{id:"base",name:"Lucky Cat",idle:["assets/gimmicks/lucky-cat/base/idle-1.png","assets/gimmicks/lucky-cat/base/idle-2.png"],hurt:"assets/gimmicks/lucky-cat/base/hurt.png"},
    blue:{id:"blue",name:"Blue Lucky Cat",idle:["assets/gimmicks/lucky-cat/blue/idle-1.png","assets/gimmicks/lucky-cat/blue/idle-2.png"],hurt:"assets/gimmicks/lucky-cat/blue/hurt.png"},
    green:{id:"green",name:"Green Lucky Cat",idle:["assets/gimmicks/lucky-cat/green/idle-1.png","assets/gimmicks/lucky-cat/green/idle-2.png"],hurt:"assets/gimmicks/lucky-cat/green/hurt.png"},
    pink:{id:"pink",name:"Pink Lucky Cat",idle:["assets/gimmicks/lucky-cat/pink/idle-1.png","assets/gimmicks/lucky-cat/pink/idle-2.png"],hurt:"assets/gimmicks/lucky-cat/pink/hurt.png"},
    purple:{id:"purple",name:"Purple Lucky Cat",idle:["assets/gimmicks/lucky-cat/purple/idle-1.png","assets/gimmicks/lucky-cat/purple/idle-2.png"],hurt:"assets/gimmicks/lucky-cat/purple/hurt.png"}
  }),
  "angy-duck":Object.freeze({
    base:{id:"base",name:"Angy Duck",idle:["assets/gimmicks/angy-duck/base/idle-1.png","assets/gimmicks/angy-duck/base/idle-2.png"],hurt:"assets/gimmicks/angy-duck/base/hurt.png"},
    blue:{id:"blue",name:"Blue Angy Duck",idle:["assets/gimmicks/angy-duck/blue/idle-1.png","assets/gimmicks/angy-duck/blue/idle-2.png"],hurt:"assets/gimmicks/angy-duck/blue/hurt.png"},
    green:{id:"green",name:"Green Angy Duck",idle:["assets/gimmicks/angy-duck/green/idle-1.png","assets/gimmicks/angy-duck/green/idle-2.png"],hurt:"assets/gimmicks/angy-duck/green/hurt.png"},
    pink:{id:"pink",name:"Pink Angy Duck",idle:["assets/gimmicks/angy-duck/pink/idle-1.png","assets/gimmicks/angy-duck/pink/idle-2.png"],hurt:"assets/gimmicks/angy-duck/pink/hurt.png"},
    purple:{id:"purple",name:"Purple Angy Duck",idle:["assets/gimmicks/angy-duck/purple/idle-1.png","assets/gimmicks/angy-duck/purple/idle-2.png"],hurt:"assets/gimmicks/angy-duck/purple/hurt.png"}
  })
});
function applyGimmickEnemyVariant(enemyId,base,forcedId=""){
  const table=GIMMICK_ENEMY_VARIANTS[enemyId];if(!table)return base;
  const ids=Object.keys(table),id=table[forcedId]?forcedId:(ids[Math.floor(Math.random()*ids.length)]||ids[0]);
  const v=table[id];return {...base,name:v.name,idle:v.idle.slice(),hurt:v.hurt,gimmickVariant:id};
}

// One rare recolor per enemy family. The special family variant replaces any
// normal recolor at a charm-adjusted rate (base 1/500) and is guaranteed to befriend with any Lil Pon.
// Amethyst Mimic is intentionally different: it only reveals itself from the
// purple Mystery Chest so the chest keeps its surprise.
const SHINY_VARIANTS = Object.freeze({
  "porcupin": {
    id:"shiny", name:"Shiny Porcupin",
    idle:["assets/enemies/porcupin/shiny/idle-1.png","assets/enemies/porcupin/shiny/idle-2.png"],
    hurt:"assets/enemies/porcupin/shiny/hurt.png"
  },
  "cat-slime": {
    id:"rainbow", name:"Rainbow Slime Kitty",
    idle:[
      "assets/shinies/rainbow-slime-kitty-idle-1.webp",
      "assets/shinies/rainbow-slime-kitty-idle-2.webp",
      "assets/shinies/rainbow-slime-kitty-idle-3.webp",
      "assets/shinies/rainbow-slime-kitty-idle-2.webp"
    ],
    hurt:"assets/shinies/rainbow-slime-kitty-idle-1.webp"
  },
  "bee": {
    id:"sky", name:"Sky Bee",
    idle:["assets/shinies/sky-bee-idle-1.webp","assets/shinies/sky-bee-idle-2.webp"],
    hurt:"assets/shinies/sky-bee-hurt.webp"
  },
  "flower": {
    id:"midnight", name:"Midnight Bloom",
    idle:["assets/shinies/midnight-bloom-idle-1.webp","assets/shinies/midnight-bloom-idle-2.webp"],
    hurt:"assets/shinies/midnight-bloom-hurt.webp"
  },
  "mushroom-cat": {
    id:"cocoa", name:"Cocoa Mushroom Cat",
    idle:["assets/shinies/cocoa-mushroom-cat-idle-1.webp","assets/shinies/cocoa-mushroom-cat-idle-2.webp"],
    hurt:"assets/shinies/cocoa-mushroom-cat-hurt.webp"
  },
  "mimic": {
    id:"amethyst", name:"Amethyst Mimic",
    portrait:"assets/shinies/amethyst-mimic-idle-1.webp",
    idle:["assets/shinies/amethyst-mimic-idle-1.webp","assets/shinies/amethyst-mimic-idle-2.webp"],
    hurt:"assets/shinies/amethyst-mimic-closed.webp"
  },
  "cool-seagull": {
    id:"royal", name:"Royal Seagull",
    idle:["assets/shinies/royal-seagull-idle-1.webp","assets/shinies/royal-seagull-idle-2.webp"],
    hurt:"assets/shinies/royal-seagull-hurt.webp"
  },
  "sea-turtle": {
    id:"shiny", name:"Shiny Sea Turtle",
    idle:["assets/enemies/sea-turtle/base/Sea-turtle-shiny-idle-1.png","assets/enemies/sea-turtle/base/Sea-turtle-shiny-idle-2.png"],
    hurt:"assets/enemies/sea-turtle/base/Sea-turtle-shiny-hurt.png"
  },
  "catfish": {
    id:"bubblegum", name:"Bubblegum Catfish",
    idle:["assets/shinies/bubblegum-catfish-idle-1.webp","assets/shinies/bubblegum-catfish-idle-2.webp"],
    hurt:"assets/shinies/bubblegum-catfish-hurt.webp"
  },
  "vampire-squid": {
    id:"crimson", name:"Crimson Squid",
    idle:["assets/shinies/crimson-squid-idle-1.webp","assets/shinies/crimson-squid-idle-2.webp"],
    hurt:"assets/shinies/crimson-squid-hurt.webp"
  },
  "acorn-mouse": {
    id:"albino", name:"Albino Acorn Mouse",
    idle:["assets/shinies/albino-acorn-mouse-idle-1.webp","assets/shinies/albino-acorn-mouse-idle-2.webp"],
    hurt:"assets/shinies/albino-acorn-mouse-hurt.webp"
  },
  "seaunicorn": {
    id:"aurora", name:"Aurora Seaunicorn",
    idle:["assets/shinies/aurora-seaunicorn-idle-1.webp","assets/shinies/aurora-seaunicorn-idle-2.webp"],
    hurt:"assets/shinies/aurora-seaunicorn-hurt.webp"
  },
  "tree-squirrel": {
    id:"sakura", name:"Sakura Tree Squirrel",
    idle:["assets/shinies/sakura-tree-squirrel-idle-1.webp","assets/shinies/sakura-tree-squirrel-idle-2.webp"],
    hurt:"assets/shinies/sakura-tree-squirrel-hurt.webp"
  },
  "jellybun": {
    id:"rainbow", name:"Rainbow Jellybun",
    idle:["assets/shinies/rainbow-jellybun-idle-1.webp","assets/shinies/rainbow-jellybun-idle-2.webp"],
    hurt:"assets/shinies/rainbow-jellybun-hurt.webp"
  },
  "catterpillar": {id:"shiny",name:"Shiny Catterpillar",idle:["assets/enemies/catterpillar/base/shiny-idle-1.png","assets/enemies/catterpillar/base/shiny-idle-2.png"],hurt:"assets/enemies/catterpillar/base/shiny-hurt.png"},
  "sea-star": {id:"shiny",name:"Shiny Sea Star",idle:["assets/enemies/sea-star/base/shiny-idle-1.png","assets/enemies/sea-star/base/shiny-idle-2.png"],hurt:"assets/enemies/sea-star/base/shiny-hurt.png"},
  "star-mouse": {id:"shiny",name:"Shiny Star Mouse",idle:["assets/enemies/star-mouse/base/shiny-idle-1.png","assets/enemies/star-mouse/base/shiny-idle-2.png"],hurt:"assets/enemies/star-mouse/base/shiny-hurt.png"},
  "puff-fairy": {id:"shiny",name:"Shiny Puff Fairy",idle:["assets/enemies/puff-fairy/base/shiny-idle-1.png","assets/enemies/puff-fairy/base/shiny-idle-2.png"],hurt:"assets/enemies/puff-fairy/base/shiny-hurt.png"},
  "tulipa": {id:"shiny",name:"Shiny Tulipa",idle:["assets/enemies/tulipa/base/shiny-idle-1.png","assets/enemies/tulipa/base/shiny-idle-2.png"],hurt:"assets/enemies/tulipa/base/shiny-hurt.png"},
  "snoud": {id:"shiny",name:"Shiny Snoud",idle:["assets/enemies/snoud/base/shiny-idle-1.png","assets/enemies/snoud/base/shiny-idle-2.png"],hurt:"assets/enemies/snoud/base/shiny-hurt.png"},
  "cloud-bunny": {id:"shiny",name:"Shiny Cloud Bunny",idle:["assets/enemies/cloud-bunny/base/shiny-idle-1.png","assets/enemies/cloud-bunny/base/shiny-idle-2.png"],hurt:"assets/enemies/cloud-bunny/base/shiny-hurt.png"},
  "lunar-moth": {id:"shiny",name:"Shiny Lunar Moth",idle:["assets/enemies/lunar-moth/base/shiny-idle-1.png","assets/enemies/lunar-moth/base/shiny-idle-2.png"],hurt:"assets/enemies/lunar-moth/base/shiny-hurt.png"},
  "aries": {id:"shiny",name:"Shiny Aries",idle:["assets/bosses/aries/base/shiny-idle-1.png","assets/bosses/aries/base/shiny-idle-2.png"],hurt:"assets/bosses/aries/base/shiny-hurt.png"},
  "cherub-duck": {id:"shiny",name:"Shiny Cherub Duck",idle:["assets/bosses/cherub-duck/base/shiny-idle-1.png","assets/bosses/cherub-duck/base/shiny-idle-2.png"],hurt:"assets/bosses/cherub-duck/base/shiny-hurt.png"},
  "apple-baby": {id:"shiny",name:"Shiny Apple Baby",idle:["assets/enemies/apple-baby/base/shiny-idle-1.webp","assets/enemies/apple-baby/base/shiny-idle-2.webp"],hurt:"assets/enemies/apple-baby/base/shiny-hurt.webp"},
  "gummy-worm": {id:"shiny",name:"Shiny Gummy Worm",idle:["assets/enemies/gummy-worm/base/shiny-idle-1.webp","assets/enemies/gummy-worm/base/shiny-idle-2.webp"],hurt:"assets/enemies/gummy-worm/base/shiny-hurt.webp"},
  "pudding-pig": {id:"shiny",name:"Shiny Pudding Pig",idle:["assets/enemies/pudding-pig/base/shiny-idle-1.webp","assets/enemies/pudding-pig/base/shiny-idle-2.webp"],hurt:"assets/enemies/pudding-pig/base/shiny-hurt.webp"},
  "gingerlolly": {id:"shiny",name:"Shiny Gingerlolly",idle:["assets/enemies/gingerlolly/base/shiny-idle-1.webp","assets/enemies/gingerlolly/base/shiny-idle-2.webp"],hurt:"assets/enemies/gingerlolly/base/shiny-hurt.webp"},
  "candycane-deer": {id:"shiny",name:"Shiny Candycane Deer",idle:["assets/enemies/candycane-deer/base/shiny-idle-1.webp","assets/enemies/candycane-deer/base/shiny-idle-2.webp"],hurt:"assets/enemies/candycane-deer/base/shiny-hurt.webp"},
  "gummy-shark": {id:"shiny",name:"Shiny Gummy Shark",idle:["assets/bosses/gummy-shark/base/shiny-idle-1.webp","assets/bosses/gummy-shark/base/shiny-idle-2.webp"],hurt:"assets/bosses/gummy-shark/base/shiny-hurt.webp"},
  "cream-fox": {id:"shiny",name:"Shiny Cream Fox",idle:["assets/bosses/cream-fox/base/shiny-idle-1.webp","assets/bosses/cream-fox/base/shiny-idle-2.webp"],hurt:"assets/bosses/cream-fox/base/shiny-hurt.webp"},
  "rotten-egg": {id:"shiny",name:"Shiny Rotten Egg",idle:["assets/gimmicks/rotten-egg/shiny/idle-1.png","assets/gimmicks/rotten-egg/shiny/idle-2.png"],hurt:"assets/gimmicks/rotten-egg/shiny/hurt.png"},
  "lucky-cat": {id:"shiny",name:"Shiny Lucky Cat",idle:["assets/gimmicks/lucky-cat/shiny/idle-1.png","assets/gimmicks/lucky-cat/shiny/idle-2.png"],hurt:"assets/gimmicks/lucky-cat/shiny/hurt.png"},
  "angy-duck": {id:"shiny",name:"Shiny Angy Duck",idle:["assets/gimmicks/angy-duck/shiny/idle-1.png","assets/gimmicks/angy-duck/shiny/idle-2.png"],hurt:"assets/gimmicks/angy-duck/shiny/hurt.png"}
});

const ENDLESS_NORMAL_ENEMIES = Object.freeze([
  "cat-slime","bee","flower","acorn-mouse","catterpillar",
  "cool-seagull","sea-turtle","catfish","seaunicorn","sea-star",
  "apple-baby","gummy-worm","pudding-pig","gingerlolly","candycane-deer",
  "star-mouse","puff-fairy","tulipa","snoud","cloud-bunny","lunar-moth","porcupin"
]);
const ENDLESS_BOSSES = Object.freeze(["mushroom-cat","tree-squirrel","scarrie","vampire-squid","jellybun","bottle-fairy","gummy-shark","cream-fox","aries","cherub-duck","three-mice-trench-coat","stoplight-owl","lil-king"]);
const ENDLESS_BACKGROUNDS = Object.freeze(
  Object.values(AREA_CONFIG).flatMap(area=>area.backgrounds)
);

const BUDDY_PONS = Object.freeze([
  {
    id:"buddy-pon", name:"Lil Pon", image:"../assets/items/buddy-pons/buddy-pon.webp",
    price:50, normalRate:.50, bossRate:0, className:""
  },
  {
    id:"super-buddy-pon", name:"Super Lil Pon", image:"../assets/items/buddy-pons/super-buddy-pon.webp",
    price:100, normalRate:.75, bossRate:.35, className:"super"
  },
  {
    id:"boss-buddy-pon", name:"Boss Lil Pon", image:"../assets/items/buddy-pons/boss-buddy-pon.webp",
    price:175, normalRate:1, bossRate:.70, className:"boss"
  }
]);

const BUDDY_SKILLS = Object.freeze({
  "bee":{name:"Honey Help",description:"Restore 15% of your OC's max HP.",type:"heal",healPercent:.15},
  "cat-slime":{name:"Goo Splash",description:"Light damage and lowers enemy Attack for 2 turns.",type:"damage-attack-down",multiplier:.65,attackDown:.20,duration:2},
  "flower":{name:"Petal Guard",description:"Reduce damage taken by 30% for 2 enemy turns.",type:"guard",damageReduction:.30,duration:2},
  "acorn-mouse":{name:"Acorn Toss",description:"Moderate damage with a 25% critical-hit chance.",type:"crit-damage",multiplier:.95,critChance:.25,critMultiplier:1.7},
  "cool-seagull":{name:"Wing Gust",description:"Light damage and makes enemy attacks 25% more likely to miss for 2 turns.",type:"damage-accuracy-down",multiplier:.65,missChance:.25,duration:2},
  "sea-turtle":{name:"Shell Shield",description:"Cut the next damaging enemy hit in half.",type:"next-hit-shield",damageReduction:.50},
  "catfish":{name:"Bubble Burst",description:"Moderate damage with a 30% chance to stun for 1 turn.",type:"damage-stun",multiplier:.95,stunChance:.30},
  "seaunicorn":{name:"Sea Sparkle",description:"Heal 10% HP and raise Attack by 15% for 2 turns.",type:"heal-attack-up",healPercent:.10,attackBoost:.15,duration:2},
  "mushroom-cat":{name:"Spore Puff",description:"Moderate damage and lowers enemy Defense for 2 turns.",type:"damage-defense-down",multiplier:.90,defenseDown:.20,duration:2,boss:true},
  "tree-squirrel":{name:"Forest Feast",description:"Heal 20% HP and reduce damage taken by 20% for 2 turns.",type:"heal-guard",healPercent:.20,damageReduction:.20,duration:2,boss:true},
  "vampire-squid":{name:"Life Drain",description:"Deal 1.2× damage and heal for 50% of damage dealt.",type:"life-drain",multiplier:1.20,drainPercent:.50,boss:true},
  "jellybun":{name:"Jelly Bounce",description:"Deal 1.4× damage with a 30% chance to weaken the enemy's next attack.",type:"damage-weaken",multiplier:1.40,weakenChance:.30,nextAttackMultiplier:.65,boss:true},
  "catterpillar":{name:"Leaf Nibble",description:"Moderate damage with a 25% critical-hit chance.",type:"crit-damage",multiplier:.90,critChance:.25,critMultiplier:1.7},
  "sea-star":{name:"Star Splash",description:"Light damage and makes enemy attacks 25% more likely to miss for 2 turns.",type:"damage-accuracy-down",multiplier:.68,missChance:.25,duration:2},
  "star-mouse":{name:"Star Toss",description:"Moderate damage with a 30% chance to stun for 1 turn.",type:"damage-stun",multiplier:.92,stunChance:.30},
  "puff-fairy":{name:"Fairy Fluff",description:"Restore 15% of your OC's max HP.",type:"heal",healPercent:.15},
  "tulipa":{name:"Petal Veil",description:"Reduce damage taken by 30% for 2 enemy turns.",type:"guard",damageReduction:.30,duration:2},
  "snoud":{name:"Cloud Cover",description:"Cut the next damaging enemy hit in half.",type:"next-hit-shield",damageReduction:.50},
  "cloud-bunny":{name:"Bunny Burst",description:"Moderate damage and lowers enemy Defense for 2 turns.",type:"damage-defense-down",multiplier:.92,defenseDown:.20,duration:2},
  "lunar-moth":{name:"Moon Dust",description:"Heal 10% HP and raise Attack by 15% for 2 turns.",type:"heal-attack-up",healPercent:.10,attackBoost:.15,duration:2},
  "aries":{name:"Ram Rush",description:"Deal 1.4× damage with a 30% chance to weaken the enemy's next attack.",type:"damage-weaken",multiplier:1.40,weakenChance:.30,nextAttackMultiplier:.65,boss:true},
  "cherub-duck":{name:"Cherub Blessing",description:"Heal 20% HP and reduce damage taken by 20% for 2 turns.",type:"heal-guard",healPercent:.20,damageReduction:.20,duration:2,boss:true},
  "apple-baby":{name:"Apple Snack",description:"Restore 15% of your OC's max HP.",type:"heal",healPercent:.15},
  "gummy-worm":{name:"Taffy Trip",description:"Light damage and lowers enemy Attack for 2 turns.",type:"damage-attack-down",multiplier:.68,attackDown:.20,duration:2},
  "pudding-pig":{name:"Pudding Guard",description:"Reduce damage taken by 30% for 2 enemy turns.",type:"guard",damageReduction:.30,duration:2},
  "gingerlolly":{name:"Lolly Bonk",description:"Moderate damage with a 30% chance to stun for 1 turn.",type:"damage-stun",multiplier:.95,stunChance:.30},
  "candycane-deer":{name:"Peppermint Dash",description:"Heal 10% HP and raise Attack by 15% for 2 turns.",type:"heal-attack-up",healPercent:.10,attackBoost:.15,duration:2},
  "gummy-shark":{name:"Gummy Chomp",description:"Deal 1.4× damage with a 30% chance to weaken the enemy's next attack.",type:"damage-weaken",multiplier:1.40,weakenChance:.30,nextAttackMultiplier:.65,boss:true},
  "cream-fox":{name:"Creamy Comfort",description:"Heal 20% HP and reduce damage taken by 20% for 2 turns.",type:"heal-guard",healPercent:.20,damageReduction:.20,duration:2,boss:true},
  "mimic":{name:"Jackpot Bite",description:"A gamble: strong damage, a heal, or bonus Pink Coins!",type:"jackpot",boss:false},
  "rotten-egg":{name:"Eggshell Bonk",description:"A sturdy little bonk with a chance to crit.",type:"crit-damage",multiplier:.90,critChance:.25,critMultiplier:1.7},
  "lucky-cat":{name:"Lucky Paw",description:"A lucky gamble: damage, healing, or bonus Pink Coins!",type:"jackpot",boss:false},
  "angy-duck":{name:"Loud Quack",description:"A loud quack that deals solid damage.",type:"crit-damage",multiplier:1.0,critChance:.15,critMultiplier:1.5}
});

function buddySkillForEnemyId(enemyId){
  return BUDDY_SKILLS[String(enemyId||"")] || null;
}

function buddyGenderSymbol(gender){
  if(gender==="female") return "♀";
  if(gender==="male") return "♂";
  if(gender==="nonbinary") return "✦";
  return "";
}

function buddySlotPersonalization(characterId,slotIndex){
  ensureBuddySave();
  return hubSave.buddies?.personalizationByCharacter?.[characterId]?.[slotIndex] || null;
}

function buddyRecordForSlot(slotIndex=0){
  ensureBuddySave();
  const safeSlot=Math.max(0,Math.min(5,Math.floor(Number(slotIndex)||0)));
  const slots=hubSave.buddies?.equippedByCharacter?.[activeCharacterId];
  const key=Array.isArray(slots) && typeof slots[safeSlot]==="string" ? slots[safeSlot] : null;
  const base=key ? hubSave.buddies?.collection?.[key] || null : null;
  if(!base) return null;
  const personal=buddySlotPersonalization(activeCharacterId,safeSlot);
  const nickname=String(personal?.nickname||"").trim();
  const catalog=BUDDY_CATALOG_BY_KEY.get(key);
  const idleFrames=Array.isArray(base.idle) && base.idle.length
    ? base.idle
    : (Array.isArray(catalog?.idle) && catalog.idle.length ? catalog.idle : [base.image].filter(Boolean));
  return {
    ...catalog,
    ...base,
    idle:idleFrames,
    speciesName:base.name,
    name:nickname || base.name,
    nickname,
    gender:String(personal?.gender||""),
    genderSymbol:buddyGenderSymbol(personal?.gender),
    slotIndex:safeSlot
  };
}

function battleBuddySlotRecords(){
  return Array.from({length:6},(_,slotIndex)=>buddyRecordForSlot(slotIndex));
}

function firstAssignedBattleBuddySlot(){
  const records=battleBuddySlotRecords();
  const index=records.findIndex(Boolean);
  return index>=0?index:0;
}

function activeBattleBuddyRecord(){
  return buddyRecordForSlot(activeBattleBuddySlot);
}

function mainBuddyRecord(){
  return buddyRecordForSlot(0);
}


function catalogEntry(enemyId, variantId, variant, boss=false, shiny=false) {
  const idleFrames=Array.isArray(variant?.idle) && variant.idle.length
    ? variant.idle.map(String)
    : (Array.isArray(ENEMIES[enemyId]?.idle) ? ENEMIES[enemyId].idle.map(String) : []);
  return {
    key:`${enemyId}:${shiny ? "shiny" : variantId}`,
    enemyId,
    variantId:shiny ? "shiny" : variantId,
    name:String(variant?.name || ENEMIES[enemyId]?.name || "Lil Guy"),
    image:String(variant?.portrait || idleFrames[0] || ""),
    idle:idleFrames,
    boss:Boolean(boss),
    shiny:Boolean(shiny)
  };
}

function buildBuddyCatalog() {
  const entries=[];
  const addTable=(enemyId,table,boss=false)=>{
    Object.values(table).forEach(v=>entries.push(catalogEntry(enemyId,v.id,v,boss,false)));
    const shiny=SHINY_VARIANTS[enemyId];
    if(shiny) entries.push(catalogEntry(enemyId,"shiny",shiny,boss,true));
  };
  addTable("porcupin",PORCUPIN_VARIANTS,false);
  addTable("cat-slime",CAT_SLIME_VARIANTS,false);
  addTable("bee",BEE_VARIANTS,false);
  addTable("flower",FLOWER_VARIANTS,false);
  addTable("acorn-mouse",ACORN_MOUSE_VARIANTS,false);
  addTable("mushroom-cat",MUSHROOM_CAT_VARIANTS,true);
  addTable("tree-squirrel",TREE_SQUIRREL_VARIANTS,true);
  entries.push(catalogEntry("mimic","base",ENEMIES.mimic,false,false));
  entries.push(catalogEntry("mimic","lucky",{
    id:"lucky",name:"Lucky Mimic",
    portrait:"assets/enemies/mimic/lucky/open.webp",
    idle:["assets/enemies/mimic/lucky/idle-1.webp","assets/enemies/mimic/lucky/idle-2.webp"],
    hurt:"assets/enemies/mimic/lucky/closed.webp"
  },false,false));
  entries.push(catalogEntry("mimic","healthy",{
    id:"healthy",name:"Healthy Mimic",
    portrait:"assets/enemies/mimic/healthy/open.webp",
    idle:["assets/enemies/mimic/healthy/idle-1.webp","assets/enemies/mimic/healthy/idle-2.webp"],
    hurt:"assets/enemies/mimic/healthy/closed.webp"
  },false,false));
  const mimicShiny=SHINY_VARIANTS.mimic;
  if(mimicShiny) entries.push(catalogEntry("mimic","shiny",mimicShiny,false,true));
  addTable("cool-seagull",SEAGULL_VARIANTS,false);
  addTable("sea-turtle",TURTLE_VARIANTS,false);
  addTable("catfish",CATFISH_VARIANTS,false);
  addTable("seaunicorn",SEAUNICORN_VARIANTS,false);
  addTable("vampire-squid",SQUID_VARIANTS,true);
  addTable("jellybun",JELLYBUN_VARIANTS,true);
  addTable("apple-baby",APPLE_BABY_VARIANTS,false);
  addTable("gummy-worm",GUMMY_WORM_VARIANTS,false);
  addTable("pudding-pig",PUDDING_PIG_VARIANTS,false);
  addTable("gingerlolly",GINGERLOLLY_VARIANTS,false);
  addTable("candycane-deer",CANDYCANE_DEER_VARIANTS,false);
  addTable("gummy-shark",GUMMY_SHARK_VARIANTS,true);
  addTable("cream-fox",CREAM_FOX_VARIANTS,true);
  addTable("catterpillar",CATTERPILLAR_VARIANTS,false);
  addTable("sea-star",SEA_STAR_VARIANTS,false);
  addTable("star-mouse",STAR_MOUSE_VARIANTS,false);
  addTable("puff-fairy",PUFF_FAIRY_VARIANTS,false);
  addTable("tulipa",TULIPA_VARIANTS,false);
  addTable("snoud",SNOUD_VARIANTS,false);
  addTable("cloud-bunny",CLOUD_BUNNY_VARIANTS,false);
  addTable("lunar-moth",LUNAR_MOTH_VARIANTS,false);
  addTable("aries",ARIES_VARIANTS,true);
  addTable("cherub-duck",CHERUB_DUCK_VARIANTS,true);
  addTable("rotten-egg",GIMMICK_ENEMY_VARIANTS["rotten-egg"],false);
  addTable("lucky-cat",GIMMICK_ENEMY_VARIANTS["lucky-cat"],false);
  addTable("angy-duck",GIMMICK_ENEMY_VARIANTS["angy-duck"],false);
  return entries;
}

// Mutable catalog: new enemy families register here for egg hatch and collections.
const BUDDY_CATALOG = buildBuddyCatalog();
const BUDDY_CATALOG_BY_KEY = new Map(BUDDY_CATALOG.map(entry=>[entry.key,entry]));

function normalizeBuddyCollection(raw) {
  const collection={};
  if(raw && typeof raw==="object" && !Array.isArray(raw)) {
    for(const [fallbackKey,value] of Object.entries(raw)) {
      if(!value || typeof value!=="object" || Array.isArray(value)) continue;
      const key=String(value.key || fallbackKey || "").trim();
      if(!key) continue;

      let normalized={
        key,
        enemyId:String(value.enemyId || ""),
        variantId:String(value.variantId || "base"),
        name:String(value.name || "Lil Guy"),
        image:String(value.image || ""),
        idle:Array.isArray(value.idle) ? value.idle.map(String).filter(Boolean) : [],
        shiny:Boolean(value.shiny),
        boss:Boolean(value.boss),
        quantity:Math.max(1,Math.floor(Number(value.quantity)||1)),
        capturedAt:Math.max(0,Number(value.capturedAt)||0)
      };

      // v24.284: Mimic key is the source of truth.
      // Old saves can contain key=mimic:base with variantId/name/image left
      // behind from Lucky/Healthy. Never let stale metadata redefine the key.
      if(key.startsWith("mimic:")){
        const catalog=BUDDY_CATALOG_BY_KEY.get(key);
        if(catalog){
          normalized={
            ...normalized,
            enemyId:"mimic",
            variantId:catalog.variantId,
            name:catalog.name,
            image:catalog.image,
            idle:Array.isArray(catalog.idle)?catalog.idle.slice():[],
            shiny:Boolean(catalog.shiny),
            boss:Boolean(catalog.boss)
          };
        }
      }

      collection[key]=normalized;
    }
  }
  return collection;
}

function ensureBuddySave() {
  if(!hubSave.buddies || typeof hubSave.buddies!=="object" || Array.isArray(hubSave.buddies)) hubSave.buddies={};
  hubSave.buddies.collection=normalizeBuddyCollection(hubSave.buddies.collection);
  if(!hubSave.buddies.equippedByCharacter || typeof hubSave.buddies.equippedByCharacter!=="object") hubSave.buddies.equippedByCharacter={};
  if(!hubSave.buddies.personalizationByCharacter || typeof hubSave.buddies.personalizationByCharacter!=="object") hubSave.buddies.personalizationByCharacter={};
  ["peep","miko","io","miho","annika","shiyu","angel"].forEach(id=>{
    const slots=Array.isArray(hubSave.buddies.equippedByCharacter[id])?hubSave.buddies.equippedByCharacter[id]:[];
    hubSave.buddies.equippedByCharacter[id]=Array.from({length:6},(_,i)=>typeof slots[i]==="string"?slots[i]:null);
    const personal=Array.isArray(hubSave.buddies.personalizationByCharacter[id])?hubSave.buddies.personalizationByCharacter[id]:[];
    hubSave.buddies.personalizationByCharacter[id]=Array.from({length:6},(_,i)=>{
      if(!hubSave.buddies.equippedByCharacter[id][i]) return null;
      const value=personal[i];
      if(!value || typeof value!=="object" || Array.isArray(value)) return null;
      const nickname=String(value.nickname||"").trim().slice(0,20);
      const gender=["female","male","nonbinary"].includes(value.gender)?value.gender:"";
      return nickname||gender?{nickname,gender}:null;
    });
  });
}

function buddyOwnedQuantity(key) {
  return Math.max(0,Number(hubSave.buddies?.collection?.[key]?.quantity)||0);
}

function enemyVariantId(enemy) {
  if(!enemy) return "base";
  if(enemy.shiny) return "shiny";
  if(enemy.id==="mimic" && enemy.mimicChestStyle) return String(enemy.mimicChestStyle)==="regular" ? "base" : String(enemy.mimicChestStyle);
  return String(
    enemy.catSlimeVariant || enemy.beeVariant || enemy.flowerVariant || enemy.acornMouseVariant || enemy.mushroomVariant || enemy.treeSquirrelVariant || enemy.oceanVariant || enemy.seaunicornVariant || enemy.jellybunVariant ||
    enemy.gimmickVariant || enemy.v313Variant || enemy.porcupinVariant || enemy.catterpillarVariant || enemy.seaStarVariant || enemy.appleBabyVariant || enemy.gummyWormVariant || enemy.puddingPigVariant || enemy.gingerlollyVariant || enemy.candycaneDeerVariant || enemy.gummySharkVariant || enemy.creamFoxVariant || enemy.starMouseVariant || enemy.puffFairyVariant || enemy.tulipaVariant || enemy.snoudVariant || enemy.cloudBunnyVariant || enemy.lunarMothVariant || enemy.ariesVariant || enemy.cherubDuckVariant || enemy.plushbunVariant || "base"
  );
}

const SPECIAL_VARIANT_POWERS = Object.freeze({
  "acorn-mouse:purple": {name:"Nutty Defense!",type:"guard",chance:.30,maxUses:2,guardMultiplier:.70,guardHits:1},
  "catterpillar:orange": {name:"Sticky Silk!",type:"hero-next-attack-down",chance:.30,maxUses:2,heroAttackMultiplier:.75},
  "tree-squirrel:peach": {name:"Acorn Barrage!",type:"attack-stun",chance:.28,maxUses:2,multiplier:1.25,stunChance:.20},
  "seaunicorn:dark": {name:"Bubble Veil!",type:"guard",chance:.30,maxUses:2,guardMultiplier:.80,guardHits:2},
  "sea-star:blue": {name:"Regrow!",type:"heal",chance:.32,maxUses:2,healPercent:.25},
  "jellybun:grey": {name:"Jelly Shock!",type:"attack-paralyze",chance:.28,maxUses:2,multiplier:1.25,paralyzeChance:.35,paralyzeMoves:5,paralyzeFailChance:.10},
  "vampire-squid:coral": {name:"Deep Drain!",type:"deep-drain",chance:.30,maxUses:2,multiplier:1.10,drainPercent:.75},
  "apple-baby:green": {name:"Juicy Snack!",type:"heal",chance:.32,maxUses:2,healPercent:.25},
  "gummy-worm:red": {name:"Sticky Gummy!",type:"hero-next-attack-down",chance:.30,maxUses:2,heroAttackMultiplier:.75},
  "pudding-pig:choco": {name:"Pudding Splash!",type:"hero-attack-down",chance:.30,maxUses:2,heroAttackMultiplier:.80,duration:2},
  "gingerlolly:purple": {name:"Double Bonk!",type:"double-hit",chance:.24,maxUses:1,multiplier:1.25,hits:2},
  "candycane-deer:yellow": {name:"Candy Headbutt!",type:"recoil-attack",chance:.28,maxUses:2,multiplier:1.50,recoilPercent:.10},
  "gummy-shark:orange": {name:"Mega Gummy Chomp!",type:"attack-hero-next-down",chance:.28,maxUses:2,multiplier:1.30,heroAttackMultiplier:.80},
  "cream-fox:strawberry": {name:"Whipped Cream!",type:"heal-guard",chance:.30,maxUses:2,healPercent:.18,guardMultiplier:.80,guardHits:1},
  "star-mouse:purple": {name:"Wish Upon a Star!",type:"heal-next-attack-up",chance:.30,maxUses:2,healPercent:.12,attackMultiplier:1.15},
  "puff-fairy:purple": {name:"Fairy Fluff!",type:"hero-stun-chance",chance:.32,maxUses:2,statusChance:.25,stunTurns:1},
  "tulipa:dark": {name:"Photosynthesis!",type:"heal-guard",chance:.30,maxUses:2,healPercent:.15,guardMultiplier:.85,guardHits:1},
  "snoud:grey": {name:"Cold Snap!",type:"hero-sleep-chance",chance:.32,maxUses:2,statusChance:.25,sleepTurns:2},
  "cloud-bunny:black": {name:"Cloud Dodge!",type:"dodge",chance:.30,maxUses:99,cooldownTurns:3},
  "lunar-moth:golden": {name:"Moon Shine!",type:"heal-attack-up",chance:.30,maxUses:2,healPercent:.10,attackMultiplier:1.15,duration:2},
  "aries:galaxy": {name:"Ram Rush!",type:"attack-hero-next-down",chance:.28,maxUses:2,multiplier:1.30,heroAttackMultiplier:.80},
  "cherub-duck:aqua": {name:"Cherub Blessing!",type:"heal-guard",chance:.30,maxUses:2,healPercent:.18,guardMultiplier:.80,guardHits:1},
  "angy-duck:base": {name:"Got Beef?!",type:"attack-up",chance:.32,maxUses:1,attackMultiplier:1.50,duration:2},
  "angy-duck:blue": {name:"Got Beef?!",type:"attack-up",chance:.32,maxUses:1,attackMultiplier:1.50,duration:2},
  "angy-duck:green": {name:"Got Beef?!",type:"attack-up",chance:.32,maxUses:1,attackMultiplier:1.50,duration:2},
  "angy-duck:pink": {name:"Got Beef?!",type:"attack-up",chance:.32,maxUses:1,attackMultiplier:1.50,duration:2},
  "angy-duck:purple": {name:"Got Beef?!",type:"attack-up",chance:.32,maxUses:1,attackMultiplier:1.50,duration:2},
  "angy-duck:shiny": {name:"Got Beef?!",type:"attack-up",chance:.32,maxUses:1,attackMultiplier:1.50,duration:2}
});

function configureEnemySpecialVariant(enemy){
  if(!enemy || (enemy.shiny && enemy.id!=="angy-duck")) return enemy;
  const key=`${String(enemy.id||"")}:${enemyVariantId(enemy)}`;
  const power=SPECIAL_VARIANT_POWERS[key];
  if(!power) return enemy;
  enemy.variantSpecial={...power};
  enemy.variantSpecialUses=0;
  enemy.variantGuardHitsRemaining=0;
  enemy.variantGuardMultiplier=1;
  enemy.variantGuardName="";
  enemy.variantDodgeReady=false;
  enemy.variantDodgeCooldown=0;
  enemy.variantNextAttackMultiplier=1;
  enemy.variantAttackBoostTurns=0;
  enemy.variantAttackBoostMultiplier=1;
  if(key==="vampire-squid:coral") enemy.lifeDrain=false;
  if(power.type==="heal"){
    enemy.healPercent=Number(power.healPercent)||0;
    enemy.maxHeals=Number(power.maxUses)||2;
    enemy.healChance=Number(power.chance)||.30;
    enemy.healMoveName=power.name;
  }
  return enemy;
}

function heroSkillDealsDamage(skill){
  if(!skill) return false;
  return !["heal","full-heal","buff","full-heal-buff","self-damage-buff","stun"].includes(String(skill.type||""));
}

async function blockHeroAttackFromSpecialStatus(skill){
  if(!heroSkillDealsDamage(skill)) return false;
  if(Number(skillState.heroSleepTurns||0)>0){
    setMessage(`${heroDisplayName()} is asleep and can't attack!${skillState.heroSleepTurns>0?` ${skillState.heroSleepTurns} sleepy turn${skillState.heroSleepTurns===1?"":"s"} left.`:""}`);
    await sleep(650); return true;
  }
  if(Number(skillState.heroStunTurns||0)>0){
    setMessage(`${heroDisplayName()} is stunned and can't attack!`);
    await sleep(650); return true;
  }
  if(Number(skillState.heroParalysisMoves||0)>0){
    const failChance=Math.max(0,Math.min(1,Number(skillState.heroParalysisFailChance)||.10));
    if(Math.random()<failChance){
      setMessage(`${heroDisplayName()} is paralyzed and couldn't attack!${skillState.heroParalysisMoves>0?` ${skillState.heroParalysisMoves} affected move${skillState.heroParalysisMoves===1?"":"s"} left.`:""}`);
      await sleep(650);
      return true;
    }
  }
  return false;
}

function beginHeroSpecialAttackScale(skill){
  specialHeroAttackScale=1;
  if(!heroSkillDealsDamage(skill)) return 1;
  let mult=1;
  if(Number(skillState.heroAttackDownTurns||0)>0){
    mult*=Math.max(.10,Number(skillState.heroAttackDownMultiplier)||1);
  }
  if(Number(skillState.heroNextAttackMultiplier||1)<1){
    mult*=Math.max(.10,Number(skillState.heroNextAttackMultiplier)||1);
    skillState.heroNextAttackMultiplier=1;
  }
  specialHeroAttackScale=Math.max(.10,mult);
  return specialHeroAttackScale;
}

function clearHeroSpecialAttackScale(){ specialHeroAttackScale=1; }

function applyEnemyVariantGuard(power){
  currentEnemy.variantGuardHitsRemaining=Math.max(1,Number(power.guardHits)||1);
  currentEnemy.variantGuardMultiplier=Math.max(.10,Math.min(1,Number(power.guardMultiplier)||1));
  currentEnemy.variantGuardName=power.name||"Special Guard";
}

function healCurrentEnemyPercent(percent){
  if(!currentEnemy || currentEnemy.hpNow<=0) return 0;
  const before=currentEnemy.hpNow;
  const amount=Math.max(1,Math.round(currentEnemy.maxHp*Math.max(0,Number(percent)||0)));
  currentEnemy.hpNow=Math.min(currentEnemy.maxHp,currentEnemy.hpNow+amount);
  const healed=Math.max(0,currentEnemy.hpNow-before);
  if(healed>0){ showFloat(`+${healed}`,"heal","enemy"); renderEnemyHp(); }
  return healed;
}

async function tryEnemySpecialVariantMove(){
  const power=currentEnemy?.variantSpecial;
  if(!currentEnemy || !power) return false;
  if(power.type==="heal") return false; // handled by the existing healer-variant branch above
  if(Number(currentEnemy.variantSpecialUses||0)>=Number(power.maxUses||2)) return false;
  if(power.type==="dodge" && (currentEnemy.variantDodgeReady || Number(currentEnemy.variantDodgeCooldown||0)>0)) return false;
  if(power.type==="guard" && Number(currentEnemy.variantGuardHitsRemaining||0)>0) return false;
  if(power.type==="heal" && currentEnemy.hpNow>=currentEnemy.maxHp) return false;
  if(power.type==="heal-guard" && currentEnemy.hpNow>=currentEnemy.maxHp && Number(currentEnemy.variantGuardHitsRemaining||0)>0) return false;
  if(Math.random()>=Math.max(0,Math.min(1,Number(power.chance)||.30))) return false;

  currentEnemy.variantSpecialUses=Math.max(0,Number(currentEnemy.variantSpecialUses)||0)+1;
  const refs=activeEnemyUi();
  const pop=async()=>{ refs.sprite?.classList.add("attack-pop"); await sleep(300); refs.sprite?.classList.remove("attack-pop"); };

  if(power.type==="guard"){
    applyEnemyVariantGuard(power);
    setMessage(`${currentEnemy.name} used ${power.name} The next ${Number(power.guardHits)||1} hit${Number(power.guardHits)===1?"":"s"} deal less damage.`);
    await pop(); return true;
  }
  if(power.type==="hero-next-attack-down"){
    skillState.heroNextAttackMultiplier=Math.min(Number(skillState.heroNextAttackMultiplier||1),Number(power.heroAttackMultiplier)||.75);
    setMessage(`${currentEnemy.name} used ${power.name} ${heroDisplayName()}'s next attack is weakened!`);
    await pop(); return true;
  }
  if(power.type==="attack-stun"){
    const dealt=await performEnemyAttack(Number(power.multiplier)||1.25,`${currentEnemy.name} used ${power.name}`);
    if(currentRun?.hp>0 && dealt>0 && Math.random()<Number(power.stunChance||.20)){
      skillState.heroStunTurns=Math.max(Number(skillState.heroStunTurns||0),1);
      setMessage(`${power.name} stunned ${heroDisplayName()}!`); await sleep(420);
    }
    return true;
  }
  if(power.type==="attack-paralyze"){
    const dealt=await performEnemyAttack(Number(power.multiplier)||1.25,`${currentEnemy.name} used ${power.name}`);
    if(currentRun?.hp>0 && dealt>0 && Math.random()<Number(power.paralyzeChance||.35)){
      skillState.heroParalysisMoves=Math.max(Number(skillState.heroParalysisMoves||0),Number(power.paralyzeMoves)||5);
      skillState.heroParalysisFailChance=Number(power.paralyzeFailChance)||.10;
      setMessage(`${heroDisplayName()} was paralyzed! For the next ${skillState.heroParalysisMoves} attacks, there is a 10% chance they can't attack.`);
      await sleep(500);
    }
    return true;
  }
  if(power.type==="deep-drain"){
    await performEnemyAttack(Number(power.multiplier)||1.10,`${currentEnemy.name} used ${power.name}`,Number(power.drainPercent)||.75);
    return true;
  }
  if(power.type==="hero-attack-down"){
    skillState.heroAttackDownTurns=Math.max(Number(skillState.heroAttackDownTurns||0),Number(power.duration)||2);
    skillState.heroAttackDownMultiplier=Math.min(Number(skillState.heroAttackDownMultiplier||1),Number(power.heroAttackMultiplier)||.80);
    setMessage(`${currentEnemy.name} used ${power.name} ${heroDisplayName()}'s Attack fell by ${Math.round((1-(Number(power.heroAttackMultiplier)||.80))*100)}% for ${Number(power.duration)||2} attacks.`);
    await pop(); return true;
  }
  if(power.type==="double-hit"){
    setMessage(`${currentEnemy.name} used ${power.name}`); await sleep(220);
    const hits=Math.max(2,Number(power.hits)||2);
    for(let i=0;i<hits && currentRun?.hp>0;i++){
      await performEnemyAttack(Number(power.multiplier)||1.25,`${power.name} Hit ${i+1}!`);
      if(i<hits-1 && currentRun?.hp>0) await sleep(120);
    }
    return true;
  }
  if(power.type==="recoil-attack"){
    await performEnemyAttack(Number(power.multiplier)||1.50,`${currentEnemy.name} used ${power.name}`);
    if(currentEnemy?.hpNow>1){
      const recoil=Math.max(1,Math.round(currentEnemy.maxHp*Math.max(0,Number(power.recoilPercent)||.10)));
      const before=currentEnemy.hpNow;
      currentEnemy.hpNow=Math.max(1,currentEnemy.hpNow-recoil);
      const lost=Math.max(0,before-currentEnemy.hpNow);
      if(lost>0){ showFloat(`-${lost}`,"damage","enemy"); renderEnemyHp(); setMessage(`${power.name} hit hard, but ${currentEnemy.name} took ${lost} recoil damage!`); await sleep(420); }
    }
    return true;
  }
  if(power.type==="attack-hero-next-down"){
    const dealt=await performEnemyAttack(Number(power.multiplier)||1.30,`${currentEnemy.name} used ${power.name}`);
    if(currentRun?.hp>0 && dealt>0){
      skillState.heroNextAttackMultiplier=Math.min(Number(skillState.heroNextAttackMultiplier||1),Number(power.heroAttackMultiplier)||.80);
      setMessage(`${power.name} weakened ${heroDisplayName()}'s next attack!`); await sleep(360);
    }
    return true;
  }
  if(power.type==="heal-guard"){
    const healed=healCurrentEnemyPercent(power.healPercent); applyEnemyVariantGuard(power);
    setMessage(`${currentEnemy.name} used ${power.name} ${healed>0?`Recovered ${healed} HP and `:""}softened the next hit.`);
    await pop(); return true;
  }
  if(power.type==="heal-next-attack-up"){
    const healed=healCurrentEnemyPercent(power.healPercent);
    currentEnemy.variantNextAttackMultiplier=Math.max(Number(currentEnemy.variantNextAttackMultiplier||1),Number(power.attackMultiplier)||1.15);
    setMessage(`${currentEnemy.name} used ${power.name} ${healed>0?`Recovered ${healed} HP and `:""}powered up its next attack!`);
    await pop(); return true;
  }
  if(power.type==="hero-stun-chance"){
    const landed=Math.random()<Number(power.statusChance||.25);
    if(landed) skillState.heroStunTurns=Math.max(Number(skillState.heroStunTurns||0),Number(power.stunTurns)||1);
    setMessage(`${currentEnemy.name} used ${power.name}${landed?` ${heroDisplayName()} is too dazed to attack next turn!`:" It sparkled harmlessly this time."}`);
    await pop(); return true;
  }
  if(power.type==="hero-sleep-chance"){
    const landed=Math.random()<Number(power.statusChance||.25);
    if(landed) skillState.heroSleepTurns=Math.max(Number(skillState.heroSleepTurns||0),Number(power.sleepTurns)||2);
    setMessage(`${currentEnemy.name} used ${power.name}${landed?` ${heroDisplayName()} fell asleep for ${Number(power.sleepTurns)||2} turns!`:" ${heroDisplayName()} stayed awake!"}`);
    await pop(); return true;
  }
  if(power.type==="dodge"){
    currentEnemy.variantDodgeReady=true;
    setMessage(`${currentEnemy.name} used ${power.name} The next incoming attack will miss completely!`);
    await pop(); return true;
  }
  if(power.type==="heal-attack-up"){
    const healed=healCurrentEnemyPercent(power.healPercent);
    currentEnemy.variantAttackBoostTurns=Math.max(Number(currentEnemy.variantAttackBoostTurns||0),Number(power.duration)||2);
    currentEnemy.variantAttackBoostMultiplier=Math.max(Number(currentEnemy.variantAttackBoostMultiplier||1),Number(power.attackMultiplier)||1.15);
    setMessage(`${currentEnemy.name} used ${power.name} ${healed>0?`Recovered ${healed} HP and `:""}Attack rose by 15% for ${Number(power.duration)||2} attacks.`);
    await pop(); return true;
  }
  if(power.type==="attack-up"){
    currentEnemy.variantAttackBoostTurns=Math.max(Number(currentEnemy.variantAttackBoostTurns||0),Number(power.duration)||2);
    currentEnemy.variantAttackBoostMultiplier=Math.max(Number(currentEnemy.variantAttackBoostMultiplier||1),Number(power.attackMultiplier)||1.50);
    setMessage(`${currentEnemy.name} used ${power.name} Its Attack rose by ${Math.round(((Number(power.attackMultiplier)||1.50)-1)*100)}%!`);
    await pop(); return true;
  }
  return false;
}

function buddyKeyForEnemy(enemy) {
  return `${enemy?.id || "enemy"}:${enemy?.shiny ? "shiny" : enemyVariantId(enemy)}`;
}

function buddyRecordFromEnemy(enemy) {
  const key=buddyKeyForEnemy(enemy);
  return {
    key,
    enemyId:String(enemy?.id || ""),
    variantId:enemy?.shiny ? "shiny" : enemyVariantId(enemy),
    name:String(enemy?.name || "Lil Guy"),
    image:String(enemy?.idle?.[0] || enemy?.hurt || ""),
    idle:Array.isArray(enemy?.idle) ? enemy.idle.map(String).filter(Boolean) : [String(enemy?.idle?.[0] || enemy?.hurt || "")].filter(Boolean),
    shiny:Boolean(enemy?.shiny),
    boss:Boolean(enemy?.boss),
    quantity:1,
    capturedAt:Date.now()
  };
}

function captureBuddy(enemy) {
  ensureBuddySave();
  const incoming=buddyRecordFromEnemy(enemy);
  const existing=hubSave.buddies.collection[incoming.key];
  if(existing) {
    existing.quantity=Math.max(1,Number(existing.quantity)||1)+1;
    existing.name=incoming.name;
    existing.image=incoming.image;
    existing.idle=incoming.idle;
    existing.shiny=incoming.shiny;
    existing.boss=incoming.boss;
  } else {
    hubSave.buddies.collection[incoming.key]=incoming;
  }
  persistAll();
  return hubSave.buddies.collection[incoming.key];
}

function maybeApplyShinyVariant(enemyId, template, forceShiny=false) {
  const shiny=SHINY_VARIANTS[enemyId];
  if(!shiny) return template;
  // The Mimic's shiny is only revealed by the purple Mystery Chest.
  if(!forceShiny && (enemyId==="mimic" || Math.random()>=currentShinyRate())) return template;
  return {
    ...template,
    name:String(shiny.name || template.name),
    idle:Array.isArray(shiny.idle)&&shiny.idle.length?shiny.idle:template.idle,
    hurt:String(shiny.hurt || template.hurt),
    shiny:true,
    shinyId:String(shiny.id || "shiny")
  };
}

const REWARD_ITEMS = [
  { id:"yarn", name:"Yarn", image:"../assets/ingredients/Yarn.webp", weight:14 },
  { id:"thread", name:"Thread", image:"../assets/ingredients/Thread.webp", weight:14 },
  { id:"glitter", name:"Glitter", image:"../assets/ingredients/Sparkle.webp", weight:9 },
  { id:"flower", name:"Flower", image:"../assets/gifts/Flower.webp", weight:9 },
  { id:"bread-loaf", name:"Bread Loaf", image:"../assets/food/Bread-loaf.webp", weight:8 },
  { id:"apple", name:"Apple", image:"../assets/food/apple.webp", weight:8 },
  { id:"pink-paint", name:"Pink Paint", image:"../assets/paint/Pink-paint.webp", weight:7 },
  { id:"red-paint", name:"Red Paint", image:"../assets/paint/Red-paint.webp", weight:7 },
  { id:"mint-paint", name:"Mint Paint", image:"../assets/paint/Mint-paint.webp", weight:6 },
  { id:"aqua-paint", name:"Aqua Paint", image:"../assets/paint/Aqua-paint.webp", weight:5 },
  { id:"gold-paint", name:"Gold Paint", image:"../assets/paint/Gold-paint.webp", weight:3 },
  { id:"rainbow-paint", name:"Rainbow Paint", image:"../assets/paint/Rainbow-paint.webp", weight:1 },
  { id:"pink-heart-refill", name:"Pink Heart Refill", image:"../assets/bakery/drops/Pink-heart-refill.webp", weight:5 },
  { id:"gold-heart-refill", name:"Gold Heart Refill", image:"../assets/bakery/drops/Gold-heart-refill.webp", weight:1 },
  { id:"buddy-pon", name:"Lil Pon", image:"../assets/items/buddy-pons/buddy-pon.webp", weight:6 },
  { id:"super-buddy-pon", name:"Super Lil Pon", image:"../assets/items/buddy-pons/super-buddy-pon.webp", weight:2.4 },
  { id:"boss-buddy-pon", name:"Boss Lil Pon", image:"../assets/items/buddy-pons/boss-buddy-pon.webp", weight:.65 }
];

function currentAreaConfig(){ return getAreaConfig(currentRun?.area || selectedArea); }
function areaProgress(areaId=selectedArea){ const progress=activeHeroProgress(); return progress.areas[areaId] || progress.areas.meadow; }

const PEepIdle = [
  "assets/characters/peep/base/idle-1.webp",
  "assets/characters/peep/base/idle-2.webp"
];

const MikoIdle = [
  "assets/characters/miko/base/idle-1.webp",
  "assets/characters/miko/base/idle-2.webp"
];

const IoIdle = [
  "assets/characters/io/base/idle-1.webp",
  "assets/characters/io/base/idle-2.webp"
];

const MihoIdle = [
  "assets/characters/miho/base/idle-1.webp",
  "assets/characters/miho/base/idle-2.webp"
];

const AnnikaIdle = [
  "assets/characters/annika/base/idle-1.webp",
  "assets/characters/annika/base/idle-2.webp"
];

const ShiyuIdle=["assets/characters/shiyu/base/Shiyu-idle-1.png","assets/characters/shiyu/base/Shiyu-idle-2.png"];
const AngelIdle=["assets/characters/angel/base/Angel-sprite-idle-1.png","assets/characters/angel/base/Angel-sprite-idle-2.png"];
function heroIdleFrames(){
  if(QUEST_NPC_HEROES[activeCharacterId])return QUEST_NPC_HEROES[activeCharacterId].idle;
  if(activeCharacterId === "miko") return MikoIdle;
  if(activeCharacterId === "io") return IoIdle;
  if(activeCharacterId === "miho") return MihoIdle;
  if(activeCharacterId === "annika") return AnnikaIdle;
  if(activeCharacterId === "shiyu") return ShiyuIdle;
  if(activeCharacterId === "angel") return AngelIdle;
  return PEepIdle;
}
function heroHurtFrame(){
  if(QUEST_NPC_HEROES[activeCharacterId])return QUEST_NPC_HEROES[activeCharacterId].idle[0];
  if(activeCharacterId === "miko") return MikoIdle[0];
  if(activeCharacterId === "io") return IoIdle[0];
  if(activeCharacterId === "miho") return "assets/characters/miho/base/hurt.webp";
  if(activeCharacterId === "annika") return "assets/characters/annika/base/hurt.webp";
  if(activeCharacterId === "shiyu") return "assets/characters/shiyu/base/Shiyu-hurt.png";
  if(activeCharacterId === "angel") return "assets/characters/angel/base/Angel-sprite-hurt.png";
  return "assets/characters/peep/base/hurt.webp";
}

const ui = {
  home: document.querySelector("#homeScreen"),
  buddy: document.querySelector("#buddyScreen"),
  battle: document.querySelector("#battleScreen"),
  result: document.querySelector("#resultScreen"),
  coinCount: document.querySelector("#coinCount"),
  levelBadge: document.querySelector("#levelBadge"),
  xpText: document.querySelector("#xpText"),
  xpFill: document.querySelector("#xpFill"),
  happinessHearts: document.querySelector("#happinessHearts"),
  happinessLevel: document.querySelector("#happinessLevel"),
  areaButtons: Array.from(document.querySelectorAll("[data-area]")),
  routePickerModal: document.querySelector("#routePickerModal"),
  closeRoutePicker: document.querySelector("#closeRoutePicker"),
  routeModalImage: document.querySelector("#routeModalImage"),
  routeModalTitle: document.querySelector("#routeModalTitle"),
  routeModalRange: document.querySelector("#routeModalRange"),
  routeModalCurrentRank: document.querySelector("#routeModalCurrentRank"),
  startCurrentRoute: document.querySelector("#startCurrentRoute"),
  startBeginningRoute: document.querySelector("#startBeginningRoute"),
  routeStartLevelPicker: document.querySelector("#routeStartLevelPicker"),
  routeStartLevelSelect: document.querySelector("#routeStartLevelSelect"),
  startSelectedRoute: document.querySelector("#startSelectedRoute"),
  skillBookModal: document.querySelector("#skillBookModal"),
  openSkillBook: document.querySelector("#openSkillBook"),
  closeSkillBook: document.querySelector("#closeSkillBook"),
  skillBookTitle: document.querySelector("#skillBookTitle"),
  uiThemeModal: document.querySelector("#uiThemeModal"),
  openUiThemes: document.querySelector("#openUiThemes"),
  closeUiThemes: document.querySelector("#closeUiThemes"),
  uiThemeGrid: document.querySelector("#uiThemeGrid"),
  uiThemeCurrent: document.querySelector("#uiThemeCurrent"),
  questThemeColor: document.querySelector("#questThemeColor"),
  affectionUnlockToast: document.querySelector("#affectionUnlockToast"),
  affectionUnlockTitle: document.querySelector("#affectionUnlockTitle"),
  affectionUnlockText: document.querySelector("#affectionUnlockText"),
  endlessRecord: document.querySelector("#endlessRecord"),
  endlessCheckpoint: document.querySelector("#endlessCheckpoint"),
  endlessRuns: document.querySelector("#endlessRuns"),
  continueEndless: document.querySelector("#continueEndless"),
  startNewEndless: document.querySelector("#startNewEndless"),
  menuSkills: document.querySelector("#menuSkills"),
  battlefield: document.querySelector("#battlefield"),
  battleBg: document.querySelector("#battleBg"),
  encounterLabel: document.querySelector("#encounterLabel"),
  rankBattleLabel: document.querySelector("#rankBattleLabel"),
  peepLevelCombat: document.querySelector("#peepLevelCombat"),
  peepHpFill: document.querySelector("#peepHpFill"),
  peepHpText: document.querySelector("#peepHpText"),
  peepSprite: document.querySelector("#peepSprite"),
  enemyCombatant: document.querySelector("#enemyCombatant"),
  enemyName: document.querySelector("#enemyName"),
  enemyRank: document.querySelector("#enemyRank"),
  enemyHpFill: document.querySelector("#enemyHpFill"),
  enemyHpText: document.querySelector("#enemyHpText"),
  enemySprite: document.querySelector("#enemySprite"),
  enemyCombatant2: document.querySelector("#enemyCombatant2"),
  enemyName2: document.querySelector("#enemyName2"),
  enemyRank2: document.querySelector("#enemyRank2"),
  enemyHpFill2: document.querySelector("#enemyHpFill2"),
  enemyHpText2: document.querySelector("#enemyHpText2"),
  enemySprite2: document.querySelector("#enemySprite2"),
  peepDamageText: document.querySelector("#peepDamageText"),
  enemyDamageText: document.querySelector("#enemyDamageText"),
  enemyDamageText2: document.querySelector("#enemyDamageText2"),
  chestLayer: document.querySelector("#chestLayer"),
  chestCaption: document.querySelector("#chestCaption"),
  chestSprite: document.querySelector("#chestSprite"),
  openChest: document.querySelector("#openChest"),
  battleMessage: document.querySelector("#battleMessage"),
  eventChoiceActions: document.querySelector("#eventChoiceActions"),
  battleUi: document.querySelector("#battleScreen .battle-ui"),
  commandStage: document.querySelector("#commandStage"),
  targetPicker: document.querySelector("#targetPicker"),
  targetPickerTitle: document.querySelector("#targetPickerTitle"),
  targetPickerGrid: document.querySelector("#targetPickerGrid"),
  closeTargetPicker: document.querySelector("#closeTargetPicker"),
  commandGrid: document.querySelector("#commandGrid"),
  attackMenuButton: document.querySelector("#attackMenuButton"),
  itemMenuButton: document.querySelector("#itemMenuButton"),
  switchBuddyMenuButton: document.querySelector("#switchBuddyMenuButton"),
  switchBuddyCommandText: document.querySelector("#switchBuddyCommandText"),
  escapeButton: document.querySelector("#escapeButton"),
  commandWindow: document.querySelector("#commandWindow"),
  commandWindowTitle: document.querySelector("#commandWindowTitle"),
  closeCommandWindow: document.querySelector("#closeCommandWindow"),
  skillButtons: document.querySelector("#skillButtons"),
  itemButtons: document.querySelector("#itemButtons"),
  noBattleItems: document.querySelector("#noBattleItems"),
  buddyMenuButton: document.querySelector("#buddyMenuButton"),
  buddyCommandText: document.querySelector("#buddyCommandText"),
  buddySwitchPanel: document.querySelector("#buddySwitchPanel"),
  buddySwitchGrid: document.querySelector("#buddySwitchGrid"),
  buddyCombatant: document.querySelector("#buddyCombatant"),
  buddyBattleName: document.querySelector("#buddyBattleName"),
  buddyBattleSprite: document.querySelector("#buddyBattleSprite"),
  buddyBattleSparkle: document.querySelector("#buddyBattleSparkle"),
  continueButton: document.querySelector("#continueButton"),
  postFloorActions: document.querySelector("#postFloorActions"),
  leaveEndlessButton: document.querySelector("#leaveEndlessButton"),
  escapeConfirm: document.querySelector("#escapeConfirm"),
  escapeConfirmText: document.querySelector("#escapeConfirmText"),
  cancelEscapeConfirm: document.querySelector("#cancelEscapeConfirm"),
  confirmEscapeButton: document.querySelector("#confirmEscapeButton"),
  runNextRank: document.querySelector("#runNextRank"),
  resultKicker: document.querySelector("#resultKicker"),
  resultTitle: document.querySelector("#resultTitle"),
  resultProgressLabel: document.querySelector("#resultProgressLabel"),
  resultRank: document.querySelector("#resultRank"),
  resultCoins: document.querySelector("#resultCoins"),
  resultExp: document.querySelector("#resultExp"),
  resultItems: document.querySelector("#resultItems"),
  levelUpNotice: document.querySelector("#levelUpNotice"),
  heroSpriteWrap: document.querySelector("#heroSpriteWrap"),
  menuPeep: document.querySelector("#menuPeep"),
  menuHeroComposite: document.querySelector("#menuHeroComposite"),
  battleHeroComposite: document.querySelector("#battleHeroComposite"),
  resultPeep: document.querySelector("#resultPeep"),
  resultHeroComposite: document.querySelector("#resultHeroComposite"),
  heroNameHome: document.querySelector("#heroNameHome"),
  heroNameCombat: document.querySelector("#heroNameCombat"),
  exploreHeading: document.querySelector("#exploreHeading"),
  skillsKicker: document.querySelector("#skillsKicker"),
  iconBackgroundButton: document.querySelector("#iconBackgroundButton"),
  iconBackgroundCurrent: document.querySelector("#iconBackgroundCurrent"),
  iconBackgroundLabel: document.querySelector("#iconBackgroundLabel"),
  iconBackgroundPicker: document.querySelector("#iconBackgroundPicker"),
  iconBorderButton: document.querySelector("#iconBorderButton"),
  iconBorderCurrent: document.querySelector("#iconBorderCurrent"),
  iconBorderLabel: document.querySelector("#iconBorderLabel"),
  iconBorderPicker: document.querySelector("#iconBorderPicker"),
  iconBorderColorButton: document.querySelector("#iconBorderColorButton"),
  iconBorderColorCurrent: document.querySelector("#iconBorderColorCurrent"),
  iconBorderColorLabel: document.querySelector("#iconBorderColorLabel"),
  iconBorderColorPicker: document.querySelector("#iconBorderColorPicker"),
  switchQuestOc: document.querySelector("#switchQuestOc"),
  questOcPicker: document.querySelector("#questOcPicker"),
  buddyHomeCount: document.querySelector("#buddyHomeCount"),
  openBuddyCollection: document.querySelector("#openBuddyCollection"),
  charm: document.querySelector("#charmScreen"),
  openCharmScreen: document.querySelector("#openCharmScreen"),
  backFromCharms: document.querySelector("#backFromCharms"),
  charmHomeSummary: document.querySelector("#charmHomeSummary"),
  charmHomeSlots: document.querySelector("#charmHomeSlots"),
  charmCoinCount: document.querySelector("#charmCoinCount"),
  charmEquippedTitle: document.querySelector("#charmEquippedTitle"),
  charmEquippedSlots: document.querySelector("#charmEquippedSlots"),
  charmCatalog: document.querySelector("#charmCatalog"),
  charmMessage: document.querySelector("#charmMessage"),
  battleCharmStrip: document.querySelector("#battleCharmStrip"),
  backFromBuddies: document.querySelector("#backFromBuddies"),
  buddyCollectionCount: document.querySelector("#buddyCollectionCount"),
  buddyCollectionGrid: document.querySelector("#buddyCollectionGrid"),
  buddyCollectionEmpty: document.querySelector("#buddyCollectionEmpty"),
  buddyFilters: Array.from(document.querySelectorAll("[data-buddy-filter]")),
  buddyDetail: document.querySelector("#buddyDetail"),
  closeBuddyDetail: document.querySelector("#closeBuddyDetail"),
  buddyDetailArt: document.querySelector("#buddyDetailArt"),
  buddyDetailVariants: document.querySelector("#buddyDetailVariants"),
  buddyDetailTag: document.querySelector("#buddyDetailTag"),
  buddyDetailName: document.querySelector("#buddyDetailName"),
  buddyDetailStatus: document.querySelector("#buddyDetailStatus"),
  buddyDetailOwned: document.querySelector("#buddyDetailOwned"),
  buddyDetailType: document.querySelector("#buddyDetailType"),
  buddyDetailSkill: document.querySelector("#buddyDetailSkill"),
  buddyFamilyIconActions: document.querySelector("#buddyFamilyIconActions"),
  setBuddyFamilyIcon: document.querySelector("#setBuddyFamilyIcon"),
  buddyFamilyIconStatus: document.querySelector("#buddyFamilyIconStatus"),
  buddyAssignOpen: document.querySelector("#buddyAssignOpen"),
  buddyAssignPanel: document.querySelector("#buddyAssignPanel"),
  buddyAssignAvailability: document.querySelector("#buddyAssignAvailability"),
  buddyAssignCharacters: document.querySelector("#buddyAssignCharacters"),
  buddyAssignSlots: document.querySelector("#buddyAssignSlots"),
  buddyAssignMessage: document.querySelector("#buddyAssignMessage"),
  buddyPersonalizePanel: document.querySelector("#buddyPersonalizePanel"),
  buddyPersonalizeSpecies: document.querySelector("#buddyPersonalizeSpecies"),
  buddyNicknameInput: document.querySelector("#buddyNicknameInput"),
  buddyGenderButtons: [...document.querySelectorAll("[data-buddy-gender]")],
  saveBuddyPersonalization: document.querySelector("#saveBuddyPersonalization"),
  buddyPersonalizeMessage: document.querySelector("#buddyPersonalizeMessage"),
  befriendPanel: document.querySelector("#befriendPanel"),
  befriendTitle: document.querySelector("#befriendTitle"),
  befriendText: document.querySelector("#befriendText"),
  befriendPonChoices: document.querySelector("#befriendPonChoices"),
  skipBefriend: document.querySelector("#skipBefriend"),
  itemPonShopActions: document.querySelector("#itemPonShopActions"),
  purchasePonButton: document.querySelector("#purchasePonButton"),
  itemBackButton: document.querySelector("#itemBackButton"),
  closePonPurchaseButton: document.querySelector("#closePonPurchaseButton"),
  ponPurchasePanel: document.querySelector("#ponPurchasePanel"),
  ponPurchaseCoins: document.querySelector("#ponPurchaseCoins"),
  ponPurchaseMessage: document.querySelector("#ponPurchaseMessage"),
  ponPurchaseChoices: document.querySelector("#ponPurchaseChoices")
};

function setPostFloorLayout(active){
  ui.battleUi?.classList.toggle("reward-mode", Boolean(active));
  ui.commandStage?.classList.toggle("hidden", Boolean(active));
}

let hubSave = loadHubSave();
ensureBuddySave();
let questSave = normalizeQuestSave(hubSave.duckQuest);

function activeCharacterIdFromQuest(){
  const unlocked=Array.isArray(hubSave.unlockedCharacters)?hubSave.unlockedCharacters:["peep"];
  // On the first v26 launch, inherit the Hub OC once. After that Duck Quest
  // remembers its own independently selected hero.
  const requested=String(questSave.activeCharacter || hubSave.selectedCharacter || "peep");
  if(npcQuestUnlocked(requested))return requested;
  if(requested==="miko" && unlocked.includes("miko")) return "miko";
  if(requested==="io" && unlocked.includes("io")) return "io";
  if(requested==="miho" && unlocked.includes("miho")) return "miho";
  if(requested==="annika" && unlocked.includes("annika")) return "annika";
  if(requested==="shiyu" && unlocked.includes("shiyu")) return "shiyu";
  if(requested==="angel" && unlocked.includes("angel")) return "angel";
  return "peep";
}

let activeCharacterId = activeCharacterIdFromQuest();
questSave.activeCharacter = activeCharacterId;

function heroDisplayName(){return QUEST_CHARACTER_NAMES[activeCharacterId] || "Peep";}

function charmState(){
  questSave.charms=normalizeCharmSave(questSave.charms);
  return questSave.charms;
}
function equippedCharmIds(characterId=activeCharacterId){
  const state=charmState();
  if(!Array.isArray(state.equippedByCharacter[characterId])) state.equippedByCharacter[characterId]=[];
  return state.equippedByCharacter[characterId];
}
function equippedCharmDefs(characterId=activeCharacterId){ return equippedCharmIds(characterId).map(id=>CHARM_DEFS[id]).filter(Boolean); }
function activeCharmByFamily(family,characterId=activeCharacterId){ return equippedCharmDefs(characterId).find(def=>def.family===family)||null; }
function currentShinyRate(){ return activeCharmByFamily("shimmer")?.shinyRate || BASE_SHINY_RATE; }
function charmArtMarkup(def,size=""){
  if(!def) return '<span class="charm-art-empty">♡</span>';
  const sizeClass=size?` ${size}`:"";
  return `<span class="charm-art family-${def.family} tier-${def.tier}${sizeClass}" aria-hidden="true"><span class="charm-layer charm-metal"></span><span class="charm-layer charm-sparkle"></span><span class="charm-layer charm-heart"></span><span class="charm-layer charm-duck"></span><span class="charm-layer charm-beak"></span><img class="charm-outline" src="assets/charms/Charm-outline.png" alt=""></span>`;
}
function charmTierLabel(tier){ return tier==="rose-gold"?"Rose Gold":tier.charAt(0).toUpperCase()+tier.slice(1); }
function charmOwned(id){ return Boolean(charmState().owned[id]); }
function setCharmMessage(message){ if(ui.charmMessage) ui.charmMessage.textContent=message; }
function purchaseCharm(id){
  const def=CHARM_DEFS[id];
  if(!def||def.special||charmOwned(id)) return;
  const price=Math.max(0,Number(def.price)||0);
  const coins=Math.max(0,Number(hubSave.coins)||0);
  if(coins<price){ setCharmMessage(`You need ${(price-coins).toLocaleString()} more Pink Coins for ${def.name}.`); return; }
  hubSave.coins=coins-price;
  charmState().owned[id]=true;
  persistAll();
  setCharmMessage(`${def.name} unlocked permanently!`);
  renderCharmScreen(); renderCharmHome(); renderMeta();
}
function toggleCharmEquip(id){
  const def=CHARM_DEFS[id];
  if(!def||!charmOwned(id)) return;
  const equipped=equippedCharmIds();
  const exactIndex=equipped.indexOf(id);
  if(exactIndex>=0){
    equipped.splice(exactIndex,1); persistAll();
    setCharmMessage(`${def.name} unequipped from ${heroDisplayName()}.`);
    renderCharmScreen(); renderCharmHome(); renderBattleCharmStrip(); renderMeta(); return;
  }
  const familyIndex=equipped.findIndex(otherId=>CHARM_DEFS[otherId]?.family===def.family);
  if(familyIndex>=0){
    equipped.splice(familyIndex,1,id); persistAll();
    setCharmMessage(`${def.name} replaced the other ${CHARM_FAMILIES[def.family]?.name || "charm"} tier.`);
    renderCharmScreen(); renderCharmHome(); renderBattleCharmStrip(); renderMeta(); return;
  }
  if(equipped.length>=CHARM_SLOT_LIMIT){ setCharmMessage(`${heroDisplayName()} already has 3 charms equipped. Unequip one first.`); return; }
  equipped.push(id); persistAll();
  setCharmMessage(`${def.name} equipped to ${heroDisplayName()}!`);
  renderCharmScreen(); renderCharmHome(); renderBattleCharmStrip(); renderMeta();
}
function renderCharmHome(){
  if(!ui.charmHomeSlots||!ui.charmHomeSummary) return;
  const defs=equippedCharmDefs();
  ui.charmHomeSummary.textContent=`${defs.length} / ${CHARM_SLOT_LIMIT} equipped for ${heroDisplayName()}`;
  ui.charmHomeSlots.innerHTML="";
  for(let i=0;i<CHARM_SLOT_LIMIT;i++){
    const def=defs[i];
    const slot=document.createElement("div");
    slot.className=`charm-home-slot${def?" filled":""}`;
    slot.innerHTML=def?`${charmArtMarkup(def,"small")}<span class="charm-mini-label">${charmTierLabel(def.tier)} ${CHARM_FAMILIES[def.family]?.name.replace(" Charm","")||"Charm"}</span>`:"<span>♡</span>";
    ui.charmHomeSlots.appendChild(slot);
  }
}
function renderBattleCharmStrip(){
  if(!ui.battleCharmStrip) return;
  const defs=equippedCharmDefs();
  ui.battleCharmStrip.classList.toggle("hidden",defs.length===0);
  ui.battleCharmStrip.innerHTML=defs.map(def=>`<span class="battle-charm-pill" title="${def.name}: ${def.effect}">${charmArtMarkup(def,"tiny")}<span>${CHARM_FAMILIES[def.family]?.name.replace(" Charm","")||"Charm"}</span></span>`).join("");
}
function renderCharmScreen(){
  if(!ui.charmCatalog) return;
  const state=charmState();
  const equipped=equippedCharmIds();
  if(ui.charmCoinCount) ui.charmCoinCount.textContent=`${Math.max(0,Number(hubSave.coins)||0).toLocaleString()} Coins`;
  if(ui.charmEquippedTitle) ui.charmEquippedTitle.textContent=`${heroDisplayName()}'s Charms`;
  if(ui.charmEquippedSlots){
    ui.charmEquippedSlots.innerHTML="";
    for(let i=0;i<CHARM_SLOT_LIMIT;i++){
      const def=CHARM_DEFS[equipped[i]];
      const button=document.createElement("button");
      button.type="button"; button.className=`charm-equip-slot${def?" filled":""}`;
      if(def){ button.innerHTML=`${charmArtMarkup(def,"small")}<small>${def.name}<br>Tap to unequip</small>`; button.addEventListener("click",()=>toggleCharmEquip(def.id)); }
      else{ button.innerHTML="<span>♡</span><small>Empty slot</small>"; button.disabled=true; }
      ui.charmEquippedSlots.appendChild(button);
    }
  }
  ui.charmCatalog.innerHTML="";
  for(const familyId of CHARM_FAMILY_ORDER){
    const family=CHARM_FAMILIES[familyId];
    const card=document.createElement("section"); card.className=`charm-family-card family-${familyId}`;
    const sample=Object.values(CHARM_DEFS).find(def=>def.family===familyId&&def.tier==="gold")||Object.values(CHARM_DEFS).find(def=>def.family===familyId);
    card.innerHTML=`<div class="charm-family-heading">${charmArtMarkup(sample,"small")}<div><h3>${family.name}</h3><p>${family.description}</p></div></div><div class="charm-tier-list"></div>`;
    const list=card.querySelector(".charm-tier-list");
    for(const def of Object.values(CHARM_DEFS).filter(def=>def.family===familyId)){
      const owned=Boolean(state.owned[def.id]); const isEquipped=equipped.includes(def.id);
      const row=document.createElement("div");
      row.className=`charm-tier-row${owned?" owned":""}${isEquipped?" equipped":""}${def.special?" special":""}${def.special&&!owned?" locked":""}`;
      let actionLabel,disabled=false;
      if(def.special&&!owned){actionLabel="Locked";disabled=true;} else if(isEquipped) actionLabel="Unequip"; else if(owned) actionLabel="Equip"; else actionLabel=`Buy ${def.price.toLocaleString()}`;
      const note=def.special&&!owned?`Complete the Duckipedia (${Math.min(CURRENT_DUCKIPEDIA_TOTAL,hubSave.unlockedDucks?.length||0)} / ${CURRENT_DUCKIPEDIA_TOTAL}) to unlock permanently.`:def.effect;
      row.innerHTML=`${charmArtMarkup(def,"small")}<div class="charm-tier-copy"><strong>${def.name}</strong><small>${note}${!def.special&&!owned?` · ${def.price.toLocaleString()} Pink Coins`:""}</small></div><button class="pixel-button small charm-tier-action" type="button" ${disabled?"disabled":""}>${actionLabel}</button>`;
      const button=row.querySelector("button"); if(!disabled) button.addEventListener("click",()=>owned?toggleCharmEquip(def.id):purchaseCharm(def.id));
      list.appendChild(row);
    }
    ui.charmCatalog.appendChild(card);
  }
}

function defaultCharacterQuestProgress(){
  return {
    level:1,
    exp:0,
    iconBackground:"white",
    iconBorderStyle:"none",
    iconBorderColor:"white",
    lastArea:"meadow",
    areas:{
      meadow:{unlockedRank:1,lastRank:1},
      ocean:{unlockedRank:1,lastRank:1},
      candy:{unlockedRank:1,lastRank:1},
      cloud:{unlockedRank:1,lastRank:1},
      city:{unlockedRank:1,lastRank:1},
      spooky:{unlockedRank:1,lastRank:1}
    },
    clearedAreas:{meadow:false,ocean:false,candy:false,cloud:false,city:false,spooky:false},
    affectionMilestonesSeen:{five:false,ten:false},
    endless:{record:0,checkpoint:1}
  };
}

function normalizeCharacterQuestProgress(raw, legacy={}){
  const d=defaultCharacterQuestProgress();
  const q=raw&&typeof raw==="object"?raw:{};
  const legacyAreas=legacy.areas&&typeof legacy.areas==="object"?legacy.areas:{};
  const rawMeadowLast=Number(q.areas?.meadow?.lastRank ?? legacyAreas.meadow?.lastRank ?? legacy.lastRank)||1;
  const rawOceanLast=Number(q.areas?.ocean?.lastRank ?? legacyAreas.ocean?.lastRank)||1;
  const rawCloudLast=Number(q.areas?.cloud?.lastRank ?? legacyAreas.cloud?.lastRank)||1;
  const rawMeadowUnlocked=Number(q.areas?.meadow?.unlockedRank ?? legacyAreas.meadow?.unlockedRank ?? legacy.unlockedRank)||1;
  const rawOceanUnlocked=Number(q.areas?.ocean?.unlockedRank ?? legacyAreas.ocean?.unlockedRank)||1;
  const rawCloudUnlocked=Number(q.areas?.cloud?.unlockedRank ?? legacyAreas.cloud?.unlockedRank)||1;
  const meadowUnlocked=clampInt(rawMeadowUnlocked,1,40,1);
  const meadowLast=clampInt(rawMeadowLast,1,meadowUnlocked,1);
  const oceanUnlocked=clampInt(rawOceanUnlocked,1,80,1);
  const oceanLast=clampInt(rawOceanLast,1,oceanUnlocked,1);
  const candyUnlocked=clampInt(q.areas?.candy?.unlockedRank ?? legacyAreas.candy?.unlockedRank,1,120,1);
  const candyLast=clampInt(q.areas?.candy?.lastRank ?? legacyAreas.candy?.lastRank,1,candyUnlocked,1);
  const cloudUnlocked=clampInt(rawCloudUnlocked,1,160,1);
  const cloudLast=clampInt(rawCloudLast,1,cloudUnlocked,1);
  const cityUnlocked=clampInt(q.areas?.city?.unlockedRank ?? legacyAreas.city?.unlockedRank,1,200,1);
  const cityLast=clampInt(q.areas?.city?.lastRank ?? legacyAreas.city?.lastRank,1,cityUnlocked,1);
  const spookyUnlocked=clampInt(q.areas?.spooky?.unlockedRank ?? legacyAreas.spooky?.unlockedRank,1,240,1);
  const spookyLast=clampInt(q.areas?.spooky?.lastRank ?? legacyAreas.spooky?.lastRank,1,spookyUnlocked,1);
  const incomingIcon=q.iconBackground ?? legacy.iconBackground;
  return {
    ...d,...q,
    level:clampInt(q.level,1,MAX_LEVEL,1),
    exp:Math.max(0,Number(q.exp)||0),
    iconBackground:ICON_BACKGROUND_COLORS.some(color=>color.id===incomingIcon)?incomingIcon:"white",
    iconBorderStyle:ICON_BORDER_STYLES.some(style=>style.id===q.iconBorderStyle)?q.iconBorderStyle:"none",
    iconBorderColor:ICON_BORDER_COLORS.some(color=>color.id===q.iconBorderColor)?q.iconBorderColor:"white",
    lastArea:AREA_CONFIG[q.lastArea ?? legacy.lastArea] ? (q.lastArea ?? legacy.lastArea) : "meadow",
    areas:{
      meadow:{unlockedRank:meadowUnlocked,lastRank:Math.min(meadowLast,meadowUnlocked)},
      ocean:{unlockedRank:oceanUnlocked,lastRank:Math.min(oceanLast,oceanUnlocked)},
      candy:{unlockedRank:candyUnlocked,lastRank:Math.min(candyLast,candyUnlocked)},
      cloud:{unlockedRank:cloudUnlocked,lastRank:Math.min(cloudLast,cloudUnlocked)},
      city:{unlockedRank:cityUnlocked,lastRank:Math.min(cityLast,cityUnlocked)},
      spooky:{unlockedRank:spookyUnlocked,lastRank:Math.min(spookyLast,spookyUnlocked)}
    },
    clearedAreas:{
      meadow:Boolean(q.clearedAreas?.meadow || rawMeadowLast>=40 || rawMeadowUnlocked>=40),
      ocean:Boolean(q.clearedAreas?.ocean || rawOceanLast>=100 || rawOceanUnlocked>=100),
      candy:Boolean(q.clearedAreas?.candy),
      cloud:Boolean(q.clearedAreas?.cloud || rawCloudLast>=150 || rawCloudUnlocked>=150),
      city:Boolean(q.clearedAreas?.city),
      spooky:Boolean(q.clearedAreas?.spooky)
    },
    affectionMilestonesSeen:{
      five:Boolean(q.affectionMilestonesSeen?.five),
      ten:Boolean(q.affectionMilestonesSeen?.ten)
    },
    endless:{
      record:Math.max(0,Math.floor(Number(q.endless?.record)||0)),
      checkpoint:Math.max(1,Math.floor(Number(q.endless?.checkpoint)||1))
    }
  };
}

function defaultQuestSave() {
  return {
    peep:defaultCharacterQuestProgress(),
    activeCharacter:"peep",
    iconBackgroundsUnlocked:["white"],
    iconBorderStylesUnlocked:["none"],
    iconBorderColorsUnlocked:["white"],
    uiThemesUnlocked:["classic-cream"],
    uiTheme:"classic-cream",
    endlessRunsCompleted:0,
    buddyFamilyIcons:{},
    charms:defaultCharmSave(),
    areaRewardMigrationV24124:false,
    completedRuns:0,bossWins:0,totalBattlesWon:0,totalCoinsEarned:0,totalExpEarned:0
  };
}

function normalizeQuestSave(raw) {
  const d=defaultQuestSave();
  const q=raw&&typeof raw==="object"?raw:{};
  const normalized={
    ...d,...q,
    peep:normalizeCharacterQuestProgress(q.peep,{
      areas:q.areas,
      unlockedRank:q.unlockedRank,
      lastRank:q.lastRank,
      lastArea:q.lastArea,
      iconBackground:q.iconBackground
    }),
    activeCharacter:QUEST_CHARACTER_IDS.includes(q.activeCharacter)?q.activeCharacter:null,
    iconBackgroundsUnlocked:[...new Set(["white",...(Array.isArray(q.iconBackgroundsUnlocked)?q.iconBackgroundsUnlocked:[])])]
      .filter(id=>ICON_BACKGROUND_COLORS.some(color=>color.id===id)),
    iconBorderStylesUnlocked:[...new Set(["none",...(Array.isArray(q.iconBorderStylesUnlocked)?q.iconBorderStylesUnlocked:[])])]
      .filter(id=>ICON_BORDER_STYLES.some(style=>style.id===id)),
    iconBorderColorsUnlocked:[...new Set(["white",...(Array.isArray(q.iconBorderColorsUnlocked)?q.iconBorderColorsUnlocked:[])])]
      .filter(id=>ICON_BORDER_COLORS.some(color=>color.id===id)),
    uiThemesUnlocked:[...new Set(["classic-cream",...(Array.isArray(q.uiThemesUnlocked)?q.uiThemesUnlocked:[])])].filter(id=>QUEST_UI_THEME_IDS.has(id)),
    uiTheme:QUEST_UI_THEME_IDS.has(q.uiTheme)?q.uiTheme:"classic-cream",
    endlessRunsCompleted:Math.max(0,Math.floor(Number(q.endlessRunsCompleted)||0)),
    buddyFamilyIcons:(q.buddyFamilyIcons&&typeof q.buddyFamilyIcons==="object")?{...q.buddyFamilyIcons}:{},
    charms:normalizeCharmSave(q.charms),
    bossWins:Math.max(0,Number(q.bossWins ?? q.completedRuns)||0)
  };
  if(q.miko&&typeof q.miko==="object") normalized.miko=normalizeCharacterQuestProgress(q.miko);
  if(q.io&&typeof q.io==="object") normalized.io=normalizeCharacterQuestProgress(q.io);
  if(q.miho&&typeof q.miho==="object") normalized.miho=normalizeCharacterQuestProgress(q.miho);
  if(q.annika&&typeof q.annika==="object") normalized.annika=normalizeCharacterQuestProgress(q.annika);
  return normalized;
}

function activeHeroProgress(){
  if(!questSave[activeCharacterId]||typeof questSave[activeCharacterId]!=="object"){
    questSave[activeCharacterId]=defaultCharacterQuestProgress();
  }else{
    questSave[activeCharacterId]=normalizeCharacterQuestProgress(questSave[activeCharacterId]);
  }
  return questSave[activeCharacterId];
}


function stageLevelAlreadyCleared(characterId,stageId,level){
  const raw=questSave[characterId];
  if(!raw || typeof raw!=="object") return false;
  const hero=normalizeCharacterQuestProgress(raw);
  questSave[characterId]=hero;
  const cfg=getAreaConfig(stageId);
  const stage=hero.areas?.[stageId];
  if(!stage) return false;
  const target=Math.max(1,Number(level)||1);
  if(target>=cfg.maxRank) return Boolean(hero.clearedAreas?.[stageId]);
  return Math.max(1,Number(stage.unlockedRank)||1)>target || Boolean(hero.clearedAreas?.[stageId]);
}

function questThemeRequirementMet(theme){
  const req=theme?.requirement;
  if(!req) return true;
  if(req.endlessRuns) return Math.max(0,Math.floor(Number(questSave.endlessRunsCompleted)||0))>=req.endlessRuns;
  if(req.character) return stageLevelAlreadyCleared(req.character,req.stage,req.level);
  return QUEST_CHARACTER_IDS.some(characterId=>stageLevelAlreadyCleared(characterId,req.stage,req.level));
}

function normalizeQuestUiThemeState(){
  if(!Array.isArray(questSave.uiThemesUnlocked)) questSave.uiThemesUnlocked=["classic-cream"];
  questSave.uiThemesUnlocked=[...new Set(["classic-cream",...questSave.uiThemesUnlocked])].filter(id=>QUEST_UI_THEME_IDS.has(id));
  for(const theme of QUEST_UI_THEMES){
    if(questThemeRequirementMet(theme) && !questSave.uiThemesUnlocked.includes(theme.id)) questSave.uiThemesUnlocked.push(theme.id);
  }
  if(!questSave.uiThemesUnlocked.includes(questSave.uiTheme)) questSave.uiTheme="classic-cream";
}

function isQuestUiThemeUnlocked(themeId){
  normalizeQuestUiThemeState();
  return questSave.uiThemesUnlocked.includes(themeId);
}

function unlockQuestUiTheme(themeId){
  const theme=questUiThemeById(themeId);
  if(!Array.isArray(questSave.uiThemesUnlocked)) questSave.uiThemesUnlocked=["classic-cream"];
  questSave.uiThemesUnlocked=[...new Set(["classic-cream",...questSave.uiThemesUnlocked])].filter(id=>QUEST_UI_THEME_IDS.has(id));
  if(questSave.uiThemesUnlocked.includes(theme.id)) return null;
  questSave.uiThemesUnlocked.push(theme.id);
  return theme;
}

function applyQuestUiTheme(){
  normalizeQuestUiThemeState();
  const theme=questUiThemeById(questSave.uiTheme);
  document.body.dataset.questTheme=theme.id;
  if(ui.questThemeColor) ui.questThemeColor.setAttribute("content",theme.themeColor || "#f6c6d6");
  if(ui.uiThemeCurrent) ui.uiThemeCurrent.textContent=theme.name;
}

function syncQuestThemeIntoHubSave(){
  hubSave.duckQuest = questSave;
  try{ localStorage.setItem(HUB_SAVE_KEY, JSON.stringify(hubSave)); }catch(error){}
}

function makeQuestThemeSwatch(theme,className="ui-theme-swatch"){
  const swatch=document.createElement("span");
  swatch.className=className;
  for(const color of theme.swatches||[]){
    const dot=document.createElement("i");
    dot.style.background=color;
    swatch.appendChild(dot);
  }
  return swatch;
}

function renderUiThemePicker(){
  if(!ui.uiThemeGrid) return;
  normalizeQuestUiThemeState();
  ui.uiThemeGrid.innerHTML="";
  const current=questUiThemeById(questSave.uiTheme);
  if(ui.uiThemeCurrent) ui.uiThemeCurrent.textContent=current.name;
  for(const theme of QUEST_UI_THEMES){
    const unlocked=isQuestUiThemeUnlocked(theme.id);
    const selected=theme.id===questSave.uiTheme;
    const button=document.createElement("button");
    button.type="button";
    button.className=`ui-theme-card${unlocked?" unlocked":" locked"}${selected?" selected":""}`;
    button.disabled=!unlocked;
    button.setAttribute("aria-pressed",String(selected));
    button.appendChild(makeQuestThemeSwatch(theme));
    const copy=document.createElement("span");
    copy.className="ui-theme-card-copy";
    const title=document.createElement("strong"); title.textContent=theme.name;
    const desc=document.createElement("small"); desc.textContent=theme.description;
    const status=document.createElement("em"); status.textContent=unlocked?(selected?"✓ Equipped":"Tap to equip"):`🔒 ${questThemeRequirementText(theme)}`;
    copy.append(title,desc,status); button.appendChild(copy);
    if(unlocked) button.addEventListener("click",()=>{
      questSave.uiTheme=theme.id;
      applyQuestUiTheme();
      syncQuestThemeIntoHubSave();
      persistAll();
      renderUiThemePicker();
    });
    ui.uiThemeGrid.appendChild(button);
  }
}

function openUiThemePicker(){
  if(currentRun) return;
  renderUiThemePicker();
  ui.uiThemeModal?.classList.remove("hidden");
  ui.uiThemeModal?.setAttribute("aria-hidden","false");
}
function closeUiThemePicker(){
  ui.uiThemeModal?.classList.add("hidden");
  ui.uiThemeModal?.setAttribute("aria-hidden","true");
}

function awardQuestThemesForClearedLevel(stageId,level,characterId){
  const earned=[];
  const clearedLevel=Math.max(1,Number(level)||1);
  for(const theme of QUEST_UI_THEMES){
    const req=theme.requirement;
    if(!req || req.stage!==stageId || clearedLevel<req.level) continue;
    if(req.character && req.character!==characterId) continue;
    const unlocked=unlockQuestUiTheme(theme.id);
    if(unlocked) earned.push(unlocked);
  }
  return earned;
}

function awardQuestThemesForEndlessRuns(){
  const earned=[];
  const completed=Math.max(0,Math.floor(Number(questSave.endlessRunsCompleted)||0));
  for(const theme of QUEST_UI_THEMES){
    const req=theme.requirement;
    if(!req?.endlessRuns || completed<req.endlessRuns) continue;
    const unlocked=unlockQuestUiTheme(theme.id);
    if(unlocked) earned.push(unlocked);
  }
  return earned;
}

let heroProgress = activeHeroProgress();
let selectedArea = AREA_CONFIG[heroProgress.lastArea] ? heroProgress.lastArea : "meadow";
let selectedRank = Math.min(areaProgress(selectedArea).unlockedRank, Math.max(1, areaProgress(selectedArea).lastRank || 1));
let currentRun = null;
let currentEnemy = null;
let doubleBattleEnemies = [];
let pendingTargetMode = "";
let pendingTargetSkill = null;
let pendingCapturePonId = "";
let idleTimer = null;
let secondaryEnemyIdleTimer = null;
let peepIdleTimer = null;
let buddyIdleTimer = null;
let enemyIdleIndex = 0;
let peepIdleIndex = 0;
let buddyIdleIndex = 0;
let actionLocked = false;
let pendingChest = null;
let pendingDefeatedEnemy = null;
let befriendAttempted = false;
let endlessExitReason = "";
let buddyCollectionFilter = "meadow";
let buddyDetailEntryKey = "";
let buddyAssignCharacterId = "";
let buddyPersonalizeCharacterId = "";
let buddyPersonalizeSlotIndex = -1;
let buddyPersonalizeGender = "";
const QUICK_HEAL_PERCENT = 0.25;
const QUICK_HEAL_MAX_USES = 4;
let quickHealUses = 0;
let skillState = {};
let specialHeroAttackScale = 1;
let buddyUsedThisHeroTurn = false;
let activeBattleBuddySlot = 0;
let buddySwitchUsedThisEncounter = false;

const ENEMY_EFFECT_KEYS=[
  "enemyAttackDownTurns","enemyAttackMultiplier",
  "enemyDefenseDownTurns","enemyDefenseMultiplier",
  "enemyAccuracyDownTurns","enemyMissChance",
  "enemyBurnTurns","enemyBurnDamagePercent",
  "enemyNextAttackMultiplier","enemyStunned","enemyStunTurns"
];

function enemyEffectDefaults(){
  return {
    enemyAttackDownTurns:0,enemyAttackMultiplier:1,
    enemyDefenseDownTurns:0,enemyDefenseMultiplier:1,
    enemyAccuracyDownTurns:0,enemyMissChance:0,
    enemyBurnTurns:0,enemyBurnDamagePercent:0,
    enemyNextAttackMultiplier:1,enemyStunned:false,enemyStunTurns:0
  };
}

function ensureEnemyEffectSnapshot(enemy){
  if(!enemy) return;
  if(!enemy._battleEffects || typeof enemy._battleEffects!=="object") enemy._battleEffects=enemyEffectDefaults();
  const defaults=enemyEffectDefaults();
  for(const key of ENEMY_EFFECT_KEYS){
    if(enemy._battleEffects[key]===undefined) enemy._battleEffects[key]=defaults[key];
  }
}

function saveCurrentEnemyEffects(enemy=currentEnemy){
  if(!enemy || !skillState) return;
  ensureEnemyEffectSnapshot(enemy);
  for(const key of ENEMY_EFFECT_KEYS) enemy._battleEffects[key]=skillState[key];
}

function loadEnemyEffects(enemy){
  if(!enemy || !skillState) return;
  ensureEnemyEffectSnapshot(enemy);
  for(const key of ENEMY_EFFECT_KEYS) skillState[key]=enemy._battleEffects[key];
}

function enemySlot(enemy=currentEnemy){
  return Number(enemy?._doubleSlot)===1?1:0;
}

function enemyUiFor(enemyOrSlot=currentEnemy){
  const slot=typeof enemyOrSlot==="number"?enemyOrSlot:enemySlot(enemyOrSlot);
  if(slot===1){
    return {
      slot:1,combatant:ui.enemyCombatant2,name:ui.enemyName2,rank:ui.enemyRank2,
      hpFill:ui.enemyHpFill2,hpText:ui.enemyHpText2,sprite:ui.enemySprite2,damageText:ui.enemyDamageText2
    };
  }
  return {
    slot:0,combatant:ui.enemyCombatant,name:ui.enemyName,rank:ui.enemyRank,
    hpFill:ui.enemyHpFill,hpText:ui.enemyHpText,sprite:ui.enemySprite,damageText:ui.enemyDamageText
  };
}

function activeEnemyUi(){ return enemyUiFor(currentEnemy); }

function isDoubleBattleActive(){
  return Boolean(currentRun && currentEncounterData()?.type==="double-enemy" && doubleBattleEnemies.length>1);
}

function aliveDoubleEnemies(){
  return doubleBattleEnemies
    .filter(enemy=>enemy && enemy.hpNow>0 && !enemy._defeated)
    .sort((a,b)=>enemySlot(a)-enemySlot(b));
}

function selectCurrentEnemy(enemy){
  if(!enemy) return;
  if(currentEnemy && currentEnemy!==enemy) saveCurrentEnemyEffects(currentEnemy);
  currentEnemy=enemy;
  loadEnemyEffects(enemy);
  if(isDoubleBattleActive()){
    for(const candidate of doubleBattleEnemies){
      enemyUiFor(candidate).combatant?.classList.toggle("target-selected",candidate===enemy && candidate.hpNow>0);
    }
  }
  renderEnemyHp(enemy);
}

function resetDoubleBattleUi(){
  doubleBattleEnemies=[];
  pendingTargetMode="";
  ui.battlefield?.classList.remove("double-battle");
  ui.enemyCombatant?.classList.remove("target-selected");
  ui.enemyCombatant2?.classList.remove("target-selected");

  // Fully clear the secondary slot so a defeated Double Trouble sprite/name
  // can never flash into the next normal or boss encounter.
  if(ui.enemyCombatant2) ui.enemyCombatant2.classList.add("hidden");
  if(ui.enemyName2) ui.enemyName2.textContent="";
  if(ui.enemyRank2) ui.enemyRank2.textContent="";
  if(ui.enemyHpFill2) ui.enemyHpFill2.style.width="0%";
  if(ui.enemyHpText2) ui.enemyHpText2.textContent="";
  if(ui.enemyDamageText2){
    ui.enemyDamageText2.textContent="";
    ui.enemyDamageText2.classList.add("hidden");
  }
  if(ui.enemySprite2){
    ui.enemySprite2.removeAttribute("src");
    ui.enemySprite2.alt="";
    ui.enemySprite2.className="pixel-sprite fighter enemy-fighter";
  }
  ui.enemyCombatant2?.querySelectorAll(".shiny-arrival-burst").forEach(node=>node.remove());

  closeTargetPicker();
  clearInterval(secondaryEnemyIdleTimer);
  secondaryEnemyIdleTimer=null;
}

function renderEnemyNameFor(enemy,slot=enemySlot(enemy)){
  const refs=enemyUiFor(slot);
  if(!refs.name) return;
  refs.name.textContent="";
  refs.name.append(document.createTextNode(String(enemy?.name || "Enemy")));
  if(enemy?.shiny){
    const sparkle=document.createElement("span");
    sparkle.className="enemy-shiny-sparkle";
    sparkle.textContent=" ✨";
    sparkle.setAttribute("aria-label","Shiny");
    refs.name.append(sparkle);
  }
  if(enemy && buddyOwnedQuantity(buddyKeyForEnemy(enemy))>0){
    const heart=document.createElement("span");
    heart.className="enemy-captured-heart";
    heart.textContent=" ♥";
    heart.setAttribute("aria-label","Already befriended");
    heart.title="Already befriended";
    refs.name.append(heart);
  }
}

function renderEnemyCombatant(enemy,slot=enemySlot(enemy)){
  if(!enemy) return;
  enemy._doubleSlot=slot;
  const refs=enemyUiFor(slot);
  // Populate every label/image before showing this combatant. This prevents
  // the HTML placeholder or previous enemy art from flashing on screen.
  refs.combatant?.classList.add("hidden");
  refs.sprite?.removeAttribute("src");
  refs.sprite?.classList.remove("boss-fighter","gold-boss-fighter","queen-bee-fighter","strawberry-slime-fighter","rainbow-flower-fighter","ocean-elite-fighter","ocean-boss-fighter","cream-fox-fighter");refs.sprite?.classList.toggle("sibling-opponent-v230",Boolean(enemy?.siblingCharacterId));ui.battlefield?.classList.toggle("sibling-battle-v230",Boolean(enemy?.siblingCharacterId));
  renderEnemyNameFor(enemy,slot);
  if(refs.rank){
    refs.rank.textContent=currentRun?.mode==="endless"
      ? `${enemy.boss?"BOSS · ":""}Lv. ${endlessEffectiveRank(currentRun.floor)} · Floor ${currentRun.floor}`
      : enemy.boss?`BOSS · Level ${currentRun.rank}`:`Level ${currentRun.rank}`;
  }
  if(refs.sprite){
    refs.sprite.classList.toggle("boss-fighter",Boolean(enemy.boss));
    refs.sprite.classList.toggle("gold-boss-fighter",enemy.mushroomVariant==="gold");
    refs.sprite.classList.toggle("queen-bee-fighter",enemy.beeVariant==="queen");
    refs.sprite.classList.toggle("strawberry-slime-fighter",enemy.catSlimeVariant==="strawberry");
    refs.sprite.classList.toggle("rainbow-flower-fighter",enemy.flowerVariant==="rainbow");
    refs.sprite.classList.toggle("ocean-elite-fighter",Boolean(enemy.eliteVariant));
    refs.sprite.classList.toggle("ocean-boss-fighter",enemy.id==="vampire-squid");
    refs.sprite.classList.toggle("cream-fox-fighter",enemy.id==="cream-fox");
    setQuestSpriteFrame(refs.sprite,enemy.idle?.[0] || enemy.image || "");
    refs.sprite.alt=enemy.name || "Enemy";
  }
  renderEnemyHp(enemy);
  refs.combatant?.classList.remove("hidden");
}

function startSecondaryEnemyIdle(enemy){
  clearInterval(secondaryEnemyIdleTimer);
  secondaryEnemyIdleTimer=null;
  if(!enemy || enemy.hpNow<=0) return;
  let index=0;
  const refs=enemyUiFor(enemy);
  const frames=Array.isArray(enemy.idle)&&enemy.idle.length?enemy.idle:[enemy.image].filter(Boolean);
  if(!frames.length || !refs.sprite) return;
  setQuestSpriteFrame(refs.sprite,frames[0]);
  if(frames.length<2) return;
  secondaryEnemyIdleTimer=setInterval(()=>{
    if(actionLocked || enemy.hpNow<=0 || refs.combatant?.classList.contains("hidden")) return;
    index=(index+1)%frames.length;
    setQuestSpriteFrame(refs.sprite,frames[index]);
  },enemy.speed || 380);
}

function skillNeedsEnemyTarget(skill){
  return Boolean(skill && ["damage","damage-burn","multi-hit","shiyu-glitch","safe-chip","stun"].includes(skill.type));
}

function closeTargetPicker(){
  const returnMode=pendingTargetMode;
  pendingTargetMode="";
  pendingTargetSkill=null;
  pendingCapturePonId="";
  ui.targetPicker?.classList.add("hidden");
  ui.targetPickerGrid && (ui.targetPickerGrid.innerHTML="");
  if(!actionLocked && currentEnemy){
    if(returnMode==="skill") openCommandWindow("attack");
    else if(returnMode==="capture") openCommandWindow("item");
    else ui.commandGrid?.classList.remove("hidden");
  }
}

function doubleTargetBaseName(enemy){
  if(!enemy) return "Enemy";
  // The base Sea Turtle art is green, so say that explicitly in target choice.
  if(enemy.id==="sea-turtle" && enemy.oceanVariant==="green") return "Green Sea Turtle";
  return String(enemy.name || "Enemy");
}

function doubleTargetLabel(enemy,targets){
  const base=doubleTargetBaseName(enemy);
  const sameName=(targets||[]).filter(candidate=>doubleTargetBaseName(candidate)===base);
  if(sameName.length>1){
    return `${base} — ${enemySlot(enemy)===0?"Left":"Right"}`;
  }
  return base;
}

function openDoubleTargetPicker(mode="skill",payload=null){
  const targets=aliveDoubleEnemies();
  if(targets.length<=1){
    if(targets[0]) selectCurrentEnemy(targets[0]);
    if(mode==="skill" && payload){ useSkill(payload); return; }
    if(mode==="capture" && payload){ attemptBattleCapture(payload,targets[0]||currentEnemy); return; }
    return;
  }

  pendingTargetMode=mode;
  pendingTargetSkill=mode==="skill"?payload:null;
  pendingCapturePonId=mode==="capture"?String(payload||""):"";
  closeCommandWindow();
  ui.commandGrid?.classList.add("hidden");

  if(ui.targetPickerTitle){
    if(mode==="capture") ui.targetPickerTitle.textContent="Choose who to befriend";
    else if(mode==="skill" && payload) ui.targetPickerTitle.textContent=`Choose ${payload.name || "move"} target`;
    else ui.targetPickerTitle.textContent="Choose a target";
  }

  if(ui.targetPickerGrid){
    ui.targetPickerGrid.innerHTML="";
    for(const enemy of targets){
      const button=document.createElement("button");
      button.type="button";
      button.className=`pixel-button target-enemy-button${enemy.shiny?" shiny-target":""}`;
      const art=document.createElement("img");
      art.src=enemy.idle?.[0] || enemy.image || "";
      art.alt="";
      const name=document.createElement("strong");
      name.textContent=`${doubleTargetLabel(enemy,targets)}${enemy.shiny?" ✨":""}`;
      const hp=document.createElement("small");
      if(mode==="capture"){
        const pon=BUDDY_PONS.find(item=>item.id===pendingCapturePonId);
        const rate=pon?buddyPonCatchRate(pon,enemy):0;
        button.disabled=rate<=0;
        hp.textContent=rate>0
          ? `${Math.max(0,Math.round(enemy.hpNow))} / ${enemy.maxHp} HP · ${Math.round(rate*100)}% catch`
          : `${Math.max(0,Math.round(enemy.hpNow))} / ${enemy.maxHp} HP · Can't catch`;
      } else {
        hp.textContent=`${Math.max(0,Math.round(enemy.hpNow))} / ${enemy.maxHp} HP`;
      }
      button.append(art,name,hp);
      button.addEventListener("click",()=>{
        const nextMode=pendingTargetMode;
        const skill=pendingTargetSkill;
        const ponId=pendingCapturePonId;
        selectCurrentEnemy(enemy);
        pendingTargetMode="";
        pendingTargetSkill=null;
        pendingCapturePonId="";
        ui.targetPicker?.classList.add("hidden");
        ui.targetPickerGrid.innerHTML="";
        ui.commandGrid?.classList.remove("hidden");
        if(nextMode==="skill" && skill){ useSkill(skill); return; }
        if(nextMode==="capture" && ponId){ attemptBattleCapture(ponId,enemy); return; }
      });
      ui.targetPickerGrid.appendChild(button);
    }
  }
  ui.targetPicker?.classList.remove("hidden");
}


const EVENT_CHOICE_SETS={
  "wishing-fountain":[
    {id:"fortune",label:"Wish for Fortune",detail:"Ask for a bigger pile of Pink Coins."},
    {id:"treasure",label:"Wish for Treasure",detail:"Ask for items and a better chance at collectible rewards."},
    {id:"friendship",label:"Wish for Friendship",detail:"Ask for extra Happiness and EXP with your OC."}
  ],
  "lucky-picnic":[
    {id:"share-snacks",label:"Share the Snacks",detail:"A cozy choice with the biggest Happiness reward."},
    {id:"check-basket",label:"Check the Basket",detail:"Look for extra items and Pink Coins inside."},
    {id:"relax",label:"Relax Together",detail:"Take a break for extra EXP and a little Happiness."}
  ]
};

function eventChoiceLabel(type,id){
  return EVENT_CHOICE_SETS[type]?.find(choice=>choice.id===id)?.label || situationTitle(type);
}

function hideEventChoices(){
  ui.eventChoiceActions?.classList.add("hidden");
  if(ui.eventChoiceActions) ui.eventChoiceActions.innerHTML="";
  ui.battleUi?.classList.remove("event-mode");
}

function showEventChoices(type){
  const choices=EVENT_CHOICE_SETS[type] || [];
  if(!ui.eventChoiceActions || !choices.length) return;
  ui.eventChoiceActions.innerHTML="";
  for(const choice of choices){
    const button=document.createElement("button");
    button.type="button";
    button.className="pixel-button event-choice-button";
    button.innerHTML=`<strong>${choice.label}</strong><small>${choice.detail}</small>`;
    button.addEventListener("click",async()=>{
      if(actionLocked || !pendingChest || pendingChest.eventType!==type) return;
      pendingChest.eventChoice=choice.id;
      hideEventChoices();
      await openPendingChest();
    });
    ui.eventChoiceActions.appendChild(button);
  }
  ui.eventChoiceActions.classList.remove("hidden");
  ui.battleUi?.classList.add("event-mode");
}

function loadHubSave() {
  try {
    const raw = localStorage.getItem(HUB_SAVE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    if (!parsed.inventory || typeof parsed.inventory !== "object") parsed.inventory = {};
    if (!parsed.characterProgress || typeof parsed.characterProgress !== "object") parsed.characterProgress = {};
    if (!parsed.characterProgress.peep || typeof parsed.characterProgress.peep !== "object") {
      parsed.characterProgress.peep = { happinessTotal:0 };
    }
    if (!parsed.characterProgress.miko || typeof parsed.characterProgress.miko !== "object") {
      parsed.characterProgress.miko = { happinessTotal:0 };
    }
    if (!parsed.characterProgress.io || typeof parsed.characterProgress.io !== "object") {
      parsed.characterProgress.io = { happinessTotal:0 };
    }
    if (!parsed.characterProgress.miho || typeof parsed.characterProgress.miho !== "object") {
      parsed.characterProgress.miho = { happinessTotal:0 };
    }
    if (!parsed.characterProgress.annika || typeof parsed.characterProgress.annika !== "object") {
      parsed.characterProgress.annika = { happinessTotal:0 };
    }
  if(!parsed.characterProgress.shiyu || typeof parsed.characterProgress.shiyu!=="object") parsed.characterProgress.shiyu={happinessTotal:0};
    if (!Array.isArray(parsed.unlockedCharacters)) parsed.unlockedCharacters=["peep"];
    if (!parsed.unlockedCharacters.includes("peep")) parsed.unlockedCharacters.unshift("peep");
    parsed.selectedCharacter = parsed.unlockedCharacters.includes(parsed.selectedCharacter) ? parsed.selectedCharacter : "peep";
    parsed.coins = Math.max(0, Number(parsed.coins) || 0);
    return parsed;
  } catch {
    return { coins:0, inventory:{}, unlockedDucks:[], unlockedCharacters:["peep"], selectedCharacter:"peep", characterProgress:{peep:{happinessTotal:0},miko:{happinessTotal:0},io:{happinessTotal:0},miho:{happinessTotal:0},annika:{happinessTotal:0},shiyu:{happinessTotal:0}} };
  }
}

// Character IDs are declared near the top with the UI-theme definitions.
const AREA_CLEAR_CLOSET_REWARDS = Object.freeze({
  meadow:{id:"daisy-crown",name:"Daisy Crown",image:"../assets/ui/daisy-crown-reward.png"},
  ocean:{id:"ocean-sunglasses",name:"Sunglasses",image:"../assets/ui/sunglasses-reward.png"},
  candy:{id:"candy-hairclip",name:"Candy Hairclip",image:"../assets/ui/candy-hairclip-reward.webp"},
  cloud:{id:"halo",name:"Halo",image:"../assets/ui/halo-reward.png"},
  city:{id:"city-crown",name:"City Crown",image:"assets/backgrounds/city/crown-base.png"},
  spooky:{id:"uclothes-spooky-cat-ears",name:"Spooky Cat Ears",image:"../assets/universal-clothing/previews/spooky-cat-ears.webp"}
});

function characterClosetUnlocks(characterId){
  if(!hubSave.characterUnlockedItems || typeof hubSave.characterUnlockedItems!=="object") hubSave.characterUnlockedItems={};
  const id=QUEST_CHARACTER_IDS.includes(characterId)?characterId:"peep";
  if(!Array.isArray(hubSave.characterUnlockedItems[id])) hubSave.characterUnlockedItems[id]=[];
  return hubSave.characterUnlockedItems[id];
}

function hasCharacterClosetReward(characterId,itemId){
  return Boolean(itemId && characterClosetUnlocks(characterId).includes(itemId));
}

function unlockCharacterClosetReward(characterId,itemId){
  if(!itemId) return false;
  const id=QUEST_CHARACTER_IDS.includes(characterId)?characterId:"peep";
  const list=characterClosetUnlocks(id);
  if(list.includes(itemId)) return false;
  list.push(itemId);
  hubSave.characterUnlockedItems[id]=[...new Set(list)];
  if(id==="peep") hubSave.unlockedItems=[...new Set([...(Array.isArray(hubSave.unlockedItems)?hubSave.unlockedItems:[]),itemId])];
  return true;
}

// Older builds granted Meadow/Ocean/Cloud completion accessories to every OC.
// v24.124 converts that old shared state into per-OC clears. The best evidence
// available in legacy saves is whether that OC last ran the old area's final
// rank. This preserves the likely completer while removing accidental copies.
function migrateAreaRewardsV24124(){
  if(questSave.areaRewardMigrationV24124) return;
  const legacyAreas=["meadow","ocean","cloud"];
  for(const characterId of QUEST_CHARACTER_IDS){
    if(!questSave[characterId] || typeof questSave[characterId]!=="object") questSave[characterId]=defaultCharacterQuestProgress();
    const hero=normalizeCharacterQuestProgress(questSave[characterId]);
    questSave[characterId]=hero;
    for(const areaId of legacyAreas){
      const reward=AREA_CLEAR_CLOSET_REWARDS[areaId];
      const list=characterClosetUnlocks(characterId);
      const earned=Boolean(hero.clearedAreas?.[areaId]) && list.includes(reward.id);
      hero.clearedAreas[areaId]=earned;
      if(!earned){
        hubSave.characterUnlockedItems[characterId]=list.filter(id=>id!==reward.id);
        const outfit=hubSave.characterOutfits?.[characterId];
        if(outfit && Array.isArray(outfit.extras)) outfit.extras=outfit.extras.filter(id=>id!==reward.id);
      }
    }
  }
  const peepUnlocks=new Set(characterClosetUnlocks("peep"));
  const areaRewardIds=new Set(Object.values(AREA_CLEAR_CLOSET_REWARDS).map(reward=>reward.id));
  hubSave.unlockedItems=(Array.isArray(hubSave.unlockedItems)?hubSave.unlockedItems:[])
    .filter(id=>!areaRewardIds.has(id) || peepUnlocks.has(id));
  questSave.areaRewardMigrationV24124=true;
  hubSave.duckQuest=questSave;
  try{ localStorage.setItem(HUB_SAVE_KEY,JSON.stringify(hubSave)); }catch(error){}
}

migrateAreaRewardsV24124();
// v24.345: grant the City reward retroactively if an OC had already cleared City
// before the crown was added. No other area/unlock is modified.
for(const characterId of QUEST_CHARACTER_IDS){
  const hero=questSave[characterId];
  if(hero?.clearedAreas?.city && unlockCharacterClosetReward(characterId,'city-crown')){
    try{localStorage.setItem(HUB_SAVE_KEY,JSON.stringify(hubSave));}catch(error){}
  }
}

function persistAll() {
  const peep=questSave.peep||defaultCharacterQuestProgress();
  questSave.areas=JSON.parse(JSON.stringify(peep.areas));
  questSave.lastArea=peep.lastArea;
  questSave.unlockedRank=peep.areas.meadow.unlockedRank;
  questSave.lastRank=peep.areas.meadow.lastRank;
  questSave.iconBackground=peep.iconBackground;
  hubSave.duckQuest = questSave;
  localStorage.setItem(HUB_SAVE_KEY, JSON.stringify(hubSave));
}


// v24.251 — Love-interest reward bridge. The love-interest runtime lives in a
// separate script, while Duck Quest keeps an in-memory hubSave object. Merge
// only the reward-bearing fields here so a subsequent persistAll() cannot
// overwrite a freshly-earned duck, outfit, or Trading Card.
window.DuckieQuestLoveRewardSync = function(incoming){
  try{
    if(!incoming || typeof incoming!=="object") return false;

    if(!hubSave.loveInterests || typeof hubSave.loveInterests!=="object") hubSave.loveInterests={};
    for(const [id,state] of Object.entries(incoming.loveInterests||{})){
      if(!state || typeof state!=="object") continue;
      hubSave.loveInterests[id]={...(hubSave.loveInterests[id]||{}),...state};
    }

    if(!hubSave.loveInterestPairs || typeof hubSave.loveInterestPairs!=="object") hubSave.loveInterestPairs={};
    for(const [id,state] of Object.entries(incoming.loveInterestPairs||{})){
      if(!state || typeof state!=="object") continue;
      hubSave.loveInterestPairs[id]={...(hubSave.loveInterestPairs[id]||{}),...state};
    }

    if(!hubSave.characterUnlockedItems || typeof hubSave.characterUnlockedItems!=="object") hubSave.characterUnlockedItems={};
    const currentMiko=Array.isArray(hubSave.characterUnlockedItems.miko)?hubSave.characterUnlockedItems.miko:[];
    const incomingMiko=Array.isArray(incoming.characterUnlockedItems?.miko)?incoming.characterUnlockedItems.miko:[];
    hubSave.characterUnlockedItems.miko=[...new Set([...currentMiko,...incomingMiko])];
    const currentAnnika=Array.isArray(hubSave.characterUnlockedItems.annika)?hubSave.characterUnlockedItems.annika:[];
    const incomingAnnika=Array.isArray(incoming.characterUnlockedItems?.annika)?incoming.characterUnlockedItems.annika:[];
    hubSave.characterUnlockedItems.annika=[...new Set([...currentAnnika,...incomingAnnika])];
    const currentShiyu=Array.isArray(hubSave.characterUnlockedItems.shiyu)?hubSave.characterUnlockedItems.shiyu:[];
    const incomingShiyu=Array.isArray(incoming.characterUnlockedItems?.shiyu)?incoming.characterUnlockedItems.shiyu:[];
    hubSave.characterUnlockedItems.shiyu=[...new Set([...currentShiyu,...incomingShiyu])];

    const currentDucks=Array.isArray(hubSave.unlockedDucks)?hubSave.unlockedDucks:[];
    const incomingDucks=Array.isArray(incoming.unlockedDucks)?incoming.unlockedDucks:[];
    hubSave.unlockedDucks=[...new Set([...currentDucks,...incomingDucks])];

    if(!hubSave.duckCollectionCounts || typeof hubSave.duckCollectionCounts!=="object") hubSave.duckCollectionCounts={};
    for(const [duckId,count] of Object.entries(incoming.duckCollectionCounts||{})){
      hubSave.duckCollectionCounts[duckId]=Math.max(Number(hubSave.duckCollectionCounts[duckId]||0),Number(count||0));
    }

    if(!hubSave.tradingCards || typeof hubSave.tradingCards!=="object") hubSave.tradingCards={};
    if(!hubSave.tradingCards.owned || typeof hubSave.tradingCards.owned!=="object") hubSave.tradingCards.owned={};
    const incomingCards=incoming.tradingCards && typeof incoming.tradingCards==="object"?incoming.tradingCards:{};
    for(const [cardId,count] of Object.entries(incomingCards.owned||{})){
      hubSave.tradingCards.owned[cardId]=Math.max(Number(hubSave.tradingCards.owned[cardId]||0),Number(count||0));
    }
    const unseenNow=Array.isArray(hubSave.tradingCards.unseen)?hubSave.tradingCards.unseen:[];
    const unseenIncoming=Array.isArray(incomingCards.unseen)?incomingCards.unseen:[];
    hubSave.tradingCards.unseen=[...new Set([...unseenNow,...unseenIncoming])];

    persistAll();
    return true;
  }catch(error){
    console.warn("Love-interest reward sync failed:",error);
    return false;
  }
};

function clampInt(value,min,max,fallback) {
  const n = Math.round(Number(value));
  return Number.isFinite(n) ? Math.min(max,Math.max(min,n)) : fallback;
}

function randInt(min,max) { return Math.floor(Math.random()*(max-min+1))+min; }
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }


// v24.88 performance pass: keep only the small set of images needed for the
// current encounter decoded/warm. This avoids animation stalls without
// preloading the entire game at startup.
const questImageWarmCache = new Map();
const QUEST_WARM_IMAGE_LIMIT = 96;
const questFrameWanted = new WeakMap();

// Resolve only after the new frame is loaded and decoded. Keep the last
// successful frame on-screen meanwhile instead of swapping to a blank IMG.
function warmQuestImage(src){
  if(!src) return Promise.resolve(false);
  const key=String(src);
  const existing=questImageWarmCache.get(key);
  if(existing){
    questImageWarmCache.delete(key);
    questImageWarmCache.set(key,existing);
    return existing.ready;
  }
  const img=new Image();
  img.decoding="async";
  let resolveReady;
  const ready=new Promise(resolve=>{resolveReady=resolve;});
  const entry={img,ready};
  const finish=ok=>{
    if(!ok && questImageWarmCache.get(key)===entry)questImageWarmCache.delete(key);
    resolveReady(ok);
  };
  img.onload=()=>{
    const decoding=typeof img.decode==="function" ? img.decode() : Promise.resolve();
    Promise.resolve(decoding).catch(()=>{}).then(()=>finish(img.naturalWidth>0));
  };
  img.onerror=()=>finish(false);
  questImageWarmCache.set(key,entry);
  img.src=key;
  while(questImageWarmCache.size>QUEST_WARM_IMAGE_LIMIT){
    const oldest=questImageWarmCache.keys().next().value;
    questImageWarmCache.delete(oldest);
  }
  return ready;
}

function setQuestSpriteFrame(target,src){
  if(!target || !src)return;
  const key=String(src);
  questFrameWanted.set(target,key);
  if(target.getAttribute('src')===key)return;
  const current=target.getAttribute('src');
  const cached=questImageWarmCache.get(key);
  if(cached?.img?.complete && cached.img.naturalWidth>0){
    target.src=key;
    warmQuestImage(key); // Mark this animation frame as recently used.
    return;
  }
  warmQuestImage(key).then(ok=>{
    if(!ok || !target.isConnected || questFrameWanted.get(target)!==key)return;
    // A hurt/skill frame might have replaced the idle frame in the meantime.
    if(target.getAttribute('src')!==current && target.getAttribute('src')!==key)return;
    if(target.getAttribute('src')!==key)target.src=key;
  });
}

function warmCurrentBattleAssets(enemy=null){
  const sources=new Set();
  heroIdleFrames().forEach(src=>sources.add(src));
  sources.add(heroHurtFrame());
  try{ sortedActiveSkills().forEach(skill=>{ if(skill?.sprite) sources.add(skill.sprite); }); }catch(error){}
  if(enemy){
    (enemy.idle||[]).forEach(src=>sources.add(src));
    if(enemy.hurt) sources.add(enemy.hurt);
  }
  battleBuddySlotRecords().forEach(buddy=>{
    if(buddy?.image) sources.add(buddy.image);
    (buddy?.idle||[]).forEach(src=>sources.add(src));
  });
  const bg=currentRun?.mode==="endless"
    ? currentRun?.floorBackground
    : currentRun ? currentAreaConfig()?.backgrounds?.[currentRun.index] : null;
  if(bg) sources.add(bg);
  REWARD_ITEMS.forEach(item=>{
    if(String(item.id||"").includes("buddy-pon") && item.image) sources.add(item.image);
  });
  [
    "assets/items/chests/treasure/closed.webp",
    "assets/items/chests/treasure/open.webp",
    "assets/shinies/amethyst-mimic-open.webp"
  ].forEach(src=>sources.add(src));
  sources.forEach(warmQuestImage);
  const nextIndex=(currentRun?.index??-1)+1;
  const upcoming=currentRun?.mode==="normal"?currentRun.plan?.[nextIndex]:null;
  if(upcoming){
    const prewarmNext=()=>{
      const nextBg=currentAreaConfig()?.backgrounds?.[nextIndex];
      if(nextBg)warmQuestImage(nextBg);
      const ids=Array.isArray(upcoming.enemyIds)?upcoming.enemyIds:[upcoming.enemyId].filter(Boolean);
      ids.slice(0,2).forEach(id=>{
        const template=ENEMIES[id];
        const preview=template?.idle?.[0]||template?.image;
        if(preview)warmQuestImage(preview);
      });
    };
    if(typeof requestIdleCallback==="function")requestIdleCallback(prewarmNext,{timeout:1800});
    else setTimeout(prewarmNext,700);
  }
}

function warmQuestMenuAssets(){
  const run=()=>{
    heroIdleFrames().forEach(warmQuestImage);
    const selected=getAreaConfig(selectedArea);
    if(selected?.backgrounds?.[0]) warmQuestImage(selected.backgrounds[0]);
    REWARD_ITEMS.forEach(item=>{ if(String(item.id||"").includes("buddy-pon")) warmQuestImage(item.image); });
  };
  if(typeof requestIdleCallback==="function") requestIdleCallback(run,{timeout:1200});
  else setTimeout(run,350);
}

function hubInventoryQty(itemId) {
  return Math.max(0, Number(hubSave.inventory?.[itemId]) || 0);
}

function consumeHubItem(itemId, quantity = 1) {
  const amount = Math.max(1, Number(quantity) || 1);
  const current = hubInventoryQty(itemId);
  if (current < amount) return false;
  const next = current - amount;
  if (next > 0) hubSave.inventory[itemId] = next;
  else delete hubSave.inventory[itemId];
  persistAll();
  return true;
}
function shuffle(arr) {
  for(let i=arr.length-1;i>0;i--) {
    const j=Math.floor(Math.random()*(i+1));
    [arr[i],arr[j]]=[arr[j],arr[i]];
  }
  return arr;
}

function expNeeded(level) {
  if (level >= MAX_LEVEL) return 0;
  return 80 + (level - 1) * 25;
}

function peepStats(level = activeHeroProgress().level) {
  const vitality=activeCharmByFamily("vitality");
  const hpBonus=Math.max(0,Number(vitality?.hpBonus)||0);
  return {
    maxHp: Math.round((42 + (level - 1) * 4.2) * (1 + hpBonus)),
    attack: Math.round((8 + (level - 1) * 1.15) * (activeCharacterId==="angel"?1.20:(activeCharacterId==="shiyu"?1.12:1)) * Math.max(0.10, Number(specialHeroAttackScale)||1)),
    defense: Math.round((2 + (level - 1) * 0.48)*(activeCharacterId==="angel"?.82:1))
  };
}

function enemyScaled(template, rank, areaId="meadow") {
  const tuning=areaId==="spooky"
    ? {hp:.026,atk:.016,exp:.023,reward:.018}
    : areaId==="cloud"
    ? {hp:.028,atk:.017,exp:.021,reward:.016}
    : areaId==="city"
      ? {hp:.024,atk:.015,exp:.022,reward:.017}
    : areaId==="candy"
      ? {hp:.031,atk:.0195,exp:.024,reward:.018}
      : areaId==="ocean"
        ? {hp:.035,atk:.0225,exp:.0275,reward:.020}
        : {hp:.090,atk:.060,exp:.070,reward:.050};
  const hpStep=tuning.hp;
  const atkStep=tuning.atk;
  const expStep=tuning.exp;
  const rewardStep=tuning.reward;
  const hpScale=1+(rank-1)*hpStep;
  const atkScale=1+(rank-1)*atkStep;
  const expScale=1+(rank-1)*expStep;
  const rewardScale=1+(rank-1)*rewardStep;
  return {
    ...template,
    maxHp:Math.round(template.hp*hpScale),hpNow:Math.round(template.hp*hpScale),
    attackNow:Math.max(1,Math.round(template.attack*atkScale)),
    expNow:Math.round(template.exp*expScale),
    coinMinNow:Math.round(template.coinMin*rewardScale),coinMaxNow:Math.round(template.coinMax*rewardScale)
  };
}

function totalHappinessRequiredForLevel(level) {
  const target = Math.max(1, Math.min(100, Number(level)||1));
  let total=0;
  for(let lv=1;lv<target;lv++) total += 10 + Math.floor((lv-1)/5);
  return total;
}

function happinessLevelFromTotal(total) {
  const safe=Math.max(0,Number(total)||0);
  let remaining=safe;
  let level=1;
  while(level<100) {
    const need=10+Math.floor((level-1)/5);
    if(remaining<need) break;
    remaining-=need;
    level++;
  }
  return level;
}

function grantQuestHappiness(amount,characterId=activeCharacterId){
  const gain=Math.max(0,Math.floor(Number(amount)||0));
  if(!gain || QUEST_NPC_HEROES[characterId]) return 0;
  if(!hubSave.characterProgress || typeof hubSave.characterProgress!=="object") hubSave.characterProgress={};
  if(!hubSave.characterProgress[characterId] || typeof hubSave.characterProgress[characterId]!=="object") hubSave.characterProgress[characterId]={happinessTotal:0};
  const maxTotal=totalHappinessRequiredForLevel(100);
  const before=Math.max(0,Math.min(maxTotal,Number(hubSave.characterProgress[characterId].happinessTotal)||0));
  const after=Math.min(maxTotal,before+gain);
  hubSave.characterProgress[characterId].happinessTotal=after;
  return Math.max(0,after-before);
}

function chestHappinessReward(chest){
  if(chest?.eventType==="lucky-picnic") return 4;
  if(chest?.eventType==="wishing-fountain") return 2;
  if(chest?.kind==="hidden-treasure") return 5;
  if(chest?.kind==="boss") return 3;
  if(chest?.kind==="double-trouble") return 2;
  if(chest?.kind==="rare") return 2;
  return 1;
}

function affectionRewardBonus(characterId=activeCharacterId){
  const hLevel=QUEST_NPC_HEROES[characterId]?taskBuddyHappiness(characterId):happinessLevelFromTotal(hubSave.characterProgress?.[characterId]?.happinessTotal);
  if(hLevel>=100) return .25;
  if(hLevel>=50) return .10;
  return 0;
}

function affectionRewardMultiplier(characterId=activeCharacterId){
  return 1+affectionRewardBonus(characterId);
}

function normalizeIconBackgroundUnlocks(){
  const validIds=new Set(ICON_BACKGROUND_COLORS.map(bg=>bg.id));
  const unlocked=new Set(Array.isArray(questSave.iconBackgroundsUnlocked)?questSave.iconBackgroundsUnlocked:["white"]);
  unlocked.add("white");
  questSave.iconBackgroundsUnlocked=[...unlocked].filter(id=>validIds.has(id));
  const hero=activeHeroProgress(); if(!questSave.iconBackgroundsUnlocked.includes(hero.iconBackground)) hero.iconBackground="white";
}

function unlockIconBackground(id){
  const bg=ICON_BACKGROUND_COLORS.find(x=>x.id===id);
  if(!bg) return null;
  normalizeIconBackgroundUnlocks();
  if(questSave.iconBackgroundsUnlocked.includes(id)) return null;
  questSave.iconBackgroundsUnlocked.push(id);
  return bg;
}

function unlockLevelIconBackgrounds(levels){
  const unlocked=[];
  for(const level of levels){
    const id=LEVEL_ICON_BACKGROUND_REWARDS[level];
    if(!id) continue;
    const bg=unlockIconBackground(id);
    if(bg) unlocked.push(bg);
  }
  return unlocked;
}

function syncPastLevelIconBackgrounds(){
  normalizeIconBackgroundUnlocks();
  const unlocked=new Set(questSave.iconBackgroundsUnlocked);
  for(const [levelText,id] of Object.entries(LEVEL_ICON_BACKGROUND_REWARDS)){
    if(activeHeroProgress().level>=Number(levelText)) unlocked.add(id);
  }
  questSave.iconBackgroundsUnlocked=[...unlocked];
}

function pickChestIconBackground(chest){
  normalizeIconBackgroundUnlocks();
  // v37: A discovered icon background can never be rolled again.
  // Exclude both persistent unlocks and anything already awarded in this run.
  const alreadyDiscovered=new Set([
    ...questSave.iconBackgroundsUnlocked,
    ...((currentRun?.iconBackgroundsEarned||[]).map(bg=>bg?.id).filter(Boolean))
  ]);
  const locked=ICON_BACKGROUND_COLORS.filter(bg=>bg.source==="chest" && !alreadyDiscovered.has(bg.id));
  if(!locked.length) return null;

  const isMimic=chest?.enemy?.id==="mimic";
  const chance=isMimic ? .50 : chest?.kind==="rare" ? .55 : chest?.kind==="boss" ? .30 : .10;
  if(Math.random()>chance) return null;

  const rarityBoost=chest?.kind==="rare" || isMimic
    ? {common:1,uncommon:1.45,rare:2.5,ultra:4}
    : chest?.kind==="boss"
      ? {common:1,uncommon:1.25,rare:2,ultra:3}
      : {common:1,uncommon:.75,rare:.35,ultra:.12};

  const weighted=locked.map(bg=>({bg,weight:(Number(bg.weight)||1)*(rarityBoost[bg.rarity]||1)}));
  let roll=Math.random()*weighted.reduce((sum,x)=>sum+x.weight,0);
  for(const entry of weighted){
    roll-=entry.weight;
    if(roll<=0) return entry.bg;
  }
  return weighted[0]?.bg||null;
}

function applyIconBackgroundStyle(element,bg){
  if(!element || !bg) return;
  element.style.background=bg.value;
  element.style.backgroundSize=bg.size||"auto";
  element.style.backgroundPosition="0 0";
}

function normalizeIconBorderStyleUnlocks(){
  const validIds=new Set(ICON_BORDER_STYLES.map(style=>style.id));
  const unlocked=new Set(Array.isArray(questSave.iconBorderStylesUnlocked)?questSave.iconBorderStylesUnlocked:["none"]);
  unlocked.add("none");
  questSave.iconBorderStylesUnlocked=[...unlocked].filter(id=>validIds.has(id));
}

function normalizeIconBorderColorUnlocks(){
  const validIds=new Set(ICON_BORDER_COLORS.map(color=>color.id));
  const unlocked=new Set(Array.isArray(questSave.iconBorderColorsUnlocked)?questSave.iconBorderColorsUnlocked:["white"]);
  unlocked.add("white");
  questSave.iconBorderColorsUnlocked=[...unlocked].filter(id=>validIds.has(id));
}

function unlockIconBorderStyle(id){
  const style=ICON_BORDER_STYLES.find(x=>x.id===id);
  if(!style) return null;
  normalizeIconBorderStyleUnlocks();
  if(questSave.iconBorderStylesUnlocked.includes(id)) return null;
  questSave.iconBorderStylesUnlocked.push(id);
  return style;
}

function unlockIconBorderColor(id){
  const color=ICON_BORDER_COLORS.find(x=>x.id===id);
  if(!color) return null;
  normalizeIconBorderColorUnlocks();
  if(questSave.iconBorderColorsUnlocked.includes(id)) return null;
  questSave.iconBorderColorsUnlocked.push(id);
  return color;
}

function pickChestIconBorderStyle(chest){
  normalizeIconBorderStyleUnlocks();
  const alreadyDiscovered=new Set([
    ...questSave.iconBorderStylesUnlocked,
    ...((currentRun?.iconBorderStylesEarned||[]).map(style=>style?.id).filter(Boolean))
  ]);
  const locked=ICON_BORDER_STYLES.filter(style=>style.source==="chest" && !alreadyDiscovered.has(style.id));
  if(!locked.length) return null;

  const isMimic=chest?.enemy?.id==="mimic";
  const chance=chest?.kind==="hidden-treasure" ? .65 : isMimic ? .28 : chest?.kind==="rare" ? .24 : chest?.kind==="boss" ? .18 : .05;
  if(Math.random()>chance) return null;

  const rarityBoost=chest?.kind==="hidden-treasure"
    ? {common:1,uncommon:1.55,rare:2.5}
    : (chest?.kind==="rare" || isMimic)
      ? {common:1,uncommon:1.35,rare:2.15}
      : chest?.kind==="boss"
        ? {common:1,uncommon:1.2,rare:1.8}
        : {common:1,uncommon:.8,rare:.45};

  const weighted=locked.map(style=>({style,weight:(Number(style.weight)||1)*(rarityBoost[style.rarity]||1)}));
  let roll=Math.random()*weighted.reduce((sum,entry)=>sum+entry.weight,0);
  for(const entry of weighted){
    roll-=entry.weight;
    if(roll<=0) return entry.style;
  }
  return weighted[0]?.style||null;
}

function pickChestIconBorderColor(chest){
  normalizeIconBorderColorUnlocks();
  const alreadyDiscovered=new Set([
    ...questSave.iconBorderColorsUnlocked,
    ...((currentRun?.iconBorderColorsEarned||[]).map(color=>color?.id).filter(Boolean))
  ]);
  const locked=ICON_BORDER_COLORS.filter(color=>color.source==="chest" && !alreadyDiscovered.has(color.id));
  if(!locked.length) return null;

  const isMimic=chest?.enemy?.id==="mimic";
  const chance=chest?.kind==="hidden-treasure" ? .88 : isMimic ? .34 : chest?.kind==="rare" ? .32 : chest?.kind==="boss" ? .24 : .07;
  if(Math.random()>chance) return null;

  const rarityBoost=chest?.kind==="hidden-treasure"
    ? {common:1,uncommon:1.45,rare:2.35}
    : (chest?.kind==="rare" || isMimic)
      ? {common:1,uncommon:1.28,rare:1.95}
      : chest?.kind==="boss"
        ? {common:1,uncommon:1.15,rare:1.65}
        : {common:1,uncommon:.82,rare:.48};

  const weighted=locked.map(color=>({color,weight:(Number(color.weight)||1)*(rarityBoost[color.rarity]||1)}));
  let roll=Math.random()*weighted.reduce((sum,entry)=>sum+entry.weight,0);
  for(const entry of weighted){
    roll-=entry.weight;
    if(roll<=0) return entry.color;
  }
  return weighted[0]?.color||null;
}

function applyIconBorderPreviewStyle(element,style,color){
  if(!element) return;
  const safeStyle=style || iconBorderStyleById("none");
  const safeColor=color || iconBorderColorById("white");
  element.classList.toggle("none",safeStyle.id==="none");

  if(safeStyle.id==="none"){
    element.style.setProperty("--icon-border-preview-image","none");
    return;
  }

  const token=`${safeStyle.id}|${safeColor.id}`;
  element.dataset.borderPreviewToken=token;
  element.style.setProperty("--icon-border-preview-image",`url("${safeStyle.file}")`);

  questIconBorderTintedSrc(safeStyle.file,safeColor.value,safeStyle.id).then(src=>{
    if(element.isConnected && element.dataset.borderPreviewToken===token && src){
      element.style.setProperty("--icon-border-preview-image",`url("${src}")`);
    }
  });
}

function normalizeWallpaperUnlocks(){
  if(!Array.isArray(hubSave.unlockedWallpapers)) hubSave.unlockedWallpapers=[];
  hubSave.unlockedWallpapers=[...new Set(hubSave.unlockedWallpapers.filter(Boolean))];
}

function unlockWallpaper(id){
  const wallpaper=questWallpaperById(id);
  if(!wallpaper) return null;
  normalizeWallpaperUnlocks();
  if(hubSave.unlockedWallpapers.includes(id)) return null;
  hubSave.unlockedWallpapers.push(id);
  return wallpaper;
}

function pickChestWallpaper(chest){
  normalizeWallpaperUnlocks();
  const alreadyDiscovered=new Set([
    ...hubSave.unlockedWallpapers,
    ...((currentRun?.wallpapersEarned||[]).map(wallpaper=>wallpaper?.id).filter(Boolean))
  ]);
  const locked=QUEST_WALLPAPERS.filter(wallpaper=>!alreadyDiscovered.has(wallpaper.id));
  if(!locked.length) return null;

  const isMimic=chest?.enemy?.id==="mimic";
  const chance=chest?.kind==="hidden-treasure" ? .95 : isMimic ? .42 : chest?.kind==="rare" ? .35 : chest?.kind==="boss" ? .22 : .04;
  if(Math.random()>chance) return null;

  const rarityBoost=chest?.kind==="hidden-treasure"
    ? {rare:1.3,ultra:3.2}
    : (chest?.kind==="rare" || isMimic)
      ? {rare:1.5,ultra:2.8}
      : chest?.kind==="boss"
        ? {rare:1.1,ultra:2.0}
        : {rare:1,ultra:.6};

  const weighted=locked.map(wallpaper=>({wallpaper,weight:(Number(wallpaper.weight)||1)*(rarityBoost[wallpaper.rarity]||1)}));
  let roll=Math.random()*weighted.reduce((sum,entry)=>sum+entry.weight,0);
  for(const entry of weighted){
    roll-=entry.weight;
    if(roll<=0) return entry.wallpaper;
  }
  return weighted[0]?.wallpaper || null;
}

function applyWallpaperStyle(element,wallpaper){
  if(!element || !wallpaper) return;
  element.style.background=wallpaper.value;
  element.style.backgroundSize=wallpaper.size||"auto";
  element.style.backgroundPosition="0 0";
}

function closeIconBackgroundPicker(){
  ui.iconBackgroundPicker?.classList.add("hidden");
  ui.iconBackgroundButton?.setAttribute("aria-expanded","false");
}

function closeIconBorderPicker(){
  ui.iconBorderPicker?.classList.add("hidden");
  ui.iconBorderButton?.setAttribute("aria-expanded","false");
}

function closeIconBorderColorPicker(){
  ui.iconBorderColorPicker?.classList.add("hidden");
  ui.iconBorderColorButton?.setAttribute("aria-expanded","false");
}

function closeAllIconAppearancePickers(){
  closeIconBackgroundPicker();
  closeIconBorderPicker();
  closeIconBorderColorPicker();
}

function renderIconBackgroundPicker(){
  normalizeIconBackgroundUnlocks();
  if(!ui.iconBackgroundPicker || !ui.heroSpriteWrap) return;
  const hero=activeHeroProgress();
  const unlocked=new Set(questSave.iconBackgroundsUnlocked);
  const selected=iconBackgroundById(hero.iconBackground);

  applyIconBackgroundStyle(ui.heroSpriteWrap,selected);
  applyQuestIconBorder(ui.heroSpriteWrap, activeCharacterId);
  if(ui.iconBackgroundCurrent) applyIconBackgroundStyle(ui.iconBackgroundCurrent,selected);
  if(ui.iconBackgroundLabel) ui.iconBackgroundLabel.textContent=selected.label;

  ui.iconBackgroundPicker.innerHTML="";
  for(const background of ICON_BACKGROUND_COLORS){
    const isUnlocked=unlocked.has(background.id);
    const button=document.createElement("button");
    button.type="button";
    button.className=`icon-background-choice${isUnlocked?"":" locked"}`;
    button.setAttribute("aria-current",String(hero.iconBackground===background.id));
    button.setAttribute("aria-label",`${background.label}${isUnlocked?"":", locked"}`);
    button.title=background.label;

    const swatch=document.createElement("span");
    swatch.className="icon-background-dot";
    applyIconBackgroundStyle(swatch,background);
    button.appendChild(swatch);

    if(!isUnlocked){
      const lock=document.createElement("span");
      lock.className="icon-background-lock";
      lock.textContent="🔒";
      button.appendChild(lock);
    }

    button.addEventListener("click",()=>{
      if(!isUnlocked) return;
      setIconBackground(background.id);
      closeIconBackgroundPicker();
    });
    ui.iconBackgroundPicker.appendChild(button);
  }
}

function setIconBackground(colorId){
  if(!questSave.iconBackgroundsUnlocked.includes(colorId)) return;
  activeHeroProgress().iconBackground=colorId;
  persistAll();
  renderIconBackgroundPicker();
  renderHeroVisuals();
  renderQuestOcPicker();
}

function renderIconBorderPicker(){
  normalizeIconBorderStyleUnlocks();
  if(!ui.iconBorderPicker || !ui.heroSpriteWrap) return;
  const hero=activeHeroProgress();
  const unlocked=new Set(questSave.iconBorderStylesUnlocked);
  if(!unlocked.has(hero.iconBorderStyle)) hero.iconBorderStyle="none";
  const selected=iconBorderStyleById(hero.iconBorderStyle);
  const selectedColor=iconBorderColorById(hero.iconBorderColor);

  if(ui.iconBorderCurrent) applyIconBorderPreviewStyle(ui.iconBorderCurrent,selected,selectedColor);
  if(ui.iconBorderLabel) ui.iconBorderLabel.textContent=selected.label;
  applyQuestIconBorder(ui.heroSpriteWrap,activeCharacterId);

  ui.iconBorderPicker.innerHTML="";
  for(const style of ICON_BORDER_STYLES){
    const isUnlocked=unlocked.has(style.id);
    const button=document.createElement("button");
    button.type="button";
    button.className=`quest-border-style-choice${isUnlocked?"":" locked"}`;
    button.setAttribute("aria-current",String(hero.iconBorderStyle===style.id));
    button.setAttribute("aria-label",`${style.label}${isUnlocked?"":", locked"}`);
    button.title=style.label;

    const preview=document.createElement("span");
    preview.className="quest-border-style-preview";
    applyIconBorderPreviewStyle(preview,style,selectedColor);
    button.append(preview);

    const label=document.createElement("span");
    label.className="quest-border-style-label";
    label.textContent=style.id==="none" ? "None" : style.label.replace(/\s+Border$/i,"");
    button.append(label);

    if(!isUnlocked){
      const lock=document.createElement("span");
      lock.className="icon-background-lock";
      lock.textContent="🔒";
      button.append(lock);
    }

    button.addEventListener("click",()=>{
      if(!isUnlocked) return;
      setIconBorderStyle(style.id);
      closeIconBorderPicker();
    });
    ui.iconBorderPicker.append(button);
  }
}

function setIconBorderStyle(styleId){
  normalizeIconBorderStyleUnlocks();
  if(!questSave.iconBorderStylesUnlocked.includes(styleId)) return;
  activeHeroProgress().iconBorderStyle=styleId;
  persistAll();
  renderIconBorderPicker();
  renderIconBorderColorPicker();
  renderHeroVisuals();
  renderQuestOcPicker();
}

function renderIconBorderColorPicker(){
  normalizeIconBorderColorUnlocks();
  if(!ui.iconBorderColorPicker || !ui.heroSpriteWrap) return;
  const hero=activeHeroProgress();
  const unlocked=new Set(questSave.iconBorderColorsUnlocked);
  if(!unlocked.has(hero.iconBorderColor)) hero.iconBorderColor="white";
  const selected=iconBorderColorById(hero.iconBorderColor);
  const selectedStyle=iconBorderStyleById(hero.iconBorderStyle);

  if(ui.iconBorderColorCurrent){
    ui.iconBorderColorCurrent.style.background=selected.value;
    ui.iconBorderColorCurrent.style.backgroundSize="auto";
  }
  if(ui.iconBorderColorLabel) ui.iconBorderColorLabel.textContent=selected.label;
  if(ui.iconBorderCurrent) applyIconBorderPreviewStyle(ui.iconBorderCurrent,selectedStyle,selected);
  applyQuestIconBorder(ui.heroSpriteWrap,activeCharacterId);

  ui.iconBorderColorPicker.innerHTML="";
  for(const color of ICON_BORDER_COLORS){
    const isUnlocked=unlocked.has(color.id);
    const button=document.createElement("button");
    button.type="button";
    button.className=`icon-background-choice${isUnlocked?"":" locked"}`;
    button.setAttribute("aria-current",String(hero.iconBorderColor===color.id));
    button.setAttribute("aria-label",`${color.label}${isUnlocked?"":", locked"}`);
    button.title=color.label;

    const swatch=document.createElement("span");
    swatch.className="icon-background-dot";
    swatch.style.background=color.value;
    button.append(swatch);

    if(!isUnlocked){
      const lock=document.createElement("span");
      lock.className="icon-background-lock";
      lock.textContent="🔒";
      button.append(lock);
    }

    button.addEventListener("click",()=>{
      if(!isUnlocked) return;
      setIconBorderColor(color.id);
      closeIconBorderColorPicker();
    });
    ui.iconBorderColorPicker.append(button);
  }
}

function setIconBorderColor(colorId){
  normalizeIconBorderColorUnlocks();
  if(!questSave.iconBorderColorsUnlocked.includes(colorId)) return;
  activeHeroProgress().iconBorderColor=colorId;
  persistAll();
  renderIconBorderPicker();
  renderIconBorderColorPicker();
  renderHeroVisuals();
  renderQuestOcPicker();
}


const MIKO_LAYER_MAP=Object.freeze({
  "hair-main":{file:"Miko-hair.webp",z:15},
  "hoodie-back":{file:"Miko-hoodie-back.webp",z:18},
  "base":{file:"Miko-base.webp",z:20},
  "socks":{file:"Miko-socks.webp",z:29},
  "socks-garter":{file:"white-garter-socks.webp",z:29},
  "bottom-capris":{file:"Miko-capri-pants.webp",z:31},
  "bottom-jeans":{file:"Miko-jeans.webp",z:31},
  "bottom-boxers":{file:"Miko-Boxers.webp",z:31},
  "bottom-shorts":{file:"shorts.webp",z:31},
  "top-button":{file:"Miko-button-shirt.webp",z:32},
  "shirt-blouse":{file:"blouse.webp",z:32},
  "belt":{file:"Miko-belt.webp",z:33},
  "top-hoodie":{file:"Miko-hoodie.webp",z:34},
  "top-sweater":{file:"Miko-sweater.webp",z:34},
  "outer-black-blazer":{file:"black-blazer.webp",z:34},
  "arm-base":{file:"Miko-base-arm.webp",z:35},
  "top-big-shirt":{file:"Miko-big-shirt.webp",z:36.5},
  "top-button-sleeve":{file:"Miko-button-sleeve.webp",z:36},
  "top-hoodie-sleeve":{file:"Miko-hoodie-sleeve.webp",z:37},
  "top-sweater-sleeve":{file:"Miko-sweater-sleeve.webp",z:37},
  "outer-black-blazer-arm":{file:"black-blazer-arm-piece.webp",z:37},
  "shoes-loafer":{file:"Miko-loafers.webp",z:39},
  "shoes-fancy-loafers":{file:"fancy-loafers.webp",z:39},
  "expression-neutral":{file:"Miko-neutral.webp",z:44},
  "headband":{file:"Miko-headband.webp",z:47},
  "bangs":{file:"Miko-bangs.webp",z:48},
  "bangs-pinned":{file:"Miko-bangs-pinned.webp",z:48},
  "hairpins-black":{file:"black-hairpins.webp",z:49}
});

function currentMikoOutfit(){
  const raw=hubSave.characterOutfits?.miko||{};
  return {
    bangsStyle:["bangs","bangs-pinned"].includes(raw.bangsStyle)?raw.bangsStyle:"bangs",
    shirt:[null,"top-button","shirt-blouse"].includes(raw.shirt)?raw.shirt:"top-button",
    outer:[null,"top-hoodie","top-sweater","top-big-shirt","outer-black-blazer"].includes(raw.outer)?raw.outer:"top-hoodie",
    bottom:["bottom-capris","bottom-jeans","bottom-boxers","bottom-shorts"].includes(raw.bottom)?raw.bottom:"bottom-capris",
    socks:["socks","socks-garter"].includes(raw.socks)?raw.socks:null,
    shoes:[null,"shoes-loafer","shoes-fancy-loafers"].includes(raw.shoes)?raw.shoes:"shoes-loafer",
    extras:Array.isArray(raw.extras)?raw.extras:[]
  };
}

function currentMikoLayerIds(){
  const outfit=currentMikoOutfit();
  const ids=["hair-main","base"];
  if(outfit.outer==="top-hoodie") ids.push("hoodie-back");
  if(outfit.socks) ids.push(outfit.socks);
  if(outfit.bottom) ids.push(outfit.bottom);
  if(outfit.shirt) ids.push(outfit.shirt);
  if(outfit.bottom==="bottom-jeans") ids.push("belt");
  if(outfit.outer) ids.push(outfit.outer);
  ids.push("arm-base");
  if(outfit.shirt==="top-button") ids.push("top-button-sleeve");
  if(outfit.outer==="top-hoodie") ids.push("top-hoodie-sleeve");
  else if(outfit.outer==="top-sweater") ids.push("top-sweater-sleeve");
  else if(outfit.outer==="outer-black-blazer") ids.push("outer-black-blazer-arm");
  if(outfit.shoes) ids.push(outfit.shoes);
  ids.push(...outfit.extras.filter(id=>MIKO_LAYER_MAP[id]));
  ids.push("expression-neutral",outfit.bangsStyle);
  return ids.filter(id=>MIKO_LAYER_MAP[id]).sort((a,b)=>MIKO_LAYER_MAP[a].z-MIKO_LAYER_MAP[b].z);
}

function renderHeroComposite(container,src=heroIdleFrames()[0]){
  if(!container) return;
  let img=container.querySelector("img");
  if(!img){
    container.innerHTML="";
    img=document.createElement("img");
    img.className="quest-composite-sprite pixel-sprite";
    container.appendChild(img);
  }
  img.alt=heroDisplayName();
  setQuestSpriteFrame(img,src);
}


function activeHeroVisual(){
  return activeCharacterId==="peep" ? ui.peepSprite : ui.battleHeroComposite;
}

function renderHeroVisuals(){
  const usesComposite=activeCharacterId!=="peep";
  const isMiko=activeCharacterId==="miko";
  const isIo=activeCharacterId==="io";
  const isMiho=activeCharacterId==="miho";
  const isAnnika=activeCharacterId==="annika";
  const isShiyu=activeCharacterId==="shiyu";
  const isAngel=activeCharacterId==="angel";
  ui.battlefield?.classList.toggle("miko-active",isMiko);
  ui.battlefield?.classList.toggle("io-active",isIo);
  ui.battlefield?.classList.toggle("miho-active",isMiho);
  ui.battlefield?.classList.toggle("annika-active",isAnnika);
  ui.battlefield?.classList.toggle("shiyu-active",isShiyu);
  ui.battlefield?.classList.toggle("angel-active",isAngel);
  const name=heroDisplayName();
  if(ui.heroNameHome) ui.heroNameHome.textContent=name;
  if(ui.heroNameCombat) ui.heroNameCombat.textContent=name;
  if(ui.exploreHeading) ui.exploreHeading.textContent=`Where should ${name} Explore?`;
  if(ui.skillsKicker) ui.skillsKicker.textContent=`${name.toUpperCase()}'S SKILLS`;
  if(ui.skillBookTitle) ui.skillBookTitle.textContent=`${name}'s Skills`;

  ui.menuPeep?.classList.toggle("hidden",usesComposite);
  ui.menuHeroComposite?.classList.toggle("hidden",!usesComposite);
  ui.peepSprite?.classList.toggle("hidden",usesComposite);
  ui.battleHeroComposite?.classList.toggle("hidden",!usesComposite);
  ui.resultPeep?.classList.toggle("hidden",usesComposite);
  ui.resultHeroComposite?.classList.toggle("hidden",!usesComposite);

  if(usesComposite){
    const idle=heroIdleFrames()[0];
    renderHeroComposite(ui.menuHeroComposite,idle);
    renderHeroComposite(ui.battleHeroComposite,idle);
    renderHeroComposite(ui.resultHeroComposite,idle);
  }
  applyQuestIconBorder(ui.heroSpriteWrap, activeCharacterId);
}

function skillDisplayName(skill){ return skill.name; }

function skillDisplayDescription(skill){ return skill.description; }


function availableQuestCharacters(){
  const unlocked=Array.isArray(hubSave.unlockedCharacters)?hubSave.unlockedCharacters:["peep"];
  return QUEST_CHARACTER_IDS.filter(id=>QUEST_NPC_HEROES[id]?npcQuestUnlocked(id):unlocked.includes(id));
}

function closeQuestOcPicker(){
  const modal=document.querySelector('#questCharacterModal');
  modal?.classList.add('hidden');
  modal?.setAttribute('aria-hidden','true');
  ui.switchQuestOc?.setAttribute('aria-expanded','false');
}

function questOcPickerOpen(){
  return Boolean(document.querySelector('#questCharacterModal:not(.hidden)'));
}

function renderQuestOcPicker(){
  if(!ui.questOcPicker) return;
  const names=QUEST_CHARACTER_NAMES;
  ui.questOcPicker.innerHTML="";
  QUEST_CHARACTER_IDS.filter(id=>!QUEST_NPC_HEROES[id] ? availableQuestCharacters().includes(id) : (id==="demon"?Boolean(hubSave?.angelDemonReunion?.firstMet):Boolean(hubSave?.loveInterests?.[id]?.encountered))).forEach(id=>{
    const button=document.createElement("button");
    button.type="button";
    button.className=`quest-oc-choice${id===activeCharacterId?" current":""}`;
    button.dataset.characterId=id;
    button.setAttribute("role","menuitem");
    if(id===activeCharacterId) button.setAttribute("aria-current","true");

    const preview=document.createElement("span");
    preview.className="quest-oc-choice-preview";
    const progress = questSave?.[id] && typeof questSave[id] === "object" ? questSave[id] : defaultCharacterQuestProgress();
    const background = iconBackgroundById(progress.iconBackground || "white");
    applyIconBackgroundStyle(preview, background);

    const sprite=document.createElement("img");
    sprite.className=`quest-oc-choice-sprite pixel-sprite${id==='peep'?' peep':''}`;
    sprite.alt="";
    sprite.src=questCharacterIconPreviewSrc(id);
    preview.append(sprite);
    applyQuestIconBorder(preview, id);

    const labelWrap=document.createElement("span");
    labelWrap.className="quest-oc-choice-copy";
    const label=document.createElement("strong");
    label.textContent=names[id]||id;
    labelWrap.append(label);
    if(id===activeCharacterId){
      const current=document.createElement("small");
      current.textContent="Current";
      labelWrap.append(current);
    }

    if(QUEST_NPC_HEROES[id]){
      const count=Math.max(0,Math.min(10,Math.floor(npcQuestEncounterCount(id))));
      const hint=document.createElement('small');hint.textContent=count>=10?'Playable unlocked ♡':`Encounters ${count}/10 · Locked`;
      labelWrap.append(hint);
      if(count<10){button.disabled=true;button.classList.add('locked');button.setAttribute('aria-disabled','true');}
    }
    button.append(preview,labelWrap);
    if(!button.disabled)button.addEventListener("click",()=>switchQuestCharacter(id));
    ui.questOcPicker.append(button);
  });
}

function renderSwitchOcButton(){
  if(!ui.switchQuestOc) return;
  const available=availableQuestCharacters();
  if(available.length<2 && !QUEST_NPC_IDS.some(id=>id==="demon"?hubSave?.angelDemonReunion?.firstMet:hubSave?.loveInterests?.[id]?.encountered)){
    ui.switchQuestOc.classList.add("hidden");
    closeQuestOcPicker();
    return;
  }
  ui.switchQuestOc.classList.remove("hidden");
  ui.switchQuestOc.textContent="Change Character";
  renderQuestOcPicker();
}

function switchQuestCharacter(characterId){
  if(currentRun) return;
  const available=availableQuestCharacters();
  if(available.length<2) return;
  const requested=available.includes(characterId)?characterId:activeCharacterId;
  if(requested===activeCharacterId){
    closeQuestOcPicker();
    return;
  }
  activeCharacterId=requested;
  questSave.activeCharacter=activeCharacterId;
  const progress=activeHeroProgress();
  selectedArea=AREA_CONFIG[progress.lastArea]?progress.lastArea:"meadow";
  selectedRank=Math.min(areaProgress(selectedArea).unlockedRank,Math.max(1,areaProgress(selectedArea).lastRank||1));
  closeAllIconAppearancePickers();
  closeQuestOcPicker();
  persistAll();
  renderMeta();
}

function buddyDisplayCatalog() {
  ensureBuddySave();
  const byKey=new Map(BUDDY_CATALOG.map(entry=>[entry.key,{...entry}]));
  Object.values(hubSave.buddies.collection||{}).forEach(record=>{
    if(!record?.key) return;
    if(!byKey.has(record.key)) byKey.set(record.key,{...record});
  });
  return [...byKey.values()];
}

function buddyCollectionProgress() {
  const catalog=buddyDisplayCatalog();
  const caught=catalog.filter(entry=>buddyOwnedQuantity(entry.key)>0).length;
  return {caught,total:catalog.length};
}

function renderBuddyHomeCount() {
  const progress=buddyCollectionProgress();
  if(ui.buddyHomeCount) ui.buddyHomeCount.textContent=`${progress.caught} / ${progress.total} befriended`;
}

function closeBuddyDetail() {
  buddyDetailEntryKey="";
  buddyAssignCharacterId="";
  buddyPersonalizeCharacterId="";
  buddyPersonalizeSlotIndex=-1;
  buddyPersonalizeGender="";
  ui.buddyPersonalizePanel?.classList.add("hidden");
  ui.buddyAssignPanel?.classList.add("hidden");
  if(ui.buddyAssignMessage) ui.buddyAssignMessage.textContent="";
  ui.buddyDetail?.classList.add("hidden");
  ui.buddyDetail?.setAttribute("aria-hidden","true");
}

function setBuddyScreenUrl(isOpen) {
  try {
    const url=new URL(window.location.href);
    if(isOpen) url.searchParams.set("screen","buddies");
    else url.searchParams.delete("screen");
    window.history.replaceState(null,"",url);
  } catch {}
}

const BUDDY_ASSIGN_CHARACTER_NAMES = Object.freeze({peep:"Peep",miko:"Miko",io:"Io",miho:"Miho",annika:"Annika",shiyu:"Shiyu",angel:"Angel"});

function buddyRecordByKey(key){
  if(!key) return null;
  return hubSave.buddies?.collection?.[key] || buddyDisplayCatalog().find(entry=>entry.key===key) || null;
}

function buddyEquippedCount(key,excludeCharacterId="",excludeSlotIndex=-1){
  if(!key) return 0;
  ensureBuddySave();
  let count=0;
  for(const characterId of ["peep","miko","io","miho","annika","shiyu","angel"]){
    const slots=hubSave.buddies.equippedByCharacter[characterId] || [];
    slots.forEach((slotKey,index)=>{
      if(characterId===excludeCharacterId && index===excludeSlotIndex) return;
      if(slotKey===key) count+=1;
    });
  }
  return count;
}

function buddyAssignCharacters(){
  const unlocked=Array.isArray(hubSave.unlockedCharacters)?hubSave.unlockedCharacters:["peep"];
  return ["peep","miko","io","miho","annika","shiyu","angel"].map(id=>({id,name:BUDDY_ASSIGN_CHARACTER_NAMES[id],unlocked:unlocked.includes(id)}));
}

function hideBuddyPersonalization(){
  buddyPersonalizeCharacterId="";
  buddyPersonalizeSlotIndex=-1;
  buddyPersonalizeGender="";
  ui.buddyPersonalizePanel?.classList.add("hidden");
  if(ui.buddyPersonalizeMessage) ui.buddyPersonalizeMessage.textContent="";
}

function openBuddyPersonalization(entry,characterId,slotIndex){
  ensureBuddySave();
  const slots=hubSave.buddies.equippedByCharacter[characterId] || [];
  if(!entry || slots[slotIndex]!==entry.key){ hideBuddyPersonalization(); return; }
  buddyPersonalizeCharacterId=characterId;
  buddyPersonalizeSlotIndex=slotIndex;
  const personal=buddySlotPersonalization(characterId,slotIndex);
  buddyPersonalizeGender=String(personal?.gender||"");
  if(ui.buddyPersonalizeSpecies) ui.buddyPersonalizeSpecies.textContent=`${BUDDY_ASSIGN_CHARACTER_NAMES[characterId]}'s ${slotIndex===0?"★ Main Lil Guy":`Lil Guy ${slotIndex+1}`} · ${entry.name}`;
  if(ui.buddyNicknameInput) ui.buddyNicknameInput.value=String(personal?.nickname||"");
  ui.buddyGenderButtons?.forEach(button=>button.classList.toggle("selected",button.dataset.buddyGender===buddyPersonalizeGender));
  if(ui.buddyPersonalizeMessage) ui.buddyPersonalizeMessage.textContent="";
  ui.buddyPersonalizePanel?.classList.remove("hidden");
}

function saveBuddyPersonalization(){
  if(!buddyPersonalizeCharacterId || buddyPersonalizeSlotIndex<0) return;
  ensureBuddySave();
  const slots=hubSave.buddies.equippedByCharacter[buddyPersonalizeCharacterId] || [];
  const key=slots[buddyPersonalizeSlotIndex];
  if(!key) return;
  const nickname=String(ui.buddyNicknameInput?.value||"").trim().slice(0,20);
  const gender=["female","male","nonbinary"].includes(buddyPersonalizeGender)?buddyPersonalizeGender:"";
  hubSave.buddies.personalizationByCharacter[buddyPersonalizeCharacterId][buddyPersonalizeSlotIndex]=nickname||gender?{nickname,gender}:null;
  persistAll();
  const species=buddyRecordByKey(key);
  const shownName=nickname || species?.name || "Lil Guy";
  const entry=buddyRecordByKey(buddyDetailEntryKey);
  if(entry) renderBuddyAssignPanel(entry);
  // Re-open after rerender so the editor remains visible.
  if(entry) openBuddyPersonalization(entry,buddyPersonalizeCharacterId,buddyPersonalizeSlotIndex);
  if(ui.buddyPersonalizeMessage) ui.buddyPersonalizeMessage.textContent=`Saved! ${shownName}${gender?` ${buddyGenderSymbol(gender)}`:""} is ready to adventure. ♡`;
}

function renderBuddyAssignPanel(entry){
  if(!entry || !ui.buddyAssignPanel || !ui.buddyAssignCharacters || !ui.buddyAssignSlots) return;
  ensureBuddySave();
  const owned=buddyOwnedQuantity(entry.key);
  if(owned<=0){
    ui.buddyAssignPanel.classList.add("hidden");
    return;
  }

  const characters=buddyAssignCharacters();
  const unlocked=characters.filter(character=>character.unlocked);
  if(!buddyAssignCharacterId || !unlocked.some(character=>character.id===buddyAssignCharacterId)){
    buddyAssignCharacterId=unlocked.some(character=>character.id===activeCharacterId)
      ? activeCharacterId
      : (unlocked[0]?.id || "peep");
  }

  const totalAssigned=buddyEquippedCount(entry.key);
  const freeCopies=Math.max(0,owned-totalAssigned);
  if(ui.buddyAssignAvailability){
    ui.buddyAssignAvailability.textContent=`Owned ×${owned} · Assigned ×${totalAssigned} · Free ×${freeCopies}`;
  }

  ui.buddyAssignCharacters.innerHTML="";
  characters.forEach(character=>{
    const button=document.createElement("button");
    button.type="button";
    button.className=`buddy-assign-character${buddyAssignCharacterId===character.id?" selected":""}${character.unlocked?"":" locked"}`;
    button.disabled=!character.unlocked;
    button.textContent=character.unlocked?character.name:`${character.name} 🔒`;
    button.addEventListener("click",()=>{
      buddyAssignCharacterId=character.id;
      hideBuddyPersonalization();
      if(ui.buddyAssignMessage) ui.buddyAssignMessage.textContent="";
      renderBuddyAssignPanel(entry);
    });
    ui.buddyAssignCharacters.appendChild(button);
  });

  const slots=hubSave.buddies.equippedByCharacter[buddyAssignCharacterId] || Array(6).fill(null);
  const sameBuddySlots=slots.map((key,index)=>key===entry.key?index:-1).filter(index=>index>=0);
  const canMoveWithinOc=freeCopies<=0 && sameBuddySlots.length>0;
  ui.buddyAssignSlots.innerHTML="";

  slots.forEach((currentKey,index)=>{
    const currentBuddy=buddyRecordByKey(currentKey);
    const personal=buddySlotPersonalization(buddyAssignCharacterId,index);
    const personalName=String(personal?.nickname||"").trim();
    const personalGender=buddyGenderSymbol(personal?.gender);
    const alreadyHere=currentKey===entry.key;
    const canAssign=alreadyHere || freeCopies>0 || canMoveWithinOc;
    const button=document.createElement("button");
    button.type="button";
    button.className=`buddy-assign-slot${index===0?" main":""}${currentBuddy?" occupied":""}${alreadyHere?" assigned":""}`;
    button.disabled=!canAssign;
    button.setAttribute("aria-label",`${index===0?"Main Lil Guy":`Lil Guy slot ${index+1}`}: ${currentBuddy?.name || "Empty"}`);

    const badge=document.createElement("span");
    badge.className="buddy-assign-slot-badge";
    badge.textContent=index===0?"★ Main":String(index+1);

    const art=document.createElement("span");
    art.className="buddy-assign-slot-art";
    if(currentBuddy?.image){
      const img=document.createElement("img");
      img.src=currentBuddy.image;
      img.alt="";
      art.appendChild(img);
    }else{
      art.textContent=currentBuddy?(currentBuddy.shiny?"✨":currentBuddy.boss?"★":"♡"):"+";
    }

    const label=document.createElement("strong");
    const baseLabel=alreadyHere?`${personalName || entry.name} ✓`:(personalName || currentBuddy?.name || "Empty");
    label.textContent=`${baseLabel}${personalGender?` ${personalGender}`:""}`;
    button.append(badge,art,label);
    button.addEventListener("click",()=>assignBuddyFromBook(entry,buddyAssignCharacterId,index));
    ui.buddyAssignSlots.appendChild(button);
  });
}

function assignBuddyFromBook(entry,characterId,slotIndex){
  if(!entry || buddyOwnedQuantity(entry.key)<=0) return;
  ensureBuddySave();
  const unlocked=buddyAssignCharacters().find(character=>character.id===characterId)?.unlocked;
  if(!unlocked) return;

  const slots=hubSave.buddies.equippedByCharacter[characterId];
  const index=Math.max(0,Math.min(5,Number(slotIndex)||0));
  if(slots[index]===entry.key){
    if(ui.buddyAssignMessage) ui.buddyAssignMessage.textContent=`Personalize this ${entry.name} below. ♡`;
    openBuddyPersonalization(entry,characterId,index);
    return;
  }

  const owned=buddyOwnedQuantity(entry.key);
  const assignedElsewhere=buddyEquippedCount(entry.key,characterId,index);
  let personalizationForNewSlot=null;
  if(assignedElsewhere>=owned){
    const moveFrom=slots.findIndex((key,sourceIndex)=>sourceIndex!==index && key===entry.key);
    if(moveFrom>=0){
      personalizationForNewSlot=hubSave.buddies.personalizationByCharacter[characterId]?.[moveFrom] || null;
      slots[moveFrom]=null;
      hubSave.buddies.personalizationByCharacter[characterId][moveFrom]=null;
    }else{
      if(ui.buddyAssignMessage) ui.buddyAssignMessage.textContent=`All ${entry.name} copies are already assigned to other OCs.`;
      renderBuddyAssignPanel(entry);
      return;
    }
  }

  // A freshly assigned copy starts unnamed unless this exact copy was moved
  // from another slot on the same OC, in which case its personalization moves too.
  hubSave.buddies.personalizationByCharacter[characterId][index]=personalizationForNewSlot;
  slots[index]=entry.key;
  hubSave.buddies.equippedByCharacter[characterId]=slots;
  persistAll();
  if(ui.buddyAssignMessage){
    ui.buddyAssignMessage.textContent=`Assigned ${entry.name} to ${BUDDY_ASSIGN_CHARACTER_NAMES[characterId]}'s ${index===0?"★ Main Lil Guy":"Lil Guy "+(index+1)} slot! ♡`;
  }
  renderBuddyAssignPanel(entry);
  openBuddyPersonalization(entry,characterId,index);
}

const BUDDY_AREA_FAMILIES = Object.freeze({
  meadow:["cat-slime","bee","flower","acorn-mouse","catterpillar","porcupin","sock-gremlin","ufono","plushbun","mushroom-cat","tree-squirrel","mimic"],
  ocean:["cool-seagull","sea-turtle","catfish","seaunicorn","sea-star","vampire-squid","jellybun"],
  candy:["apple-baby","gummy-worm","pudding-pig","gingerlolly","candycane-deer","gummy-shark","cream-fox"],
  cloud:["star-mouse","puff-fairy","tulipa","snoud","cloud-bunny","lunar-moth","aries","cherub-duck"],
    city:[],
    spooky:["pumpkitty","webby","voodoo-dollie","vampire-bat","dizzy-mushie","nurse-boo-boo","miss-wick","spider-maid","pumpkin-knight"]
});

const BUDDY_AREA_BY_ENEMY = Object.freeze(Object.fromEntries(
  Object.entries(BUDDY_AREA_FAMILIES).flatMap(([area,ids])=>ids.map(id=>[id,area]))
));

function buddyFamilyEntries(enemyId){
  const entries=buddyDisplayCatalog().filter(entry=>entry.enemyId===enemyId);
  return entries.sort((a,b)=>{
    if(a.shiny!==b.shiny) return a.shiny?1:-1;
    if(a.variantId==="base" && b.variantId!=="base") return -1;
    if(b.variantId==="base" && a.variantId!=="base") return 1;
    return a.name.localeCompare(b.name);
  });
}

function buddyFamilyIconKey(enemyId,preferShiny=false){ return `${enemyId}::${preferShiny?"shiny":"normal"}`; }
function selectedBuddyFamilyIconKey(enemyId,preferShiny=false){
  if(!questSave.buddyFamilyIcons || typeof questSave.buddyFamilyIcons!=="object") questSave.buddyFamilyIcons={};
  return String(questSave.buddyFamilyIcons[buddyFamilyIconKey(enemyId,preferShiny)] || "");
}
function setSelectedBuddyFamilyIcon(entry){
  if(!entry || buddyOwnedQuantity(entry.key)<=0) return false;
  if(!questSave.buddyFamilyIcons || typeof questSave.buddyFamilyIcons!=="object") questSave.buddyFamilyIcons={};
  questSave.buddyFamilyIcons[buddyFamilyIconKey(entry.enemyId,Boolean(entry.shiny))]=entry.key;
  persistAll();
  return true;
}
function buddyFamilyRepresentative(enemyId,preferShiny=false){
  const entries=buddyFamilyEntries(enemyId);
  const relevant=entries.filter(entry=>Boolean(entry.shiny)===Boolean(preferShiny));
  const chosenKey=selectedBuddyFamilyIconKey(enemyId,preferShiny);
  const chosen=relevant.find(entry=>entry.key===chosenKey && buddyOwnedQuantity(entry.key)>0);
  if(chosen) return chosen;
  if(preferShiny) return relevant.find(entry=>buddyOwnedQuantity(entry.key)>0) || relevant[0] || entries[0] || null;
  return relevant.find(entry=>entry.variantId==="base" && buddyOwnedQuantity(entry.key)>0)
    || relevant.find(entry=>buddyOwnedQuantity(entry.key)>0)
    || relevant.find(entry=>entry.variantId==="base")
    || relevant[0] || entries[0] || null;
}

function openBuddyDetail(entry) {
  if(!entry || !ui.buddyDetail) return;
  const owned=buddyOwnedQuantity(entry.key);
  const caught=owned>0;
  buddyDetailEntryKey=entry.key;
  buddyAssignCharacterId=availableQuestCharacters().includes(activeCharacterId)?activeCharacterId:(availableQuestCharacters()[0]||"peep");
  ui.buddyAssignPanel?.classList.add("hidden");
  if(ui.buddyAssignMessage) ui.buddyAssignMessage.textContent="";
  if(ui.buddyAssignOpen){
    ui.buddyAssignOpen.classList.toggle("hidden",!caught);
    ui.buddyAssignOpen.textContent="Assign to OC";
  }
  ui.buddyDetailArt.innerHTML="";
  ui.buddyDetailArt.classList.toggle("unknown",!caught);
  if(entry.image) {
    const img=document.createElement("img");
    img.src=entry.image;
    img.alt="";
    img.decoding="async";
    ui.buddyDetailArt.appendChild(img);
  } else {
    ui.buddyDetailArt.textContent=caught?(entry.shiny?"✨":entry.boss?"★":"♡"):"?";
  }
  ui.buddyDetailTag.textContent=entry.shiny?"SHINY BUDDY ✨":entry.boss?"BOSS BUDDY":"BUDDY";
  ui.buddyDetailName.textContent=caught?entry.name:"???";
  ui.buddyDetailStatus.textContent=caught
    ? `Befriended! You currently own ${owned} ${owned===1?"copy":"copies"}.`
    : "Not befriended yet. Find this form in Duck Quest and use a Lil Pon!";
  ui.buddyDetailOwned.textContent=`×${owned}`;
  ui.buddyDetailType.textContent=entry.shiny?(entry.boss?"Shiny Boss":"Shiny"):entry.boss?"Boss":"Normal";
  const buddySkill=buddySkillForEnemyId(entry.enemyId);
  if(ui.buddyDetailSkill) ui.buddyDetailSkill.innerHTML=buddySkill
    ? `<strong>Lil Guy Skill: ${buddySkill.name}</strong><br>${buddySkill.description}`
    : `<strong>Lil Guy Skill:</strong> No skill assigned yet.`;

  if(ui.buddyFamilyIconActions){
    ui.buddyFamilyIconActions.classList.toggle("hidden",!caught);
    if(caught){
      const isMain=selectedBuddyFamilyIconKey(entry.enemyId,Boolean(entry.shiny))===entry.key;
      if(ui.setBuddyFamilyIcon){
        ui.setBuddyFamilyIcon.disabled=isMain;
        ui.setBuddyFamilyIcon.textContent=isMain?(entry.shiny?"✓ Shiny Book Icon":"✓ Book Icon"):(entry.shiny?"Use as Shiny Icon":"Use as Book Icon");
      }
      if(ui.buddyFamilyIconStatus) ui.buddyFamilyIconStatus.textContent=isMain
        ? "This form currently represents the family in your Lil Guy Book."
        : "Use this befriended form as the family portrait in your Lil Guy Book.";
    }
  }

  if(ui.buddyDetailVariants){
    ui.buddyDetailVariants.innerHTML="";
    buddyFamilyEntries(entry.enemyId).forEach(variant=>{
      const variantOwned=buddyOwnedQuantity(variant.key)>0;
      const button=document.createElement("button");
      button.type="button";
      const isBookIcon=selectedBuddyFamilyIconKey(variant.enemyId,Boolean(variant.shiny))===variant.key;
      button.className=`buddy-variant-button${variant.key===entry.key?" selected":""}${variantOwned?" caught":" unknown"}${variant.shiny?" shiny":""}${isBookIcon?" book-icon":""}`;
      button.setAttribute("aria-label",variantOwned?variant.name:"Undiscovered form");
      button.title=variantOwned?variant.name:"???";
      if(variant.image){
        const img=document.createElement("img");
        img.src=variant.image;
        img.alt="";
        img.loading="lazy";
        img.decoding="async";
        button.appendChild(img);
      }else button.textContent=variantOwned?"♡":"?";
      button.addEventListener("click",()=>openBuddyDetail(variant));
      ui.buddyDetailVariants.appendChild(button);
    });
  }

  ui.buddyDetail.classList.remove("hidden");
  ui.buddyDetail.setAttribute("aria-hidden","false");
}

function renderBuddyCollection() {
  ensureBuddySave();
  const progress=buddyCollectionProgress();
  if(ui.buddyCollectionCount) ui.buddyCollectionCount.textContent=`${progress.caught} / ${progress.total}`;
  renderBuddyHomeCount();
  ui.buddyFilters.forEach(button=>button.classList.toggle("selected",button.dataset.buddyFilter===buddyCollectionFilter));

  const shinyTab=buddyCollectionFilter==="shiny";
  const familyIds=shinyTab
    ? [...new Set(Object.keys(SHINY_VARIANTS).filter(id=>buddyFamilyEntries(id).some(entry=>entry.shiny)))]
    : (BUDDY_AREA_FAMILIES[buddyCollectionFilter] || BUDDY_AREA_FAMILIES.meadow);

  ui.buddyCollectionGrid.innerHTML="";
  familyIds.forEach(enemyId=>{
    const family=buddyFamilyEntries(enemyId);
    const relevant=shinyTab?family.filter(entry=>entry.shiny):family.filter(entry=>!entry.shiny);
    if(!relevant.length) return;
    const representative=buddyFamilyRepresentative(enemyId,shinyTab);
    if(!representative) return;
    const caughtEntries=relevant.filter(entry=>buddyOwnedQuantity(entry.key)>0);
    const caughtAny=caughtEntries.length>0;
    const familyName=String(ENEMIES[enemyId]?.name || representative.name || "Lil Guy");
    const button=document.createElement("button");
    button.type="button";
    button.className=`buddy-tile buddy-family-tile${caughtAny?" caught":" unknown"}${representative.boss?" boss":""}${shinyTab?" shiny":""}`;
    button.setAttribute("aria-label",caughtAny?`${familyName}, ${caughtEntries.length} forms befriended`:`Undiscovered ${familyName}`);

    const art=document.createElement("span");
    art.className="buddy-tile-art";
    if(representative.image){
      const img=document.createElement("img");
      img.src=representative.image;
      img.alt="";
      img.loading="lazy";
      img.decoding="async";
      art.appendChild(img);
    }else art.textContent=caughtAny?(shinyTab?"✨":representative.boss?"★":"♡"):"?";

    const name=document.createElement("strong");
    name.textContent=caughtAny?`${familyName}${shinyTab?" ✨":""}`:"???";
    const state=document.createElement("small");
    state.textContent=shinyTab
      ? (caughtAny?"Shiny befriended":"Shiny undiscovered")
      : `${caughtEntries.length} / ${relevant.length} forms`;
    const badge=document.createElement("span");
    badge.className="buddy-tile-badge";
    badge.textContent=shinyTab?"✨":representative.boss?"★":caughtAny?"♡":"?";

    button.append(art,name,state,badge);
    button.addEventListener("click",()=>openBuddyDetail(representative));
    ui.buddyCollectionGrid.appendChild(button);
  });

  const empty=!ui.buddyCollectionGrid.children.length;
  ui.buddyCollectionEmpty?.classList.toggle("hidden",!empty);
  if(empty && ui.buddyCollectionEmpty) ui.buddyCollectionEmpty.textContent="No Lil Guy families are available in this tab yet.";
}

function closeRoutePicker(){
  ui.routeStartLevelPicker?.classList.add("hidden");
  ui.startBeginningRoute?.setAttribute("aria-expanded","false");
  ui.routePickerModal?.classList.add("hidden");
  ui.routePickerModal?.setAttribute("aria-hidden","true");
}

function syncStartingPointButton(){
  if(!ui.routeStartLevelSelect||!ui.startSelectedRoute) return;
  const level=Math.max(1,Number(ui.routeStartLevelSelect.value)||1);
  ui.startSelectedRoute.textContent=`Start Level ${level}`;
}

function populateStartingPointPicker(progress){
  if(!ui.routeStartLevelSelect) return;
  const latest=Math.max(1,Math.floor(Number(progress?.unlockedRank)||1));
  const previous=Math.max(1,Math.min(latest,Math.floor(Number(progress?.lastRank)||latest)));
  ui.routeStartLevelSelect.innerHTML="";
  for(let level=1;level<=latest;level++){
    const option=document.createElement("option");
    option.value=String(level);
    option.textContent=`Level ${level}`;
    ui.routeStartLevelSelect.appendChild(option);
  }
  ui.routeStartLevelSelect.value=String(previous);
  syncStartingPointButton();
}

// v24.349: opt-in restoration of Miko's previously documented City Level 4.
// No automatic grants to fresh saves; never lower an existing City level.
function offerMikoCityRecoveryV349(){
  const card=ui.routePickerModal?.querySelector('.route-picker-modal-card');
  if(!card)return;
  card.querySelector('[data-city-recovery-v349]')?.remove();
  if(selectedArea!=='city'||activeCharacterId!=='miko')return;
  const city=areaProgress('city');
  if((Number(city?.unlockedRank)||1)>=4||questSave.mikoCityLevel4RecoveryV349)return;
  const button=document.createElement('button');
  button.type='button';
  button.className='pixel-button';
  button.dataset.cityRecoveryV349='1';
  button.style.cssText='width:100%;margin-top:9px;min-height:44px;white-space:normal;padding:8px;font-size:.73rem;';
  button.textContent='Restore Miko’s City Level 4 ♡';
  button.addEventListener('click',()=>{
    if(currentRun||selectedArea!=='city'||activeCharacterId!=='miko')return;
    const progress=areaProgress('city');
    progress.unlockedRank=Math.max(4,Number(progress.unlockedRank)||1);
    progress.lastRank=Math.max(4,Math.min(progress.unlockedRank,Number(progress.lastRank)||1));
    activeHeroProgress().lastArea='city';
    questSave.mikoCityLevel4RecoveryV349=true;
    persistAll();
    openRoutePicker('city');
  });
  card.appendChild(button);
}

function openRoutePicker(areaId){
  if(!AREA_CONFIG[areaId] || currentRun) return;
  selectedArea=areaId;
  activeHeroProgress().lastArea=areaId;
  const cfg=getAreaConfig(areaId);
  const progress=areaProgress(areaId);
  selectedRank=Math.max(1,Math.min(cfg.maxRank,progress.unlockedRank||1));
  if(ui.routeModalImage){ ui.routeModalImage.src=cfg.backgrounds[0]; ui.routeModalImage.alt=`${cfg.name} preview`; }
  if(ui.routeModalTitle) ui.routeModalTitle.textContent=cfg.name;
  if(ui.routeModalRange) ui.routeModalRange.textContent=`Levels 1–${cfg.maxRank}`;
  if(ui.routeModalCurrentRank) ui.routeModalCurrentRank.textContent=String(progress.unlockedRank||1);
  populateStartingPointPicker(progress);
  offerMikoCityRecoveryV349();
  ui.routeStartLevelPicker?.classList.add("hidden");
  ui.startBeginningRoute?.setAttribute("aria-expanded","false");
  persistAll();
  renderMeta();
  ui.routePickerModal?.classList.remove("hidden");
  ui.routePickerModal?.setAttribute("aria-hidden","false");
}

function openSkillBook(){
  if(currentRun) return;
  renderMenuSkills();
  ui.skillBookModal?.classList.remove("hidden");
  ui.skillBookModal?.setAttribute("aria-hidden","false");
}

function closeSkillBook(){
  ui.skillBookModal?.classList.add("hidden");
  ui.skillBookModal?.setAttribute("aria-hidden","true");
}

let affectionToastTimer=null;
function showAffectionUnlockToast(title,text){
  if(!ui.affectionUnlockToast) return;
  clearTimeout(affectionToastTimer);
  if(ui.affectionUnlockTitle) ui.affectionUnlockTitle.textContent=title;
  if(ui.affectionUnlockText) ui.affectionUnlockText.textContent=text;
  ui.affectionUnlockToast.classList.remove("hidden");
  affectionToastTimer=setTimeout(()=>ui.affectionUnlockToast?.classList.add("hidden"),3200);
}

function maybeShowAffectionMilestone(hLevel){
  const hero=activeHeroProgress();
  if(!hero.affectionMilestonesSeen || typeof hero.affectionMilestonesSeen!=="object") hero.affectionMilestonesSeen={five:false,ten:false};
  if(hLevel>=100 && !hero.affectionMilestonesSeen.ten){
    hero.affectionMilestonesSeen.five=true;
    hero.affectionMilestonesSeen.ten=true;
    persistAll();
    showAffectionUnlockToast("10 Hearts!","+25% Pink Coins & EXP from battles!");
    return;
  }
  if(hLevel>=50 && !hero.affectionMilestonesSeen.five){
    hero.affectionMilestonesSeen.five=true;
    persistAll();
    showAffectionUnlockToast("5 Hearts!","+10% Pink Coins & EXP from battles!");
  }
}

function renderMeta() {
  applyQuestUiTheme();
  renderSwitchOcButton();
  renderIconBackgroundPicker();
  renderIconBorderPicker();
  renderIconBorderColorPicker();
  ui.coinCount.textContent=hubSave.coins.toLocaleString();
  const hero=activeHeroProgress(); renderHeroVisuals();
  ui.levelBadge.textContent=`Lv. ${hero.level}`;
  const need=expNeeded(hero.level);
  ui.xpText.textContent=hero.level>=MAX_LEVEL?"MAX LEVEL":`${Math.floor(hero.exp)} / ${need} EXP`;
  ui.xpFill.style.width=hero.level>=MAX_LEVEL?"100%":`${Math.min(100,(hero.exp/need)*100)}%`;
  const hLevel=QUEST_NPC_HEROES[activeCharacterId]?taskBuddyHappiness(activeCharacterId):happinessLevelFromTotal(hubSave.characterProgress?.[activeCharacterId]?.happinessTotal);
  ui.happinessLevel.textContent=`Lv. ${hLevel}`; ui.happinessHearts.innerHTML="";
  const filled=Math.max(0,Math.min(10,Math.floor(hLevel/10)));
  for(let i=1;i<=10;i++){const heart=document.createElement("span");heart.textContent="♥";heart.className=i<=filled?"heart-full":"heart-empty";ui.happinessHearts.appendChild(heart);}
  maybeShowAffectionMilestone(hLevel);

  const cfg=getAreaConfig(selectedArea);
  const progress=areaProgress(selectedArea);
  selectedRank=Math.min(Math.max(1,selectedRank),progress.unlockedRank);
  ui.areaButtons.forEach(btn=>btn.classList.toggle("selected",btn.dataset.area===selectedArea));

  const endless=hero.endless || {record:0,checkpoint:1};
  if(ui.endlessRecord) ui.endlessRecord.textContent=`Floor ${Math.max(0,Number(endless.record)||0)}`;
  if(ui.endlessCheckpoint) ui.endlessCheckpoint.textContent=`Floor ${Math.max(1,Number(endless.checkpoint)||1)}`;
  if(ui.endlessRuns) ui.endlessRuns.textContent=String(Math.max(0,Math.floor(Number(questSave.endlessRunsCompleted)||0)));
  if(ui.continueEndless){
    const checkpoint=Math.max(1,Number(endless.checkpoint)||1);
    ui.continueEndless.textContent=`Continue from Floor ${checkpoint}`;
    ui.continueEndless.disabled=checkpoint<=1 && Math.max(0,Number(endless.record)||0)===0;
  }

  renderBuddyHomeCount();
  renderCharmHome();
  renderMenuSkills();
}

function rankWord(rank) {
  const ones=["Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"];
  const tens=["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"];
  const n=Math.max(1,Math.min(160,Math.round(Number(rank)||1)));
  if(n<20) return ones[n];
  if(n<100){ const ten=Math.floor(n/10),one=n%10; return one ? `${tens[ten]}-${ones[one]}` : tens[ten]; }
  if(n===100) return "One Hundred";
  return `One Hundred ${rankWord(n-100)}`;
}

function rankDescription(rank,areaId=selectedArea) {
  if(areaId==="spooky")return `Spooky Forest Level ${rank} · The haunted woods are full of surprises!`;
  if(areaId==="city"){
    if(rank<=1)return "City Streets Level 1 · The neighborhood is full of surprises!";
    if(rank<200)return `City Streets Level ${rank} · Something curious is stirring along the sidewalks.`;
    return "City Streets Level 200 · The City Crossroads finale is here!";
  }
  if(areaId==="cloud"){
    if(rank<=1) return "Cloud Garden Level 1 · The stairs are soft and sparkly.";
    if(rank<=35) return `Cloud Garden Level ${rank} · New celestial colors are drifting in.`;
    if(rank<=75) return `Cloud Garden Level ${rank} · The garden is growing stronger.`;
    if(rank<=120) return `Cloud Garden Level ${rank} · Elite sky creatures are appearing.`;
    if(rank<160) return `Cloud Garden Level ${rank} · The Star Sanctuary is close.`;
    return `Cloud Garden Level 160 · The Star Sanctuary is waiting. Give it everything you have!`;
  }
  if(areaId==="candy"){
    if(rank<=1) return "Candyland Level 1 · Lollipop Lane is sweet and deceptively calm.";
    if(rank<=30) return `Candyland Level ${rank} · New candy colors are appearing.`;
    if(rank<=65) return `Candyland Level ${rank} · The gumdrop creatures are getting tougher.`;
    if(rank<=95) return `Candyland Level ${rank} · Candycane Bridge is getting dangerous.`;
    if(rank<120) return `Candyland Level ${rank} · The Chocolate Lake is getting close.`;
    return `Candyland Level 120 · The Chocolate Lake finale is here. Something special may be waiting!`;
  }
  if(areaId==="ocean"){
    if(rank<=1) return "Ocean Level 1 · The shore is calm... for now.";
    if(rank<=18) return `Ocean Level ${rank} · New colors are beginning to appear.`;
    if(rank<=38) return `Ocean Level ${rank} · Special enemy moves are joining the tide.`;
    if(rank<=58) return `Ocean Level ${rank} · Deep-water enemies are much tougher.`;
    if(rank<80) return `Ocean Level ${rank} · Elite colors are beginning to surface.`;
    return `Ocean Level 80 · The deepest route is here. A surprise waits beyond the clear!`;
  }
  if(rank<=1) return "Level 1 · A gentle place to begin.";
  if(rank<=6) return `Level ${rank} · Enemies are starting to toughen up.`;
  if(rank<=12) return `Level ${rank} · A proper challenge. Better loot too!`;
  if(rank<=20) return `Level ${rank} · The meadow is getting dangerous.`;
  return rank>=40 ? `Level 40 · The final clearing is here. Something special may be waiting!` : `Level ${rank} · High-risk, high-reward territory.`;
}

function renderMenuSkills() {
  if(!ui.menuSkills) return;
  ui.menuSkills.innerHTML="";
  sortedActiveSkills().forEach(skill=>{
    const el=document.createElement("div");
    const unlocked=activeHeroProgress().level>=skill.unlock;
    el.className=`skill-summary${unlocked?"":" locked"}`;
    const status=unlocked?"Unlocked":`Unlocks at Lv. ${skill.unlock}`;
    el.innerHTML=`<div class="skill-summary-title"><strong>${skillDisplayName(skill)}</strong><small>${status}</small></div><span>${skillDisplayDescription(skill)}</span>`;
    ui.menuSkills.appendChild(el);
  });
}

function makeStageEncounter(enemyPool){
  if(Math.random()<.07) return {type:"enemy",enemyId:"porcupin"};
  return buildEncounterFromPool(enemyPool,"stage");
}

function makeEncounterPlan(rank,areaId=selectedArea) {
  if(areaId==="candy"){
    const stagePools=[
      ["apple-baby","gummy-worm"],
      ["pudding-pig","gingerlolly"],
      ["candycane-deer","gingerlolly"]
    ];
    const encounters=stagePools.map(pool=>makeStageEncounter(pool));
    const candyBosses=["gummy-shark","cream-fox"];
    encounters.push({type:"boss",enemyId:candyBosses[randInt(0,candyBosses.length-1)]});
    return encounters;
  }
  if(areaId==="cloud"){
    const stagePools=[
      ["star-mouse","puff-fairy"],
      ["tulipa","snoud"],
      ["cloud-bunny","lunar-moth"]
    ];
    const encounters=stagePools.map(pool=>makeStageEncounter(pool));
    const cloudBosses=["aries","cherub-duck"];
    encounters.push({type:"boss",enemyId:cloudBosses[randInt(0,cloudBosses.length-1)]});
    return encounters;
  }
  if(areaId==="ocean"){
    const stagePools=[
      ["cool-seagull","sea-turtle","seaunicorn","sea-star"],
      ["cool-seagull","sea-turtle","seaunicorn","sea-star"],
      ["catfish","sea-turtle","seaunicorn","sea-star"]
    ];
    const encounters=stagePools.map(pool=>makeStageEncounter(pool));
    const oceanBosses=["vampire-squid","jellybun"];
    encounters.push({type:"boss",enemyId:oceanBosses[randInt(0,oceanBosses.length-1)]});
    return encounters;
  }

  const stagePools=[
    ["bee","cat-slime","acorn-mouse","catterpillar"],
    ["cat-slime","flower","acorn-mouse","catterpillar"],
    ["bee","flower","cat-slime","acorn-mouse","catterpillar"]
  ];
  const encounters=stagePools.map(pool=>makeStageEncounter(pool));
  const meadowBosses=["mushroom-cat","tree-squirrel"];
  encounters.push({type:"boss",enemyId:meadowBosses[randInt(0,meadowBosses.length-1)]});
  return encounters;
}

function endlessProgress(){
  const hero=activeHeroProgress();
  if(!hero.endless || typeof hero.endless!=="object") hero.endless={record:0,checkpoint:1};
  hero.endless.record=Math.max(0,Math.floor(Number(hero.endless.record)||0));
  hero.endless.checkpoint=Math.max(1,Math.floor(Number(hero.endless.checkpoint)||1));
  return hero.endless;
}

function endlessEffectiveRank(floor){
  return Math.max(1,Math.min(999,1+Math.floor((Math.max(1,floor)-1)/2)));
}

function endlessEnemyScaled(template,floor){
  const cappedFloor=Math.min(1997,Math.max(1,Number(floor)||1));
  const block=Math.floor((cappedFloor-1)/5);
  const hpScale=1+block*.05;
  const atkScale=1+block*.04;
  const rewardScale=1+block*.05;
  return {
    ...template,
    maxHp:Math.max(1,Math.round(template.hp*hpScale)),
    hpNow:Math.max(1,Math.round(template.hp*hpScale)),
    attackNow:Math.max(1,Math.round(template.attack*atkScale)),
    expNow:Math.max(1,Math.round(template.exp*rewardScale)),
    coinMinNow:Math.max(1,Math.round(template.coinMin*rewardScale)),
    coinMaxNow:Math.max(1,Math.round(template.coinMax*rewardScale))
  };
}

function makeEndlessEncounter(floor){
  const f=Math.max(1,Math.floor(Number(floor)||1));
  if(f%5===0){
    return {type:"boss",enemyId:ENDLESS_BOSSES[randInt(0,ENDLESS_BOSSES.length-1)]};
  }
  return buildEncounterFromPool(ENDLESS_NORMAL_ENEMIES,"endless");
}

function chooseEndlessBackground(previous=""){
  const choices=ENDLESS_BACKGROUNDS.filter(path=>path!==previous);
  return (choices.length?choices:ENDLESS_BACKGROUNDS)[randInt(0,(choices.length?choices:ENDLESS_BACKGROUNDS).length-1)];
}

function beginEndlessRun(startFloor=1){
  const stats=peepStats();
  const floor=Math.max(1,Math.floor(Number(startFloor)||1));
  const progress=endlessProgress();
  progress.checkpoint=floor;
  endlessExitReason="";
  currentRun={
    mode:"endless",floor,rank:endlessEffectiveRank(floor),area:"endless",index:0,plan:[],
    endlessEncounter:makeEndlessEncounter(floor),floorBackground:chooseEndlessBackground(),
    hp:stats.maxHp,maxHp:stats.maxHp,coinsEarned:0,expEarned:0,happinessEarned:0,itemsEarned:[],iconBackgroundsEarned:[],iconBorderStylesEarned:[],iconBorderColorsEarned:[],wallpapersEarned:[],closetRewardsEarned:[],uiThemesEarned:[],levelBackgroundsEarned:[],levelsGained:[],bossWon:false,
    endlessFloorsCompleted:0,endlessRunCounted:false
  };
  persistAll();
  showScreen("battle");
  startEncounter();
}


function openEscapeConfirm() {
  if (!currentRun || actionLocked) return;
  if(currentRun.mode==="endless"){
    const checkpoint=endlessProgress().checkpoint;
    ui.escapeConfirmText.textContent=`Leave Endless Run? Floor ${checkpoint} will stay saved as your checkpoint, and your record will not be erased.`;
    ui.confirmEscapeButton.textContent="Leave Endless";
  } else {
    ui.escapeConfirmText.textContent="Are you sure? Your current run will end.";
    ui.confirmEscapeButton.textContent="Escape Run";
  }
  ui.escapeConfirm.classList.remove("hidden");
  ui.escapeConfirm.setAttribute("aria-hidden", "false");
}

function closeEscapeConfirm() {
  ui.escapeConfirm.classList.add("hidden");
  ui.escapeConfirm.setAttribute("aria-hidden", "true");
}

function confirmEscapeRun() {
  closeEscapeConfirm();
  if(currentRun?.mode==="endless") endlessExitReason="paused";
  endRun(false);
}

function beginRun() {
  const stats=peepStats();
  const cfg=getAreaConfig(selectedArea);
  const progress=areaProgress(selectedArea);
  selectedRank=Math.min(Math.max(1,selectedRank),progress.unlockedRank);
  endlessExitReason="";
  currentRun={
    mode:"normal",area:selectedArea,rank:selectedRank,index:0,plan:makeEncounterPlan(selectedRank,selectedArea),
    hp:stats.maxHp,maxHp:stats.maxHp,coinsEarned:0,expEarned:0,happinessEarned:0,itemsEarned:[],iconBackgroundsEarned:[],iconBorderStylesEarned:[],iconBorderColorsEarned:[],wallpapersEarned:[],closetRewardsEarned:[],uiThemesEarned:[],levelBackgroundsEarned:[],levelsGained:[],bossWon:false
  };
  progress.lastRank=selectedRank; activeHeroProgress().lastArea=selectedArea; persistAll();
  showScreen("battle"); startEncounter();
}

function showScreen(which) {
  if(which!=="home"){ closeRoutePicker(); closeSkillBook(); }
  ui.home.classList.toggle("hidden", which!=="home");
  ui.charm?.classList.toggle("hidden", which!=="charm");
  ui.buddy?.classList.toggle("hidden", which!=="buddy");
  ui.battle.classList.toggle("hidden", which!=="battle");
  ui.result.classList.toggle("hidden", which!=="result");
  if(which==="buddy") renderBuddyCollection();
  if(which==="charm") renderCharmScreen();
}

function startEncounter() {
  clearAnimations();
  actionLocked=false;
  pendingChest=null;
  pendingDefeatedEnemy=null;
  befriendAttempted=false;
  ui.befriendPanel?.classList.add("hidden");
  ui.ponPurchasePanel?.classList.add("hidden");
  quickHealUses=0;
  skillState={
    cooldowns:{}, onceUsed:{}, attackBuffTurns:0, attackBuffMultiplier:1.30, activeBuffSkillId:null,
    heartRayCount:0, ioRainbowUses:0, buddyCooldown:0,
    buddyAttackBuffTurns:0, buddyAttackMultiplier:1.15,
    heroGuardTurns:0, heroGuardMultiplier:1,
    heroNextDamageMultiplier:1,
    enemyAttackDownTurns:0, enemyAttackMultiplier:1,
    enemyDefenseDownTurns:0, enemyDefenseMultiplier:1,
    enemyAccuracyDownTurns:0, enemyMissChance:0,
    enemyBurnTurns:0, enemyBurnDamagePercent:0,
    heroMissTurns:0, heroMissChance:0,
    heroNextAttackMultiplier:1, heroAttackDownTurns:0, heroAttackDownMultiplier:1,
    heroStunTurns:0, heroSleepTurns:0, heroParalysisMoves:0, heroParalysisFailChance:0,
    enemyNextAttackMultiplier:1, enemyStunned:false, enemyStunTurns:0
  };
  specialHeroAttackScale=1;
  currentRun.luckyFluffUsedThisEncounter=false;
  buddyUsedThisHeroTurn=false;
  activeBattleBuddySlot=firstAssignedBattleBuddySlot();
  buddySwitchUsedThisEncounter=false;
  renderBattleCharmStrip();
  resetDoubleBattleUi();
  hideEventChoices();
  ui.enemyCombatant2?.classList.add("hidden");
  ui.chestLayer.classList.add("hidden");
  ui.postFloorActions?.classList.add("hidden");
  ui.leaveEndlessButton?.classList.add("hidden");
  setPostFloorLayout(false);
  ui.commandGrid.classList.remove("hidden");
  closeCommandWindow();
  ui.enemyCombatant.classList.remove("hidden");
  ui.buddyCombatant?.classList.add("hidden");

  const isEndless=currentRun?.mode==="endless";
  const encounter=isEndless ? currentRun.endlessEncounter : currentRun.plan[currentRun.index];

  if(isEndless){
    currentRun.rank=endlessEffectiveRank(currentRun.floor);
    if(!currentRun.floorBackground) currentRun.floorBackground=chooseEndlessBackground();
    setQuestSpriteFrame(ui.battleBg,currentRun.floorBackground);
    const oceanish=String(currentRun.floorBackground).includes('/ocean/');
    ui.battlefield.classList.toggle("ocean-peep-raised",oceanish && !String(currentRun.floorBackground).includes('/floor.'));
  } else {
    const cfg=currentAreaConfig();
    setQuestSpriteFrame(ui.battleBg,cfg.backgrounds[currentRun.index]);
    ui.battlefield.classList.toggle("ocean-peep-raised", currentRun.area==="ocean" && (currentRun.index===1 || currentRun.index===2));
  }
  updateEncounterHeader(encounter);

  ui.peepLevelCombat.textContent=`Lv. ${activeHeroProgress().level}`;
  renderPeepHp();
  startPeepIdle();

  if(encounter.type==="mystery-chest") {
    currentEnemy=null;
    ui.enemyCombatant.classList.add("hidden");
    ui.enemyCombatant2?.classList.add("hidden");
    ui.commandGrid.classList.add("hidden");
    closeCommandWindow();
    showChest({kind:"mystery", mystery:true, revealMimic:false});
    setMessage("A strange purple chest appeared... Jackpot or trouble?");
    return;
  }

  if(encounter.type==="rare-chest") {
    currentEnemy=null;
    ui.enemyCombatant.classList.add("hidden");
    ui.enemyCombatant2?.classList.add("hidden");
    ui.commandGrid.classList.add("hidden");
    closeCommandWindow();
    showChest({kind:"rare", revealMimic:false});
    setMessage("A rare treasure chest appeared instead of an enemy!");
    return;
  }

  if(encounter.type==="mimic") {
    currentEnemy=null;
    ui.enemyCombatant.classList.add("hidden");
    ui.enemyCombatant2?.classList.add("hidden");
    ui.commandGrid.classList.add("hidden");
    closeCommandWindow();
    showChest({kind:"mimic", revealMimic:true});
    setMessage("A treasure chest appeared!");
    return;
  }

  if(encounter.type==="lucky-picnic"){
    currentEnemy=null;
    ui.enemyCombatant.classList.add("hidden");
    ui.enemyCombatant2?.classList.add("hidden");
    ui.commandGrid.classList.add("hidden");
    closeCommandWindow();
    showChest({kind:"event", eventType:"lucky-picnic", captionText:"Lucky Picnic! Your buddy found a cozy snack spot."});
    ui.openChest.classList.add("hidden");
    setMessage("You found a Lucky Picnic! What should you do?");
    showEventChoices("lucky-picnic");
    return;
  }

  if(encounter.type==="wishing-fountain"){
    currentEnemy=null;
    ui.enemyCombatant.classList.add("hidden");
    ui.enemyCombatant2?.classList.add("hidden");
    ui.commandGrid.classList.add("hidden");
    closeCommandWindow();
    showChest({kind:"event", eventType:"wishing-fountain", captionText:"Wishing Fountain! Toss in a wish and see what happens."});
    ui.openChest.classList.add("hidden");
    setMessage("You found a Wishing Fountain! What would you like to wish for?");
    showEventChoices("wishing-fountain");
    return;
  }

  if(encounter.type==="double-enemy"){
    if(!Array.isArray(encounter.enemyIds) || encounter.enemyIds.length<2) encounter.enemyIds=pickEncounterEnemies(isEndless?ENDLESS_NORMAL_ENEMIES:["bee","cat-slime"],2);
    encounter.defeatedEnemies=[];
    startDoubleBattle(encounter.enemyIds);
    return;
  }

  ui.battlefield?.classList.remove("double-battle");
  ui.enemyCombatant2?.classList.add("hidden");
  startEnemy(encounter.enemyId);
}

function playShinyArrivalSparkle(target){
  if(!target) return;
  target.querySelectorAll(".shiny-arrival-burst").forEach(node=>node.remove());
  const burst=document.createElement("span");
  burst.className="shiny-arrival-burst";
  burst.setAttribute("aria-hidden","true");
  const stars=[
    ["✦","8%","14%","0s"],["✨","28%","5%",".08s"],["★","52%","1%",".16s"],
    ["✧","76%","8%",".04s"],["✨","94%","24%",".20s"],["✦","98%","52%",".10s"],
    ["★","88%","78%",".28s"],["✧","66%","92%",".14s"],["✨","43%","96%",".32s"],
    ["✦","20%","88%",".22s"],["★","3%","72%",".12s"],["✨","0%","44%",".26s"],
    ["✧","24%","48%",".34s"],["✦","72%","46%",".38s"]
  ];
  stars.forEach(([glyph,left,top,delay],index)=>{
    const star=document.createElement("span");
    star.className="shiny-arrival-star";
    star.textContent=glyph;
    star.style.left=left; star.style.top=top; star.style.animationDelay=delay;
    star.style.setProperty("--sparkle-rotate",`${index%2?22:-22}deg`);
    burst.appendChild(star);
  });
  target.appendChild(burst);
  setTimeout(()=>burst.remove(),1900);
}

function renderEnemyName(enemy) {
  renderEnemyNameFor(enemy,enemySlot(enemy));
}


function startEnemy(enemyId, options={}) {
  const baseTemplate=ENEMIES[enemyId];
  const variantRank=currentRun?.mode==="endless" ? endlessEffectiveRank(currentRun.floor) : currentRun.rank;
  const normalTemplate =
    enemyId==="mushroom-cat" ? applyMushroomVariant(baseTemplate,variantRank) :
    enemyId==="bee" ? applyBeeVariant(baseTemplate,variantRank) :
    enemyId==="cat-slime" ? applyCatSlimeVariant(baseTemplate,variantRank) :
    enemyId==="flower" ? applyFlowerVariant(baseTemplate,variantRank) :
    enemyId==="cool-seagull" ? applySeagullVariant(baseTemplate,variantRank) :
    enemyId==="sea-turtle" ? applyTurtleVariant(baseTemplate,variantRank) :
    enemyId==="catfish" ? applyCatfishVariant(baseTemplate,variantRank) :
    enemyId==="vampire-squid" ? applySquidVariant(baseTemplate,variantRank) :
    enemyId==="acorn-mouse" ? applyAcornMouseVariant(baseTemplate,variantRank) :
    enemyId==="seaunicorn" ? applySeaunicornVariant(baseTemplate,variantRank) :
    enemyId==="tree-squirrel" ? applyTreeSquirrelVariant(baseTemplate,variantRank) :
    enemyId==="jellybun" ? applyJellybunVariant(baseTemplate,variantRank) :
    enemyId==="catterpillar" ? applyCatterpillarVariant(baseTemplate,variantRank) :
    enemyId==="sea-star" ? applySeaStarVariant(baseTemplate,variantRank) :
    enemyId==="apple-baby" ? applyAppleBabyVariant(baseTemplate,variantRank) :
    enemyId==="gummy-worm" ? applyGummyWormVariant(baseTemplate,variantRank) :
    enemyId==="pudding-pig" ? applyPuddingPigVariant(baseTemplate,variantRank) :
    enemyId==="gingerlolly" ? applyGingerlollyVariant(baseTemplate,variantRank) :
    enemyId==="candycane-deer" ? applyCandycaneDeerVariant(baseTemplate,variantRank) :
    enemyId==="gummy-shark" ? applyGummySharkVariant(baseTemplate,variantRank) :
    enemyId==="cream-fox" ? applyCreamFoxVariant(baseTemplate,variantRank) :
    enemyId==="star-mouse" ? applyStarMouseVariant(baseTemplate,variantRank) :
    enemyId==="puff-fairy" ? applyPuffFairyVariant(baseTemplate,variantRank) :
    enemyId==="tulipa" ? applyTulipaVariant(baseTemplate,variantRank) :
    enemyId==="snoud" ? applySnoudVariant(baseTemplate,variantRank) :
    enemyId==="cloud-bunny" ? applyCloudBunnyVariant(baseTemplate,variantRank) :
    enemyId==="lunar-moth" ? applyLunarMothVariant(baseTemplate,variantRank) :
    enemyId==="aries" ? applyAriesVariant(baseTemplate,variantRank) :
    enemyId==="cherub-duck" ? applyCherubDuckVariant(baseTemplate,variantRank) :
    enemyId==="rotten-egg" ? applyGimmickEnemyVariant(enemyId,baseTemplate,options.gimmickVariant) :
    enemyId==="lucky-cat" ? applyGimmickEnemyVariant(enemyId,baseTemplate,options.gimmickVariant) :
    enemyId==="angy-duck" ? applyGimmickEnemyVariant(enemyId,baseTemplate,options.gimmickVariant) :
    enemyId==="porcupin" ? applyPorcupinVariant(baseTemplate) :
    enemyId==="mimic" ? applyMimicProfile(baseTemplate,variantRank) : baseTemplate;
  const template=maybeApplyShinyVariant(enemyId,normalTemplate,Boolean(options.forceShiny));

  currentEnemy=currentRun?.mode==="endless"
    ? endlessEnemyScaled(template,currentRun.floor)
    : enemyScaled(template,currentRun.rank,currentRun.area);
  currentEnemy.id=enemyId;
  currentEnemy._doubleSlot=Number(options.slot)===1?1:0;
  configureEnemySpecialVariant(currentEnemy);
  currentEnemy.healsUsed=0; currentEnemy.specialUses=0; currentEnemy.shellHitsRemaining=0;
  currentEnemy.zoomiesBoost=false; currentEnemy.lifeDrainsUsed=0;
  ensureEnemyEffectSnapshot(currentEnemy);
  loadEnemyEffects(currentEnemy);
  warmCurrentBattleAssets(currentEnemy);
  renderEnemyCombatant(currentEnemy,currentEnemy._doubleSlot);
  if(!options.silentSetup){
    startEnemyIdle(); renderBattleBuddy(); renderSkills(); renderBattleItems();
    if(currentEnemy.shiny) requestAnimationFrame(()=>playShinyArrivalSparkle(enemyUiFor(currentEnemy).combatant));
    const openingBuddy=activeBattleBuddyRecord();
    if(openingBuddy?.shiny) requestAnimationFrame(()=>playShinyArrivalSparkle(ui.buddyCombatant));
    ui.commandGrid.classList.remove("hidden"); closeCommandWindow(); renderBattleItems(); renderCommandButtons();
  }
  if(!options.suppressIntro){
    if(currentEnemy.shiny) setMessage(`${currentEnemy.name} ✨ appeared! A super-rare Shiny Lil Guy!`);
    else if(enemyId==="vampire-squid") setMessage(`${currentEnemy.name} rises from the depths!`);
    else if(enemyId==="jellybun") setMessage(`${currentEnemy.name} bounces in to guard the Ocean Floor!`);
    else if(enemyId==="tree-squirrel") setMessage(`${currentEnemy.name} drops down to guard the clearing!`);
    else if(enemyId==="gummy-shark") setMessage(`${currentEnemy.name} splashes out of the Chocolate Lake!`);
    else if(enemyId==="cream-fox") setMessage(`${currentEnemy.name} bounds in to guard the Chocolate Lake!`);
    else if(enemyId==="aries") setMessage(`${currentEnemy.name} charges into the Star Sanctuary!`);
    else if(enemyId==="cherub-duck") setMessage(`${currentEnemy.name} flutters down to guard the Halo!`);
    else if(currentEnemy.boss) setMessage(`${currentEnemy.name} blocks the path!`);
    else setMessage(`${currentEnemy.name} appeared!`);
  }
}

function startDoubleBattle(enemyIds=[]){
  resetDoubleBattleUi();
  currentEnemy=null;
  // Clear both visible slots before generating the pair.
  for(const slot of [0,1]){
    const refs=enemyUiFor(slot);
    refs.combatant?.classList.add("hidden");
    if(refs.name) refs.name.textContent="";
    if(refs.rank) refs.rank.textContent="";
    if(refs.hpFill) refs.hpFill.style.width="0%";
    if(refs.hpText) refs.hpText.textContent="";
    refs.sprite?.removeAttribute("src");
  }
  const ids=Array.isArray(enemyIds)?enemyIds.filter(Boolean).slice(0,2):[];
  if(ids.length<2){
    startEnemy(ids[0]||"bee");
    return;
  }

  ui.battlefield?.classList.add("double-battle");
  const spawned=[];
  ids.forEach((enemyId,slot)=>{
    startEnemy(enemyId,{slot,suppressIntro:true,silentSetup:true});
    currentEnemy._doubleSlot=slot;
    ensureEnemyEffectSnapshot(currentEnemy);
    saveCurrentEnemyEffects(currentEnemy);
    spawned.push(currentEnemy);
  });
  doubleBattleEnemies=spawned;
  for(const enemy of doubleBattleEnemies) renderEnemyCombatant(enemy,enemy._doubleSlot);
  selectCurrentEnemy(doubleBattleEnemies[0]);
  startEnemyIdle();
  startSecondaryEnemyIdle(doubleBattleEnemies[1]);
  renderBattleBuddy(); renderSkills(); renderBattleItems(); renderCommandButtons();
  ui.commandGrid?.classList.remove("hidden");
  closeCommandWindow();
  for(const enemy of doubleBattleEnemies){
    if(enemy.shiny) requestAnimationFrame(()=>playShinyArrivalSparkle(enemyUiFor(enemy).combatant));
  }
  const openingBuddy=activeBattleBuddyRecord();
  if(openingBuddy?.shiny) requestAnimationFrame(()=>playShinyArrivalSparkle(ui.buddyCombatant));
  setMessage(`Double Trouble! ${doubleBattleEnemies[0].name}${doubleBattleEnemies[0].shiny?" ✨":""} and ${doubleBattleEnemies[1].name}${doubleBattleEnemies[1].shiny?" ✨":""} appeared together!`);
}

function startBuddyIdle(buddy){
  clearInterval(buddyIdleTimer);
  buddyIdleTimer=null;
  buddyIdleIndex=0;
  const frames=Array.isArray(buddy?.idle) && buddy.idle.length ? buddy.idle : [buddy?.image].filter(Boolean);
  if(!frames.length || !ui.buddyBattleSprite) return;
  setQuestSpriteFrame(ui.buddyBattleSprite,frames[0]);
  if(frames.length < 2) return;
  buddyIdleTimer=setInterval(()=>{
    if(actionLocked || !ui.buddyCombatant || ui.buddyCombatant.classList.contains("hidden")) return;
    buddyIdleIndex=(buddyIdleIndex+1)%frames.length;
    setQuestSpriteFrame(ui.buddyBattleSprite,frames[buddyIdleIndex]);
  },380);
}

function renderBattleBuddy(){
  const buddy=activeBattleBuddyRecord();
  if(!ui.buddyCombatant || !ui.buddyBattleSprite) return;
  if(!buddy || !buddySkillForEnemyId(buddy.enemyId) || !currentEnemy){
    clearInterval(buddyIdleTimer);
    buddyIdleTimer=null;
    ui.buddyCombatant.classList.add("hidden");
    return;
  }
  const buddyLabel=`${buddy.name || "Lil Guy"}${buddy.genderSymbol?` ${buddy.genderSymbol}`:""}`;
  ui.buddyBattleName.textContent=buddyLabel;
  ui.buddyBattleSprite.alt=buddyLabel;
  ui.buddyCombatant.classList.toggle("boss-buddy",Boolean(buddy.boss));
  ui.buddyBattleSparkle?.classList.toggle("hidden",!buddy.shiny);
  ui.buddyCombatant.classList.remove("hidden");
  startBuddyIdle(buddy);
}

function buddyDamageBase(multiplier=1,critChance=.08,critMultiplier=1.5){
  const stats=peepStats();
  const heroBuff=(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1) *
    (skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1);
  const defenseDebuff=skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1;
  const crit=Math.random()<critChance;
  const variance=.92+Math.random()*.16;
  return {
    damage:Math.max(1,Math.round(stats.attack*heroBuff*multiplier*defenseDebuff*variance*(crit?critMultiplier:1))),
    crit
  };
}

function animateBuddyAction(){
  if(!ui.buddyCombatant) return;
  ui.buddyCombatant.classList.remove("buddy-action-pop");
  void ui.buddyCombatant.offsetWidth;
  ui.buddyCombatant.classList.add("buddy-action-pop");
  setTimeout(()=>ui.buddyCombatant?.classList.remove("buddy-action-pop"),520);
}

function tickPlayerBuddyEffects(){
  // Lil Guy is a bonus action. The cooldown begins AFTER the OC finishes the
  // turn in which the Lil Guy was used, so "3 turns" means three full OC turns.
  if(skillState.buddyCooldown>0 && !buddyUsedThisHeroTurn) skillState.buddyCooldown--;
  buddyUsedThisHeroTurn=false;
  if(skillState.buddyAttackBuffTurns>0) skillState.buddyAttackBuffTurns--;
  if(skillState.enemyDefenseDownTurns>0){
    skillState.enemyDefenseDownTurns--;
    if(skillState.enemyDefenseDownTurns<=0) skillState.enemyDefenseMultiplier=1;
  }
  saveCurrentEnemyEffects();
}

function tickEnemyBuddyEffects(){
  if(skillState.enemyAttackDownTurns>0){
    skillState.enemyAttackDownTurns--;
    if(skillState.enemyAttackDownTurns<=0) skillState.enemyAttackMultiplier=1;
  }
  if(skillState.enemyAccuracyDownTurns>0){
    skillState.enemyAccuracyDownTurns--;
    if(skillState.enemyAccuracyDownTurns<=0) skillState.enemyMissChance=0;
  }
  if(skillState.heroGuardTurns>0){
    skillState.heroGuardTurns--;
    if(skillState.heroGuardTurns<=0) skillState.heroGuardMultiplier=1;
  }
  saveCurrentEnemyEffects();
}

async function useBuddySkill(){
  const buddy=activeBattleBuddyRecord();
  const baseSkill=buddySkillForEnemyId(buddy?.enemyId);
  const skill=window.DUCKIE_BUDDY_BOX_V265?.scaleSkill?.(baseSkill,buddy?.level||1)||baseSkill;
  if(actionLocked || !currentEnemy || !buddy || !skill || Number(skillState.buddyCooldown||0)>0) return;
  if(currentRun && buddy.enemyId==="plushbun" && buddy.variantId==="red") currentRun.luckyFluffUsedThisEncounter=true;
  closeCommandWindow();
  actionLocked=true;
  skillState.buddyCooldown=3;
  buddyUsedThisHeroTurn=true;
  renderCommandButtons();
  animateBuddyAction();
  setMessage(`${buddy.name}${buddy.shiny?" ✨":""} used ${skill.name}!`);
  await sleep(260);

  let dealt=0;
  const hit=async(mult=.8,critChance=.08,critMultiplier=1.5)=>{
    const roll=buddyDamageBase(mult,critChance,critMultiplier);
    dealt=await hurtEnemy(roll.damage);
    if(roll.crit) setMessage(`${buddy.name}'s ${skill.name} landed a CRITICAL hit!`);
    return dealt;
  };
  const healHero=(percent)=>{
    const before=currentRun.hp;
    currentRun.hp=Math.min(currentRun.maxHp,currentRun.hp+Math.max(1,Math.round(currentRun.maxHp*percent)));
    const healed=currentRun.hp-before;
    if(healed>0){showFloat(`+${healed}`,"heal","peep");renderPeepHp();}
    return healed;
  };

  switch(skill.type){
    case "heal": {
      const healed=healHero(skill.healPercent||.15);
      setMessage(`${skill.name}! ${buddy.name} restored ${healed} HP.`);
      break;
    }
    case "damage-attack-down":
      await hit(skill.multiplier||.65);
      skillState.enemyAttackDownTurns=skill.duration||2;
      skillState.enemyAttackMultiplier=1-(skill.attackDown||.20);
      setMessage(`${skill.name}! ${currentEnemy?.name||"The enemy"}'s Attack fell for ${skill.duration||2} turns.`);
      break;
    case "guard":
      skillState.heroGuardTurns=skill.duration||2;
      skillState.heroGuardMultiplier=1-(skill.damageReduction||.30);
      setMessage(`${skill.name}! Damage taken is reduced for ${skill.duration||2} turns.`);
      break;
    case "crit-damage":
      await hit(skill.multiplier||.95,skill.critChance||.25,skill.critMultiplier||1.7);
      break;
    case "damage-accuracy-down":
      await hit(skill.multiplier||.65);
      skillState.enemyAccuracyDownTurns=skill.duration||2;
      skillState.enemyMissChance=skill.missChance||.25;
      setMessage(`${skill.name}! ${currentEnemy?.name||"The enemy"} may miss for ${skill.duration||2} turns.`);
      break;
    case "next-hit-shield":
      skillState.heroNextDamageMultiplier=1-(skill.damageReduction||.50);
      setMessage(`${skill.name}! The next damaging enemy hit will be cut in half.`);
      break;
    case "damage-stun":
      await hit(skill.multiplier||.95);
      if(currentEnemy && Math.random()<(skill.stunChance||.30)){
        skillState.enemyStunned=true;
        setMessage(`${skill.name}! ${currentEnemy.name} was stunned!`);
      }
      break;
    case "heal-attack-up": {
      const healed=healHero(skill.healPercent||.10);
      skillState.buddyAttackBuffTurns=skill.duration||2;
      skillState.buddyAttackMultiplier=1+(skill.attackBoost||.15);
      setMessage(`${skill.name}! Restored ${healed} HP and raised Attack for ${skill.duration||2} turns.`);
      break;
    }
    case "damage-defense-down":
      await hit(skill.multiplier||.90);
      skillState.enemyDefenseDownTurns=skill.duration||2;
      skillState.enemyDefenseMultiplier=1+(skill.defenseDown||.20);
      setMessage(`${skill.name}! ${currentEnemy?.name||"The enemy"}'s Defense fell for ${skill.duration||2} turns.`);
      break;
    case "heal-guard": {
      const healed=healHero(skill.healPercent||.20);
      skillState.heroGuardTurns=skill.duration||2;
      skillState.heroGuardMultiplier=1-(skill.damageReduction||.20);
      setMessage(`${skill.name}! Restored ${healed} HP and raised Defense for ${skill.duration||2} turns.`);
      break;
    }
    case "life-drain": {
      const actual=await hit(skill.multiplier||1.2);
      const before=currentRun.hp;
      currentRun.hp=Math.min(currentRun.maxHp,currentRun.hp+Math.max(1,Math.round(actual*(skill.drainPercent||.5))));
      const healed=currentRun.hp-before;
      if(healed>0){showFloat(`+${healed}`,"heal","peep");renderPeepHp();}
      setMessage(`${skill.name}! ${buddy.name} drained ${actual} damage and restored ${healed} HP.`);
      break;
    }
    case "damage-weaken":
      await hit(skill.multiplier||1.4);
      if(currentEnemy && Math.random()<(skill.weakenChance||.30)){
        skillState.enemyNextAttackMultiplier=skill.nextAttackMultiplier||.65;
        setMessage(`${skill.name}! ${currentEnemy.name}'s next attack was weakened.`);
      }
      break;
    case "jackpot": {
      const roll=Math.random();
      if(roll<.45){
        await hit(skill.multiplier||1.6,skill.critChance||.12,skill.critMultiplier||1.6);
        setMessage(`Jackpot Bite! ${buddy.name} hit the damage jackpot!`);
      }else if(roll<.75){
        const healed=healHero(skill.healPercent||.25);
        setMessage(`Jackpot Bite! Healing prize — restored ${healed} HP!`);
      }else{
        const coins=Math.max(1,Math.round(randInt(15,35)*affectionRewardMultiplier()));
        hubSave.coins=Math.max(0,Number(hubSave.coins)||0)+coins;
        if(!hubSave.stats||typeof hubSave.stats!=="object") hubSave.stats={};
        hubSave.stats.coinsEarnedTotal=Math.max(0,Number(hubSave.stats.coinsEarnedTotal)||0)+coins;
        currentRun.coinsEarned+=coins;
        questSave.totalCoinsEarned=(Number(questSave.totalCoinsEarned)||0)+coins;
        persistAll();renderMeta();
        setMessage(`Jackpot Bite! ${buddy.name} found +${coins} Pink Coins!`);
      }
      break;
    }
  }

  saveCurrentEnemyEffects();
  if(currentEnemy && currentEnemy.hpNow<=0){
    const encounterDone=await enemyDefeated();
    if(encounterDone) return;
  }
  await sleep(320);
  actionLocked=false;
  ui.commandGrid.classList.remove("hidden");
  setMessage(`${buddy.name}${buddy.shiny?" ✨":""} helped! Now choose ${heroDisplayName()}'s move.`);
  renderCommandButtons();
  renderSkills();
}

function setHeroFrame(src){
  if(activeCharacterId!=="peep") renderHeroComposite(ui.battleHeroComposite,src);
  else if(ui.peepSprite) setQuestSpriteFrame(ui.peepSprite,src);
}

function restoreHeroIdleFrame(){
  const frames=heroIdleFrames();
  const index=peepIdleIndex%frames.length;
  setHeroFrame(frames[index]);
}

function addHeroVisualClass(className){
  activeHeroVisual()?.classList.add(className);
}

function removeHeroVisualClass(...classNames){
  activeHeroVisual()?.classList.remove(...classNames);
}

function hpFillColor(pct, enemy=false) {
  const value=Math.max(0,Math.min(100,Number(pct)||0));
  if(enemy){
    if(value<=25) return "#b94456";
    if(value<=50) return "#dc7a68";
    return "#d76570";
  }
  if(value<=25) return "#d85b63";
  if(value<=50) return "#d6aa52";
  return "#6fb875";
}

function paintHpBar(fillEl,pct,enemy=false) {
  if(!fillEl) return;
  const value=Math.max(0,Math.min(100,Number(pct)||0));
  const bar=fillEl.parentElement;
  const color=hpFillColor(value,enemy);

  // Hub v24.79: paint the fill on the OUTER bar itself. Some mobile
  // browsers were reporting the correct HP/width while failing to paint
  // the inner span, leaving a visually empty bar.
  if(bar){
    bar.style.setProperty("--hp-pct",`${value}%`);
    bar.style.setProperty("--hp-color",color);
    bar.setAttribute("aria-valuenow",String(Math.round(value)));
  }

  // Keep the legacy child updated for compatibility/accessibility, but the
  // visible fill no longer depends on this element.
  fillEl.style.width=`${value}%`;
  fillEl.style.backgroundColor=color;
  fillEl.setAttribute("aria-valuenow",String(Math.round(value)));
}

function renderPeepHp() {
  const pct=Math.max(0,Math.min(100,(currentRun.hp/currentRun.maxHp)*100));
  paintHpBar(ui.peepHpFill,pct,false);
  ui.peepHpText.textContent=`${Math.max(0,Math.round(currentRun.hp))} / ${currentRun.maxHp} HP`;
}

function renderEnemyHp(enemy=currentEnemy) {
  if(!enemy) return;
  const refs=enemyUiFor(enemy);
  const pct=Math.max(0,Math.min(100,(enemy.hpNow/enemy.maxHp)*100));
  paintHpBar(refs.hpFill,pct,true);
  if(refs.hpText) refs.hpText.textContent=`${Math.max(0,Math.round(enemy.hpNow))} / ${enemy.maxHp} HP`;
}

function startPeepIdle() {
  clearInterval(peepIdleTimer);
  peepIdleIndex=0;
  const frames=heroIdleFrames();
  setHeroFrame(frames[0]);
  peepIdleTimer=setInterval(()=>{
    if(actionLocked) return;
    peepIdleIndex=(peepIdleIndex+1)%frames.length;
    setHeroFrame(frames[peepIdleIndex]);
  },520);
}

function startEnemyIdle() {
  clearInterval(idleTimer);
  enemyIdleIndex=0;
  if(!currentEnemy) return;
  const tracked=currentEnemy;
  const refs=enemyUiFor(tracked);
  setQuestSpriteFrame(refs.sprite,tracked.idle[0]);
  refs.sprite.alt=tracked.name;
  idleTimer=setInterval(()=>{
    if(actionLocked || !tracked || tracked.hpNow<=0 || refs.combatant?.classList.contains("hidden")) return;
    enemyIdleIndex=(enemyIdleIndex+1)%tracked.idle.length;
    setQuestSpriteFrame(refs.sprite,tracked.idle[enemyIdleIndex]);
  },tracked.speed || 380);
}

function clearAnimations() {
  clearInterval(idleTimer); idleTimer=null;
  clearInterval(secondaryEnemyIdleTimer); secondaryEnemyIdleTimer=null;
  clearInterval(peepIdleTimer); peepIdleTimer=null;
  clearInterval(buddyIdleTimer); buddyIdleTimer=null;
}

function renderSkills() {
  ui.skillButtons.innerHTML="";

  sortedActiveSkills()
    .filter(skill => activeHeroProgress().level >= skill.unlock)
    .forEach(skill=>{
      const button=document.createElement("button");
      button.type="button";
      let unavailable=false;
      let detail=skillDisplayDescription(skill);

      const cooldown=Number(skillState.cooldowns?.[skill.id]||0);
      if(skill.cooldown && cooldown>0) {
        unavailable=true;
        detail=`Cooldown: ${cooldown} turn${cooldown===1?"":"s"}`;
      } else if(skill.oncePerBattle && skillState.onceUsed?.[skill.id]) {
        unavailable=true;
        detail="Already used this battle.";
      } else if(["buff","full-heal-buff","self-damage-buff"].includes(skill.type) && skill.type!=="full-heal-buff" && skillState.attackBuffTurns>0) {
        unavailable=true;
        const boost=Math.round((skill.attackBoost||0.30)*100);
        detail=`Attack +${boost}% active · ${skillState.attackBuffTurns} turn${skillState.attackBuffTurns===1?"":"s"}`;
      } else if(skill.id==="rainbow-check") {
        const used=Math.max(0,Number(skillState.ioRainbowUses)||0);
        const maxUses=Math.max(1,Number(skill.maxUses)||2);
        if(used>=maxUses){ unavailable=true; detail="No uses left this battle."; }
        else if(currentRun && currentRun.hp>=currentRun.maxHp){ unavailable=true; detail=`Full HP · ${maxUses-used}/${maxUses} uses left`; }
        else detail=`Full heal · ${maxUses-used}/${maxUses} uses left`;
      } else if(skill.id==="heart-ray") {
        const count=Math.max(0,Number(skillState.heartRayCount)||0);
        const until=5-(count%5);
        detail=until===1?"Next Heart Ray is boosted!":`Boost in ${until} uses`;
      }

      button.className=`pixel-button skill-button ${(skill.type==="heal"||skill.type==="full-heal")?"heal":isStatusSkill(skill)?"buff":skill.id==="duck-throw"?"duck":skill.oncePerBattle?"ultimate":""}`;
      button.disabled=unavailable || actionLocked;
      button.innerHTML=`<strong>${skillDisplayName(skill)}</strong><span${detail.startsWith("Cooldown")?' class="cooldown"':""}>${detail}</span>`;

      if(skill.hitsAll && isDoubleBattleActive() && aliveDoubleEnemies().length>1 && !unavailable){
        detail += " · Hits BOTH enemies";
        button.innerHTML=`<strong>${skillDisplayName(skill)}</strong><span${detail.startsWith("Cooldown")?' class="cooldown"':""}>${detail}</span>`;
      }

      if(!unavailable) {
        button.addEventListener("click",()=>{
          closeCommandWindow();
          if(isDoubleBattleActive() && aliveDoubleEnemies().length>1 && skillNeedsEnemyTarget(skill) && !skill.hitsAll){
            openDoubleTargetPicker("skill",skill);
            return;
          }
          useSkill(skill);
        });
      }

      ui.skillButtons.appendChild(button);
    });

  const quick=document.createElement("button");
  quick.type="button";
  quick.className="pixel-button skill-button heal quick-heal-skill";
  const usesLeft=Math.max(0,QUICK_HEAL_MAX_USES-quickHealUses);
  const atFullHp=!currentRun || currentRun.hp>=currentRun.maxHp;
  quick.disabled=actionLocked || !currentEnemy || atFullHp || usesLeft<=0;
  quick.innerHTML=`<strong>Quick Heal</strong><span>Restore 25% HP · ${usesLeft}/${QUICK_HEAL_MAX_USES} uses</span>`;
  quick.addEventListener("click",()=>{closeCommandWindow();quickHealTurn();});
  ui.skillButtons.appendChild(quick);

  renderCommandButtons();
}

function renderCommandButtons() {
  const disabled = actionLocked || !currentEnemy;
  if (ui.attackMenuButton) ui.attackMenuButton.disabled = disabled;
  if (ui.itemMenuButton) ui.itemMenuButton.disabled = disabled;

  const buddy=activeBattleBuddyRecord();
  const buddySkill=buddySkillForEnemyId(buddy?.enemyId);
  const buddyCooldown=Math.max(0,Number(skillState.buddyCooldown)||0);
  if(ui.buddyMenuButton){
    ui.buddyMenuButton.disabled=disabled || !buddy || !buddySkill || buddyCooldown>0 || buddyUsedThisHeroTurn;
    if(ui.buddyCommandText){
      ui.buddyCommandText.textContent=!buddy
        ? "No Main Lil Guy"
        : !buddySkill
          ? "No helper skill"
          : buddyUsedThisHeroTurn
            ? "Bonus move used · choose an OC move"
            : buddyCooldown>0
              ? `${buddySkill.name} · ${buddyCooldown} turn${buddyCooldown===1?"":"s"}`
              : `${buddy.name} · Bonus Move`;
    }
  }

  const assignedBuddyCount=battleBuddySlotRecords().filter(Boolean).length;
  if(ui.switchBuddyMenuButton){
    const canSwitch=!disabled && !buddySwitchUsedThisEncounter && assignedBuddyCount>1;
    ui.switchBuddyMenuButton.disabled=!canSwitch;
    if(ui.switchBuddyCommandText){
      ui.switchBuddyCommandText.textContent=buddySwitchUsedThisEncounter
        ? "Switch used this encounter"
        : assignedBuddyCount<=1
          ? "Assign 2+ Lil Guys in Profiles"
          : `${assignedBuddyCount} Lil Guys ready`;
    }
  }

  if (ui.escapeButton) ui.escapeButton.disabled = actionLocked || !currentRun;
}

function escapeHtml(value){
  return String(value??"").replace(/[&<>"']/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[char]));
}

function renderBuddySkillMenu(){
  if(!ui.skillButtons) return;
  ui.skillButtons.innerHTML="";
  const buddy=activeBattleBuddyRecord();
  const skill=buddySkillForEnemyId(buddy?.enemyId);
  if(!buddy || !skill){
    const empty=document.createElement("p");
    empty.className="no-battle-items";
    empty.textContent="Choose a Main Lil Guy from Profiles to use a helper skill.";
    ui.skillButtons.appendChild(empty);
    return;
  }
  const cooldown=Math.max(0,Number(skillState.buddyCooldown)||0);
  const button=document.createElement("button");
  button.type="button";
  button.className=`pixel-button skill-button buddy-skill-button${buddy.shiny?" shiny":""}${buddy.boss?" boss":""}`;
  button.disabled=actionLocked || cooldown>0 || buddyUsedThisHeroTurn || !currentEnemy;
  const buddyNameLabel=`${buddy.shiny?"✨ ":""}${escapeHtml(buddy.name)}${buddy.genderSymbol?` ${buddy.genderSymbol}`:""}`;
  button.innerHTML=`<span class="buddy-skill-row"><img src="${buddy.image}" alt=""><span><strong>${buddyNameLabel}</strong><em>${skill.name}</em></span></span><span>${cooldown>0?`Cooldown: ${cooldown} turn${cooldown===1?"":"s"}`:skill.description}</span>`;
  button.addEventListener("click",useBuddySkill);
  ui.skillButtons.appendChild(button);
}

function renderBattleBuddySwitchMenu(){
  if(!ui.buddySwitchGrid) return;
  ui.buddySwitchGrid.innerHTML="";
  const records=battleBuddySlotRecords();
  records.forEach((buddy,slotIndex)=>{
    const card=document.createElement("button");
    card.type="button";
    const isCurrent=Boolean(buddy) && slotIndex===activeBattleBuddySlot;
    card.className=`buddy-switch-card${isCurrent?" current":""}${buddy?.shiny?" shiny":""}${!buddy?" empty":""}`;
    card.dataset.slot=String(slotIndex);

    if(!buddy){
      card.disabled=true;
      card.innerHTML=`<span class="buddy-switch-empty-art">${slotIndex+1}</span><span class="buddy-switch-copy"><strong>Empty Slot ${slotIndex+1}</strong><small>Assign a Lil Guy in Profiles.</small></span>`;
      ui.buddySwitchGrid.appendChild(card);
      return;
    }

    const skill=buddySkillForEnemyId(buddy.enemyId);
    const displayName=`${buddy.shiny?"✨ ":""}${escapeHtml(buddy.name)}${buddy.genderSymbol?` ${buddy.genderSymbol}`:""}`;
    const species=buddy.nickname && buddy.speciesName && buddy.speciesName!==buddy.name ? ` · ${escapeHtml(buddy.speciesName)}` : "";
    const detail=skill?.description || "This Lil Guy does not have a helper move yet.";
    card.innerHTML=`<span class="buddy-switch-portrait"><img src="${escapeHtml(buddy.image)}" alt=""></span><span class="buddy-switch-copy"><strong>${displayName}${species}</strong><em>${escapeHtml(skill?.name||"Lil Guy")}</em><small>${escapeHtml(detail)}</small></span>${isCurrent?'<span class="buddy-switch-current">CURRENT</span>':''}`;
    card.disabled=isCurrent || buddySwitchUsedThisEncounter || actionLocked || !currentEnemy;
    if(!card.disabled) card.addEventListener("click",()=>switchBattleBuddy(slotIndex));
    ui.buddySwitchGrid.appendChild(card);
  });
}

async function switchBattleBuddy(slotIndex){
  if(actionLocked || !currentEnemy || buddySwitchUsedThisEncounter) return;
  const nextSlot=Math.max(0,Math.min(5,Math.floor(Number(slotIndex)||0)));
  if(nextSlot===activeBattleBuddySlot) return;
  const buddy=buddyRecordForSlot(nextSlot);
  if(!buddy) return;

  closeCommandWindow();
  actionLocked=true;
  activeBattleBuddySlot=nextSlot;
  buddySwitchUsedThisEncounter=true;
  skillState.buddyCooldown=0;
  buddyUsedThisHeroTurn=false;
  renderBattleBuddy();
  renderCommandButtons();
  setMessage(`${heroDisplayName()} switched to ${buddy.name}${buddy.shiny?" ✨":""}! Switching used the turn.`);
  if(buddy.shiny) requestAnimationFrame(()=>playShinyArrivalSparkle(ui.buddyCombatant));
  await sleep(520);

  decrementCooldowns("buddy-switch");
  await enemyTurnSequence();
  actionLocked=false;
  renderCommandButtons();
  renderSkills();
}

function openCommandWindow(kind) {
  if (actionLocked || !currentEnemy) return;

  ui.targetPicker?.classList.add("hidden");
  ui.commandGrid?.classList.remove("hidden");
  ui.commandWindow.dataset.kind = kind;
  ui.commandWindow.classList.remove("hidden");
  ui.skillButtons.classList.add("hidden");
  ui.itemButtons.classList.add("hidden");
  ui.buddySwitchPanel?.classList.add("hidden");
  ui.noBattleItems.classList.add("hidden");
  ui.itemPonShopActions?.classList.add("hidden");
  ui.ponPurchasePanel?.classList.add("hidden");

  if (kind === "attack") {
    ui.commandWindowTitle.textContent = "Attack";
    renderSkills();
    ui.skillButtons.classList.remove("hidden");
  } else if(kind === "buddy") {
    ui.commandWindowTitle.textContent = "Lil Guy";
    renderBuddySkillMenu();
    ui.skillButtons.classList.remove("hidden");
  } else if(kind === "switch-buddy") {
    ui.commandWindowTitle.textContent = "Switch Lil Guy";
    renderBattleBuddySwitchMenu();
    ui.buddySwitchPanel?.classList.remove("hidden");
  } else {
    ui.commandWindowTitle.textContent = "Item";
    renderBattleItems();
    ui.itemButtons.classList.remove("hidden");
    ui.itemPonShopActions?.classList.remove("hidden");
    ui.noBattleItems.classList.add("hidden");
  }
}

function closeCommandWindow() {
  delete ui.commandWindow.dataset.kind;
  ui.commandWindow.classList.add("hidden");
  ui.skillButtons.classList.add("hidden");
  ui.itemButtons.classList.add("hidden");
  ui.buddySwitchPanel?.classList.add("hidden");
  ui.noBattleItems.classList.add("hidden");
  ui.itemPonShopActions?.classList.add("hidden");
  ui.ponPurchasePanel?.classList.add("hidden");
}

function renderBattleItems() {
  if (!ui.itemButtons || !ui.noBattleItems) return;

  const battleItems = [
    {
      id: "pink-heart-refill",
      name: "Pink Heart Refill",
      image: "../assets/bakery/drops/Pink-heart-refill.webp",
      detail: "Heal 50% HP"
    },
    {
      id: "gold-heart-refill",
      name: "Gold Heart Refill",
      image: "../assets/bakery/drops/Gold-heart-refill.webp",
      detail: "Restore full HP"
    }
  ];

  ui.itemButtons.innerHTML = "";

  // Healing items stay in Item and only appear when the player owns one.
  battleItems.forEach(item => {
    const qty = hubInventoryQty(item.id);
    if (qty <= 0) return;

    const button = document.createElement("button");
    button.type = "button";
    button.className = `pixel-button battle-item-button${item.id === "gold-heart-refill" ? " gold" : ""}`;

    const fullHp = !currentRun || currentRun.hp >= currentRun.maxHp;
    button.disabled = actionLocked || !currentEnemy || fullHp;
    button.innerHTML = `
      <img src="${item.image}" alt="">
      <span>
        <strong>${item.name}</strong>
        <small>${item.detail} · ×${qty}</small>
      </span>
    `;
    button.addEventListener("click", () => {
      closeCommandWindow();
      useBattleHeart(item.id);
    });
    ui.itemButtons.appendChild(button);
  });

  // v37: Lil Pons are now battle items. They are always shown so the
  // player can see their current quantity and exact catch chance.
  BUDDY_PONS.forEach(pon => {
    const qty=hubInventoryQty(pon.id);
    const captureTargets=isDoubleBattleActive()?aliveDoubleEnemies():[currentEnemy].filter(Boolean);
    const rates=captureTargets.map(enemy=>buddyPonCatchRate(pon,enemy));
    const rate=rates.length?Math.max(...rates):0;
    const button=document.createElement("button");
    button.type="button";
    button.className=`pixel-button battle-item-button buddy-pon-item${pon.className?` ${pon.className}`:""}`;
    button.dataset.ponId=pon.id;
    button.disabled=actionLocked || !currentEnemy || qty<=0 || rate<=0;
    const lowHpBonus=!isDoubleBattleActive() && buddyLowHpCatchBonus(currentEnemy)>0;
    const rateLabel=isDoubleBattleActive() && captureTargets.length>1
      ? "Choose which enemy to catch"
      : rate>0 ? `${Math.round(rate*100)}% catch${lowHpBonus?" · Low HP bonus!":""}` : "Can't catch this boss";
    button.innerHTML=`
      <img src="${pon.image}" alt="">
      <span>
        <strong>${pon.name}</strong>
        <small>×${qty} · ${rateLabel}</small>
      </span>
    `;
    button.addEventListener("click",()=>{
      if(isDoubleBattleActive() && aliveDoubleEnemies().length>1){
        openDoubleTargetPicker("capture",pon.id);
      } else {
        attemptBattleCapture(pon.id);
      }
    });
    ui.itemButtons.appendChild(button);
  });

  ui.noBattleItems.classList.add("hidden");
  renderPonPurchaseChoices();
}

async function useBattleHeart(itemId) {
  if (actionLocked || !currentEnemy || !currentRun) return;
  if (currentRun.hp >= currentRun.maxHp) {
    setMessage(`${heroDisplayName()} is already at full health!`);
    renderBattleItems();
    return;
  }

  const isGold = itemId === "gold-heart-refill";
  const itemName = isGold ? "Gold Heart Refill" : "Pink Heart Refill";

  if (!consumeHubItem(itemId, 1)) {
    setMessage(`No ${itemName}s left!`);
    renderBattleItems();
    return;
  }

  actionLocked = true;
  renderSkills();
  renderBattleItems();
  renderCommandButtons();

  const before = currentRun.hp;
  if (isGold) {
    currentRun.hp = currentRun.maxHp;
  } else {
    currentRun.hp = Math.min(
      currentRun.maxHp,
      currentRun.hp + Math.max(1, Math.round(currentRun.maxHp * 0.50))
    );
  }

  const healed = Math.max(0, currentRun.hp - before);
  renderPeepHp();
  showFloat(`+${healed}`, "heal", "peep");
  setMessage(`${itemName}! ${heroDisplayName()} restored ${healed} HP.`);
  await sleep(600);

  // Healing items are intentionally a combat turn so stocking up helps
  // without removing the challenge.
  decrementCooldowns("battle-item");
  await enemyTurnSequence();

  actionLocked = false;
  renderCommandButtons();
  renderSkills();
  renderBattleItems();
}

function heroCanMissFromFluster(skill) {
  if(!skill || !skillState) return false;
  if(["heal","full-heal","buff","full-heal-buff","self-damage-buff"].includes(skill.type)) return false;
  return Number(skillState.heroMissTurns||0) > 0 && Math.random() < Number(skillState.heroMissChance||0);
}

async function applyEnemyBurnTick() {
  if(!currentEnemy || currentEnemy.hpNow<=0 || Number(skillState.enemyBurnTurns||0)<=0) return false;
  const percent=Math.max(0.01, Number(skillState.enemyBurnDamagePercent||0.08));
  const dmg=Math.max(1, Math.round(currentEnemy.maxHp*percent));
  const before=currentEnemy.hpNow;
  currentEnemy.hpNow=Math.max(0, currentEnemy.hpNow-dmg);
  const dealt=Math.max(0, before-currentEnemy.hpNow);
  if(dealt>0) {
    setMessage(`${currentEnemy.name} is hurt by burn!`);
    const refs=activeEnemyUi();
    if(refs.sprite) refs.sprite.classList.add("hurt-pop");
    showFloat(`-${dealt}`,"damage","enemy");
    renderEnemyHp();
    await sleep(420);
    if(refs.sprite) refs.sprite.classList.remove("hurt-pop");
  }
  if(Number.isFinite(skillState.enemyBurnTurns)) skillState.enemyBurnTurns=Math.max(0, Number(skillState.enemyBurnTurns)-1);
  if(currentEnemy.hpNow<=0) {
    await enemyDefeated();
    return true;
  }
  return false;
}

async function useAllEnemySkill(skill){
  const targets=aliveDoubleEnemies();
  if(targets.length<2){
    if(targets[0]) selectCurrentEnemy(targets[0]);
    return useSkill(skill);
  }
  if(actionLocked || !currentRun) return;

  actionLocked=true;
  renderSkills();
  renderCommandButtons();
  if(await blockHeroAttackFromSpecialStatus(skill)){
    decrementCooldowns("special-status-skip");
    await enemyTurnSequence();
    actionLocked=false;
    renderCommandButtons(); renderSkills(); renderBattleItems();
    return;
  }
  beginHeroSpecialAttackScale(skill);
  setHeroFrame(skill.sprite || heroIdleFrames()[0]);
  addHeroVisualClass("attack-pop");

  if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
  if(skill.oncePerBattle) skillState.onceUsed[skill.id]=true;

  if(heroCanMissFromFluster(skill)){
    setMessage(`${heroDisplayName()} got too flustered and the attack missed everybody!`);
    await sleep(600);
  } else {
    const failedSpellRoll=skill.id==="failed-spell"?Math.random():null;
    const failedSpellBackfire=skill.id==="failed-spell" && failedSpellRoll<0.01;
    const failedSpellHuge=skill.id==="failed-spell" && !failedSpellBackfire && failedSpellRoll<0.16;

    if(failedSpellBackfire){
      const before=currentRun.hp;
      const backlash=Math.max(1,Math.round(currentRun.maxHp*0.25));
      currentRun.hp=Math.max(1,currentRun.hp-backlash);
      const lost=Math.max(0,before-currentRun.hp);
      setMessage(`Failed Spell BACKFIRED! The magic loops around and bonks Miko for ${lost} HP!`);
      if(lost>0) showFloat(`-${lost}`,"damage","peep");
      renderPeepHp();
      await sleep(700);
    } else {
      const names=targets.map(enemy=>enemy.name).join(" and ");
      setMessage(failedSpellHuge
        ? `Failed Spell goes WILD! A huge blast hits ${names}!`
        : `${skillDisplayName(skill)} hits ${names}!`);
      await sleep(260);

      for(const target of targets){
        if(!target || target.hpNow<=0) continue;
        selectCurrentEnemy(target);
        const stats=peepStats();
        const boostedAttack=stats.attack
          *(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)
          *(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)
          *(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
        const crit=Math.random()<0.11;
        const variance=0.92+Math.random()*0.16;
        const multiplier=failedSpellHuge?4.25:(Number(skill.multiplier)||1);
        const dmg=Math.max(1,Math.round(boostedAttack*multiplier*variance*(crit?1.5:1)));
        await hurtEnemy(dmg);

        if(skill.type==="damage-burn" && target.hpNow>0 && Math.random()<Number(skill.burnChance||1)){
          skillState.enemyBurnTurns=Math.max(Number(skillState.enemyBurnTurns||0),Number(skill.burnTurns||99));
          skillState.enemyBurnDamagePercent=Number(skill.burnDamagePercent||0.08);
          saveCurrentEnemyEffects(target);
        }
        if(target.hpNow>0) saveCurrentEnemyEffects(target);
        await sleep(80);
      }
    }
  }

  if(activeCharacterId==="angel" && skill.shieldPercent){
    skillState.angelShieldHp=Math.max(1,Math.round(currentRun.maxHp*skill.shieldPercent));
    skillState.angelShieldTurns=skill.shieldDuration||2;
    skillState.angelShieldPendingTick=true;
    // Buddy assistance also uses hero HP; the whole party is protected by this shared combat shield.
    setMessage(`${skill.name} protects the party with ${skillState.angelShieldHp} HP of magic shielding!`);
    await sleep(350);
  }
  removeHeroVisualClass("attack-pop");
  restoreHeroIdleFrame();
  clearHeroSpecialAttackScale();
  decrementCooldowns(skill.id);

  const defeated=targets.filter(enemy=>enemy && enemy.hpNow<=0 && !enemy._defeated);
  for(const enemy of defeated){
    selectCurrentEnemy(enemy);
    const encounterDone=await enemyDefeated();
    if(encounterDone) return;
  }

  const remaining=aliveDoubleEnemies();
  if(remaining.length) selectCurrentEnemy(remaining[0]);
  await sleep(260);
  await enemyTurnSequence();
  actionLocked=false;
  renderCommandButtons();
  renderSkills();
  renderBattleItems();
}

async function useSkill(skill) {
  if(skill?.hitsAll && isDoubleBattleActive() && aliveDoubleEnemies().length>1){
    await useAllEnemySkill(skill);
    return;
  }
  if(actionLocked || !currentEnemy) return;
  actionLocked=true;
  renderSkills();
  renderCommandButtons();

  if(await blockHeroAttackFromSpecialStatus(skill)){
    decrementCooldowns("special-status-skip");
    await enemyTurnSequence();
    actionLocked=false;
    renderCommandButtons(); renderSkills(); renderBattleItems();
    return;
  }
  beginHeroSpecialAttackScale(skill);
  setHeroFrame(skill.sprite || heroIdleFrames()[0]);
  addHeroVisualClass("attack-pop");

  if(skill.type==="heal") {
    const amount=Math.max(1,Math.round(currentRun.maxHp*skill.healPercent));
    const healed=Math.min(amount,currentRun.maxHp-currentRun.hp);
    currentRun.hp+=healed;
    if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
    setMessage(`${skillDisplayName(skill)} ${heroDisplayName()} restored ${healed} HP.`);
    showFloat(`+${healed}`,"heal","peep");
    renderPeepHp();
    await sleep(700);
  } else if(skill.type==="full-heal") {
    const maxUses=Math.max(1,Number(skill.maxUses)||2);
    if((skillState.ioRainbowUses||0)>=maxUses){
      setMessage(`${skillDisplayName(skill)} has no uses left this battle!`);
      actionLocked=false; renderSkills(); renderCommandButtons(); return;
    }
    const before=currentRun.hp;
    currentRun.hp=currentRun.maxHp;
    skillState.ioRainbowUses=(skillState.ioRainbowUses||0)+1;
    const healed=Math.max(0,currentRun.hp-before);
    setMessage(`${skillDisplayName(skill)}! ${heroDisplayName()} restored ${healed} HP.`);
    showFloat(`+${healed}`,"heal","peep");
    renderPeepHp();
    await sleep(700);
  } else if(skill.type==="full-heal-buff") {
    if(skill.oncePerBattle && skillState.onceUsed?.[skill.id]){
      setMessage(`${skillDisplayName(skill)} has already been used this battle!`);
      actionLocked=false; renderSkills(); renderCommandButtons(); return;
    }
    const before=currentRun.hp;
    currentRun.hp=currentRun.maxHp;
    const healed=Math.max(0,currentRun.hp-before);
    skillState.attackBuffTurns=skill.duration||4;
    skillState.attackBuffMultiplier=1+(skill.attackBoost||0.50);
    skillState.activeBuffSkillId=skill.id;
    if(skill.oncePerBattle) skillState.onceUsed[skill.id]=true;
    const boost=Math.round((skill.attackBoost||0.50)*100);
    setMessage(`${skillDisplayName(skill)}! ${heroDisplayName()} restored ${healed} HP and Attack rose by ${boost}% for ${skillState.attackBuffTurns} turns.`);
    if(healed>0) showFloat(`+${healed}`,"heal","peep");
    renderPeepHp();
    await sleep(760);
  } else if(skill.type==="self-damage-buff") {
    const requested=Math.max(0,Number(skill.selfDamage)||10);
    const before=currentRun.hp;
    currentRun.hp=Math.max(1,currentRun.hp-requested);
    const lost=Math.max(0,before-currentRun.hp);
    skillState.attackBuffTurns=skill.duration||4;
    skillState.attackBuffMultiplier=1+(skill.attackBoost||0.50);
    skillState.activeBuffSkillId=skill.id;
    const boost=Math.round((skill.attackBoost||0.50)*100);
    setMessage(`${skillDisplayName(skill)}! ${heroDisplayName()} loses ${lost} HP, but Attack rises by ${boost}% for ${skillState.attackBuffTurns} turns.`);
    if(lost>0) showFloat(`-${lost}`,"damage","peep");
    renderPeepHp();
    await sleep(760);
  } else if(skill.type==="buff") {
    skillState.attackBuffTurns=skill.duration||3;
    skillState.attackBuffMultiplier=1+(skill.attackBoost||0.30);
    skillState.activeBuffSkillId=skill.id;
    if(skill.missChance){
      skillState.heroMissTurns=skillState.attackBuffTurns;
      skillState.heroMissChance=skill.missChance;
    } else {
      skillState.heroMissTurns=0;
      skillState.heroMissChance=0;
    }
    const boost=Math.round((skill.attackBoost||0.30)*100);
    if(skill.missChance){
      const missPct=Math.round(skill.missChance*100);
      setMessage(`${skillDisplayName(skill)}! ${heroDisplayName()}'s Attack rose by ${boost}% for ${skillState.attackBuffTurns} turns, but there is a ${missPct}% chance to miss while flustered.`);
    } else {
      setMessage(`${skillDisplayName(skill)}! ${heroDisplayName()}'s Attack rose by ${boost}% for ${skillState.attackBuffTurns} turns.`);
    }
    await sleep(700);
  } else if(skill.type==="stun") {
    if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
    skillState.enemyStunTurns=Math.max(Number(skillState.enemyStunTurns||0), Math.max(1,Number(skill.duration)||2));
    const turns=skillState.enemyStunTurns;
    setMessage(`${skillDisplayName(skill)}! ${currentEnemy.name} froze for ${turns} turn${turns===1?"":"s"}!`);
    await sleep(700);
  } else if(skill.type==="safe-chip") {
    if(heroCanMissFromFluster(skill)) {
      setMessage(`${heroDisplayName()} got too flustered and missed!`);
      await sleep(540);
    } else {
    const beforeHp=Math.max(0,Number(currentEnemy.hpNow)||0);
    const canDamage=beforeHp>1;
    if(canDamage){
      const stats=peepStats();
      const boostedAttack=stats.attack
        *(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)
        *(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)
        *(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
      const crit=Math.random()<0.11;
      const variance=0.9+Math.random()*0.2;
      const dmg=Math.max(1,Math.round(boostedAttack*variance*(crit?1.5:1)));
      setMessage(`${skillDisplayName(skill)} ${heroDisplayName()} gives ${currentEnemy.name} a careful smack!${crit?" CRITICAL!":""}`);
      await sleep(280);
      await hurtEnemyNonLethal(dmg);
    } else {
      setMessage(`${currentEnemy.name} is already at 1 HP — the smack won't knock it out!`);
      await sleep(540);
    }
    }
  } else if(skill.type==="shiyu-glitch") {
    if(skillState && skill.oncePerBattle)skillState.onceUsed[skill.id]=true;
    const triggered=Math.random()<0.40;
    const hits=triggered?3:1;
    const stats=peepStats();
    const attack=stats.attack*(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)
      *(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)
      *(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
    setMessage(triggered?"Glitch Assault! Shiyu follows up with TWO extra stabs!":"Glitch Assault! Shiyu stabs!");
    await sleep(250);
    for(let i=0;i<hits && currentEnemy?.hpNow>0;i++){
      const variance=.96+Math.random()*.08;
      await hurtEnemy(Math.max(1,Math.round(attack*variance)));
      if(i<hits-1 && currentEnemy?.hpNow>0)await sleep(110);
    }
  } else if(skill.type==="multi-hit") {
    if(heroCanMissFromFluster(skill)) {
      if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
      if(skill.oncePerBattle) skillState.onceUsed[skill.id]=true;
      setMessage(`${heroDisplayName()} got too flustered and missed!`);
      await sleep(540);
    } else {
    if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
    if(skill.oncePerBattle) skillState.onceUsed[skill.id]=true;
    const stats=peepStats();
    const boostedAttack=stats.attack*(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)*(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)*(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
    const hits=Math.max(2,Number(skill.hits)||4);
    const perHit=(skill.multiplier||1)/hits;
    const multiMessage = skill.id==="gun"
      ? "He has a gun! Miko fires four quick shots!"
      : skill.id==="sparkle-shot"
        ? "Sparkle Shot! Io fires three sparkling stars!"
        : `${skillDisplayName(skill)}! ${heroDisplayName()} attacks ${hits} times!`;
    setMessage(multiMessage);
    await sleep(240);
    for(let i=0;i<hits && currentEnemy && currentEnemy.hpNow>0;i++){
      const variance=0.96+Math.random()*0.08;
      const dmg=Math.max(1,Math.round(boostedAttack*perHit*variance));
      await hurtEnemy(dmg);
      if(i<hits-1 && currentEnemy?.hpNow>0) await sleep(90);
    }
    }
  } else if(skill.id==="failed-spell") {
    if(heroCanMissFromFluster(skill)) {
      setMessage(`${heroDisplayName()} got too flustered and missed!`);
      await sleep(540);
    } else {
      if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
      if(skill.oncePerBattle) skillState.onceUsed[skill.id]=true;
      const roll=Math.random();
      if(roll<0.01){
        const before=currentRun.hp;
        const backlash=Math.max(1,Math.round(currentRun.maxHp*0.25));
        currentRun.hp=Math.max(1,currentRun.hp-backlash);
        const lost=Math.max(0,before-currentRun.hp);
        setMessage(`Failed Spell BACKFIRED! The magic loops around and bonks Miko for ${lost} HP!`);
        if(lost>0) showFloat(`-${lost}`,"damage","peep");
        renderPeepHp();
        await sleep(700);
      } else {
        const huge=roll<0.16;
        const multiplier=huge?4.25:(skill.multiplier||1.85);
        const stats=peepStats();
        const boostedAttack=stats.attack*(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)*(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)*(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
        const crit=Math.random()<0.11;
        const variance=0.9+Math.random()*0.2;
        const dmg=Math.max(1,Math.round(boostedAttack*multiplier*variance*(crit?1.5:1)));
        setMessage((huge?"Failed Spell goes WILD! HUGE DAMAGE!":"Failed Spell!") + (crit?" CRITICAL!":""));
        await sleep(280);
        await hurtEnemy(dmg);
      }
    }
  } else if(skill.type==="damage-burn") {
    if(heroCanMissFromFluster(skill)) {
      setMessage(`${heroDisplayName()} got too flustered and missed!`);
      await sleep(540);
    } else {
      let multiplier=skill.multiplier||1;
      let flavor=skillDisplayName(skill);
      if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
      if(skill.oncePerBattle) skillState.onceUsed[skill.id]=true;

      const stats=peepStats();
      const boostedAttack=stats.attack*(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)*(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)*(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
      const crit=Math.random()<0.11;
      const variance=0.9+Math.random()*0.2;
      const dmg=Math.max(1,Math.round(boostedAttack*multiplier*variance*(crit?1.5:1)));
      setMessage(flavor + (crit?" CRITICAL!":""));
      await sleep(280);
      await hurtEnemy(dmg);
      if(currentEnemy && currentEnemy.hpNow>0 && Math.random() < Number(skill.burnChance||1)) {
        skillState.enemyBurnTurns=Math.max(Number(skillState.enemyBurnTurns||0), Number(skill.burnTurns||99));
        skillState.enemyBurnDamagePercent=Number(skill.burnDamagePercent||0.08);
        setMessage(`${currentEnemy.name} was burned!`);
        await sleep(420);
      }
    }
  } else {
    if(heroCanMissFromFluster(skill)) {
      setMessage(`${heroDisplayName()} got too flustered and missed!`);
      await sleep(540);
    } else {
    let multiplier=skill.multiplier||1;
    let flavor=skillDisplayName(skill);
    if(skill.id==="shiyu-final-warning" && currentEnemy && currentEnemy.hpNow/currentEnemy.maxHp < .40) multiplier *= 1.75;

    if(skill.id==="heart-ray") {
      skillState.heartRayCount=(skillState.heartRayCount||0)+1;
      if(skillState.heartRayCount%5===0){
        multiplier=skill.boostedMultiplier||1.8;
        flavor="Heart Ray! The 5th heart bursts with extra power!";
      }
    }

    if(skill.id==="duck-throw") {
      const duck=pickThrowDuck();
      flavor=`Duck Throw! ${duck.name} goes flying!`;
      showThrownDuck(duck);
    }
    if(skill.cooldown) skillState.cooldowns[skill.id]=skill.cooldown;
    if(skill.oncePerBattle) skillState.onceUsed[skill.id]=true;

    const stats=peepStats();
    const boostedAttack=stats.attack*(skillState.attackBuffTurns>0?skillState.attackBuffMultiplier:1)*(skillState.buddyAttackBuffTurns>0?skillState.buddyAttackMultiplier:1)*(skillState.enemyDefenseDownTurns>0?skillState.enemyDefenseMultiplier:1);
    const crit=Math.random()<0.11;
    const variance=0.9+Math.random()*0.2;
    const dmg=Math.max(1,Math.round(boostedAttack*multiplier*variance*(crit?1.5:1)));
    setMessage(flavor + (crit?" CRITICAL!":""));
    await sleep(280);
    await hurtEnemy(dmg);
    if(activeCharacterId==="angel" && skill.splashChance && Math.random()<skill.splashChance){
      const original=currentEnemy;
      const other=aliveDoubleEnemies().find(enemy=>enemy!==original && enemy.hpNow>0);
      if(other){selectCurrentEnemy(other);await hurtEnemy(Math.max(1,Math.round(dmg*skill.splashMultiplier)));selectCurrentEnemy(original);}
    }
    if(activeCharacterId==="angel" && skill.attackDownChance && currentEnemy?.hpNow>0 && Math.random()<skill.attackDownChance){
      skillState.enemyAttackDownTurns=2;skillState.enemyAttackMultiplier=.80;
      saveCurrentEnemyEffects(currentEnemy);
      setMessage(`${currentEnemy.name}'s Attack fell by 20% for 2 turns!`);
    }
    }
  }

  if(activeCharacterId==="angel" && skill.shieldPercent){
    skillState.angelShieldHp=Math.max(1,Math.round(currentRun.maxHp*skill.shieldPercent));
    skillState.angelShieldTurns=skill.shieldDuration||2;
    skillState.angelShieldPendingTick=true;
    // Buddy assistance also uses hero HP; the whole party is protected by this shared combat shield.
    setMessage(`${skill.name} protects the party with ${skillState.angelShieldHp} HP of magic shielding!`);
    await sleep(350);
  }
  removeHeroVisualClass("attack-pop");
  restoreHeroIdleFrame();
  clearHeroSpecialAttackScale();
  decrementCooldowns(skill.id);

  if(currentEnemy && currentEnemy.hpNow<=0) {
    const encounterDone=await enemyDefeated();
    if(encounterDone) return;
  }

  await sleep(300);
  await enemyTurnSequence();
  actionLocked=false;
  renderCommandButtons();
  renderSkills();
}

function decrementCooldowns(usedSkillId) {
  if(activeCharacterId==="angel" && skillState?.angelShieldTurns>0){
    if(skillState.angelShieldPendingTick)skillState.angelShieldPendingTick=false;
    else if(--skillState.angelShieldTurns<=0)skillState.angelShieldHp=0;
  }

  if(!skillState.cooldowns) skillState.cooldowns={};
  Object.keys(skillState.cooldowns).forEach(id=>{
    if(id!==usedSkillId && skillState.cooldowns[id]>0) skillState.cooldowns[id]--;
  });
  if(usedSkillId!==skillState.activeBuffSkillId && skillState.attackBuffTurns>0) {
    skillState.attackBuffTurns--;
    if(skillState.attackBuffTurns<=0) skillState.activeBuffSkillId=null;
  }
  if(usedSkillId!==skillState.activeBuffSkillId && skillState.heroMissTurns>0) {
    skillState.heroMissTurns--;
    if(skillState.heroMissTurns<=0) skillState.heroMissChance=0;
  }
  if(Number(skillState.heroAttackDownTurns||0)>0){
    skillState.heroAttackDownTurns=Math.max(0,Number(skillState.heroAttackDownTurns||0)-1);
    if(skillState.heroAttackDownTurns<=0) skillState.heroAttackDownMultiplier=1;
  }
  if(Number(skillState.heroStunTurns||0)>0) skillState.heroStunTurns=Math.max(0,Number(skillState.heroStunTurns||0)-1);
  if(Number(skillState.heroSleepTurns||0)>0) skillState.heroSleepTurns=Math.max(0,Number(skillState.heroSleepTurns||0)-1);
  if(Number(skillState.heroParalysisMoves||0)>0){
    skillState.heroParalysisMoves=Math.max(0,Number(skillState.heroParalysisMoves||0)-1);
    if(skillState.heroParalysisMoves<=0) skillState.heroParalysisFailChance=0;
  }
  tickPlayerBuddyEffects();
}

async function hurtEnemyNonLethal(dmg=1) {
  if(!currentEnemy) return;
  const before=Math.max(0,Number(currentEnemy.hpNow)||0);

  if(currentEnemy.variantDodgeReady){
    currentEnemy.variantDodgeReady=false;
    const cooldown=Math.max(1,Number(currentEnemy.variantSpecial?.cooldownTurns)||3);
    currentEnemy.variantDodgeCooldown=cooldown+1;
    setMessage(`${currentEnemy.name}'s Cloud Dodge made the attack miss completely!`);
    await sleep(360);
    return 0;
  }

  if(before<=1){
    currentEnemy.hpNow=1;
    renderEnemyHp();
    return;
  }
  let finalDmg=Math.max(1,Math.round(Number(dmg)||1));
  if(Number(currentEnemy.variantGuardHitsRemaining||0)>0){
    finalDmg=Math.max(1,Math.ceil(finalDmg*Math.max(.10,Number(currentEnemy.variantGuardMultiplier)||1)));
    currentEnemy.variantGuardHitsRemaining=Math.max(0,Number(currentEnemy.variantGuardHitsRemaining||0)-1);
    setMessage(`${currentEnemy.variantGuardName||"Special Guard"} reduced the damage!`);
  }
  currentEnemy.hpNow=Math.max(1,before-finalDmg);
  const dealt=Math.max(0,before-currentEnemy.hpNow);
  const refs=activeEnemyUi();
  if(refs.sprite){
    refs.sprite.src=currentEnemy.hurt;
    refs.sprite.classList.add("hurt-pop");
  }
  if(dealt>0) showFloat(`-${dealt}`,"damage","enemy");
  renderEnemyHp();
  await sleep(360);
  if(refs.sprite) refs.sprite.classList.remove("hurt-pop");
  if(currentEnemy.hpNow>0 && refs.sprite) refs.sprite.src=currentEnemy.idle[0];
}

async function hurtEnemy(dmg) {
  if(!currentEnemy) return;
  let finalDmg=Math.max(1,Math.round(dmg));

  if(currentEnemy.variantDodgeReady){
    currentEnemy.variantDodgeReady=false;
    const cooldown=Math.max(1,Number(currentEnemy.variantSpecial?.cooldownTurns)||3);
    currentEnemy.variantDodgeCooldown=cooldown+1;
    setMessage(`${currentEnemy.name}'s Cloud Dodge made the attack miss completely!`);
    await sleep(360);
    return 0;
  }

  if(Number(currentEnemy.variantGuardHitsRemaining||0)>0){
    finalDmg=Math.max(1,Math.ceil(finalDmg*Math.max(.10,Number(currentEnemy.variantGuardMultiplier)||1)));
    currentEnemy.variantGuardHitsRemaining=Math.max(0,Number(currentEnemy.variantGuardHitsRemaining||0)-1);
    setMessage(`${currentEnemy.variantGuardName||"Special Guard"} reduced the damage!`);
  }

  if(Number(currentEnemy.shellHitsRemaining||0)>0){
    finalDmg=Math.max(1,Math.ceil(finalDmg*.75));
    currentEnemy.shellHitsRemaining--;
    setMessage(`${currentEnemy.name}'s Harden Shell reduced the damage!`);
  }
  currentEnemy.hpNow=Math.max(0,currentEnemy.hpNow-finalDmg);
  const refs=activeEnemyUi();
  if(refs.sprite){refs.sprite.src=currentEnemy.hurt; refs.sprite.classList.add("hurt-pop");}
  showFloat(`-${finalDmg}`,"damage","enemy"); renderEnemyHp(); await sleep(360);
  if(refs.sprite) refs.sprite.classList.remove("hurt-pop");
  if(currentEnemy.hpNow>0 && refs.sprite) refs.sprite.src=currentEnemy.idle[enemyIdleIndex%currentEnemy.idle.length];
  return finalDmg;
}

async function performEnemyAttack(multiplier=1,label="",lifeDrainHeal=0){
  if(!currentEnemy) return 0;
  setMessage(label||`${currentEnemy.name} attacks!`);
  const refs=activeEnemyUi();
  if(currentEnemy.id==='miss-wick'&&!currentEnemy._summonedFlameV359){
    currentEnemy._summonedFlameV359=true;
    const field=ui.battlefield||document.querySelector('#battlefield');
    if(field){
      const spirit=document.createElement('img');spirit.className='flame-spirit-summon-v359';
      const colors=['','blue-','green-','purple-','grey-'];
      spirit.src='assets/enemies/flame-spirit/base/'+colors[Math.floor(Math.random()*colors.length)]+'idle-1.webp';
      spirit.alt='Miss Wick’s summoned Flame Spirit';field.append(spirit);
      setMessage('Miss Wick summons a tiny Flame Spirit! ✨');
      await sleep(700);spirit.remove();
      if(!currentRun||currentRun.hp<=0)return 0;
    }
    setMessage(label||`${currentEnemy.name} attacks!`);
  }
  refs.sprite?.classList.add("attack-pop"); await sleep(300);

  if(skillState.enemyAccuracyDownTurns>0 && Math.random()<Number(skillState.enemyMissChance||0)){
    refs.sprite?.classList.remove("attack-pop");
    setMessage(`${currentEnemy.name}'s attack missed thanks to Wing Gust!`);
    await sleep(350);
    return 0;
  }

  const stats=peepStats(); const crit=Math.random()<.05;
  const attackDebuff=skillState.enemyAttackDownTurns>0?skillState.enemyAttackMultiplier:1;
  const weakened=Math.max(.1,Number(skillState.enemyNextAttackMultiplier)||1);
  skillState.enemyNextAttackMultiplier=1;
  const variantNextBoost=Math.max(.1,Number(currentEnemy.variantNextAttackMultiplier)||1);
  const variantTimedBoost=Number(currentEnemy.variantAttackBoostTurns||0)>0
    ? Math.max(.1,Number(currentEnemy.variantAttackBoostMultiplier)||1)
    : 1;
  currentEnemy.variantNextAttackMultiplier=1;
  if(Number(currentEnemy.variantAttackBoostTurns||0)>0){
    currentEnemy.variantAttackBoostTurns=Math.max(0,Number(currentEnemy.variantAttackBoostTurns||0)-1);
    if(currentEnemy.variantAttackBoostTurns<=0) currentEnemy.variantAttackBoostMultiplier=1;
  }
  let dmg=Math.max(1,Math.round((currentEnemy.attackNow*attackDebuff-(stats.defense*.55))*(.85+Math.random()*.25)*multiplier*weakened*variantNextBoost*variantTimedBoost));
  if(crit) dmg=Math.round(dmg*1.5);
  if(skillState.heroGuardTurns>0) dmg=Math.max(1,Math.round(dmg*Math.max(.1,Number(skillState.heroGuardMultiplier)||1)));
  if(Number(skillState.heroNextDamageMultiplier||1)<1){
    dmg=Math.max(1,Math.round(dmg*skillState.heroNextDamageMultiplier));
    skillState.heroNextDamageMultiplier=1;
  }
  if(activeCharacterId==="angel" && (skillState?.angelShieldTurns||0)>0 && (skillState?.angelShieldHp||0)>0){
    const blocked=Math.min(dmg,skillState.angelShieldHp);
    skillState.angelShieldHp-=blocked;dmg-=blocked;
    if(blocked)showFloat(`Shield -${blocked}`,"heal","peep");
  }
  currentRun.hp=Math.max(0,currentRun.hp-dmg);
  setHeroFrame(heroHurtFrame());addHeroVisualClass("hurt-pop");
  showFloat(`-${dmg}`,"damage","peep");renderPeepHp();
  if(lifeDrainHeal>0 && currentEnemy.hpNow>0){
    const before=currentEnemy.hpNow;
    currentEnemy.hpNow=Math.min(currentEnemy.maxHp,currentEnemy.hpNow+Math.max(1,Math.round(dmg*lifeDrainHeal)));
    const healed=currentEnemy.hpNow-before;
    if(healed>0){showFloat(`+${healed}`,"heal","enemy");renderEnemyHp();}
  }
  await sleep(420);removeHeroVisualClass("hurt-pop");refs.sprite?.classList.remove("attack-pop");
  restoreHeroIdleFrame();
  if(currentRun.hp<=0) endRun(false);
  else if(!label) setMessage(crit?`${currentEnemy.name} landed a critical hit!`:`${heroDisplayName()} is ready!`);
  return dmg;
}

async function enemyTurn() {
  if(!currentEnemy || currentEnemy.hpNow<=0) return;

  if(Number(currentEnemy.variantDodgeCooldown||0)>0){
    currentEnemy.variantDodgeCooldown=Math.max(0,Number(currentEnemy.variantDodgeCooldown||0)-1);
  }

  if(Number(skillState.enemyStunTurns||0)>0){
    skillState.enemyStunTurns=Math.max(0,Number(skillState.enemyStunTurns||0)-1);
    const remaining=skillState.enemyStunTurns;
    setMessage(`${currentEnemy.name} is frozen and couldn't move!${remaining>0?` ${remaining} frozen turn${remaining===1?"":"s"} left.`:""}`);
    await sleep(650);
    tickEnemyBuddyEffects();
    setMessage(`${heroDisplayName()} is ready!`);
    return;
  }

  if(skillState.enemyStunned){
    skillState.enemyStunned=false;
    setMessage(`${currentEnemy.name} is stunned and couldn't move!`);
    await sleep(650);
    tickEnemyBuddyEffects();
    setMessage(`${heroDisplayName()} is ready!`);
    return;
  }

  const finishEnemyBuddyTurn=async()=>{
    const burnedOut = await applyEnemyBurnTick();
    if(burnedOut) return true;
    tickEnemyBuddyEffects();
    return false;
  };

  // Generic healer variants: Blue Seagull, Green Slime, Orange Flower, etc.
  const canSelfHeal=currentEnemy.healPercent>0 && currentEnemy.hpNow<currentEnemy.maxHp &&
    Number(currentEnemy.healsUsed||0)<Number(currentEnemy.maxHeals||0) &&
    currentEnemy.hpNow<=currentEnemy.maxHp*.72 && Math.random()<Number(currentEnemy.healChance||0);
  if(canSelfHeal){
    const amount=Math.max(1,Math.round(currentEnemy.maxHp*currentEnemy.healPercent));
    const before=currentEnemy.hpNow; currentEnemy.hpNow=Math.min(currentEnemy.maxHp,currentEnemy.hpNow+amount); currentEnemy.healsUsed++;
    const gained=currentEnemy.hpNow-before; setMessage(`${currentEnemy.name} used ${currentEnemy.healMoveName||"Recovery!"}`);
    const refs=activeEnemyUi(); refs.sprite?.classList.add("attack-pop");showFloat(`+${gained}`,"heal","enemy");renderEnemyHp();await sleep(650);
    refs.sprite?.classList.remove("attack-pop");if(await finishEnemyBuddyTurn()) return; setMessage(`${heroDisplayName()} is ready!`);return;
  }

  // New color-specific special variants.
  if(await tryEnemySpecialVariantMove()){
    if(await finishEnemyBuddyTurn()) return;
    return;
  }

  // Pink Sea Turtle: protects itself from the next two player attacks.
  if(currentEnemy.specialType==="harden-shell" && !currentEnemy.shellHitsRemaining &&
     currentEnemy.specialUses<currentEnemy.maxSpecialUses && Math.random()<currentEnemy.specialChance){
    currentEnemy.specialUses++;currentEnemy.shellHitsRemaining=2;
    setMessage(`${currentEnemy.name} used Harden Shell! The next 2 hits deal 25% less damage.`);
    const refs=activeEnemyUi(); refs.sprite?.classList.add("attack-pop");await sleep(650);refs.sprite?.classList.remove("attack-pop");if(await finishEnemyBuddyTurn()) return; return;
  }

  // Orange Cat-Fish: spends a turn powering up its next attack.
  if(currentEnemy.specialType==="zoomies" && !currentEnemy.zoomiesBoost &&
     currentEnemy.specialUses<currentEnemy.maxSpecialUses && Math.random()<currentEnemy.specialChance){
    currentEnemy.specialUses++;currentEnemy.zoomiesBoost=true;
    setMessage(`${currentEnemy.name} used Zoomies! Its next attack is powered up by 25%.`);
    const refs=activeEnemyUi(); refs.sprite?.classList.add("attack-pop");await sleep(650);refs.sprite?.classList.remove("attack-pop");if(await finishEnemyBuddyTurn()) return; return;
  }

  // Every Vampire Squid can use Life Drain twice per battle.
  if(currentEnemy.lifeDrain && currentEnemy.hpNow<currentEnemy.maxHp &&
     currentEnemy.lifeDrainsUsed<currentEnemy.maxLifeDrains && Math.random()<currentEnemy.lifeDrainChance){
    currentEnemy.lifeDrainsUsed++;
    await performEnemyAttack(currentEnemy.lifeDrainDamage,`${currentEnemy.name} used Life Drain!`,currentEnemy.lifeDrainHeal);
    if(await finishEnemyBuddyTurn()) return;
    if(currentRun.hp>0) setMessage(`Life Drain stole some of ${heroDisplayName()}'s HP!`);
    return;
  }

  const boosted=Boolean(currentEnemy.zoomiesBoost);
  if(boosted) currentEnemy.zoomiesBoost=false;
  await performEnemyAttack(boosted?1.25:1,boosted?`${currentEnemy.name}'s Zoomies-powered attack!`:(currentEnemy.id==="angy-duck"?`${currentEnemy.name} used Loud Quack!`:""));
  if(await finishEnemyBuddyTurn()) return;
  if(currentRun.hp>0) setMessage(`${heroDisplayName()} is ready!`);
}

async function enemyTurnSequence(){
  if(!currentEnemy || !currentRun) return;
  if(!isDoubleBattleActive()){
    await enemyTurn();
    return;
  }

  saveCurrentEnemyEffects();
  const turnOrder=[...aliveDoubleEnemies()];
  for(const enemy of turnOrder){
    if(!currentRun || currentRun.hp<=0) break;
    if(!enemy || enemy.hpNow<=0 || enemy._defeated) continue;
    selectCurrentEnemy(enemy);
    setMessage(`${enemy.name}${enemy.shiny?" ✨":""}'s turn!`);
    await sleep(260);
    await enemyTurn();
    if(currentEnemy===enemy) saveCurrentEnemyEffects(enemy);
  }

  if(currentRun?.hp>0){
    const remaining=aliveDoubleEnemies();
    if(remaining.length){
      selectCurrentEnemy(remaining[0]);
      startEnemyIdle();
      if(remaining[1]) startSecondaryEnemyIdle(remaining[1]);
      setMessage(`${heroDisplayName()} is ready! Choose who to attack.`);
    }
  }
}

async function quickHealTurn() {
  if(actionLocked || !currentEnemy || !currentRun) return;

  if(quickHealUses >= QUICK_HEAL_MAX_USES){
    setMessage("No Quick Heals left this battle!");
    renderCommandButtons();
    return;
  }

  if(currentRun.hp >= currentRun.maxHp){
    setMessage(`${heroDisplayName()} is already at full health!`);
    renderCommandButtons();
    return;
  }

  actionLocked=true;
  quickHealUses++;

  const amount=Math.max(1,Math.round(currentRun.maxHp*QUICK_HEAL_PERCENT));
  const before=currentRun.hp;
  currentRun.hp=Math.min(currentRun.maxHp,currentRun.hp+amount);
  const healed=currentRun.hp-before;

  setMessage(`Quick Heal! ${heroDisplayName()} restored ${healed} HP.`);
  showFloat(`+${healed}`,"heal","peep");
  renderPeepHp();
  renderCommandButtons();
  await sleep(500);

  decrementCooldowns("quick-heal");
  await enemyTurnSequence();

  actionLocked=false;
  renderCommandButtons();
  renderSkills();
}

function buddyLowHpCatchBonus(enemy){
  if(!enemy || enemy.shiny) return 0;
  const maxHp=Math.max(1,Number(enemy.maxHp)||1);
  const hpNow=Math.max(0,Number(enemy.hpNow));
  return hpNow/maxHp<=0.50 ? 0.10 : 0;
}

function buddyPonCatchRate(pon, enemy) {
  if(!pon || !enemy) return 0;
  if(enemy.shiny) return 1;
  const base=enemy.boss
    ? Math.max(0,Math.min(1,Number(pon.bossRate)||0))
    : Math.max(0,Math.min(1,Number(pon.normalRate)||0));
  if(base<=0) return 0;
  const friendBonus=Math.max(0,Number(activeCharmByFamily("best-friend")?.catchBonus)||0);
  return Math.max(0,Math.min(1,base+buddyLowHpCatchBonus(enemy)+friendBonus));
}

function hasCompatibleBuddyPon(enemy) {
  return BUDDY_PONS.some(pon=>hubInventoryQty(pon.id)>0 && buddyPonCatchRate(pon,enemy)>0);
}

function renderPonPurchaseChoices() {
  if(!ui.ponPurchaseChoices) return;
  ui.ponPurchaseChoices.innerHTML="";
  if(ui.ponPurchaseCoins) ui.ponPurchaseCoins.textContent=`${Math.max(0,Number(hubSave.coins)||0).toLocaleString()} Pink Coins`;
  BUDDY_PONS.forEach(pon=>{
    const button=document.createElement("button");
    button.type="button";
    button.className=`pon-purchase-option${pon.className?` ${pon.className}`:""}`;
    button.dataset.ponId=pon.id;
    const price=Math.max(0,Number(pon.price)||0);
    const catchRate=currentEnemy ? buddyPonCatchRate(pon,currentEnemy) : 0;
    const canAfford=Number(hubSave.coins)>=price;
    button.disabled=actionLocked || !currentEnemy || !canAfford || catchRate<=0;
    const lowHpBonus=buddyLowHpCatchBonus(currentEnemy)>0;
    const chanceLabel=catchRate>0 ? `${Math.round(catchRate*100)}% vs ${currentEnemy.name}${currentEnemy.shiny?" ✨":""}${lowHpBonus?" · Low HP bonus":""}` : "0% vs this boss";
    button.innerHTML=`<img src="${pon.image}" alt=""><span><strong>${pon.name}</strong><small>${price} Pink Coins · ${chanceLabel}</small></span>`;
    button.addEventListener("click",()=>purchaseBuddyPon(pon.id));
    ui.ponPurchaseChoices.appendChild(button);
  });
  if(ui.purchasePonButton) ui.purchasePonButton.disabled=actionLocked || !currentEnemy;
}

function togglePonPurchasePanel() {
  if(!ui.ponPurchasePanel || actionLocked || !currentEnemy) return;
  const willOpen=ui.ponPurchasePanel.classList.contains("hidden");
  ui.ponPurchasePanel.classList.toggle("hidden",!willOpen);
  if(willOpen) {
    if(ui.ponPurchaseMessage) ui.ponPurchaseMessage.textContent="Buy Pons here and use them immediately in this battle.";
    renderPonPurchaseChoices();
  }
}

function purchaseBuddyPon(ponId) {
  if(actionLocked || !currentEnemy) return;
  const pon=BUDDY_PONS.find(item=>item.id===ponId);
  if(!pon) return;
  const catchRate=buddyPonCatchRate(pon,currentEnemy);
  if(catchRate<=0) return;
  const price=Math.max(0,Number(pon.price)||0);
  const coins=Math.max(0,Number(hubSave.coins)||0);
  if(coins<price) {
    if(ui.ponPurchaseMessage) ui.ponPurchaseMessage.textContent=`You need ${price-coins} more Pink Coins for a ${pon.name}.`;
    renderPonPurchaseChoices();
    return;
  }
  hubSave.coins=coins-price;
  if(!hubSave.inventory || typeof hubSave.inventory!=="object" || Array.isArray(hubSave.inventory)) hubSave.inventory={};
  const nextQty=hubInventoryQty(pon.id)+1;
  hubSave.inventory[pon.id]=nextQty;
  persistAll();
  renderMeta();
  renderBattleItems();
  renderPonPurchaseChoices();
  if(ui.ponPurchaseMessage) ui.ponPurchaseMessage.textContent=`Purchased 1 ${pon.name}! You now have ×${nextQty}.`;
}

async function attemptBattleCapture(ponId,targetOverride=null) {
  if(actionLocked || !currentEnemy || !currentRun) return;
  const pon=BUDDY_PONS.find(item=>item.id===ponId);
  if(!pon) return;
  const target=targetOverride || currentEnemy;
  if(target) selectCurrentEnemy(target);
  const rate=buddyPonCatchRate(pon,target);
  if(rate<=0 || hubInventoryQty(pon.id)<=0) return;
  if(!consumeHubItem(pon.id,1)) return;

  closeCommandWindow();
  actionLocked=true;
  renderCommandButtons();
  renderBattleItems();
  setMessage(`${heroDisplayName()} threw a ${pon.name}!`);
  animateBuddyPon(pon);
  await sleep(760);

  const success=rate>=1 || Math.random()<rate;
  if(success) {
    const buddy=captureBuddy(target);
    renderEnemyName(target);
    renderBuddyHomeCount();
    setMessage(`${target.name}${target.shiny?" ✨":""} became your Lil Guy! You now own ×${buddy.quantity}.`);
    await sleep(520);
    const encounterDone=await enemyDefeated({captured:true});
    if(encounterDone) return;
    decrementCooldowns("buddy-pon");
    await enemyTurnSequence();
    actionLocked=false;
    ui.commandGrid.classList.remove("hidden");
    renderCommandButtons(); renderSkills(); renderBattleItems();
    return;
  }

  setMessage(`${target.name}${target.shiny?" ✨":""} slipped out of the ${pon.name}!`);
  await sleep(520);
  // A failed throw is the OC's Item action, just like a healing item.
  decrementCooldowns("buddy-pon");
  await enemyTurnSequence();
  actionLocked=false;
  renderCommandButtons();
  renderSkills();
  renderBattleItems();
}

function renderBefriendChoices() {
  if(!ui.befriendPonChoices || !pendingDefeatedEnemy) return;
  ui.befriendPonChoices.innerHTML="";
  BUDDY_PONS.forEach(pon=>{
    const qty=hubInventoryQty(pon.id);
    const rate=buddyPonCatchRate(pon,pendingDefeatedEnemy);
    const button=document.createElement("button");
    button.type="button";
    button.className=`befriend-pon-button${pon.className?` ${pon.className}`:""}`;
    button.dataset.ponId=pon.id;
    button.disabled=befriendAttempted || qty<=0 || rate<=0 || actionLocked;
    const rateLabel=rate>0?`${Math.round(rate*100)}% chance`:"Normal enemies only";
    button.innerHTML=`<img src="${pon.image}" alt=""><strong>${pon.name}</strong><small>×${qty} · ${rateLabel}</small>`;
    button.addEventListener("click",()=>attemptBefriend(pon.id));
    ui.befriendPonChoices.appendChild(button);
  });
  renderPonPurchaseChoices();
}

function showBefriendPanel(enemy) {
  pendingDefeatedEnemy=enemy;
  befriendAttempted=false;
  const owned=buddyOwnedQuantity(buddyKeyForEnemy(enemy));
  ui.befriendTitle.textContent=`Befriend ${enemy.name}${enemy.shiny?" ✨":""}?`;
  const hasPon=hasCompatibleBuddyPon(enemy);
  if(enemy.shiny) {
    ui.befriendText.textContent=`Shiny Lil Guy! Any Lil Pon is a guaranteed catch. Owned so far: ×${owned}.${hasPon?"":" No Pon? Purchase one below before continuing!"}`;
  } else if(enemy.boss) {
    ui.befriendText.textContent=`Boss Lil Guys are tougher to befriend. Owned so far: ×${owned}.${hasPon?"":" You can purchase a compatible Pon below."}`;
  } else {
    ui.befriendText.textContent=`Choose one Lil Pon for a chance to befriend it. Owned so far: ×${owned}.${hasPon?"":" You can purchase one below."}`;
  }
  ui.skipBefriend.textContent="Continue to Chest";
  if(ui.purchasePonButton) {
    ui.purchasePonButton.disabled=false;
    ui.purchasePonButton.textContent="Purchase Pon";
  }
  ui.ponPurchasePanel?.classList.add("hidden");
  if(ui.ponPurchaseMessage) ui.ponPurchaseMessage.textContent="Buy a Lil Pon without leaving this encounter.";
  ui.befriendPanel.classList.remove("hidden");
  renderBefriendChoices();
}

function animateBuddyPon(pon) {
  const img=document.createElement("img");
  img.src=pon.image;
  img.alt="";
  img.className="capture-pon-fly";
  ui.battlefield.appendChild(img);
  setTimeout(()=>img.remove(),820);
}

async function attemptBefriend(ponId) {
  if(actionLocked || befriendAttempted || !pendingDefeatedEnemy) return;
  const pon=BUDDY_PONS.find(item=>item.id===ponId);
  if(!pon) return;
  const rate=buddyPonCatchRate(pon,pendingDefeatedEnemy);
  if(rate<=0 || hubInventoryQty(pon.id)<=0) return;
  if(!consumeHubItem(pon.id,1)) return;

  actionLocked=true;
  befriendAttempted=true;
  renderBefriendChoices();
  setMessage(`${heroDisplayName()} used a ${pon.name}!`);
  animateBuddyPon(pon);
  await sleep(760);

  const success=rate>=1 || Math.random()<rate;
  if(success) {
    const buddy=captureBuddy(pendingDefeatedEnemy);
    renderEnemyName(pendingDefeatedEnemy);
    ui.befriendTitle.textContent=`${pendingDefeatedEnemy.name}${pendingDefeatedEnemy.shiny?" ✨":""} became your Lil Guy!`;
    ui.befriendText.textContent=`Befriended! You now own ×${buddy.quantity}.`;
    setMessage(`${pendingDefeatedEnemy.name}${pendingDefeatedEnemy.shiny?" ✨":""} became your Lil Guy!`);
    renderBuddyHomeCount();
  } else {
    ui.befriendTitle.textContent=`Almost! ${pendingDefeatedEnemy.name} slipped away.`;
    ui.befriendText.textContent="That Lil Pon was used up. You can try again next time you meet this Lil Guy!";
    setMessage(`${pendingDefeatedEnemy.name} slipped away this time!`);
  }
  ui.skipBefriend.textContent="Continue to Chest";
  ui.ponPurchasePanel?.classList.add("hidden");
  if(ui.purchasePonButton) ui.purchasePonButton.disabled=true;
  actionLocked=false;
  renderBefriendChoices();
}

async function finishBefriendStep() {
  if(actionLocked || !pendingChest) return;
  actionLocked=true;
  ui.befriendPanel?.classList.add("hidden");
  ui.ponPurchasePanel?.classList.add("hidden");
  ui.enemyCombatant.classList.add("hidden");
    ui.enemyCombatant2?.classList.add("hidden");
  await sleep(220);
  pendingDefeatedEnemy=null;
  befriendAttempted=false;
  actionLocked=false;
  showChest(pendingChest);
}

async function enemyDefeated(options={}) {
  if(!currentEnemy) return true;
  const defeated=currentEnemy;
  clearInterval(idleTimer);
  const refs=enemyUiFor(defeated);
  defeated._defeated=true;
  defeated.hpNow=0;
  saveCurrentEnemyEffects(defeated);
  ui.commandGrid.classList.add("hidden");
  closeCommandWindow();
  refs.combatant?.classList.add("hidden");
  setMessage(options.captured
    ? `${defeated.name}${defeated.shiny?" ✨":""} was befriended!`
    : `${defeated.name}${defeated.shiny?" ✨":""} was defeated!`);

  await sleep(options.captured?360:420);

  const encounter=currentEncounterData();
  const isDouble=encounter?.type==="double-enemy" && doubleBattleEnemies.length>1;
  if(isDouble){
    if(!Array.isArray(encounter.defeatedEnemies)) encounter.defeatedEnemies=[];
    if(!encounter.defeatedEnemies.some(entry=>entry?._doubleSlot===defeated._doubleSlot)) encounter.defeatedEnemies.push({...defeated});
    const alive=aliveDoubleEnemies();
    if(alive.length){
      selectCurrentEnemy(alive[0]);
      clearInterval(secondaryEnemyIdleTimer); secondaryEnemyIdleTimer=null;
      startEnemyIdle();
      ui.commandGrid.classList.remove("hidden");
      renderCommandButtons(); renderSkills(); renderBattleItems();
      setMessage(`${defeated.name}${options.captured?" was befriended":" is down"}! ${alive.map(enemy=>enemy.name).join(" remains! ")}${alive.length===1?" remains!":""}`);
      return false;
    }
  }

  const isBoss=Boolean(defeated.boss);
  pendingChest={
    kind:isBoss?"boss":isDouble?"double-trouble":"normal",
    revealMimic:false,
    enemy:defeated,
    enemies:isDouble?[...(encounter?.defeatedEnemies||[])] : [defeated],
    doubleTrouble:Boolean(isDouble)
  };

  currentEnemy=defeated;
  actionLocked=false;
  showChest(pendingChest);
  return true;
}

function showChest(data) {
  pendingChest=data;
  if(!data?.eventType) hideEventChoices();
  ui.buddyCombatant?.classList.add("hidden");
  ui.chestSprite.src=data.eventType==="lucky-picnic"
    ? "assets/events/Picnic.png"
    : data.eventType==="wishing-fountain"
      ? "assets/events/Fountain.png"
      : data.mystery
        ? "assets/shinies/amethyst-mimic-closed.webp"
        : "assets/items/chests/treasure/closed.webp";
  ui.chestSprite.classList.remove("opening","mystery-chest-sprite","event-scene-art","merchant-duck");
  ui.chestSprite.classList.toggle("mystery-chest-sprite",Boolean(data.mystery));
  ui.openChest.classList.remove("hidden");
  ui.openChest.disabled=false;
  ui.openChest.textContent=data.buttonLabel || "Open";
  ui.chestLayer.classList.remove("hidden");
  ui.chestCaption.textContent=data.captionText || (data.mystery
    ? "A strange purple chest appeared..."
    :data.kind==="rare"
      ?"A rare treasure chest appeared!"
      :data.kind==="double-trouble"
        ?"Double Trouble cleared!"
        :data.revealMimic
          ?"A treasure chest appeared!"
          :"Victory chest!");
}

function addRewardItem(items,item,qty=1){
  if(!item) return;
  const existing=items.find(x=>x.id===item.id);
  if(existing) existing.qty+=qty;
  else items.push({...item,qty});
}

function jackpotItem(){
  const pool=REWARD_ITEMS.filter(item=>!["buddy-pon","super-buddy-pon","boss-buddy-pon"].includes(item.id));
  const weighted=pool.map(item=>({item,weight:Math.max(1,16-Math.min(15,Number(item.weight)||1))}));
  const total=weighted.reduce((sum,x)=>sum+x.weight,0);
  let roll=Math.random()*total;
  for(const entry of weighted){ roll-=entry.weight; if(roll<=0) return entry.item; }
  return pool[0];
}

function weightedRewardItemByIds(ids){
  const pool=REWARD_ITEMS.filter(item=>ids.includes(item.id));
  if(!pool.length) return weightedItemWithCharm();
  const total=pool.reduce((sum,item)=>sum+(Number(item.weight)||1),0);
  let roll=Math.random()*total;
  for(const item of pool){
    roll-=(Number(item.weight)||1);
    if(roll<=0) return item;
  }
  return pool[0];
}

function markEndlessFloorComplete(){
  if(currentRun?.mode!=="endless") return;
  const progress=endlessProgress();
  const completed=Math.max(1,Math.floor(Number(currentRun.floor)||1));
  progress.record=Math.max(progress.record,completed);
  progress.checkpoint=completed+1;
  currentRun.endlessFloorsCompleted=Math.max(0,Math.floor(Number(currentRun.endlessFloorsCompleted)||0))+1;
  persistAll();
  renderMeta();
}

async function openPendingChest() {
  if(!pendingChest || ui.chestLayer.classList.contains("hidden")) return;
  if(ui.openChest.disabled) return;
  actionLocked=true;
  ui.openChest.disabled=true;
  ui.chestSprite.classList.remove("opening");
  await sleep(260);

  if(pendingChest.eventType){
    if(pendingChest.eventType==="lucky-picnic") ui.chestSprite.src="assets/events/Picnic.png";
    else if(pendingChest.eventType==="wishing-fountain") ui.chestSprite.src="assets/events/Fountain.png";
    await sleep(140);
    const choiceName=eventChoiceLabel(pendingChest.eventType,pendingChest.eventChoice);
    setMessage(pendingChest.eventType==="lucky-picnic"
      ? `${choiceName}! The picnic turned into a lovely little break.`
      : `${choiceName}! The Wishing Fountain sparkles...`);
  } else if(pendingChest.mystery){
    ui.chestSprite.src="assets/shinies/amethyst-mimic-open.webp";
    await sleep(180);
    const isAmethystMimic=Math.random()<AMETHYST_MIMIC_RATE;
    if(isAmethystMimic){
      ui.chestCaption.textContent="Oh no... it moved!";
      setMessage("The purple chest was an Amethyst Mimic ✨!");
      await sleep(420);
      ui.chestLayer.classList.add("hidden");
      actionLocked=false;
      startEnemy("mimic",{forceShiny:true});
      return;
    }
    pendingChest={kind:"hidden-treasure",hiddenTreasure:true,revealMimic:false};
    ui.chestCaption.textContent="Hidden Treasure! JACKPOT!";
    setMessage("Hidden Treasure! You found a huge jackpot!");
  } else if(pendingChest.revealMimic) {
    ui.chestSprite.src="assets/items/chests/treasure/open.webp";
    await sleep(140);
    ui.chestLayer.classList.add("hidden");
    actionLocked=false;
    startEnemy("mimic");
    return;
  } else {
    ui.chestSprite.src="assets/items/chests/treasure/open.webp";
  }

  const rewards=generateRewards(pendingChest);
  applyRewards(rewards);

  const textParts=[];
  if(rewards.coins) textParts.push(`+${rewards.coins} Pink Coins`);
  if(rewards.exp) textParts.push(`+${rewards.exp} EXP`);
  if(rewards.happiness) textParts.push(`♡ +${rewards.happiness} Happiness`);
  else if(rewards.happinessMaxed) textParts.push("♡ Happiness MAX");
  if(rewards.unlockedBackgrounds?.length) textParts.push(rewards.unlockedBackgrounds.map(bg=>`${bg.label} Icon`).join(", "));
  if(rewards.iconBorderStyle) textParts.push(`${rewards.iconBorderStyle.label}`);
  if(rewards.iconBorderColor) textParts.push(`${rewards.iconBorderColor.label} Border Color`);
  if(rewards.items.length) textParts.push(rewards.items.map(x=>`${x.name} ×${x.qty}`).join(", "));
  if(rewards.charmTreasureBonus) textParts.push("Treasure Charm bonus!");
  if(rewards.luckyFluffBonus) textParts.push(`Lucky Fluff +${rewards.luckyFluffBonus} Coins!`);
  if(rewards.tradingCardResults?.length) textParts.push(rewards.tradingCardResults.map(result=>`${result.card.name} Card${result.isNew?" ✨":""}`).join(", "));

  ui.chestCaption.textContent=pendingChest.hiddenTreasure
    ? `JACKPOT! · ${textParts.join(" · ")}`
    : pendingChest.eventType
      ? `${eventChoiceLabel(pendingChest.eventType,pendingChest.eventChoice)} · ${textParts.join(" · ")}`
      : pendingChest.kind==="double-trouble"
        ? `Double Trouble cleared! · ${textParts.join(" · ")}`
        : textParts.join(" · ");
  ui.openChest.classList.add("hidden");
  if(!pendingChest.hiddenTreasure){
    if(pendingChest.eventType){
      setMessage(`${eventChoiceLabel(pendingChest.eventType,pendingChest.eventChoice)} rewards collected!`);
    } else if(pendingChest.kind==="double-trouble"){
      setMessage("Double Trouble rewards collected!");
    } else {
      setMessage("Treasure collected!");
    }
  }

  // Fully recover between encounters so every new fight begins at max HP.
  currentRun.hp=currentRun.maxHp;
  renderPeepHp();
  markEndlessFloorComplete();

  await sleep(350);
  ui.continueButton.textContent=currentRun?.mode==="endless"?"Next Floor":"Continue";
  ui.postFloorActions?.classList.remove("hidden");
  ui.leaveEndlessButton?.classList.toggle("hidden",currentRun?.mode!=="endless");
  setPostFloorLayout(true);
  actionLocked=false;
}

function weightedItemWithCharm(){
  const fortune=activeCharmByFamily("fortune");
  const luck=Math.max(0,Math.min(1,Number(fortune?.itemLuck)||0));
  return luck>0&&Math.random()<luck?jackpotItem():weightedItem();
}
function finalizeCharmRewards(reward,chest){
  const fortune=activeCharmByFamily("fortune");
  const training=activeCharmByFamily("training");
  const treasure=activeCharmByFamily("treasure");
  reward.coins=Math.max(0,Math.round((Number(reward.coins)||0)*(1+Math.max(0,Number(fortune?.coinBonus)||0))));
  reward.exp=Math.max(0,Math.round((Number(reward.exp)||0)*(1+Math.max(0,Number(training?.expBonus)||0))));

  // Red Plushbun — Lucky Fluff: +5–12 coins when the special Plushbun was
  // defeated/caught, or when a Red Plushbun Lil Guy was active/used in the fight.
  const battleFoes=Array.isArray(chest?.enemies) && chest.enemies.length
    ? chest.enemies
    : (chest?.enemy ? [chest.enemy] : []);
  const redPlushbunFoe=battleFoes.some(enemy=>enemy?.id==="plushbun" && enemyVariantId(enemy)==="red");
  const activeBuddy=activeBattleBuddyRecord();
  const redPlushbunBuddy=activeBuddy?.enemyId==="plushbun" && activeBuddy?.variantId==="red";
  if(battleFoes.length && (redPlushbunFoe || redPlushbunBuddy || currentRun?.luckyFluffUsedThisEncounter)){
    reward.luckyFluffBonus=randInt(5,12);
  }

  const treasureChance=Math.max(0,Math.min(1,Number(treasure?.treasureChance)||0));
  if(treasureChance>0&&Math.random()<treasureChance){ addRewardItem(reward.items,jackpotItem(),1); reward.charmTreasureBonus=true; }
  return reward;
}

function generateRewards(chest) {
  const rank=currentRun.rank;
  let coins=0, exp=0, itemRolls=0, itemChance=0;
  const items=[];

  if(chest.eventType==="lucky-picnic"){
    const choice=chest.eventChoice || "share-snacks";
    if(choice==="check-basket"){
      coins=randInt(22,36)+Math.max(2,Math.round(rank*1.35));
      exp=randInt(5,9)+Math.max(1,Math.round(rank*.55));
      addRewardItem(items,weightedRewardItemByIds(["bread-loaf","apple","flower","thread","yarn","glitter"]),1);
      addRewardItem(items,weightedRewardItemByIds(["bread-loaf","apple","flower","thread","yarn"]),1);
      return finalizeCharmRewards({coins,exp,happiness:2,items,iconBackground:null,iconBorderStyle:null,iconBorderColor:null,wallpaper:null},chest);
    }
    if(choice==="relax"){
      coins=randInt(8,14)+Math.max(1,Math.round(rank*.65));
      exp=randInt(18,28)+Math.max(2,Math.round(rank*1.35));
      addRewardItem(items,weightedRewardItemByIds(["bread-loaf","apple","flower"]),1);
      return finalizeCharmRewards({coins,exp,happiness:3,items,iconBackground:null,iconBorderStyle:null,iconBorderColor:null,wallpaper:null},chest);
    }
    coins=randInt(10,18)+Math.max(1,Math.round(rank*.85));
    exp=randInt(8,13)+Math.max(1,Math.round(rank*.65));
    addRewardItem(items,weightedRewardItemByIds(["bread-loaf","apple","flower"]),1);
    return finalizeCharmRewards({coins,exp,happiness:5,items,iconBackground:null,iconBorderStyle:null,iconBorderColor:Math.random()<.08?pickChestIconBorderColor({kind:"normal"}):null,wallpaper:null},chest);
  }

  if(chest.eventType==="wishing-fountain"){
    const choice=chest.eventChoice || "fortune";
    if(choice==="treasure"){
      coins=randInt(10,18)+Math.max(1,Math.round(rank*.75));
      exp=randInt(7,11)+Math.max(1,Math.round(rank*.55));
      addRewardItem(items,weightedRewardItemByIds(["glitter","pink-paint","mint-paint","aqua-paint","gold-paint","buddy-pon","super-buddy-pon"]),1);
      if(Math.random()<.55) addRewardItem(items,weightedItemWithCharm(),1);
      return finalizeCharmRewards({
        coins,exp,happiness:2,items,
        iconBackground:Math.random()<.24 ? pickChestIconBackground({kind:"rare"}) : null,
        iconBorderStyle:Math.random()<.12 ? pickChestIconBorderStyle({kind:"rare"}) : null,
        iconBorderColor:Math.random()<.28 ? pickChestIconBorderColor({kind:"rare"}) : null,
        wallpaper:Math.random()<.12 ? pickChestWallpaper({kind:"rare"}) : null
      },chest);
    }
    if(choice==="friendship"){
      coins=randInt(6,12)+Math.max(1,Math.round(rank*.55));
      exp=randInt(20,30)+Math.max(2,Math.round(rank*1.35));
      addRewardItem(items,weightedRewardItemByIds(["flower","apple","glitter"]),1);
      return finalizeCharmRewards({coins,exp,happiness:6,items,iconBackground:null,iconBorderStyle:null,iconBorderColor:null,wallpaper:null},chest);
    }
    coins=randInt(35,55)+Math.max(3,Math.round(rank*2.0));
    exp=randInt(6,10)+Math.max(1,Math.round(rank*.5));
    addRewardItem(items,weightedRewardItemByIds(["pink-paint","mint-paint","aqua-paint","glitter"]),1);
    return finalizeCharmRewards({coins,exp,happiness:2,items,iconBackground:Math.random()<.08?pickChestIconBackground({kind:"normal"}):null,iconBorderStyle:null,iconBorderColor:null,wallpaper:null},chest);
  }

  if(chest.kind==="hidden-treasure") {
    coins=randInt(300,500);
    exp=randInt(180,300);
    addRewardItem(items,REWARD_ITEMS.find(x=>x.id==="buddy-pon"),1);
    if(Math.random()<.70) addRewardItem(items,REWARD_ITEMS.find(x=>x.id==="super-buddy-pon"),1);
    if(Math.random()<.30) addRewardItem(items,REWARD_ITEMS.find(x=>x.id==="boss-buddy-pon"),1);
    for(let i=0;i<3;i++) addRewardItem(items,jackpotItem(),1);
    return finalizeCharmRewards({
      coins,exp,happiness:chestHappinessReward(chest),items,
      iconBackground:pickChestIconBackground({kind:"rare"}),
      iconBorderStyle:pickChestIconBorderStyle({kind:"hidden-treasure"}),
      iconBorderColor:pickChestIconBorderColor({kind:"hidden-treasure"}),
      wallpaper:pickChestWallpaper({kind:"hidden-treasure"})
    },chest);
  }

  if(chest.kind==="double-trouble"){
    const foes=Array.isArray(chest.enemies) && chest.enemies.length ? chest.enemies : (chest.enemy?[chest.enemy]:[]);
    coins=foes.reduce((sum,foe)=>sum+randInt(Math.max(1,Number(foe.coinMinNow)||1),Math.max(1,Number(foe.coinMaxNow)||1)),0)+12;
    exp=foes.reduce((sum,foe)=>sum+Math.max(1,Number(foe.expNow)||1),0)+6;
    itemRolls=2;
    itemChance=1;
  } else if(chest.kind==="rare") {
    coins=randInt(28,45)+rank*2;
    exp=randInt(8,14)+rank;
    itemRolls=1;
    itemChance=1;
  } else if(chest.kind==="boss") {
    coins=randInt(chest.enemy.coinMinNow,chest.enemy.coinMaxNow)+12;
    exp=chest.enemy.expNow;
    itemRolls=2;
    itemChance=1;
  } else {
    coins=randInt(chest.enemy.coinMinNow,chest.enemy.coinMaxNow);
    exp=chest.enemy.expNow;
    itemRolls=1;
    itemChance=0.38;
  }

  if(chest.enemy?.id==="mimic") {
    coins+=randInt(20,32);
    itemRolls=Math.max(1,itemRolls)+1;
    itemChance=1;
  }

  for(let i=0;i<itemRolls;i++) {
    if(Math.random()<=itemChance) {
      let item=weightedItemWithCharm();
      if((chest.kind==="boss" || chest.kind==="double-trouble") && items.some(x=>x.id===item.id)) {
        for(let retry=0; retry<5 && items.some(x=>x.id===item.id); retry++) item=weightedItemWithCharm();
      }
      addRewardItem(items,item,1);
    }
  }

  const rewardChestKind=chest.kind==="double-trouble" ? "rare" : chest.kind;
  const iconBackground=pickChestIconBackground({kind:rewardChestKind,enemy:chest.enemy});
  const iconBorderStyle=pickChestIconBorderStyle({kind:rewardChestKind,enemy:chest.enemy});
  const iconBorderColor=pickChestIconBorderColor({kind:rewardChestKind,enemy:chest.enemy});
  const wallpaper=pickChestWallpaper({kind:rewardChestKind,enemy:chest.enemy});
  return finalizeCharmRewards({coins,exp,happiness:chestHappinessReward(chest),items,iconBackground,iconBorderStyle,iconBorderColor,wallpaper},chest);
}

function weightedItem() {
  const total=REWARD_ITEMS.reduce((s,x)=>s+x.weight,0);
  let roll=Math.random()*total;
  for(const item of REWARD_ITEMS) {
    roll-=item.weight;
    if(roll<=0) return item;
  }
  return REWARD_ITEMS[0];
}

function ensureCurrentRunRewardCollections(){
  if(!currentRun || typeof currentRun!=="object") return;
  const collectionKeys=[
    "itemsEarned",
    "iconBackgroundsEarned",
    "iconBorderStylesEarned",
    "iconBorderColorsEarned",
    "wallpapersEarned",
    "closetRewardsEarned",
    "uiThemesEarned",
    "levelBackgroundsEarned",
    "levelsGained"
  ];
  for(const key of collectionKeys){
    if(!Array.isArray(currentRun[key])) currentRun[key]=[];
  }
}

function applyRewards(rewards) {
  ensureCurrentRunRewardCollections();
  const affectionMultiplier=affectionRewardMultiplier();
  rewards.coins=Math.max(0,Math.round((Number(rewards.coins)||0)*affectionMultiplier));
  rewards.exp=Math.max(0,Math.round((Number(rewards.exp)||0)*affectionMultiplier));
  // Lucky Fluff is a flat +5–12 coin bonus, so charms/affection do not inflate it.
  if(rewards.luckyFluffBonus) rewards.coins+=Math.max(0,Math.round(Number(rewards.luckyFluffBonus)||0));
  hubSave.coins=Math.max(0,Number(hubSave.coins)||0)+rewards.coins;
  if(!hubSave.stats || typeof hubSave.stats!=="object") hubSave.stats={};
  hubSave.stats.coinsEarnedTotal=Math.max(0,Number(hubSave.stats.coinsEarnedTotal)||0)+Math.max(0,Number(rewards.coins)||0);
  currentRun.coinsEarned+=rewards.coins;
  questSave.totalCoinsEarned=(Number(questSave.totalCoinsEarned)||0)+rewards.coins;

  const chestBackground=rewards.iconBackground ? unlockIconBackground(rewards.iconBackground.id) : null;
  const unlockedBorderStyle=rewards.iconBorderStyle ? unlockIconBorderStyle(rewards.iconBorderStyle.id) : null;
  const unlockedBorderColor=rewards.iconBorderColor ? unlockIconBorderColor(rewards.iconBorderColor.id) : null;
  const unlockedWallpaper=rewards.wallpaper ? unlockWallpaper(rewards.wallpaper.id) : null;

  const levelResult=grantExp(rewards.exp);
  const levelBackgrounds=unlockLevelIconBackgrounds(levelResult);
  rewards.unlockedBackgrounds=[...(chestBackground?[chestBackground]:[]),...levelBackgrounds];

  currentRun.expEarned+=rewards.exp;
  questSave.totalExpEarned=(Number(questSave.totalExpEarned)||0)+rewards.exp;
  const requestedHappiness=Math.max(0,Math.floor(Number(rewards.happiness)||0));
  rewards.happiness=grantQuestHappiness(requestedHappiness);
  rewards.happinessMaxed=requestedHappiness>0 && rewards.happiness===0;
  currentRun.happinessEarned=Math.max(0,Math.floor(Number(currentRun.happinessEarned)||0))+rewards.happiness;
  if(levelResult.length) currentRun.levelsGained.push(...levelResult);
  if(chestBackground) currentRun.iconBackgroundsEarned.push(chestBackground);
  if(unlockedBorderStyle) currentRun.iconBorderStylesEarned.push(unlockedBorderStyle);
  if(unlockedBorderColor) currentRun.iconBorderColorsEarned.push(unlockedBorderColor);
  if(unlockedWallpaper) currentRun.wallpapersEarned.push(unlockedWallpaper);
  if(levelBackgrounds.length){
    currentRun.iconBackgroundsEarned.push(...levelBackgrounds);
    currentRun.levelBackgroundsEarned.push(...levelBackgrounds);
  }

  if(!hubSave.inventory || typeof hubSave.inventory!=="object") hubSave.inventory={};
  rewards.items.forEach(item=>{
    hubSave.inventory[item.id]=Math.max(0,Number(hubSave.inventory[item.id])||0)+item.qty;
    const existing=currentRun.itemsEarned.find(x=>x.id===item.id);
    if(existing) existing.qty+=item.qty;
    else currentRun.itemsEarned.push({...item});
  });

  questSave.totalBattlesWon=(Number(questSave.totalBattlesWon)||0)+(pendingChest?.doubleTrouble ? Math.max(1,Math.floor(Number(pendingChest?.enemies?.length)||2)) : (pendingChest?.enemy?1:0));
  const newRewardMessages=[];
  if(chestBackground) newRewardMessages.push(`${chestBackground.label} Icon Background`);
  if(unlockedBorderStyle) newRewardMessages.push(`${unlockedBorderStyle.label}`);
  if(unlockedBorderColor) newRewardMessages.push(`${unlockedBorderColor.label} Border Color`);
  if(unlockedWallpaper) newRewardMessages.push(`${unlockedWallpaper.label} Wallpaper`);
  if(newRewardMessages.length) setMessage(`Treasure collected! New reward: ${newRewardMessages.join(" · ")}`);

  persistAll();
  renderMeta();
  renderBattleItems();
}

function grantExp(amount) {
  const gained=[];
  const hero=activeHeroProgress();
  if(hero.level>=MAX_LEVEL) return gained;
  hero.exp+=Math.max(0,Number(amount)||0);
  while(hero.level<MAX_LEVEL) {
    const need=expNeeded(hero.level);
    if(hero.exp<need) break;
    hero.exp-=need;
    hero.level++;
    gained.push(hero.level);
    if(hero.level>=MAX_LEVEL) {
      hero.exp=0;
      break;
    }
  }
  return gained;
}

function refillActiveHeroHpV210(){
  if(!currentRun) return;
  const stats=peepStats(activeHeroProgress().level);
  const maxHp=Math.max(1,Math.round(Number(stats?.maxHp)||Number(currentRun.maxHp)||1));
  currentRun.maxHp=maxHp;
  currentRun.hp=maxHp;
  renderPeepHp();
}
window.DUCKIE_HP_REFILL_CORE='24.210-all-oc-between-encounters';

function nextEncounter() {
  if(window.DuckieLoveInterests?.maybeBeforeNextEncounter?.(()=>nextEncounter())) return;
  refillActiveHeroHpV210();
  resetDoubleBattleUi();
  ui.chestLayer.classList.add("hidden");
  ui.postFloorActions?.classList.add("hidden");
  setPostFloorLayout(false);
  if(currentRun?.mode==="endless"){
    const nextFloor=endlessProgress().checkpoint;
    currentRun.floor=Math.max(1,nextFloor);
    currentRun.rank=endlessEffectiveRank(currentRun.floor);
    currentRun.floorBackground=chooseEndlessBackground(currentRun.floorBackground);
    currentRun.endlessEncounter=makeEndlessEncounter(currentRun.floor);
    startEncounter();
    return;
  }

  currentRun.index++;
  if(currentRun.index>=4) {
    endRun(true);
    return;
  }
  startEncounter();
}

function leaveEndlessAfterFloor(){
  if(currentRun?.mode!=="endless") return;
  endlessExitReason="paused";
  endRun(false);
}

function endRun(won) {
  clearAnimations();
  if(currentRun?.mode==="endless"){
    if(!endlessExitReason) endlessExitReason="defeated";
    // Count one Endless Run when the player finishes or pauses a session after
    // completing at least one floor. Simply opening and immediately leaving
    // does not advance the theme milestone counter.
    if(!currentRun.endlessRunCounted && Math.max(0,Number(currentRun.endlessFloorsCompleted)||0)>0){
      currentRun.endlessRunCounted=true;
      questSave.endlessRunsCompleted=Math.max(0,Math.floor(Number(questSave.endlessRunsCompleted)||0))+1;
      const newThemes=awardQuestThemesForEndlessRuns();
      if(newThemes.length) currentRun.uiThemesEarned.push(...newThemes);
    }
    // The checkpoint is updated only when a floor is completed. If the hero
    // falls or leaves mid-floor, the same floor is waiting next time.
    persistAll();
    renderMeta();
    renderResult(false);
    showScreen("result");
    return;
  }

  if(won){
    currentRun.bossWon=true; questSave.completedRuns=(Number(questSave.completedRuns)||0)+1; questSave.bossWins=(Number(questSave.bossWins)||0)+1;
    grantQuestHappiness(2);
    const progress=areaProgress(currentRun.area); const maxRank=getAreaConfig(currentRun.area).maxRank;
    if(currentRun.rank===progress.unlockedRank && progress.unlockedRank<maxRank) progress.unlockedRank++;
    const newThemes=awardQuestThemesForClearedLevel(currentRun.area,currentRun.rank,activeCharacterId);
    if(newThemes.length){
      if(!Array.isArray(currentRun.uiThemesEarned)) currentRun.uiThemesEarned=[];
      currentRun.uiThemesEarned.push(...newThemes);
    }
    const areaReward=AREA_CLEAR_CLOSET_REWARDS[currentRun.area];
    if(areaReward && currentRun.rank>=maxRank){
      const hero=activeHeroProgress();
      if(!hero.clearedAreas || typeof hero.clearedAreas!=="object") hero.clearedAreas={meadow:false,ocean:false,candy:false,cloud:false};
      hero.clearedAreas[currentRun.area]=true;
      if(!hasCharacterClosetReward(activeCharacterId,areaReward.id) && unlockCharacterClosetReward(activeCharacterId,areaReward.id)){
        if(!Array.isArray(currentRun.closetRewardsEarned)) currentRun.closetRewardsEarned=[];
        currentRun.closetRewardsEarned.push({name:`${areaReward.name} · Unlocked for ${heroDisplayName()}!`,image:areaReward.image});
        // Spooky reward is a paintable Universal Clothing extra. Grant one persistent copy once per OC.
        if(currentRun.area==='spooky'){
          if(!hubSave.inventory || typeof hubSave.inventory!=='object')hubSave.inventory={};
          hubSave.inventory['uclothes-spooky-cat-ears']=Math.max(0,Number(hubSave.inventory['uclothes-spooky-cat-ears'])||0)+1;
        }
      }
    }
  }
  persistAll(); renderMeta(); renderResult(won); showScreen("result");
}

function renderResult(won) {
  ensureCurrentRunRewardCollections();
  const isEndless=currentRun?.mode==="endless";

  if(isEndless){
    const progress=endlessProgress();
    const paused=endlessExitReason==="paused";
    ui.resultKicker.textContent=paused?"ENDLESS RUN PAUSED!":"ENDLESS RUN ENDED";
    ui.resultTitle.textContent=paused
      ? `Checkpoint saved at Floor ${progress.checkpoint}!`
      : `${heroDisplayName()} made it to Floor ${Math.max(1,currentRun.floor)}!`;
    if(ui.resultProgressLabel) ui.resultProgressLabel.textContent="Record";
    ui.resultRank.textContent=`Floor ${progress.record}`;
    ui.runNextRank.classList.add("hidden");
    ui.runNextRank.disabled=true;
    const runAgain=document.querySelector("#runAgain");
    if(runAgain){
      runAgain.classList.remove("hidden");
      runAgain.textContent=`Continue Floor ${progress.checkpoint}`;
    }
  } else {
    const areaId=currentRun?.area||selectedArea; const cfg=getAreaConfig(areaId); const progress=areaProgress(areaId);
    ui.resultKicker.textContent=won?"RUN COMPLETE!":"RUN ENDED";
    ui.resultTitle.textContent=won?cfg.resultTitle:`${heroDisplayName()} needs a little rest.`;
    const finishedRank=Math.max(1,Number(currentRun?.rank||selectedRank)||1);
    const nextRank=Math.min(cfg.maxRank,finishedRank+1);
    const canRunNext=Boolean(won)&&nextRank>finishedRank&&nextRank<=progress.unlockedRank;
    ui.runNextRank.classList.toggle("hidden",!won);
    ui.runNextRank.disabled=Boolean(won)&&!canRunNext;
    ui.runNextRank.textContent=canRunNext?"Run Next Level":"Max Level Reached";
    ui.runNextRank.dataset.rank=canRunNext?String(nextRank):"";
    ui.runNextRank.dataset.area=areaId;
    if(ui.resultProgressLabel) ui.resultProgressLabel.textContent="Level";
    ui.resultRank.textContent=`${cfg.name} Level ${finishedRank}`;
    const runAgain=document.querySelector("#runAgain");
    if(runAgain) runAgain.classList.add("hidden");
  }

  ui.resultCoins.textContent=currentRun?.coinsEarned||0;
  ui.resultExp.textContent=currentRun?.expEarned||0;
  ui.resultItems.innerHTML="";
  (currentRun?.itemsEarned||[]).forEach(item=>{
    const el=document.createElement("div");
    el.className="result-item";
    el.innerHTML=`<img src="${item.image}" alt=""><span>${item.name} ×${item.qty}</span>`;
    ui.resultItems.appendChild(el);
  });
  (currentRun?.iconBackgroundsEarned||[]).forEach(bg=>{
    const el=document.createElement("div");el.className="result-item";
    const swatch=document.createElement("span");swatch.className="result-icon-bg-swatch";applyIconBackgroundStyle(swatch,bg);
    const label=document.createElement("span");label.textContent=`${bg.label} Icon Background`;
    el.append(swatch,label);ui.resultItems.appendChild(el);
  });
  (currentRun?.iconBorderStylesEarned||[]).forEach(style=>{
    const el=document.createElement("div");el.className="result-item border-reward";
    const preview=document.createElement("span");preview.className="result-icon-border-preview";applyIconBorderPreviewStyle(preview,style,iconBorderColorById("white"));
    const label=document.createElement("span");label.textContent=`NEW BORDER STYLE! ${style.label}`;
    el.append(preview,label);ui.resultItems.appendChild(el);
  });
  (currentRun?.iconBorderColorsEarned||[]).forEach(color=>{
    const el=document.createElement("div");el.className="result-item border-reward";
    const preview=document.createElement("span");preview.className="result-icon-border-preview";applyIconBorderPreviewStyle(preview,iconBorderStyleById("stitched"),color);
    const label=document.createElement("span");label.textContent=`NEW BORDER COLOR! ${color.label}`;
    el.append(preview,label);ui.resultItems.appendChild(el);
  });
  (currentRun?.wallpapersEarned||[]).forEach(wallpaper=>{
    const el=document.createElement("div");el.className="result-item wallpaper-reward";
    const swatch=document.createElement("span");swatch.className="result-wallpaper-swatch";applyWallpaperStyle(swatch,wallpaper);
    const label=document.createElement("span");label.textContent=`NEW WALLPAPER! ${wallpaper.label}`;
    el.append(swatch,label);ui.resultItems.appendChild(el);
  });
  (currentRun?.closetRewardsEarned||[]).forEach(reward=>{
    const el=document.createElement("div");el.className="result-item closet-reward";
    el.innerHTML=`<img src="${reward.image}" alt=""><span>${reward.name}</span>`;
    ui.resultItems.appendChild(el);
  });
  (currentRun?.uiThemesEarned||[]).forEach(theme=>{
    const el=document.createElement("div");el.className="result-item theme-reward";
    el.appendChild(makeQuestThemeSwatch(theme,"result-theme-swatch"));
    const label=document.createElement("span");label.textContent=`NEW UI THEME! ${theme.name}`;
    el.appendChild(label); ui.resultItems.appendChild(el);
  });
  if(!(currentRun?.itemsEarned||[]).length && !(currentRun?.iconBackgroundsEarned||[]).length && !(currentRun?.iconBorderStylesEarned||[]).length && !(currentRun?.iconBorderColorsEarned||[]).length && !(currentRun?.wallpapersEarned||[]).length && !(currentRun?.closetRewardsEarned||[]).length && !(currentRun?.uiThemesEarned||[]).length){
    const el=document.createElement("div");el.className="result-item";el.textContent="No item drops this time — try another run!";ui.resultItems.appendChild(el);
  }
  const levels=[...new Set(currentRun?.levelsGained||[])];
  if(levels.length){
    ui.levelUpNotice.classList.remove("hidden");
    const unlocked=activeSkills().filter(s=>levels.includes(s.unlock)).map(skillDisplayName);
    const levelBgs=[...new Map((currentRun?.levelBackgroundsEarned||[]).map(bg=>[bg.id,bg])).values()];
    const extras=[];
    if(unlocked.length) extras.push(`New skill unlocked: ${unlocked.join(", ")}`);
    if(levelBgs.length) extras.push(`New Icon Background: ${levelBgs.map(bg=>bg.label).join(", ")}`);
    ui.levelUpNotice.textContent=`Level up! ${heroDisplayName()} reached Lv. ${activeHeroProgress().level}.${extras.length?` ${extras.join(" · ")}`:""}`;
  } else ui.levelUpNotice.classList.add("hidden");
}

function pickThrowDuck() {
  const unlocked=Array.isArray(hubSave.unlockedDucks)?hubSave.unlockedDucks:[];
  const normalize=v=>String(v||"").toLowerCase().replace(/\.[^.]+$/,"").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
  const unlockedIds=new Set(unlocked.map(normalize));
  const pool=DUCK_LIBRARY.filter(d=>unlockedIds.has(normalize(d.id)));
  const candidates=pool.length?pool:DUCK_LIBRARY.filter(d=>normalize(d.id)==="standard-duck");
  return candidates[randInt(0,candidates.length-1)] || DUCK_LIBRARY[0];
}

function showThrownDuck(duck) {
  const img=document.createElement("img");
  img.src=`../assets/ducks/${duck.file}`;
  img.alt="";
  img.style.cssText="position:absolute;z-index:20;width:36px;height:36px;object-fit:contain;image-rendering:pixelated;left:30%;top:64%;transition:transform .45s linear,left .45s linear,top .45s linear;pointer-events:none;";
  document.querySelector("#battlefield").appendChild(img);
  requestAnimationFrame(()=>{
    img.style.left="69%";
    img.style.top="56%";
    img.style.transform="rotate(360deg)";
  });
  setTimeout(()=>img.remove(),650);
}

function showFloat(text,type="damage",target="enemy") {
  const el = target === "peep" ? ui.peepDamageText : activeEnemyUi().damageText;
  if (!el) return;

  el.textContent = text;
  el.classList.remove("hidden","damage-show","heal-pop");
  if (type === "heal") el.classList.add("heal-pop");

  // Restart the tiny pop animation even on repeated -1 hits.
  void el.offsetWidth;
  el.classList.add("damage-show");

  setTimeout(() => {
    el.classList.remove("damage-show","heal-pop");
    el.classList.add("hidden");
  }, 520);
}

function setMessage(text) { ui.battleMessage.textContent=text; }

function returnHome() {
  clearAnimations(); resetDoubleBattleUi(); closeBuddyDetail(); currentRun=null;
  selectedArea=AREA_CONFIG[activeHeroProgress().lastArea]?activeHeroProgress().lastArea:"meadow";
  selectedRank=areaProgress(selectedArea).lastRank||1;
  showScreen("home"); renderMeta();
}

document.querySelector("#backGames").addEventListener("click",()=>window.location.href="../#games");
ui.openBuddyCollection?.addEventListener("click",()=>{ closeBuddyDetail(); setBuddyScreenUrl(true); showScreen("buddy"); });
ui.openUiThemes?.addEventListener("click",openUiThemePicker);
ui.closeUiThemes?.addEventListener("click",closeUiThemePicker);
ui.uiThemeModal?.addEventListener("click",event=>{ if(event.target===ui.uiThemeModal) closeUiThemePicker(); });
ui.backFromBuddies?.addEventListener("click",()=>{ closeBuddyDetail(); setBuddyScreenUrl(false); showScreen("home"); renderMeta(); });
ui.openCharmScreen?.addEventListener("click",()=>{ setCharmMessage("Choose up to three different charm families."); showScreen("charm"); });
ui.backFromCharms?.addEventListener("click",()=>{ showScreen("home"); renderMeta(); });
ui.buddyFilters.forEach(button=>button.addEventListener("click",()=>{
  buddyCollectionFilter=button.dataset.buddyFilter || "meadow";
  renderBuddyCollection();
}));
ui.closeBuddyDetail?.addEventListener("click",closeBuddyDetail);
ui.buddyGenderButtons?.forEach(button=>button.addEventListener("click",()=>{
  const selected=button.dataset.buddyGender || "";
  buddyPersonalizeGender=buddyPersonalizeGender===selected?"":selected;
  ui.buddyGenderButtons.forEach(item=>item.classList.toggle("selected",item.dataset.buddyGender===buddyPersonalizeGender));
}));
ui.saveBuddyPersonalization?.addEventListener("click",saveBuddyPersonalization);
ui.setBuddyFamilyIcon?.addEventListener("click",()=>{
  const entry=buddyDisplayCatalog().find(candidate=>candidate.key===buddyDetailEntryKey);
  if(!entry || buddyOwnedQuantity(entry.key)<=0) return;
  if(setSelectedBuddyFamilyIcon(entry)){
    renderBuddyCollection();
    openBuddyDetail(entry);
  }
});

ui.buddyAssignOpen?.addEventListener("click",()=>{
  const entry=buddyDisplayCatalog().find(candidate=>candidate.key===buddyDetailEntryKey);
  if(!entry || buddyOwnedQuantity(entry.key)<=0) return;
  const opening=ui.buddyAssignPanel?.classList.contains("hidden");
  if(opening){
    ui.buddyAssignPanel.classList.remove("hidden");
    ui.buddyAssignOpen.textContent="Hide Assignment";
    renderBuddyAssignPanel(entry);
  }else{
    ui.buddyAssignPanel.classList.add("hidden");
    ui.buddyAssignOpen.textContent="Assign to OC";
  }
});
ui.buddyDetail?.addEventListener("click",event=>{ if(event.target===ui.buddyDetail) closeBuddyDetail(); });
ui.runNextRank.addEventListener("click",()=>{
  const areaId=AREA_CONFIG[ui.runNextRank.dataset.area]?ui.runNextRank.dataset.area:selectedArea;
  const nextRank=Math.max(1,Number(ui.runNextRank.dataset.rank)||0);
  const progress=areaProgress(areaId),maxRank=getAreaConfig(areaId).maxRank;
  if(!nextRank||nextRank>progress.unlockedRank||nextRank>maxRank)return;
  selectedArea=areaId;selectedRank=nextRank;beginRun();
});
ui.areaButtons.forEach(btn=>btn.addEventListener("click",()=>{
  const areaId=btn.dataset.area;if(!AREA_CONFIG[areaId])return;
  openRoutePicker(areaId);
}));
ui.closeRoutePicker?.addEventListener("click",closeRoutePicker);
ui.routePickerModal?.addEventListener("click",event=>{ if(event.target===ui.routePickerModal) closeRoutePicker(); });
ui.startCurrentRoute?.addEventListener("click",()=>{
  const progress=areaProgress(selectedArea);
  selectedRank=Math.max(1,Math.min(getAreaConfig(selectedArea).maxRank,progress.unlockedRank||1));
  closeRoutePicker();
  beginRun();
});
ui.startBeginningRoute?.addEventListener("click",()=>{
  const opening=ui.routeStartLevelPicker?.classList.contains("hidden");
  ui.routeStartLevelPicker?.classList.toggle("hidden",!opening);
  ui.startBeginningRoute?.setAttribute("aria-expanded",String(Boolean(opening)));
  if(opening) ui.routeStartLevelSelect?.focus();
});
ui.routeStartLevelSelect?.addEventListener("change",syncStartingPointButton);
ui.startSelectedRoute?.addEventListener("click",()=>{
  const progress=areaProgress(selectedArea);
  const latest=Math.max(1,Math.min(getAreaConfig(selectedArea).maxRank,Math.floor(Number(progress.unlockedRank)||1)));
  selectedRank=Math.max(1,Math.min(latest,Math.floor(Number(ui.routeStartLevelSelect?.value)||1)));
  closeRoutePicker();
  beginRun();
});
ui.openSkillBook?.addEventListener("click",openSkillBook);
ui.closeSkillBook?.addEventListener("click",closeSkillBook);
ui.skillBookModal?.addEventListener("click",event=>{ if(event.target===ui.skillBookModal) closeSkillBook(); });
ui.continueEndless?.addEventListener("click",()=>beginEndlessRun(endlessProgress().checkpoint));
ui.startNewEndless?.addEventListener("click",()=>{
  const progress=endlessProgress();
  if(progress.checkpoint>1){
    const okay=window.confirm(`Start a new Endless Run from Floor 1?\n\nYour current Floor ${progress.checkpoint} checkpoint will reset, but your Floor ${progress.record} record will NOT be erased.`);
    if(!okay) return;
  }
  progress.checkpoint=1;
  persistAll();
  beginEndlessRun(1);
});
ui.buddyMenuButton?.addEventListener("click",()=>openCommandWindow("buddy"));
ui.switchBuddyMenuButton?.addEventListener("click",()=>openCommandWindow("switch-buddy"));
ui.attackMenuButton.addEventListener("click",()=>{
  openCommandWindow("attack");
});
ui.closeTargetPicker?.addEventListener("click",closeTargetPicker);
ui.itemMenuButton.addEventListener("click",()=>openCommandWindow("item"));
ui.closeCommandWindow.addEventListener("click",closeCommandWindow);
ui.escapeButton.addEventListener("click",()=>{
  closeCommandWindow();
  openEscapeConfirm();
});
document.querySelector("#openChest").addEventListener("click",openPendingChest);
ui.skipBefriend?.addEventListener("click",finishBefriendStep);
ui.itemBackButton?.addEventListener("click",closeCommandWindow);
ui.purchasePonButton?.addEventListener("click",togglePonPurchasePanel);
ui.closePonPurchaseButton?.addEventListener("click",()=>ui.ponPurchasePanel?.classList.add("hidden"));
document.querySelector("#continueButton").addEventListener("click",nextEncounter);
ui.leaveEndlessButton?.addEventListener("click",leaveEndlessAfterFloor);
document.querySelector("#runAgain").addEventListener("click",()=>{
  if(currentRun?.mode==="endless"){ beginEndlessRun(endlessProgress().checkpoint); return; }
  selectedArea=currentRun?.area||selectedArea;selectedRank=currentRun?.rank||selectedRank;beginRun();
});
document.querySelector("#backToQuest").addEventListener("click",returnHome);
ui.cancelEscapeConfirm.addEventListener("click",closeEscapeConfirm);
ui.confirmEscapeButton.addEventListener("click",confirmEscapeRun);

ui.switchQuestOc?.addEventListener('click',()=>{
  if(currentRun)return;
  renderQuestOcPicker();
  const modal=document.querySelector('#questCharacterModal');
  const opening=!questOcPickerOpen();
  modal?.classList.toggle('hidden',!opening);
  modal?.setAttribute('aria-hidden',String(!opening));
  ui.switchQuestOc?.setAttribute('aria-expanded',String(opening));
  if(opening)document.querySelector('#questCharacterClose')?.focus();
});
document.querySelector('#questCharacterBackdrop')?.addEventListener('click',closeQuestOcPicker);
document.querySelector('#questCharacterClose')?.addEventListener('click',closeQuestOcPicker);
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&questOcPickerOpen()){closeQuestOcPicker();ui.switchQuestOc?.focus();}
});

ui.iconBackgroundButton?.addEventListener("click",()=>{
  closeIconBorderPicker();
  closeIconBorderColorPicker();
  const opening=ui.iconBackgroundPicker.classList.contains("hidden");
  ui.iconBackgroundPicker.classList.toggle("hidden",!opening);
  ui.iconBackgroundButton.setAttribute("aria-expanded",String(opening));
});
ui.iconBorderButton?.addEventListener("click",()=>{
  closeIconBackgroundPicker();
  closeIconBorderColorPicker();
  const opening=ui.iconBorderPicker.classList.contains("hidden");
  ui.iconBorderPicker.classList.toggle("hidden",!opening);
  ui.iconBorderButton.setAttribute("aria-expanded",String(opening));
});
ui.iconBorderColorButton?.addEventListener("click",()=>{
  closeIconBackgroundPicker();
  closeIconBorderPicker();
  const opening=ui.iconBorderColorPicker.classList.contains("hidden");
  ui.iconBorderColorPicker.classList.toggle("hidden",!opening);
  ui.iconBorderColorButton.setAttribute("aria-expanded",String(opening));
});
document.addEventListener("keydown",event=>{
  if(event.key!=="Escape") return;
  if(ui.routePickerModal && !ui.routePickerModal.classList.contains("hidden")){ closeRoutePicker(); return; }
  if(ui.uiThemeModal && !ui.uiThemeModal.classList.contains("hidden")){ closeUiThemePicker(); return; }
  if(ui.skillBookModal && !ui.skillBookModal.classList.contains("hidden")){ closeSkillBook(); }
});
syncPastLevelIconBackgrounds();
normalizeQuestUiThemeState();
applyQuestUiTheme();
persistAll();
renderMeta();
renderMenuSkills();
const initialQuestScreen=new URLSearchParams(window.location.search).get("screen");
showScreen(initialQuestScreen==="buddies"?"buddy":initialQuestScreen==="charms"?"charm":"home");
warmQuestMenuAssets();

// Menu idle bounce.
const menuPeep=document.querySelector("#menuPeep");
let menuFrame=0;
setInterval(()=>{
  if(ui.home.classList.contains("hidden")) return;
  if(activeCharacterId!=="peep"){
    const frames=heroIdleFrames();
    menuFrame=(menuFrame+1)%frames.length;
    renderHeroComposite(ui.menuHeroComposite,frames[menuFrame]);
    return;
  }
  menuFrame=(menuFrame+1)%PEepIdle.length;
  menuPeep.src=PEepIdle[menuFrame];
},560);


// v24.166 — Duckie Dash, Lil Guy Eggs, Mysterious Merchant, and Sibling Spat
(function(){
  const DASH_RUN_OPTIONS={30:{duration:30,cost:3},60:{duration:60,cost:5}};
  const DASH_GROUND_RATIO=.05;
  const DASH_RUNNER_RAISE=4;
  const DASH_BASE_SPEED=.54;
  window.DUCKIE_DASH_CORE='24.229-aligned-foreground';
  window.DUCKIE_DASH_REWARD_FIX='24.232-persist-coins-and-tiny-ducks';
  window.DUCKIE_DASH_LIVE_REWARDS='24.233-results-total-refresh';
  window.DUCKIE_BOOST_CORE='24.213-candy-blanket-time-hearts';
  const COMMON_EGG_MS=60*60*1000;
  const RARE_EGG_MS=24*60*60*1000;
  const SHINY_EGG_MS=24*60*60*1000;
  const RARE_EGG_SHINY_RATE=1/100;
  const DASH_CARTS=[
    {id:'default',name:'Default Cart',image:'assets/dash/carts/Duck-car-default.png',kind:'default'},
    {id:'pink',name:'Pink Cart',image:'assets/dash/carts/Duck-car-pink.png',kind:'shop',itemId:'dash-cart-pink'},
    {id:'mint',name:'Mint Cart',image:'assets/dash/carts/Duck-car-mint.png',kind:'shop',itemId:'dash-cart-mint'},
    {id:'purple',name:'Purple Cart',image:'assets/dash/carts/Duck-car-purple.png',kind:'shop',itemId:'dash-cart-purple'},
    {id:'black',name:'Black Cart',image:'assets/dash/carts/Duck-car-black.png',kind:'shop',itemId:'dash-cart-black'},
    {id:'peep',name:'Peep Cart',image:'assets/dash/carts/Duck-car-peep.png',kind:'happiness',characterId:'peep'},
    {id:'miko',name:'Miko Cart',image:'assets/dash/carts/Duck-car-miko.png',kind:'happiness',characterId:'miko'},
    {id:'io',name:'Io Cart',image:'assets/dash/carts/Duck-car-io.png',kind:'happiness',characterId:'io'},
    {id:'miho',name:'Miho Cart',image:'assets/dash/carts/Duck-car-miho.png',kind:'happiness',characterId:'miho'},
    {id:'annika',name:'Annika Cart',image:'assets/dash/carts/Duck-car-annika.png',kind:'happiness',characterId:'annika'}
  ];
  const DASH_STAGE={
    meadow:{name:'Meadow',dashBackground:'assets/dash/backgrounds/DD-Meadow-3x.png',backgrounds:['assets/dash/backgrounds/DD-Meadow-3x.png'],obstacle:'assets/dash/Obstacle-mushroom.png'},
    ocean:{name:'Ocean',dashBackground:'assets/dash/backgrounds/DD-Ocean-3x.png',backgrounds:['assets/dash/backgrounds/DD-Ocean-3x.png'],obstacle:'assets/dash/Obstacle-rock.png'},
    candy:{name:'Candyland',dashBackground:'assets/dash/backgrounds/DD-Candyland-3x.png',backgrounds:['assets/dash/backgrounds/DD-Candyland-3x.png'],obstacle:'assets/dash/Obstacle-gumdrop.png'},
    cloud:{name:'Cloud Garden',dashBackground:'assets/dash/backgrounds/DD-CloudGarden-3x.png',backgrounds:['assets/dash/backgrounds/DD-CloudGarden-3x.png'],obstacle:'assets/dash/Obstacle-cloud.png'},
    city:{name:'City Streets',dashBackground:'assets/backgrounds/city/duckie-dash.png',backgrounds:['assets/backgrounds/city/duckie-dash.png'],obstacle:'assets/dash/Obstacle-traffic-cone.webp'},
    spooky:{name:'Spooky Forest',dashBackground:'assets/dash/backgrounds/DD-SpookyForest.webp',backgrounds:['assets/dash/backgrounds/DD-SpookyForest.webp'],obstacle:'assets/dash/Obstacle-pumpkin.webp'}
  };
  const SPECIAL_REWARD_ITEMS={
    token:{id:'jump-token',name:'Jump Token',image:'assets/dash/Jump-Token.png'},
    commonEgg:{id:'common-egg',name:'Common Egg',image:'assets/eggs/Common-egg.png'},
    rareEgg:{id:'rare-egg',name:'Rare Egg',image:'assets/eggs/Rare-egg.png'},
    shinyEgg:{id:'shiny-egg',name:'Shiny Egg',image:'assets/gimmicks/shiny-egg.png'}
  };
  const EVENT_ART={
    'lucky-picnic':'assets/events/Picnic.png',
    'wishing-fountain':'assets/events/Fountain.png'
  };
  const SIBLING_SCRIPTS={
    miho:[
      {speaker:'Miho',who:'miho',expression:'neutral',text:'Ugh. What the hell are you doing here?'},
      {speaker:'Miko',who:'miko',expression:'angry',text:"I don’t need YOUR permission to be here, Miho. I’m just looking for one of my loves."},
      {speaker:'Miho',who:'miho',expression:'neutral',text:"Then scram. I don’t want to deal with your bullshit."},
      {speaker:'Miko',who:'miko',expression:'angry',text:'Eh?! No, YOU move! I was here first!'},
      {speaker:'Miho',who:'miho',expression:'threaten',text:'You are so damn annoying! Get out of my way!'},
      {speaker:'Miko',who:'miko',expression:'angry',text:'No!! You get out of MY way!!'}
    ],
    miko:[
      {speaker:'Miko',who:'miko',expression:'mock',text:'Oho? Is that Miho I see? Hiding from your boys?'},
      {speaker:'Miho',who:'miho',expression:'fluster',text:"Shut the fuck up, Miko. I’m hiding from Dad."},
      {speaker:'Miko',who:'miko',expression:'angry',text:"He’s here?! Oh hell no."},
      {speaker:'Miho',who:'miho',expression:'neutral',text:'Maybe I should throw you to him so he’ll leave me alone.'},
      {speaker:'Miko',who:'miko',expression:'angry',text:'Over my dead body!! I’m going to throw YOU!'},
      {speaker:'Miho',who:'miho',expression:'threaten',text:"Fuck you! I’ve dealt with him enough!"},
      {speaker:'Miko',who:'miko',expression:'smug',text:'Too bad!!'}
    ]
  };
  const SIBLING_SPRITES={
    miko:{
      neutral:'assets/characters/miko/base/idle-1.webp',
      mock:'assets/characters/miko/base/mock.webp',
      smug:'assets/characters/miko/base/smug.webp',
      angry:'assets/characters/miko/base/Miko-angry.png'
    },
    miho:{
      neutral:'assets/characters/miho/base/idle-1.webp',
      fluster:'assets/characters/miho/base/fluster.webp',
      threaten:'assets/characters/miho/base/threaten.webp'
    }
  };

  // The opposite sister is a real battle opponent, not a cutscene-only dummy.
  ENEMIES['sibling-miko']={name:'Miko',hp:38,attack:7,exp:46,coinMin:15,coinMax:24,idle:['assets/characters/miko/base/idle-1.webp','assets/characters/miko/base/idle-2.webp'],hurt:SIBLING_SPRITES.miko.angry,speed:520,uncatchable:true,siblingCharacterId:'miko'};
  ENEMIES['sibling-miho']={name:'Miho',hp:40,attack:8,exp:46,coinMin:15,coinMax:24,idle:['assets/characters/miho/base/idle-1.webp','assets/characters/miho/base/idle-2.webp'],hurt:SIBLING_SPRITES.miho.fluster,speed:520,uncatchable:true,siblingCharacterId:'miho'};

  const extraCss=document.createElement('style');
  extraCss.textContent=`
    .dq-expand-card{margin-top:16px;padding:15px;border:3px solid var(--border,#8c625d);border-radius:20px;background:rgba(255,250,246,.94);display:grid;gap:11px;box-shadow:0 7px 0 rgba(140,98,93,.12)}
    .dq-expand-head{display:flex;gap:10px;align-items:flex-start;justify-content:space-between}.dq-expand-head h2{margin:2px 0 0}.dq-expand-head small{display:block;color:#725d68}.dq-token-pill{display:inline-flex;align-items:center;gap:6px;border:2px solid rgba(140,98,93,.2);border-radius:999px;padding:6px 9px;background:#fff}.dq-token-pill img{width:24px;height:24px;object-fit:contain;image-rendering:pixelated}
    .dq-mini-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.dq-mini-grid>div{padding:9px;border:2px solid rgba(140,98,93,.14);border-radius:14px;background:#fff;display:grid;gap:2px}.dq-mini-grid span{font-size:.68rem;letter-spacing:.08em;text-transform:uppercase;color:#8b7380}.dq-mini-grid strong{color:#5f4552}.dq-expand-actions{display:flex;gap:8px;flex-wrap:wrap}.dq-expand-actions .pixel-button{flex:1 1 150px}
    #dashScreen,#hatcheryScreen{padding:14px;display:grid;align-content:start;gap:12px}.dq-feature-shell{display:grid;gap:14px;background:rgba(255,250,246,.96);border:3px solid var(--border,#8c625d);border-radius:22px;padding:15px}.dq-feature-top{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap}.dq-feature-top h2{margin:2px 0}.dq-feature-top small{color:#725d68}
    .dash-stage-buttons,.dash-garage{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.dash-stage-button.selected,.dash-cart-card.selected{box-shadow:inset 0 0 0 3px rgba(233,145,178,.35);background:#fff0f7}.dash-stage-button{min-height:52px}
    .dash-playbox{display:grid;justify-items:center;gap:9px}.dash-hud{width:min(100%,520px);display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px}.dash-hud>span{font-size:.73rem;text-align:center;padding:6px 4px;border:2px solid rgba(140,98,93,.15);border-radius:11px;background:#fff}.dash-track{position:relative;width:min(100%,520px);aspect-ratio:16/9;overflow:hidden;border:4px solid var(--border,#8c625d);border-radius:18px;background:#cde8f4;touch-action:manipulation;user-select:none}.dash-bg{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;image-rendering:pixelated}.dash-runner{position:absolute;width:20%;max-width:92px;height:auto;left:12%;bottom:calc(5% + 4px);z-index:5;object-fit:contain;image-rendering:pixelated;transition:filter .12s}.dash-runner.hit{filter:brightness(1.65)}.dash-thing{position:absolute;z-index:4;object-fit:contain;image-rendering:pixelated;pointer-events:none}.dash-obstacle{width:15.5%;max-width:74px}.dash-coin{width:9.8%;max-width:42px}.dash-tiny-duck{width:10.8%;max-width:48px}.dash-powerup-v217{width:10.8%;max-width:48px;filter:drop-shadow(0 2px 0 rgba(255,255,255,.7))}.dash-bg-scroll-v217{position:absolute;inset:0;z-index:0;display:flex;width:max-content;height:100%;will-change:transform;pointer-events:none}.dash-bg-scroll-v217 .dash-bg{position:relative!important;inset:auto!important;flex:0 0 auto!important;width:auto!important;max-width:none!important;height:100%!important;object-fit:fill!important}.dash-bubble-v217{position:absolute!important;z-index:9!important;width:142%!important;height:142%!important;left:-21%!important;top:-21%!important;object-fit:contain!important;pointer-events:none!important;opacity:0!important;transform:scale(.82)!important;transition:opacity .14s ease,transform .14s ease!important;filter:drop-shadow(0 0 8px rgba(180,239,255,.8))!important}.dash-bubble-v217.active{opacity:1!important;transform:scale(1)!important}.dash-power-pop-v217{position:absolute;left:17%;bottom:36%;z-index:12;padding:5px 8px;border:2px solid #fff;border-radius:999px;background:rgba(255,248,224,.95);color:#8b5a6d;font-size:.65rem;font-weight:900;animation:dashPowerPopV217 .9s ease-out forwards;pointer-events:none}@keyframes dashPowerPopV217{to{opacity:0;transform:translateY(-28px)}}.dash-overlay{position:absolute;inset:0;z-index:10;display:grid;place-items:center;background:rgba(255,249,253,.78);padding:15px}.dash-overlay.hidden{display:none}.dash-overlay-card{max-width:280px;display:grid;gap:9px;text-align:center;padding:14px;border:3px solid var(--border,#8c625d);border-radius:17px;background:#fff}.dash-tap-note{font-size:.76rem;color:#735e69;text-align:center}.dash-garage-wrap{display:grid;gap:8px}.dash-cart-card{border:2px solid rgba(140,98,93,.15);border-radius:15px;padding:9px;background:#fff;display:grid;grid-template-columns:60px 1fr;gap:8px;align-items:center;text-align:left}.dash-cart-card img{width:58px;height:58px;object-fit:contain;image-rendering:pixelated}.dash-cart-card small{display:block;color:#796471}.dash-cart-card.locked{opacity:.62}
    .hatch-bg{background-image:linear-gradient(rgba(255,250,246,.3),rgba(255,250,246,.3)),url('assets/eggs/Egg-hatching-background.png');background-size:cover;background-position:center;border:3px solid var(--border,#8c625d);border-radius:18px;padding:13px;display:grid;gap:13px;min-height:360px}.egg-grid,.incubator-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.egg-card,.incubator-card{background:rgba(255,255,255,.9);border:2px solid rgba(140,98,93,.17);border-radius:14px;padding:9px;text-align:center;display:grid;gap:6px;align-content:start}.egg-card img,.incubator-card img{width:64px;height:64px;object-fit:contain;image-rendering:pixelated;margin:auto}.egg-card small,.incubator-card small{color:#765f6b}.egg-shake{animation:eggShake .65s ease-in-out}@keyframes eggShake{0%,100%{transform:rotate(0)}20%{transform:rotate(-10deg) translateY(-2px)}40%{transform:rotate(10deg)}60%{transform:rotate(-8deg) translateY(-3px)}80%{transform:rotate(8deg)}}.hatch-log{padding:10px;border:2px dashed rgba(140,98,93,.25);border-radius:13px;background:rgba(255,255,255,.9);min-height:58px}
    .event-scene-art{width:min(210px,52vw)!important;height:min(210px,52vw)!important;object-fit:contain!important;image-rendering:pixelated}.merchant-duck{width:min(170px,46vw)!important;height:min(170px,46vw)!important}.merchant-wares{display:grid;gap:8px}.merchant-ware{display:grid;grid-template-columns:48px 1fr auto;gap:8px;align-items:center;text-align:left}.merchant-ware img{width:46px;height:46px;object-fit:contain;image-rendering:pixelated}.merchant-ware small{display:block;color:#755f6a}.merchant-ware .price{white-space:nowrap;font-weight:700}.chest-layer.merchant-active-v197{display:flex!important;flex-direction:column!important;justify-content:center!important;align-items:center!important;gap:8px!important;padding:10px!important;overflow:auto!important;background:rgba(74,52,48,.34)!important}.chest-layer.merchant-active-v197 .merchant-duck{width:min(112px,30vw)!important;height:min(112px,30vw)!important;flex:0 0 auto!important}.merchant-shop-v197{width:min(96%,460px)!important;display:grid!important;gap:7px!important;padding:9px!important;border:3px solid var(--border,#8c625d)!important;border-radius:14px!important;background:rgba(255,250,246,.98)!important;box-shadow:0 8px 24px rgba(74,52,48,.22)!important}.merchant-shop-v197 .merchant-ware{width:100%!important;min-height:54px!important;padding:7px 9px!important;grid-template-columns:42px minmax(0,1fr) auto!important;gap:7px!important}.merchant-shop-v197 .merchant-ware img{width:40px!important;height:40px!important}.merchant-shop-v197 .merchant-ware strong{font-size:.72rem!important}.merchant-shop-v197 .merchant-ware small{font-size:.53rem!important;line-height:1.2!important}.merchant-shop-v197 .price{font-size:.62rem!important;grid-column:auto!important}.merchant-leave-v197{width:100%!important;min-height:42px!important}
    .sibling-scene{position:absolute;inset:0;z-index:13;display:flex;align-items:flex-end;justify-content:space-between;padding:7% 6% 5%;pointer-events:none}.sibling-scene.hidden{display:none}.sibling-scene img{width:36%;height:62%;object-fit:contain;object-position:center bottom;image-rendering:pixelated;filter:drop-shadow(0 4px 0 rgba(0,0,0,.12))}.battlefield .peep-combatant.sibling-spat-hidden-v224{display:none!important}.sibling-scene.sibling-spat-v224 img{transform-origin:center bottom;will-change:transform}.sibling-scene.sibling-spat-v224 .sibling-left-v224{animation:siblingLeftIdleV224 1.05s ease-in-out infinite}.sibling-scene.sibling-spat-v224 .sibling-right-v224{animation:siblingRightIdleV224 1.05s ease-in-out -.525s infinite}@keyframes siblingLeftIdleV224{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}@keyframes siblingRightIdleV224{0%,100%{transform:scaleX(-1) translateY(0)}50%{transform:scaleX(-1) translateY(-4px)}}.sibling-dialogue-actions{display:flex;justify-content:flex-end}.sibling-dialogue-actions .pixel-button{min-width:120px}
    /* v24.230 — Sibling Spat battle only: face the opponent inward and size by height. */
    .battlefield.sibling-battle-v230 .enemy-combatant .enemy-fighter.sibling-opponent-v230{width:auto!important;max-width:none!important;max-height:none!important;scale:-1 1;transform-origin:center bottom!important;object-fit:contain!important}
    .battlefield.sibling-battle-v230.miho-active .enemy-combatant .enemy-fighter.sibling-opponent-v230{height:40.2%!important;bottom:8%!important}
    .battlefield.sibling-battle-v230.miko-active .enemy-combatant .enemy-fighter.sibling-opponent-v230{height:53.3%!important;bottom:6%!important}
    @media(max-width:600px){.battlefield.sibling-battle-v230.miho-active .enemy-combatant .enemy-fighter.sibling-opponent-v230{height:44.5%!important;bottom:9%!important}.battlefield.sibling-battle-v230.miko-active .enemy-combatant .enemy-fighter.sibling-opponent-v230{height:54.2%!important;bottom:7%!important}}

    @media(max-width:560px){.dq-mini-grid,.egg-grid,.incubator-grid{grid-template-columns:1fr}.dash-hud{grid-template-columns:repeat(2,minmax(0,1fr))}.dash-cart-card{grid-template-columns:52px 1fr}.dash-cart-card img{width:50px;height:50px}.merchant-ware{grid-template-columns:42px 1fr}.merchant-ware .price{grid-column:2}.sibling-scene img{width:42%;height:58%}}

    /* v24.167 — Hatching Area as a dedicated portrait location. */
    #hatcheryScreen{padding:0!important;min-height:100dvh;background:linear-gradient(180deg,#d9eef9,#f9edf4);overflow:auto;}
    .hatch-world-shell{min-height:100dvh;display:grid;place-items:center;padding:10px 10px calc(18px + env(safe-area-inset-bottom));}
    .hatch-world{position:relative;width:min(100%,420px);aspect-ratio:9/16;overflow:hidden;border:4px solid var(--border,#8c625d);border-radius:24px;background:#9ee78f;box-shadow:0 16px 42px rgba(77,67,83,.22);isolation:isolate;}
    .hatch-world-bg{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;image-rendering:pixelated;z-index:0;}
    .hatch-world-topbar{position:absolute;left:0;right:0;top:0;z-index:12;display:grid;grid-template-columns:auto 1fr auto;align-items:start;gap:8px;padding:calc(9px + env(safe-area-inset-top)) 9px 0;pointer-events:none;}
    .hatch-world-topbar>*{pointer-events:auto;}
    .hatch-back-button,.hatch-inventory-button{min-height:36px;border:2px solid #d8647d;border-radius:10px;background:rgba(255,247,249,.94);color:#a7425b;font-weight:800;box-shadow:0 3px 0 rgba(167,66,91,.14);}
    .hatch-back-button{width:42px;font-size:1.1rem;}.hatch-inventory-button{padding:6px 9px;display:inline-flex;align-items:center;gap:6px;justify-self:end;}
    .hatch-inventory-button .count{display:inline-grid;place-items:center;min-width:22px;height:22px;padding:0 6px;border-radius:999px;background:#ed7892;color:white;font-size:.75rem;}
    .hatch-world-title{align-self:start;justify-self:center;margin-top:1px;padding:6px 10px;border:2px solid rgba(255,255,255,.9);border-radius:999px;background:rgba(255,250,252,.86);color:#8b4b5d;font-size:.72rem;font-weight:900;letter-spacing:.08em;text-transform:uppercase;box-shadow:0 3px 12px rgba(96,77,88,.12);white-space:nowrap;}
    .hatch-world-ready{position:absolute;left:50%;top:12%;transform:translateX(-50%);z-index:10;background:#fff6b9;color:#8b5b20;border:2px solid #e5c64f;border-radius:999px;padding:5px 10px;font-size:.72rem;font-weight:900;box-shadow:0 4px 12px rgba(105,84,45,.14);}.hatch-world-ready.hidden{display:none;}
    .hatch-nest-slots{position:absolute;inset:0;z-index:4;}.hatch-nest-slot{position:absolute;left:50%;width:44%;height:19%;transform:translate(-50%,-50%);border:0;background:transparent;padding:0;display:grid;place-items:center;cursor:pointer;touch-action:manipulation;}
    .hatch-nest-slot:nth-child(1){top:32.5%;}.hatch-nest-slot:nth-child(2){top:63.5%;}.hatch-nest-slot:nth-child(3){top:89%;}.hatch-nest-slot:focus-visible{outline:3px solid rgba(216,100,125,.9);outline-offset:3px;border-radius:50%;}
    .hatch-main-egg{position:absolute;width:72%;height:72%;object-fit:contain;image-rendering:pixelated;filter:drop-shadow(0 5px 0 rgba(122,76,60,.16));transition:transform .16s ease;}.hatch-nest-slot:hover .hatch-main-egg,.hatch-nest-slot:active .hatch-main-egg{transform:translateY(-3px);}
    .hatch-empty-plus{display:grid;place-items:center;width:42px;height:42px;border:2px dashed rgba(173,84,103,.62);border-radius:50%;background:rgba(255,250,252,.78);color:#b6516b;font-size:1.45rem;font-weight:700;}
    .hatch-slot-status{position:absolute;top:83%;left:50%;transform:translateX(-50%);max-width:140%;white-space:nowrap;padding:4px 8px;border-radius:999px;border:2px solid rgba(255,255,255,.9);background:rgba(255,248,250,.88);color:#ad4963;font-size:.68rem;font-weight:900;box-shadow:0 3px 9px rgba(91,70,81,.12);}
    .hatch-nest-slot.ready .hatch-slot-status{background:#fff4a9;border-color:#ffe978;color:#8c5d1f;animation:hatchReadyPulse 1.25s ease-in-out infinite;}.hatch-nest-slot.ready .hatch-main-egg{animation:hatchReadyBob 1.35s ease-in-out infinite;}
    @keyframes hatchReadyPulse{50%{transform:translateX(-50%) scale(1.06);box-shadow:0 0 18px rgba(255,235,101,.85)}}@keyframes hatchReadyBob{50%{transform:translateY(-5px)}}
    .hatch-world-tip{margin:8px 0 0;text-align:center;color:#755f6c;font-size:.78rem;}
    .hatch-modal{position:fixed;inset:0;z-index:350;display:grid;place-items:center;padding:14px;background:rgba(54,42,51,.38);backdrop-filter:blur(3px);}.hatch-modal.hidden{display:none;}.hatch-modal-backdrop{position:absolute;inset:0;border:0;background:transparent;}
    .hatch-modal-card{position:relative;z-index:1;width:min(94vw,390px);max-height:min(86dvh,720px);overflow:auto;border:3px solid #cf667d;border-radius:22px;background:#fff8f4;box-shadow:0 18px 50px rgba(60,43,52,.26);padding:15px;display:grid;gap:12px;color:#684b58;}
    .hatch-modal-close{position:absolute;top:8px;right:8px;width:32px;height:32px;border:2px solid #dd748b;border-radius:50%;background:#fff;color:#bd4d66;font-weight:900;font-size:1rem;z-index:4;}.hatch-modal-heading{padding-right:34px;text-align:center;}.hatch-modal-heading h2{margin:2px 0 0;font-size:1.2rem;}.hatch-modal-heading small{color:#8b6b78;}
    .hatch-window{position:relative;width:min(100%,270px);aspect-ratio:4/3;margin:auto;overflow:hidden;border:3px solid #efb4c1;border-radius:18px;background:linear-gradient(180deg,#fff2ef,#ffe9e4);display:grid;place-items:center;isolation:isolate;}
    .hatch-window-nest{position:absolute;width:150%;height:auto;left:50%;top:50%;transform:translate(-50%,-49%);image-rendering:pixelated;z-index:1;pointer-events:none;}.hatch-window-egg{position:relative;z-index:3;width:43%;height:72%;object-fit:contain;image-rendering:pixelated;filter:drop-shadow(0 5px 0 rgba(122,76,60,.14));transform-origin:50% 82%;}
    .hatch-window-glow{position:absolute;z-index:2;width:55%;aspect-ratio:1;border-radius:50%;background:radial-gradient(circle,rgba(255,252,157,.96) 0%,rgba(255,229,113,.72) 35%,rgba(255,203,231,.35) 62%,transparent 76%);opacity:0;transform:scale(.45);filter:blur(1px);pointer-events:none;}.hatch-window-glow.active{animation:hatchGlow 1.35s ease-in-out forwards;}.hatch-window-egg.hatching{animation:hatchBounce 1.35s cubic-bezier(.22,.9,.3,1) forwards;}
    @keyframes hatchBounce{0%{transform:translateY(0) rotate(0)}14%{transform:translateY(-12px) rotate(-5deg)}27%{transform:translateY(0) rotate(5deg)}42%{transform:translateY(-18px) rotate(-7deg)}57%{transform:translateY(0) rotate(6deg)}73%{transform:translateY(-24px) rotate(-8deg)}88%{transform:translateY(-4px) rotate(7deg)}100%{transform:translateY(-8px) rotate(0) scale(1.08)}}@keyframes hatchGlow{0%{opacity:0;transform:scale(.45)}35%{opacity:.55;transform:scale(.82)}75%{opacity:1;transform:scale(1.22)}100%{opacity:.95;transform:scale(1.12)}}
    .hatch-result{position:absolute;inset:0;z-index:5;display:grid;place-items:center;padding:12px;text-align:center;background:radial-gradient(circle at 50% 50%,rgba(255,255,214,.92),rgba(255,246,252,.88) 52%,rgba(255,238,246,.9));}.hatch-result.hidden{display:none;}.hatch-result img{width:52%;height:54%;object-fit:contain;image-rendering:pixelated;animation:hatchBuddyPop .55s cubic-bezier(.2,1.5,.45,1) both;filter:drop-shadow(0 6px 0 rgba(111,75,87,.12));}.hatch-result strong{display:block;margin-top:2px;color:#9b405a;font-size:1.05rem;}.hatch-result small{display:block;color:#806571;margin-top:2px;}
    .hatch-result.shiny::before,.hatch-result.shiny::after{content:'✦';position:absolute;color:#f0b93b;font-size:1.4rem;animation:hatchSparkle .9s ease-in-out infinite alternate;}.hatch-result.shiny::before{left:18%;top:20%;}.hatch-result.shiny::after{right:17%;top:29%;animation-delay:.2s;}@keyframes hatchBuddyPop{from{opacity:0;transform:scale(.55) translateY(12px)}to{opacity:1;transform:scale(1) translateY(0)}}@keyframes hatchSparkle{to{transform:scale(1.4) rotate(18deg);opacity:.45}}
    .hatch-detail-status{text-align:center;background:#fff;border:2px solid rgba(207,102,125,.18);border-radius:14px;padding:9px;font-weight:800;color:#8f5061;}.hatch-detail-actions{display:flex;gap:8px;flex-wrap:wrap;}.hatch-detail-actions .pixel-button{flex:1 1 130px;}
    .egg-inventory-summary{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;}.egg-inventory-card{border:2px solid rgba(207,102,125,.2);border-radius:16px;background:#fff;padding:10px;display:grid;gap:7px;text-align:center;}.egg-inventory-card img{width:72px;height:72px;margin:auto;object-fit:contain;image-rendering:pixelated}.egg-inventory-card strong{color:#8e4b5d}.egg-inventory-card small{color:#826c76;line-height:1.35}.egg-inventory-card .egg-count{font-size:.9rem;font-weight:900;color:#ba526b}.egg-inventory-note{margin:0;text-align:center;color:#856b77;font-size:.75rem;line-height:1.4;}
    @media(max-width:460px){.hatch-world-shell{padding:0}.hatch-world{width:100%;max-width:none;border-left:0;border-right:0;border-radius:0;min-height:100dvh;aspect-ratio:auto}.hatch-world-bg{object-fit:cover}.hatch-world-tip{display:none}.hatch-slot-status{font-size:.64rem}.hatch-modal{padding:9px}.hatch-modal-card{width:min(96vw,390px)}}
  `;
  document.head.appendChild(extraCss);

  const dashV208Style=document.createElement('style');
  dashV208Style.id='duckieDashCoreV208Style';
  dashV208Style.textContent=`
    #dashRunner.dash-runner-v208{
      position:absolute!important;
      width:20%!important;
      max-width:92px!important;
      aspect-ratio:1 / 1!important;
      height:auto!important;
      left:12%!important;
      bottom:calc(5% + 4px)!important;
      z-index:5!important;
      overflow:visible!important;
      pointer-events:none!important;
      image-rendering:pixelated!important;
      will-change:transform;
    }
    #dashRunner.dash-runner-v208 .dash-cart-v208,
    #dashRunner.dash-runner-v208 .dash-driver-v208{
      position:absolute!important;
      display:block!important;
      object-fit:contain!important;
      image-rendering:pixelated!important;
      pointer-events:none!important;
      user-select:none!important;
      -webkit-user-drag:none!important;
    }
    #dashRunner.dash-runner-v208 .dash-cart-v208{
      inset:0!important;
      width:100%!important;
      height:100%!important;
      z-index:5!important;
    }
    /* Show the upper body clearly above the duck while hiding the legs so the OC reads as riding. */
    #dashRunner.dash-runner-v208 .dash-driver-v208{
      width:70%!important;
      height:112%!important;
      left:2%!important;
      top:-31%!important;
      z-index:6!important;
      object-position:center top!important;
      clip-path:inset(0 0 29% 0);
      filter:drop-shadow(0 1px 0 rgba(0,0,0,.12));
    }
    #dashRunner.dash-runner-v208.hit .dash-driver-v208{
      filter:brightness(1.15) saturate(1.08) drop-shadow(0 1px 0 rgba(0,0,0,.12));
    }
  `;
  document.head.appendChild(dashV208Style);

  function injectFeatureMarkup(){
    if(!document.querySelector('#duckieDashHomeCard')){
      const anchor=document.querySelector('.endless-home-card');
      anchor?.insertAdjacentHTML('afterend',`
        <section id="duckieDashHomeCard" class="dq-expand-card">
          <div class="dq-expand-head"><div><span class="mini-label">DUCKIE DASH</span><h2>Duckie Dash</h2><small>A 30-second tap-to-jump run for Pink Coins and rare Tiny Ducks!</small></div><span class="dq-token-pill"><img src="assets/dash/Jump-Token.png" alt=""><strong id="dashTokenHome">0</strong></span></div>
          <div class="dq-mini-grid"><div><span>Entry</span><strong>3 Tokens</strong></div><div><span>Free Runs</span><strong id="dashFreeHome">0</strong></div><div><span>High Score</span><strong id="dashHighHome">0</strong></div></div>
          <div class="dq-expand-actions"><button id="openDuckieDash" class="pixel-button primary" type="button">Play Duckie Dash</button></div>
        </section>`);
    }
    const battle=document.querySelector('#battleScreen');
    if(battle && !document.querySelector('#dashScreen')){
      battle.insertAdjacentHTML('beforebegin',`
        <section id="dashScreen" class="screen hidden">
          <div class="dq-feature-shell">
            <div class="dq-feature-top"><div><span class="mini-label">DUCKIE DASH</span><h2>Duckie Dash</h2><small>Tap the course to jump. Keep going until the timer reaches zero!</small></div><button id="dashBack" class="pixel-button" type="button">← Quest Menu</button></div>
            <div class="dq-mini-grid"><div><span>Jump Tokens</span><strong id="dashTokenCount">0</strong></div><div><span>Free Runs</span><strong id="dashFreeCount">0</strong></div><div><span>Selected Cart</span><strong id="dashCartLabel">Default Cart</strong></div></div>
            <div><span class="mini-label">COURSE</span><div id="dashStageButtons" class="dash-stage-buttons"></div></div>
            <div class="dash-playbox">
              <div class="dash-hud"><span>Power <strong id="dashPower">—</strong></span><span>Time <strong id="dashTime">30.0</strong></span><span>Coins <strong id="dashCoins">0</strong></span><span>Tiny Ducks <strong id="dashTiny">0</strong></span></div>
              <div id="dashTrack" class="dash-track"><div id="dashBgScrollV217" class="dash-bg-scroll-v217"><img id="dashBg" class="dash-bg" src="assets/dash/backgrounds/DD-Meadow-3x.png" alt=""><img id="dashBgCloneV217" class="dash-bg" src="assets/dash/backgrounds/DD-Meadow-3x.png" alt=""></div><div id="dashRunner" class="dash-runner dash-runner-v208" aria-label="OC riding a duck cart"><img id="dashRunnerDriverV208" class="dash-driver-v208" src="assets/characters/peep/base/idle-1.webp" alt=""><img id="dashRunnerCartV208" class="dash-cart-v208" src="${DASH_CARTS[0].image}" alt="Duck cart"><img id="dashBubble" class="dash-bubble-v217" src="assets/dash/Bubble.png" alt=""></div><div id="dashOverlay" class="dash-overlay"><div class="dash-overlay-card"><strong>Ready?</strong><label class="dash-duration-label-v235">Run Length<select id="dashRunDurationV235"><option value="30">30 Seconds · 3 Tokens</option><option value="60">60 Seconds · 5 Tokens</option></select></label><small>A rare Free Run is used first if you have one.</small><button id="dashStart" class="pixel-button primary" type="button">Start Duckie Dash</button></div></div></div>
              <div class="dash-tap-note">Tap anywhere on the course to jump! ♡</div>
            </div>
            <div class="dash-garage-wrap"><span class="mini-label">CART GARAGE</span><div id="dashGarage" class="dash-garage"></div></div>
          </div>
        </section>
        <section id="hatcheryScreen" class="screen hidden">
          <div class="hatch-world-shell">
            <div class="hatch-world" aria-label="Hatching Area">
              <img class="hatch-world-bg" src="assets/eggs/Hatching-background-new.png" alt="">
              <div class="hatch-world-topbar">
                <button id="hatchBack" class="hatch-back-button" type="button" aria-label="Back to Duck Quest">←</button>
                <div class="hatch-world-title">Hatching Area</div>
                <button id="hatchInventoryButton" class="hatch-inventory-button" type="button">Inventory <span id="hatchInventoryCount" class="count">0</span></button>
              </div>
              <div id="hatchWorldReady" class="hatch-world-ready hidden">An egg is ready! ✨</div>
              <div id="hatchNestSlots" class="hatch-nest-slots" aria-label="Incubating eggs"></div>
            </div>
            <p class="hatch-world-tip">Tap an empty nest to choose an egg, or tap an incubating egg to check on it. ♡</p>
          </div>
          <div id="hatchDetailModal" class="hatch-modal hidden" aria-hidden="true">
            <button id="hatchDetailBackdrop" class="hatch-modal-backdrop" type="button" aria-label="Close egg window"></button>
            <section class="hatch-modal-card" role="dialog" aria-modal="true" aria-labelledby="hatchDetailTitle">
              <button id="closeHatchDetail" class="hatch-modal-close" type="button" aria-label="Close">×</button>
              <div class="hatch-modal-heading"><span id="hatchDetailKicker" class="mini-label">INCUBATOR</span><h2 id="hatchDetailTitle">Lil Guy Egg</h2><small id="hatchDetailSubtitle">Warm and cozy.</small></div>
              <div class="hatch-window">
                <div id="hatchGlow" class="hatch-window-glow" aria-hidden="true"></div>
                <img class="hatch-window-nest" src="assets/eggs/Hatch-nest.png" alt="">
                <img id="hatchDetailEgg" class="hatch-window-egg" src="assets/eggs/Common-egg.png" alt="Lil Guy egg">
                <div id="hatchResult" class="hatch-result hidden" aria-live="polite"></div>
              </div>
              <div id="hatchDetailStatus" class="hatch-detail-status">Incubating...</div>
              <div id="hatchDetailActions" class="hatch-detail-actions"></div>
            </section>
          </div>
          <div id="eggInventoryModal" class="hatch-modal hidden" aria-hidden="true">
            <button id="eggInventoryBackdrop" class="hatch-modal-backdrop" type="button" aria-label="Close egg inventory"></button>
            <section class="hatch-modal-card" role="dialog" aria-modal="true" aria-labelledby="eggInventoryTitle">
              <button id="closeEggInventory" class="hatch-modal-close" type="button" aria-label="Close">×</button>
              <div class="hatch-modal-heading"><span class="mini-label">EGG INVENTORY</span><h2 id="eggInventoryTitle">Choose an Egg</h2><small>You can keep as many eggs as you find.</small></div>
              <div id="eggInventoryGrid" class="egg-inventory-summary"></div>
              <p id="eggInventoryNote" class="egg-inventory-note">Up to six eggs can incubate at once.</p>
            </section>
          </div>
        </section>
        <section id="siblingScene" class="sibling-scene hidden" aria-hidden="true"><img id="siblingLeft" src="" alt=""><img id="siblingRight" src="" alt=""></section>`);
    }
  }
  injectFeatureMarkup();
  const siblingSceneNode=document.querySelector('#siblingScene');
  if(siblingSceneNode && document.querySelector('#battlefield')) document.querySelector('#battlefield').appendChild(siblingSceneNode);

  function ensureExpansionSave(){
    if(!questSave.dash || typeof questSave.dash!=='object') questSave.dash={};
    questSave.dash.selectedCart=String(questSave.dash.selectedCart||'default');
    questSave.dash.selectedStage=DASH_STAGE[questSave.dash.selectedStage]?questSave.dash.selectedStage:'meadow';
    questSave.dash.highScore=Math.max(0,Math.floor(Number(questSave.dash.highScore)||0));
    questSave.dash.runs=Math.max(0,Math.floor(Number(questSave.dash.runs)||0));
    questSave.dash.freeRuns=Math.max(0,Math.floor(Number(questSave.dash.freeRuns)||0));
    if(!questSave.eggs || typeof questSave.eggs!=='object') questSave.eggs={};
    if(!Array.isArray(questSave.eggs.incubators)) questSave.eggs.incubators=[];
    questSave.eggs.incubators=Array.from({length:6},(_,i)=>{
      const x=questSave.eggs.incubators[i];
      if(!x || typeof x!=='object') return null;
      return {type:x.type==='shiny'?'shiny':x.type==='rare'?'rare':'common',startAt:Math.max(0,Number(x.startAt)||0),endAt:Math.max(0,Number(x.endAt)||0)};
    });
    if(!questSave.eggs.lastHatch || typeof questSave.eggs.lastHatch!=='object') questSave.eggs.lastHatch=null;
  }
  ensureExpansionSave();

  function specialQty(id){return Math.max(0,Math.floor(Number(hubSave.inventory?.[id])||0));}
  function addInventory(id,qty=1){if(!hubSave.inventory||typeof hubSave.inventory!=='object')hubSave.inventory={};hubSave.inventory[id]=specialQty(id)+Math.max(1,Math.floor(Number(qty)||1));}
  function useInventory(id,qty=1){const n=Math.max(1,Math.floor(Number(qty)||1));if(specialQty(id)<n)return false;const left=specialQty(id)-n;if(left)hubSave.inventory[id]=left;else delete hubSave.inventory[id];return true;}
  function cartUnlocked(cart){
    if(cart.kind==='default') return true;
    if(cart.kind==='shop') return specialQty(cart.itemId)>0;
    return happinessLevelFromTotal(hubSave.characterProgress?.[cart.characterId]?.happinessTotal)>=100;
  }
  function selectedCart(){ensureExpansionSave();let c=DASH_CARTS.find(x=>x.id===questSave.dash.selectedCart);if(!c||!cartUnlocked(c)){questSave.dash.selectedCart='default';c=DASH_CARTS[0];}return c;}
  function readyEggs(){ensureExpansionSave();const now=Date.now();return questSave.eggs.incubators.filter(x=>x&&now>=x.endAt).length;}
  function dashDriverIdleSrcV208(){
    try{const frames=heroIdleFrames();return Array.isArray(frames)&&frames[0]?frames[0]:'assets/characters/peep/base/idle-1.webp';}
    catch(error){return 'assets/characters/peep/base/idle-1.webp';}
  }
  function dashDriverHurtSrcV208(){
    try{return heroHurtFrame()||dashDriverIdleSrcV208();}
    catch(error){return dashDriverIdleSrcV208();}
  }
  function syncDashDriverV208(hurt=false){
    const driver=document.querySelector('#dashRunnerDriverV208');
    const cart=document.querySelector('#dashRunnerCartV208');
    if(cart){const selected=selectedCart();if(selected?.image&&cart.getAttribute('src')!==selected.image)cart.src=selected.image;}
    if(driver){
      const src=hurt?dashDriverHurtSrcV208():dashDriverIdleSrcV208();
      if(driver.getAttribute('src')!==src)driver.src=src;
      driver.onerror=()=>{driver.onerror=null;driver.src='assets/characters/peep/base/idle-1.webp';};
    }
  }

  function refreshFeatureBadges(){
    ensureExpansionSave();
    const token=specialQty('jump-token'),free=questSave.dash.freeRuns,ready=readyEggs(),cart=selectedCart();
    const map=[['#dashTokenHome',token],['#dashTokenCount',token],['#dashFreeHome',free],['#dashFreeCount',free],['#dashHighHome',questSave.dash.highScore],['#commonEggQty',specialQty('common-egg')],['#rareEggQty',specialQty('rare-egg')],['#hatchReadyQty',ready]];
    map.forEach(([sel,v])=>{const el=document.querySelector(sel);if(el)el.textContent=String(v);});
    const badge=document.querySelector('#hatchReadyBadge');if(badge)badge.textContent=ready?`(${ready} Ready!)`:'';
    const cartLabel=document.querySelector('#dashCartLabel');if(cartLabel)cartLabel.textContent=cart.name;
    const cartImage=document.querySelector('#dashRunnerCartV208');if(cartImage)cartImage.src=cart.image;
    else {const runner=document.querySelector('#dashRunner');if(runner&&runner.tagName==='IMG')runner.src=cart.image;}
    syncDashDriverV208(false);
  }

  function renderDashSelectors(){
    ensureExpansionSave();
    const stageBox=document.querySelector('#dashStageButtons');if(stageBox){stageBox.innerHTML='';Object.entries(DASH_STAGE).forEach(([id,cfg])=>{const b=document.createElement('button');b.type='button';b.className=`pixel-button dash-stage-button${questSave.dash.selectedStage===id?' selected':''}`;b.textContent=cfg.name;b.addEventListener('click',()=>{questSave.dash.selectedStage=id;persistAll();renderDashSelectors();resetDashPreview();});stageBox.appendChild(b);});}
    const garage=document.querySelector('#dashGarage');if(garage){garage.innerHTML='';DASH_CARTS.forEach(cart=>{const unlocked=cartUnlocked(cart);const card=document.createElement('button');card.type='button';card.className=`dash-cart-card${unlocked?'':' locked'}${questSave.dash.selectedCart===cart.id?' selected':''}`;card.disabled=!unlocked;let note='';if(cart.kind==='shop')note=unlocked?'Owned':'Buy this color in the Hub Shop';else if(cart.kind==='happiness')note=unlocked?'Max Happiness reward unlocked!':`Reach Happiness Lv. 100 with ${QUEST_CHARACTER_NAMES[cart.characterId]}`;else note='Always available';card.innerHTML=`<img src="${cart.image}" alt=""><span><strong>${cart.name}</strong><small>${note}</small></span>`;card.addEventListener('click',()=>{questSave.dash.selectedCart=cart.id;persistAll();renderDashSelectors();refreshFeatureBadges();});garage.appendChild(card);});}
    refreshFeatureBadges();
  }

  // ----- Hatching Area -----
  function eggDefinition(type){return type==='shiny'?{type:'shiny',name:'Shiny Egg',image:'assets/gimmicks/shiny-egg.png',ms:SHINY_EGG_MS}:type==='rare'?{type:'rare',name:'Rare Egg',image:'assets/eggs/Rare-egg.png',ms:RARE_EGG_MS}:{type:'common',name:'Common Egg',image:'assets/eggs/Common-egg.png',ms:COMMON_EGG_MS};}
  function fmtRemaining(ms){const sec=Math.max(0,Math.ceil(ms/1000));const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;if(h)return `${h}h ${String(m).padStart(2,'0')}m`;return `${m}m ${String(s).padStart(2,'0')}s`;}
  function emptyIncubator(){ensureExpansionSave();return questSave.eggs.incubators.findIndex(x=>!x);}
  function startEgg(type,preferredSlot=null,replace=false){const def=eggDefinition(type);const target=Number.isInteger(preferredSlot)&&preferredSlot>=0&&preferredSlot<6?preferredSlot:emptyIncubator();if(target<0){setMessage('All six nests are busy!');return false;}const existing=questSave.eggs.incubators[target];if(existing&&!replace){setMessage('That nest already has an egg.');return false;}if(specialQty(`${type}-egg`)<=0){setMessage(`You do not have a ${def.name}.`);return false;}if(!useInventory(`${type}-egg`,1))return false;if(existing&&replace)addInventory(`${existing.type}-egg`,1);const now=Date.now();questSave.eggs.incubators[target]={type,startAt:now,endAt:now+def.ms};persistAll();renderHatchery();refreshFeatureBadges();closeEggInventory();closeHatchDetail();return true;}
  function baseEggCandidates(type){const excluded=new Set(['mimic','rotten-egg','lucky-cat','angy-duck','plushbun','gift-mimic']);if(type==='shiny')return BUDDY_CATALOG.filter(e=>e.shiny&&!excluded.has(e.enemyId));const normals=BUDDY_CATALOG.filter(e=>!e.shiny&&!excluded.has(e.enemyId));if(type==='common')return normals.filter(e=>!e.boss);const bosses=normals.filter(e=>e.boss),nonboss=normals.filter(e=>!e.boss);return Math.random()<.65?bosses:nonboss;}
  function rollEggBuddy(type){const pool=baseEggCandidates(type);let entry=pool[Math.floor(Math.random()*pool.length)]||BUDDY_CATALOG.find(e=>!e.shiny&&!e.boss);if(type==='shiny')return entry;const shinyRate=type==='rare'?RARE_EGG_SHINY_RATE:BASE_SHINY_RATE;if(entry&&Math.random()<shinyRate){const shiny=BUDDY_CATALOG.find(e=>e.enemyId===entry.enemyId&&e.shiny);if(shiny)entry=shiny;}return entry;}
  function grantCatalogBuddy(entry){ensureBuddySave();const existing=hubSave.buddies.collection[entry.key];if(existing){existing.quantity=Math.max(1,Number(existing.quantity)||1)+1;return existing;}const record={key:entry.key,enemyId:entry.enemyId,variantId:entry.variantId,name:entry.name,image:entry.image,idle:Array.isArray(entry.idle)?entry.idle.slice():[entry.image].filter(Boolean),shiny:Boolean(entry.shiny),boss:Boolean(entry.boss),quantity:1,capturedAt:Date.now()};hubSave.buddies.collection[entry.key]=record;return record;}
  let selectedHatchSlot=null,inventoryTargetSlot=null,inventoryReplacing=false,hatchAnimating=false;
  function closeHatchDetail(){if(hatchAnimating)return;selectedHatchSlot=null;const modal=document.querySelector('#hatchDetailModal');modal?.classList.add('hidden');modal?.setAttribute('aria-hidden','true');}
  function closeEggInventory(){inventoryTargetSlot=null;inventoryReplacing=false;const modal=document.querySelector('#eggInventoryModal');modal?.classList.add('hidden');modal?.setAttribute('aria-hidden','true');}
  function renderEggInventory(){const grid=document.querySelector('#eggInventoryGrid');if(!grid)return;grid.innerHTML='';['common','rare','shiny'].forEach(type=>{const d=eggDefinition(type),qty=specialQty(`${type}-egg`);const card=document.createElement('div');card.className='egg-inventory-card';const detail=type==='common'?'1 hour · Non-boss Lil Guys · normal Shiny chance':type==='rare'?'24 hours · Bosses favored · 1 / 100 Shiny chance':'24 hours · Guaranteed random Shiny Lil Guy ✨';card.innerHTML=`<img src="${d.image}" alt="${d.name}"><strong>${d.name}</strong><span class="egg-count">Owned ×${qty}</span><small>${detail}</small>`;const b=document.createElement('button');b.type='button';b.className='pixel-button primary';const noSlot=inventoryTargetSlot===null&&emptyIncubator()<0;b.disabled=qty<=0||noSlot;b.textContent=qty<=0?'None Owned':inventoryReplacing?`Switch to ${d.name}`:'Incubate';b.addEventListener('click',()=>startEgg(type,inventoryTargetSlot,inventoryReplacing));card.appendChild(b);grid.appendChild(card);});const note=document.querySelector('#eggInventoryNote');if(note){if(inventoryReplacing)note.textContent='Switching returns the current egg to your inventory and restarts the new egg timer.';else if(inventoryTargetSlot!==null)note.textContent=`This egg will go into Nest ${inventoryTargetSlot+1}.`;else if(emptyIncubator()<0)note.textContent='All six nests are occupied. Tap an incubating egg and choose Switch Egg if you want to replace one.';else note.textContent='Up to six eggs can incubate at once. Your extras stay safely in inventory.';}const title=document.querySelector('#eggInventoryTitle');if(title)title.textContent=inventoryReplacing?'Switch Egg':'Choose an Egg';}
  function openEggInventory(targetSlot=null,replace=false){inventoryTargetSlot=Number.isInteger(targetSlot)?targetSlot:null;inventoryReplacing=Boolean(replace);renderEggInventory();const modal=document.querySelector('#eggInventoryModal');modal?.classList.remove('hidden');modal?.setAttribute('aria-hidden','false');}
  function updateHatchDetailTimer(){if(selectedHatchSlot===null||hatchAnimating)return;const slot=questSave.eggs.incubators[selectedHatchSlot];if(!slot)return;const ready=Date.now()>=slot.endAt;const status=document.querySelector('#hatchDetailStatus');if(status)status.textContent=ready?'Oh?':`${fmtRemaining(slot.endAt-Date.now())} until hatch`;if(ready&&!document.querySelector('#hatchNowButton'))openHatchDetail(selectedHatchSlot);}
  function warmBlanketQtyV213(){return Math.max(0,Math.floor(Number(hubSave?.inventory?.['warm-blanket'])||0));}
  function applyWarmBlanketV213(index){
    const slot=questSave?.eggs?.incubators?.[index];
    if(!slot || Date.now()>=slot.endAt) return;
    if(!useInventory('warm-blanket',1)){setMessage('You do not have a Warm Blanket.');return;}
    const now=Date.now(),remaining=Math.max(0,slot.endAt-now);
    slot.endAt=now+Math.max(1000,Math.ceil(remaining*.50));
    persistAll();refreshFeatureBadges();renderHatchery();openHatchDetail(index);
  }
  function openHatchDetail(index){
    ensureExpansionSave();const slot=questSave.eggs.incubators[index];if(!slot)return;selectedHatchSlot=index;hatchAnimating=false;
    const d=eggDefinition(slot.type),ready=Date.now()>=slot.endAt;const modal=document.querySelector('#hatchDetailModal');
    modal?.classList.remove('hidden');modal?.setAttribute('aria-hidden','false');
    const result=document.querySelector('#hatchResult');if(result){result.className='hatch-result hidden';result.innerHTML='';}
    const glow=document.querySelector('#hatchGlow');glow?.classList.remove('active');
    const egg=document.querySelector('#hatchDetailEgg');if(egg){egg.src=d.image;egg.alt=d.name;egg.className='hatch-window-egg';egg.classList.remove('hidden');}
    const title=document.querySelector('#hatchDetailTitle');if(title)title.textContent=d.name;
    const kicker=document.querySelector('#hatchDetailKicker');if(kicker)kicker.textContent=`NEST ${index+1}`;
    const sub=document.querySelector('#hatchDetailSubtitle');if(sub)sub.textContent=ready?'It is wiggling... it wants out!':slot.type==='shiny'?'Something sparkling is warming up... ✨':slot.type==='rare'?'A rare little surprise is warming up.':'Warm and cozy.';
    const status=document.querySelector('#hatchDetailStatus');if(status)status.textContent=ready?'Oh?':`${fmtRemaining(slot.endAt-Date.now())} until hatch`;
    const actions=document.querySelector('#hatchDetailActions');if(actions){
      actions.innerHTML='';
      if(ready){
        const hatch=document.createElement('button');hatch.id='hatchNowButton';hatch.type='button';hatch.className='pixel-button primary';hatch.textContent='Hatch!';hatch.addEventListener('click',()=>hatchSlot(index));actions.appendChild(hatch);
      }else{
        const swap=document.createElement('button');swap.type='button';swap.className='pixel-button';swap.textContent='Switch Egg';swap.addEventListener('click',()=>{closeHatchDetail();openEggInventory(index,true)});actions.appendChild(swap);
        const blankets=warmBlanketQtyV213();
        if(blankets>0){
          const blanket=document.createElement('button');blanket.type='button';blanket.className='pixel-button warm-blanket-use-v213';blanket.innerHTML=`<img src="../assets/items/quest-boosts/Warm-blanket.png" alt="">Warm Blanket ×${blankets}`;blanket.addEventListener('click',()=>applyWarmBlanketV213(index));actions.appendChild(blanket);
        }
      }
      const close=document.createElement('button');close.type='button';close.className='pixel-button';close.textContent=ready?'Not Yet':'Close';close.addEventListener('click',closeHatchDetail);actions.appendChild(close);
    }
  }
  async function hatchSlot(index){const slot=questSave.eggs.incubators[index];if(!slot||Date.now()<slot.endAt||hatchAnimating)return;hatchAnimating=true;const egg=document.querySelector('#hatchDetailEgg'),glow=document.querySelector('#hatchGlow'),actions=document.querySelector('#hatchDetailActions'),status=document.querySelector('#hatchDetailStatus');if(actions)actions.querySelectorAll('button').forEach(b=>b.disabled=true);if(status)status.textContent='Something is happening...!';egg?.classList.add('hatching');glow?.classList.add('active');await sleep(1380);const entry=rollEggBuddy(slot.type);if(!entry){hatchAnimating=false;return;}const owned=grantCatalogBuddy(entry),eggDef=eggDefinition(slot.type);questSave.eggs.incubators[index]=null;questSave.eggs.lastHatch={name:entry.name,image:entry.image,shiny:Boolean(entry.shiny),boss:Boolean(entry.boss),eggName:eggDef.name,quantity:owned.quantity};persistAll();refreshFeatureBadges();renderBuddyHomeCount();renderHatchery();if(egg)egg.classList.add('hidden');const result=document.querySelector('#hatchResult');if(result){result.className=`hatch-result${entry.shiny?' shiny':''}`;result.innerHTML=`<div><img src="${entry.image}" alt="${entry.name}"><strong>${entry.name}${entry.shiny?' ✨':''}</strong><small>${entry.boss?'Boss Lil Guy · ':''}${entry.shiny?'Shiny · ':''}Owned ×${owned.quantity}</small></div>`;}const title=document.querySelector('#hatchDetailTitle');if(title)title.textContent='It hatched!';const sub=document.querySelector('#hatchDetailSubtitle');if(sub)sub.textContent=`Your ${eggDef.name} became a new Lil Guy!`;if(status)status.textContent=`Meet ${entry.name}${entry.shiny?' ✨':''}!`;if(actions){actions.innerHTML='';const done=document.createElement('button');done.type='button';done.className='pixel-button primary';done.textContent='Yay! ♡';done.addEventListener('click',()=>{hatchAnimating=false;closeHatchDetail();renderHatchery();});actions.appendChild(done);}}
  function hatchAllReadyV343(){
    ensureExpansionSave();
    if(hatchAnimating)return [];
    const ready=questSave.eggs.incubators.map((slot,i)=>slot&&Date.now()>=slot.endAt?i:-1).filter(i=>i>=0);
    if(!ready.length)return [];
    const out=[];
    for(const index of ready){
      const slot=questSave.eggs.incubators[index];
      if(!slot||Date.now()<slot.endAt)continue;
      const entry=rollEggBuddy(slot.type);
      if(!entry)continue;
      const owned=grantCatalogBuddy(entry);
      questSave.eggs.incubators[index]=null;
      questSave.eggs.lastHatch={name:entry.name,image:entry.image,shiny:Boolean(entry.shiny),boss:Boolean(entry.boss),eggName:eggDefinition(slot.type).name,quantity:owned.quantity};
      out.push({name:entry.name,shiny:Boolean(entry.shiny),image:entry.image});
    }
    if(out.length){persistAll();renderBuddyHomeCount();renderHatchery();refreshFeatureBadges();}
    return out;
  }
  function renderHatchery(){ensureExpansionSave();const total=specialQty('common-egg')+specialQty('rare-egg')+specialQty('shiny-egg');const count=document.querySelector('#hatchInventoryCount');if(count)count.textContent=String(total);const ready=readyEggs(),flag=document.querySelector('#hatchWorldReady');if(flag){flag.classList.toggle('hidden',ready<=0);flag.textContent=ready===1?'An egg is ready! ✨':`${ready} eggs are ready! ✨`;}const slots=document.querySelector('#hatchNestSlots');if(slots){slots.innerHTML='';questSave.eggs.incubators.forEach((slot,i)=>{const b=document.createElement('button');b.type='button';b.className='hatch-nest-slot';b.setAttribute('aria-label',slot?`Nest ${i+1}, ${eggDefinition(slot.type).name}`:`Nest ${i+1}, empty`);if(!slot){b.innerHTML=`<span class="hatch-empty-plus" aria-hidden="true">＋</span><span class="hatch-slot-status">Empty Nest</span>`;b.addEventListener('click',()=>openEggInventory(i,false));}else{const d=eggDefinition(slot.type),isReady=Date.now()>=slot.endAt;b.classList.toggle('ready',isReady);b.innerHTML=`<img class="hatch-main-egg" src="${d.image}" alt="${d.name}"><span class="hatch-slot-status">${isReady?'Ready! Tap to hatch':fmtRemaining(slot.endAt-Date.now())}</span>`;b.addEventListener('click',()=>openHatchDetail(i));}slots.appendChild(b);});}if(!document.querySelector('#eggInventoryModal')?.classList.contains('hidden'))renderEggInventory();refreshFeatureBadges();updateHatchDetailTimer();}
  setInterval(()=>{refreshFeatureBadges();if(!document.querySelector('#hatcheryScreen')?.classList.contains('hidden'))renderHatchery();},1000);

  // ----- Duckie Dash -----
  const dash={running:false,raf:0,last:0,elapsed:0,duration:30,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacles:[],pickups:[],obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0,speedBoost:0,bubble:0,bgOffset:0};
  function dashTrack(){return document.querySelector('#dashTrack');}
  function clearDashObjects(){dash.obstacles.forEach(o=>o.el.remove());dash.pickups.forEach(o=>o.el.remove());dash.obstacles=[];dash.pickups=[];}
  function dashHud(){const set=(id,v)=>{const e=document.querySelector(id);if(e)e.textContent=String(v)};set('#dashCoins',dash.coins);set('#dashTiny',dash.tiny);set('#dashTime',Math.max(0,(Number(dash.duration)||30)-dash.elapsed).toFixed(1));set('#dashPower',dash.bubble>0?`Bubble ${dash.bubble.toFixed(1)}s`:dash.speedBoost>0?`Wing ${dash.speedBoost.toFixed(1)}s`:'—');document.querySelector('#dashBubble')?.classList.toggle('active',dash.bubble>0);}
  function resetDashPreview(){ensureExpansionSave();const cfg=DASH_STAGE[questSave.dash.selectedStage];const bg=document.querySelector('#dashBg'),clone=document.querySelector('#dashBgCloneV217'),strip=document.querySelector('#dashBgScrollV217');if(bg)bg.src=cfg.dashBackground;if(clone)clone.src=cfg.dashBackground;if(strip)strip.style.transform='translateX(0px)';dash.bgOffset=0;const runner=document.querySelector('#dashRunner');if(runner)runner.style.transform='translateY(0px)';document.querySelector('#dashBubble')?.classList.remove('active');syncDashDriverV208(false);dashHud();}
  function selectedDashRunV235(){ensureExpansionSave();const select=document.querySelector('#dashRunDurationV235');const duration=Number(select?.value||questSave.dash.runDuration||30)===60?60:30;questSave.dash.runDuration=duration;return DASH_RUN_OPTIONS[duration];}
  function renderDashReadyOverlay(){const ov=document.querySelector('#dashOverlay');if(!ov)return;ensureExpansionSave();const duration=Number(questSave.dash.runDuration)===60?60:30;ov.classList.remove('hidden');ov.innerHTML=`<div class="dash-overlay-card"><strong>Ready?</strong><label class="dash-duration-label-v235">Run Length<select id="dashRunDurationV235"><option value="30" ${duration===30?'selected':''}>30 Seconds · 3 Tokens</option><option value="60" ${duration===60?'selected':''}>60 Seconds · 5 Tokens</option></select></label><small>A rare Free Run is used first if you have one.</small><button id="dashStart" class="pixel-button primary" type="button">Start Duckie Dash</button></div>`;ov.querySelector('#dashRunDurationV235')?.addEventListener('change',()=>{questSave.dash.runDuration=Number(ov.querySelector('#dashRunDurationV235').value)===60?60:30;persistAll()});ov.querySelector('#dashStart')?.addEventListener('click',e=>{e.stopPropagation();startDash()});}
  function leaveDashRunStage(){dash.running=false;cancelAnimationFrame(dash.raf);clearDashObjects();document.querySelector('#dashScreen')?.classList.remove('dash-run-stage-v193');document.body.classList.remove('dash-run-stage-v193-active');resetDashPreview();renderDashReadyOverlay();try{renderDashSelectors?.();}catch(error){}}
  function dashJump(){if(!dash.running)return;if(dash.jumpCount<=0){dash.jumpCount=1;dash.jumpV=560;return;}if(dash.jumpCount===1){dash.jumpCount=2;dash.jumpV=Math.min(650,Math.max(360,dash.jumpV)+180);}}
  function spawnDashThing(kind){
    const track=dashTrack();if(!track)return;
    const cfg=DASH_STAGE[questSave.dash.selectedStage];
    const W=track.clientWidth,spawnX=W+40,groundRaise=4;
    const safeObstacleGap=Math.max(112,Math.min(140,W*.28));
    const pickupGap=Math.max(52,Math.min(66,W*.14));
    const obstacleNear=(x,gap=safeObstacleGap)=>dash.obstacles.some(o=>Math.abs(o.x-x)<gap);
    const pickupNear=(x,gap=pickupGap)=>dash.pickups.some(o=>Math.abs(o.x-x)<gap);
    const add=(thing,x,raise,extra={})=>{
      const el=document.createElement('img');
      const timeHeart=thing==='time-pink'||thing==='time-gold';
      const powerup=thing==='wing'||thing==='bubble';
      el.className=`dash-thing ${thing==='obstacle'?'dash-obstacle':thing==='tiny'?'dash-tiny-duck':timeHeart?'dash-time-heart-v213':powerup?'dash-powerup-v217':'dash-coin'}`;
      el.src=thing==='obstacle'?cfg.obstacle:thing==='tiny'?'../assets/ducks/Tiny-duck.webp':thing==='time-pink'?'../assets/bakery/drops/Pink-heart-refill.webp':thing==='time-gold'?'../assets/bakery/drops/Gold-heart-refill.webp':thing==='wing'?'assets/dash/Angel-Wing.png':thing==='bubble'?'assets/dash/Bubble-icon.png':'../assets/ui/pink-coin.webp';
      el.alt='';track.appendChild(el);
      const obj={kind:thing,x,raise,el,hit:false,...extra};
      (thing==='obstacle'?dash.obstacles:dash.pickups).push(obj);
      return obj;
    };

    if(kind==='obstacle'){
      // v24.216: Mushrooms use only two intentionally safe patterns:
      // 1) a single obstacle with enough time to land and jump again, or
      // 2) a tight two-mushroom cluster that behaves like one wider obstacle.
      // This avoids the awkward middle-distance pair that could be impossible to clear.
      const cluster=Math.random()<0.20;
      const clusterGap=Math.max(64,Math.min(78,W*.18));
      const conflictsPickup=px=>dash.pickups.some(o=>o.kind!=='tiny'&&!o.overObstacleStack&&Math.abs(o.x-px)<safeObstacleGap);
      let x=spawnX,tries=0;
      while((obstacleNear(x,96)||conflictsPickup(x)||(cluster&&(obstacleNear(x+clusterGap,96)||conflictsPickup(x+clusterGap))))&&tries<12){x+=70;tries++;}
      add('obstacle',x,groundRaise,{dashPattern:cluster?'cluster':'single'});
      if(cluster){
        add('obstacle',x+clusterGap,groundRaise,{dashPattern:'cluster'});
        // Give the player extra recovery room after the wider cluster.
        dash.nextObstacleDelay=2.55+Math.random()*.25;
      }else{
        // A normal single gets a larger landing/reaction window than the old 1.75s cadence.
        dash.nextObstacleDelay=2.05+Math.random()*.28;
      }
      return;
    }
    if(kind==='tiny'){
      let x=spawnX,tries=0;while((obstacleNear(x,94)||pickupNear(x,48))&&tries<8){x+=54;tries++;}add('tiny',x,groundRaise);return;
    }
    if(kind==='coin'){
      // Keep the fun two-coin vertical reward over mushrooms for double-jumps.
      const support=dash.obstacles.filter(o=>o.x>W-105&&o.x<W+190).sort((a,b)=>Math.abs(a.x-spawnX)-Math.abs(b.x-spawnX))[0]||null;
      if(support&&Math.random()<0.46){
        const obstacleW=Math.min(W*.155,74),coinW=Math.min(W*.098,42);
        const stackX=support.x+Math.max(7,(obstacleW-coinW)/2);
        add('coin',stackX,96,{overObstacleStack:true});add('coin',stackX,148,{overObstacleStack:true});return;
      }

      // Rare hearts extend the run; Angel Wing and Bubble are ten-second power-ups.
      const specialRoll=Math.random();
      const specialKind=specialRoll<0.008?'time-gold':specialRoll<0.042?'time-pink':specialRoll<0.060?'wing':specialRoll<0.078?'bubble':null;
      let x=spawnX+Math.floor(Math.random()*68),tries=0;
      while((obstacleNear(x,safeObstacleGap)||pickupNear(x,pickupGap))&&tries<12){x+=48;tries++;}
      while(obstacleNear(x,safeObstacleGap)){x+=safeObstacleGap;}
      if(specialKind){
        const raise=[54,78,102][Math.floor(Math.random()*3)];
        add(specialKind,x,raise,{timeBonus:specialKind==='time-gold'?30:specialKind==='time-pink'?10:0});
        return;
      }
      const heights=[28,52,76,102,128];const raise=heights[Math.floor(Math.random()*heights.length)];add('coin',x,raise);
    }
  }
  function addDashDuckCopyV232(saveData,duckId,amount=0){
    if(!saveData || !duckId)return 0;
    if(!Array.isArray(saveData.unlockedDucks))saveData.unlockedDucks=[];
    const wasUnlocked=saveData.unlockedDucks.includes(duckId);
    if(!wasUnlocked)saveData.unlockedDucks.push(duckId);
    if(!saveData.duckCollectionCounts||typeof saveData.duckCollectionCounts!=='object'||Array.isArray(saveData.duckCollectionCounts))saveData.duckCollectionCounts={};
    const before=Math.max(wasUnlocked?1:0,Math.floor(Number(saveData.duckCollectionCounts[duckId])||0));
    const after=amount>0?before+Math.max(0,Math.floor(Number(amount)||0)):Math.max(1,before);
    saveData.duckCollectionCounts[duckId]=after;
    return after;
  }
  function awardDashRewardsV232(collectedCoins,collectedTiny,success){
    const latest=loadHubSave();
    const pickupCoins=Math.max(0,Math.floor(Number(collectedCoins)||0));
    const tinyDucks=Math.max(0,Math.floor(Number(collectedTiny)||0));
    const coinAward=(success?20:5)+pickupCoins;
    latest.coins=Math.max(0,Number(latest.coins)||0)+coinAward;
    latest.stats=latest.stats&&typeof latest.stats==='object'?latest.stats:{};
    latest.stats.coinsEarnedTotal=Math.max(0,Number(latest.stats.coinsEarnedTotal)||0)+coinAward;
    let tinyOwned=Math.max(
      Array.isArray(latest.unlockedDucks)&&latest.unlockedDucks.includes('tiny-duck')?1:0,
      Math.floor(Number(latest.duckCollectionCounts?.['tiny-duck'])||0)
    );
    if(tinyDucks>0){
      latest.tinyDuckSightings=Math.max(0,Number(latest.tinyDuckSightings)||0)+tinyDucks;
      tinyOwned=addDashDuckCopyV232(latest,'tiny-duck',tinyDucks);
      if(latest.tinyDuckSightings>=4)addDashDuckCopyV232(latest,'tiny-duck-stack');
      if(latest.tinyDuckSightings>=100)addDashDuckCopyV232(latest,'pile-of-tiny-ducks');
    }
    hubSave=latest;
    return {coins:coinAward,tiny:tinyDucks,totalCoins:Math.floor(latest.coins),tinyOwned};
  }
  function overlap(ax,ay,aw,ah,bx,by,bw,bh){return ax<bx+bw&&ax+aw>bx&&ay<by+bh&&ay+ah>by;}
  function changeDashSegment(){const segment=Math.floor(dash.elapsed/5);if(segment===dash.segment)return;dash.segment=segment;if(segment>0&&Math.random()<.25)setTimeout(()=>{if(dash.running)spawnDashThing('tiny')},900);}
  function finishDash(success){
    if(!dash.running)return;
    dash.running=false;
    cancelAnimationFrame(dash.raf);
    document.querySelector('#dashBubble')?.classList.remove('active');
    const rewards=awardDashRewardsV232(dash.coins,dash.tiny,success);
    questSave.dash.runs=Math.max(0,Number(questSave.dash.runs)||0)+1;
    const score=Math.max(0,Math.floor(dash.elapsed*4+dash.coins*8+dash.tiny*60+(success?100:0)));
    questSave.dash.highScore=Math.max(questSave.dash.highScore,score);
    persistAll();
    if(ui.coinCount)ui.coinCount.textContent=rewards.totalCoins.toLocaleString();
    refreshFeatureBadges();
    const ov=document.querySelector('#dashOverlay');
    if(ov){
      ov.classList.remove('hidden');
      ov.innerHTML=`<div class="dash-overlay-card"><strong>${success?'Time’s Up!':'Run Ended!'}</strong><small>${success?'The timer reached zero — run complete!':'The run ended early.'}<br>Pink Coins +${rewards.coins} · Total ${rewards.totalCoins.toLocaleString()}<br>Tiny Ducks +${rewards.tiny} · Owned ×${rewards.tinyOwned}<br>Score ${score}</small><div class="dash-result-actions-v193"><button id="dashAgain" class="pixel-button primary" type="button">Run Again</button><button id="dashRunMenuV193" class="pixel-button" type="button">Dash Menu</button></div></div>`;
      ov.querySelector('#dashAgain')?.addEventListener('click',startDash);
      ov.querySelector('#dashRunMenuV193')?.addEventListener('click',leaveDashRunStage);
    }
  }
  function showDashPowerPopV217(text){const track=dashTrack();if(!track)return;const pop=document.createElement('div');pop.className='dash-power-pop-v217';pop.textContent=text;track.appendChild(pop);setTimeout(()=>pop.remove(),950);}
  function dashFrame(ts){if(!dash.running)return;if(!dash.last)dash.last=ts;const dt=Math.min(.04,(ts-dash.last)/1000);dash.last=ts;dash.elapsed+=dt;dash.invuln=Math.max(0,dash.invuln-dt);dash.speedBoost=Math.max(0,dash.speedBoost-dt);dash.bubble=Math.max(0,dash.bubble-dt);dash.obstacleClock+=dt;dash.coinClock+=dt;changeDashSegment();if(dash.elapsed>=(Number(dash.duration)||30)){finishDash(true);return;}if(dash.obstacleClock>(Number(dash.nextObstacleDelay)||2.10)){dash.obstacleClock=0;spawnDashThing('obstacle')}if(dash.coinClock>.9){dash.coinClock=0;spawnDashThing('coin')}
    dash.jumpV-=1380*dt;dash.jumpY=Math.max(0,dash.jumpY+dash.jumpV*dt);if(dash.jumpY<=0&&dash.jumpV<0){dash.jumpY=0;dash.jumpV=0;dash.jumpCount=0}const runner=document.querySelector('#dashRunner');if(runner)runner.style.transform=`translateY(${-dash.jumpY}px)`;const track=dashTrack();if(!track){finishDash(false);return;}const W=track.clientWidth,H=track.clientHeight,playerX=W*.12,playerW=Math.min(W*.20,92),playerH=playerW*.75,ground=H*DASH_GROUND_RATIO,playerY=H-ground-DASH_RUNNER_RAISE-playerH-dash.jumpY;const speed=W*DASH_BASE_SPEED*(dash.speedBoost>0?1.55:1);const strip=document.querySelector('#dashBgScrollV217'),bg=document.querySelector('#dashBg');if(strip&&bg?.clientWidth){dash.bgOffset=(dash.bgOffset+speed*dt*.55)%bg.clientWidth;strip.style.transform=`translateX(${-dash.bgOffset}px)`;}
    dash.obstacles=dash.obstacles.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const ow=Math.min(W*.155,74),oh=ow,hitW=ow*.44,hitH=oh*.27,hitX=o.x+ow*.28,hitY=H-ground-hitH-o.raise;if(!o.hit&&dash.invuln<=0&&overlap(playerX,playerY,playerW*.72,playerH*.75,hitX,hitY,hitW,hitH)){o.hit=true;dash.invuln=.85;if(dash.bubble>0){showDashPowerPopV217('Blocked!');}else{dash.elapsed=Math.min(Number(dash.duration)||30,dash.elapsed+10);runner?.classList.add('hit');syncDashDriverV208(true);showDashPowerPopV217('-10s');setTimeout(()=>{runner?.classList.remove('hit');syncDashDriverV208(false)},420);}dashHud();}if(o.x<-80){o.el.remove();return false}return true});
    dash.pickups=dash.pickups.filter(o=>{o.x-=speed*dt;o.el.style.left=`${o.x}px`;o.el.style.bottom=`${ground+o.raise}px`;const isTime=o.kind==='time-pink'||o.kind==='time-gold',isPower=o.kind==='wing'||o.kind==='bubble';const iw=o.kind==='tiny'?Math.min(W*.108,48):(isTime||isPower)?Math.min(W*.108,46):Math.min(W*.098,42),ih=iw,pickW=iw*.74,pickH=ih*.74,pickX=o.x+iw*.13,pickY=H-ground-pickH-o.raise;if(overlap(playerX,playerY,playerW*.72,playerH*.75,pickX,pickY,pickW,pickH)){if(o.kind==='tiny'){dash.tiny++}else if(isTime){const bonus=Math.max(0,Number(o.timeBonus)||0);dash.duration=(Number(dash.duration)||30)+bonus;showDashPowerPopV217(`+${bonus}s`)}else if(o.kind==='wing'){dash.speedBoost=10;showDashPowerPopV217('Speed Up!')}else if(o.kind==='bubble'){dash.bubble=10;showDashPowerPopV217('Bubble Shield!')}else dash.coins++;o.el.remove();dashHud();return false}if(o.x<-60){o.el.remove();return false}return true});dashHud();dash.raf=requestAnimationFrame(dashFrame)}
  function startDash(){if(dash.running)return;ensureExpansionSave();const run=selectedDashRunV235();if(questSave.dash.freeRuns>0)questSave.dash.freeRuns--;else if(!useInventory('jump-token',run.cost)){setMessage(`Duckie Dash costs ${run.cost} Jump Tokens for ${run.duration} seconds.`);refreshFeatureBadges();return;}clearDashObjects();Object.assign(dash,{running:true,last:0,elapsed:0,duration:run.duration,coins:0,tiny:0,jumpY:0,jumpV:0,jumpCount:0,obstacleClock:0,nextObstacleDelay:2.10,coinClock:0,segment:-1,invuln:0,speedBoost:0,bubble:0,bgOffset:0});document.querySelector('#dashScreen')?.classList.add('dash-run-stage-v193');document.body.classList.add('dash-run-stage-v193-active');const ov=document.querySelector('#dashOverlay');ov?.classList.add('hidden');persistAll();refreshFeatureBadges();resetDashPreview();dash.raf=requestAnimationFrame(dashFrame)}
  document.querySelector('#dashTrack')?.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;dashJump()});
  document.addEventListener('keydown',e=>{if(document.querySelector('#dashScreen')?.classList.contains('hidden'))return;if(e.key===' '||e.key==='ArrowUp'){e.preventDefault();dashJump()}});
  document.querySelector('#dashStart')?.addEventListener('click',e=>{e.stopPropagation();startDash()});

  // ----- Mysterious Merchant -----
  function clearMerchantUi(){const layer=ui.chestLayer;layer?.classList.remove('merchant-active-v197');layer?.querySelector('#merchantShopV197')?.remove();}
  function finishNonBattleEvent(message){clearMerchantUi();hideEventChoices();ui.openChest?.classList.add('hidden');ui.chestLayer?.classList.add('hidden');setMessage(message);if(currentRun){refillActiveHeroHpV210();markEndlessFloorComplete();}ui.continueButton.textContent=currentRun?.mode==='endless'?'Next Floor':'Continue';ui.postFloorActions?.classList.remove('hidden');ui.leaveEndlessButton?.classList.toggle('hidden',currentRun?.mode!=='endless');setPostFloorLayout(true);actionLocked=false;persistAll();refreshFeatureBadges();}
  function merchantStock(){
    const options=[
      {kind:'item',id:'buddy-pon',name:'Lil Pon',image:'../assets/items/buddy-pons/buddy-pon.webp',price:40,normalPrice:50,detail:'A basic Lil Pon.'},
      {kind:'item',id:'super-buddy-pon',name:'Super Lil Pon',image:'../assets/items/buddy-pons/super-buddy-pon.webp',price:80,normalPrice:100,detail:'A stronger Lil Pon.'},
      {kind:'item',id:'boss-buddy-pon',name:'Boss Lil Pon',image:'../assets/items/buddy-pons/boss-buddy-pon.webp',price:140,normalPrice:175,detail:'Made for tougher Lil Guys.'},
      {kind:'item',id:'jump-token',name:'Jump Token',image:'assets/dash/Jump-Token.png',price:64,normalPrice:80,detail:'One token toward Duckie Dash.'},
      {kind:'item',id:'common-egg',name:'Common Egg',image:'assets/eggs/Common-egg.png',price:128,normalPrice:160,detail:'Hatches a non-boss Lil Guy.'},
      {kind:'item',id:'rare-egg',name:'Rare Egg',image:'assets/eggs/Rare-egg.png',price:340,normalPrice:425,detail:'Bosses favored + better Shiny chance.'}
    ];
    const craft=REWARD_ITEMS.filter(x=>!String(x.id).includes('buddy-pon')&&!String(x.id).includes('heart-refill'));if(craft.length){const x=craft[Math.floor(Math.random()*craft.length)],normalPrice=70+Math.floor(Math.random()*51);options.push({kind:'item',id:x.id,name:x.name,image:x.image,price:Math.max(1,Math.round(normalPrice*.8)),normalPrice,detail:'A random crafting supply.'});}
    const owned=charmState().owned||{};const charms=Object.values(CHARM_DEFS).filter(c=>!c.special&&!owned[c.id]);if(charms.length){const c=charms[Math.floor(Math.random()*charms.length)],normalPrice=Number(c.price||200);options.push({kind:'charm',id:c.id,name:c.name,image:'assets/charms/Charm-outline.png',price:Math.max(1,Math.round(normalPrice*.8)),normalPrice,detail:c.effect});}
    const copy=options.slice(),out=[];while(copy.length&&out.length<2){out.push(copy.splice(Math.floor(Math.random()*copy.length),1)[0])}return out;
  }
  function showMerchantEvent(){
    currentEnemy=null;
    ui.enemyCombatant.classList.add('hidden');
    ui.enemyCombatant2?.classList.add('hidden');
    ui.commandGrid.classList.add('hidden');
    closeCommandWindow();
    pendingChest={kind:'event',eventType:'mysterious-merchant',wares:merchantStock()};
    showChest({kind:'event',eventType:'mysterious-merchant',captionText:'Mysterious Merchant! Gentleman Duck has a tiny roadside shop.'});
    ui.chestSprite.src='../assets/ducks/Top-hat-duck.webp';
    ui.chestSprite.alt='Gentleman Duck';
    ui.chestSprite.classList.add('event-scene-art','merchant-duck');
    ui.openChest.classList.add('hidden');
    setMessage('Gentleman Duck offers two completely random items today.');
    renderMerchantButtons();
  }
  function renderMerchantButtons(){
    if(!pendingChest?.wares||!ui.chestLayer)return;
    ui.eventChoiceActions?.classList.add('hidden');
    if(ui.eventChoiceActions)ui.eventChoiceActions.innerHTML='';
    ui.battleUi?.classList.add('event-mode');
    ui.chestLayer.classList.add('merchant-active-v197');
    let shop=ui.chestLayer.querySelector('#merchantShopV197');
    if(!shop){shop=document.createElement('div');shop.id='merchantShopV197';shop.className='merchant-shop-v197';ui.chestLayer.appendChild(shop);}
    shop.innerHTML='';
    pendingChest.wares.forEach(ware=>{
      const b=document.createElement('button');
      b.type='button';
      b.className='pixel-button merchant-ware';
      b.disabled=Boolean(ware.sold);
      const artwork=ware.kind==='charm'?charmArtMarkup(CHARM_DEFS[ware.id],'small'):`<img src="${ware.image}" alt="">`;
      b.innerHTML=`${artwork}<span><strong>${ware.name}</strong><small>20% off · ${ware.detail}</small></span><span class="price">${ware.sold?'Sold':'◉ '+ware.price}</span>`;
      b.addEventListener('click',()=>{
        if(ware.sold)return;
        if(Number(hubSave.coins||0)<ware.price){setMessage('Not enough Pink Coins for that item.');return;}
        hubSave.coins-=ware.price;
        if(ware.kind==='charm')charmState().owned[ware.id]=true;else addInventory(ware.id,1);
        ware.sold=true;
        persistAll();renderMeta();renderMerchantButtons();refreshFeatureBadges();setMessage(`Bought ${ware.name}!`);
      });
      shop.appendChild(b);
    });
    const leave=document.createElement('button');
    leave.type='button';
    leave.className='pixel-button merchant-leave-v197';
    leave.textContent='No Thanks';
    leave.addEventListener('click',()=>finishNonBattleEvent('Gentleman Duck tips his hat and packs up his tiny shop.'));
    shop.appendChild(leave);
  }
  window.SIBLING_SPAT_BATTLE_FIX='24.230-inward-equal-height';
  // ----- Sibling Spat dialogue + battle -----
  let siblingDialogueIndex=0,siblingDialogueState=null,siblingIdleTimer=null,siblingIdleIndex=0;
  const SIBLING_IDLE_FRAMES={miko:['assets/characters/miko/base/idle-1.webp','assets/characters/miko/base/idle-2.webp'],miho:['assets/characters/miho/base/idle-1.webp','assets/characters/miho/base/idle-2.webp']};
  function siblingSprite(who,expression,frame=0){if(expression==='neutral'){const idle=SIBLING_IDLE_FRAMES[who];if(idle?.length)return idle[frame%idle.length]}return SIBLING_SPRITES[who]?.[expression]||SIBLING_SPRITES[who]?.neutral||''}
  function stopSiblingAnimation(){if(siblingIdleTimer){clearInterval(siblingIdleTimer);siblingIdleTimer=null}}
  function updateSiblingSceneSprites(){const state=siblingDialogueState;if(!state)return;const left=document.querySelector('#siblingLeft'),right=document.querySelector('#siblingRight');if(left)left.src=siblingSprite(state.leftWho,state.leftExpression,siblingIdleIndex);if(right)right.src=siblingSprite(state.rightWho,state.rightExpression,siblingIdleIndex)}
  function startSiblingAnimation(){stopSiblingAnimation();siblingIdleIndex=0;updateSiblingSceneSprites();siblingIdleTimer=setInterval(()=>{siblingIdleIndex=(siblingIdleIndex+1)%2;updateSiblingSceneSprites()},520)}
  function showSiblingEvent(){const script=SIBLING_SCRIPTS[activeCharacterId];if(!script)return;const hero=document.querySelector('.peep-combatant');hero?.classList.add('hidden','sibling-spat-hidden-v224');currentEnemy=null;ui.enemyCombatant.classList.add('hidden');ui.enemyCombatant2?.classList.add('hidden');ui.buddyCombatant?.classList.add('hidden');ui.commandGrid.classList.add('hidden');closeCommandWindow();ui.chestLayer.classList.add('hidden');const scene=document.querySelector('#siblingScene'),left=document.querySelector('#siblingLeft'),right=document.querySelector('#siblingRight');scene?.classList.add('sibling-spat-v224');scene?.classList.remove('hidden');scene?.setAttribute('aria-hidden','false');left?.classList.add('sibling-left-v224');right?.classList.add('sibling-right-v224');const leftWho=activeCharacterId,rightWho=activeCharacterId==='miko'?'miho':'miko';if(left)left.alt=leftWho==='miko'?'Miko':'Miho';if(right)right.alt=rightWho==='miko'?'Miko':'Miho';siblingDialogueState={script,leftWho,rightWho,leftExpression:'neutral',rightExpression:'neutral'};siblingDialogueIndex=0;startSiblingAnimation();renderSiblingLine();}
  function renderSiblingLine(){const state=siblingDialogueState;if(!state)return;const line=state.script[siblingDialogueIndex];if(!line)return;const side=line.who===state.leftWho?'left':'right';state[`${side}Expression`]=line.expression;const img=document.querySelector(side==='left'?'#siblingLeft':'#siblingRight');if(img)img.src=siblingSprite(line.who,line.expression);setMessage(`${line.speaker}: ${line.text}`);const holder=ui.eventChoiceActions;holder.innerHTML='';const b=document.createElement('button');b.type='button';b.className='pixel-button primary';const last=siblingDialogueIndex>=state.script.length-1;b.textContent=last?'Fight!':'Next';b.addEventListener('click',()=>{if(last)beginSiblingBattle();else{siblingDialogueIndex++;renderSiblingLine()}});const row=document.createElement('div');row.className='sibling-dialogue-actions';row.appendChild(b);holder.appendChild(row);holder.classList.remove('hidden');ui.battleUi?.classList.add('event-mode');}
  function beginSiblingBattle(){const opponent=activeCharacterId==='miko'?'sibling-miho':'sibling-miko';stopSiblingAnimation();document.querySelector('.peep-combatant')?.classList.remove('hidden','sibling-spat-hidden-v224');document.querySelector('#siblingScene')?.classList.add('hidden');document.querySelector('#siblingScene')?.setAttribute('aria-hidden','true');hideEventChoices();ui.enemyCombatant.classList.remove('hidden');ui.commandGrid.classList.remove('hidden');startEnemy(opponent,{suppressIntro:true});ui.battlefield?.classList.add('sibling-battle-v230');ui.enemySprite?.classList.add('sibling-opponent-v230');currentEnemy.uncatchable=true;currentEnemy.siblingCharacterId=opponent.endsWith('miko')?'miko':'miho';currentEnemy.siblingAttackBuffTurns=0;currentEnemy.siblingAttackMultiplier=1;currentEnemy.siblingBuffUsed=false;setMessage(`Sibling Spat! ${currentEnemy.name} is ready to fight!`);}

  const oldCatchRate=buddyPonCatchRate;buddyPonCatchRate=function(pon,enemy){if(enemy?.uncatchable)return 0;return oldCatchRate(pon,enemy)};
  const oldEnemyTurn=enemyTurn;enemyTurn=async function(){
    if(!currentEnemy?.siblingCharacterId)return oldEnemyTurn();
    if(currentEnemy.hpNow<=0)return;
    const id=currentEnemy.siblingCharacterId;const skills=(id==='miko'?MIKO_SKILLS:MIHO_SKILLS).filter(x=>activeHeroProgress().level>=x.unlock&&x.id!=='just-a-smack');let candidates=skills.filter(x=>['damage','damage-burn','multi-hit'].includes(x.type));
    if(id==='miko'&&!currentEnemy.siblingBuffUsed&&currentEnemy.hpNow<currentEnemy.maxHp*.55){const heal=skills.find(x=>x.id==='thoughts-of-lovers');if(heal)candidates=[...candidates,heal,heal]}
    const buff=skills.find(x=>x.type==='buff');if(buff&&currentEnemy.siblingAttackBuffTurns<=0)candidates.push(buff);
    const skill=candidates[Math.floor(Math.random()*candidates.length)]||skills[0];const refs=activeEnemyUi();if(skill?.sprite&&refs.sprite)refs.sprite.src=skill.sprite;
    if(skill?.type==='buff'){currentEnemy.siblingAttackMultiplier=1+Number(skill.attackBoost||.3);currentEnemy.siblingAttackBuffTurns=Number(skill.duration||3);currentEnemy.siblingBuffUsed=true;setMessage(`${currentEnemy.name} used ${skill.name}! Attack rose!`);refs.sprite?.classList.add('attack-pop');await sleep(650);refs.sprite?.classList.remove('attack-pop');}
    else if(skill?.type==='full-heal-buff'){currentEnemy.hpNow=currentEnemy.maxHp;currentEnemy.siblingAttackMultiplier=1+Number(skill.attackBoost||.5);currentEnemy.siblingAttackBuffTurns=Number(skill.duration||4);currentEnemy.siblingBuffUsed=true;renderEnemyHp();setMessage(`${currentEnemy.name} used ${skill.name}! Full heal + Attack boost!`);await sleep(750);}
    else {const mult=Math.max(.7,Number(skill?.multiplier)||1)*Math.max(1,Number(currentEnemy.siblingAttackMultiplier)||1);await performEnemyAttack(mult,`${currentEnemy.name} used ${skill?.name||'Attack'}!`);}
    currentEnemy.siblingAttackBuffTurns=Math.max(0,Number(currentEnemy.siblingAttackBuffTurns||0)-1);if(currentEnemy.siblingAttackBuffTurns<=0)currentEnemy.siblingAttackMultiplier=1;if(currentRun?.hp>0){if(refs.sprite)refs.sprite.src=currentEnemy.idle[0];setMessage(`${heroDisplayName()} is ready!`)}
  };

  // Add Merchant + character-only Sibling Spat to the existing special-event pool.
  pickSituationType=function(mode='stage'){const entries=mode==='endless'?[{value:'lucky-picnic',weight:5},{value:'wishing-fountain',weight:4},{value:'mysterious-merchant',weight:3}]:[{value:'lucky-picnic',weight:6},{value:'wishing-fountain',weight:4},{value:'mysterious-merchant',weight:3}];if(activeCharacterId==='miko'||activeCharacterId==='miho')entries.push({value:'sibling-spat',weight:1});return weightedPick(entries)};
  const oldSituationTitle=situationTitle;situationTitle=function(type){if(type==='mysterious-merchant')return'Mysterious Merchant';if(type==='sibling-spat')return'Sibling Spat';return oldSituationTitle(type)};
  const oldHeader=updateEncounterHeader;updateEncounterHeader=function(encounter=currentEncounterData()){oldHeader(encounter);if(encounter?.type==='mysterious-merchant')ui.encounterLabel.textContent+=' · MERCHANT';else if(encounter?.type==='sibling-spat')ui.encounterLabel.textContent+=' · SIBLING SPAT'};
  const oldStartEncounter=startEncounter;startEncounter=function(){const encounter=currentRun?.mode==='endless'?currentRun.endlessEncounter:currentRun?.plan?.[currentRun?.index];if(encounter?.type!=='mysterious-merchant'&&encounter?.type!=='sibling-spat')return oldStartEncounter();
    clearAnimations();actionLocked=false;pendingChest=null;pendingDefeatedEnemy=null;befriendAttempted=false;ui.befriendPanel?.classList.add('hidden');ui.ponPurchasePanel?.classList.add('hidden');quickHealUses=0;skillState={cooldowns:{},onceUsed:{},attackBuffTurns:0,attackBuffMultiplier:1.30,activeBuffSkillId:null,heartRayCount:0,ioRainbowUses:0,buddyCooldown:0,buddyAttackBuffTurns:0,buddyAttackMultiplier:1.15,heroGuardTurns:0,heroGuardMultiplier:1,heroNextDamageMultiplier:1,enemyAttackDownTurns:0,enemyAttackMultiplier:1,enemyDefenseDownTurns:0,enemyDefenseMultiplier:1,enemyAccuracyDownTurns:0,enemyMissChance:0,enemyBurnTurns:0,enemyBurnDamagePercent:0,heroMissTurns:0,heroMissChance:0,heroNextAttackMultiplier:1,heroAttackDownTurns:0,heroAttackDownMultiplier:1,heroStunTurns:0,heroSleepTurns:0,heroParalysisMoves:0,heroParalysisFailChance:0,enemyNextAttackMultiplier:1,enemyStunned:false,enemyStunTurns:0};specialHeroAttackScale=1;if(currentRun)currentRun.luckyFluffUsedThisEncounter=false;buddyUsedThisHeroTurn=false;activeBattleBuddySlot=firstAssignedBattleBuddySlot();buddySwitchUsedThisEncounter=false;renderBattleCharmStrip();resetDoubleBattleUi();hideEventChoices();ui.postFloorActions?.classList.add('hidden');ui.leaveEndlessButton?.classList.add('hidden');setPostFloorLayout(false);
    const endless=currentRun.mode==='endless';if(endless){currentRun.rank=endlessEffectiveRank(currentRun.floor);if(!currentRun.floorBackground)currentRun.floorBackground=chooseEndlessBackground();ui.battleBg.src=currentRun.floorBackground}else{const cfg=currentAreaConfig();ui.battleBg.src=cfg.backgrounds[currentRun.index]}updateEncounterHeader(encounter);ui.peepLevelCombat.textContent=`Lv. ${activeHeroProgress().level}`;renderPeepHp();startPeepIdle();if(encounter.type==='mysterious-merchant')showMerchantEvent();else showSiblingEvent();};

  // Fountain + Picnic keep their custom art throughout the event.
  const oldShowEventChoices=showEventChoices;showEventChoices=function(type){oldShowEventChoices(type);if(EVENT_ART[type]){ui.chestSprite.src=EVENT_ART[type];ui.chestSprite.classList.add('event-scene-art')}};

  // Eggs + Jump Tokens can drop from every chest tier and special event.
  const oldGenerateRewards=generateRewards;generateRewards=function(chest){const r=oldGenerateRewards(chest);r.freeDashRuns=0;if(!Array.isArray(r.items))r.items=[];const add=(item,qty=1)=>addRewardItem(r.items,item,qty);
    if(chest?.eventType==='lucky-picnic'){if(Math.random()<.16)add(SPECIAL_REWARD_ITEMS.commonEgg);if(Math.random()<.22)add(SPECIAL_REWARD_ITEMS.token)}
    else if(chest?.eventType==='wishing-fountain'){if(Math.random()<.18)add(SPECIAL_REWARD_ITEMS.commonEgg);if(Math.random()<.05)add(SPECIAL_REWARD_ITEMS.rareEgg);if(Math.random()<.24)add(SPECIAL_REWARD_ITEMS.token);if(Math.random()<.05)r.freeDashRuns++}
    else if(chest?.kind==='hidden-treasure'){add(SPECIAL_REWARD_ITEMS.token,2);add(SPECIAL_REWARD_ITEMS.rareEgg);if(Math.random()<.18)r.freeDashRuns++}
    else if(chest?.kind==='double-trouble'){if(Math.random()<.42)add(SPECIAL_REWARD_ITEMS.token);if(Math.random()<.18)add(SPECIAL_REWARD_ITEMS.commonEgg);if(Math.random()<.04)add(SPECIAL_REWARD_ITEMS.rareEgg)}
    else if(chest?.kind==='rare'){if(Math.random()<.38)add(SPECIAL_REWARD_ITEMS.token);if(Math.random()<.20)add(SPECIAL_REWARD_ITEMS.commonEgg);if(Math.random()<.05)add(SPECIAL_REWARD_ITEMS.rareEgg);if(Math.random()<.04)r.freeDashRuns++}
    else if(chest?.kind==='boss'){if(Math.random()<.32)add(SPECIAL_REWARD_ITEMS.token);if(Math.random()<.18)add(SPECIAL_REWARD_ITEMS.commonEgg);if(Math.random()<.08)add(SPECIAL_REWARD_ITEMS.rareEgg);if(Math.random()<.05)r.freeDashRuns++}
    else {if(Math.random()<.08)add(SPECIAL_REWARD_ITEMS.token);if(Math.random()<.035)add(SPECIAL_REWARD_ITEMS.commonEgg);if(Math.random()<.006)add(SPECIAL_REWARD_ITEMS.rareEgg)}return r};
  const oldApplyRewards=applyRewards;applyRewards=function(r){oldApplyRewards(r);if(Number(r?.freeDashRuns)>0){ensureExpansionSave();questSave.dash.freeRuns+=Math.max(0,Math.floor(Number(r.freeDashRuns)||0));persistAll();refreshFeatureBadges()}};

  // Home/screen integration.
  const oldShowScreen=showScreen;showScreen=function(which){oldShowScreen(which);const dashScreen=document.querySelector('#dashScreen');dashScreen?.classList.toggle('hidden',which!=='dash');document.querySelector('#hatcheryScreen')?.classList.toggle('hidden',which!=='hatchery');if(which!=='dash'){if(dash.running){dash.running=false;cancelAnimationFrame(dash.raf);clearDashObjects()}dashScreen?.classList.remove('dash-run-stage-v193');document.body.classList.remove('dash-run-stage-v193-active')}if(which==='dash'){renderDashSelectors();resetDashPreview();if(!dash.running)renderDashReadyOverlay()}if(which==='hatchery')renderHatchery()};
  const oldRenderMeta=renderMeta;renderMeta=function(){oldRenderMeta();refreshFeatureBadges()};
  document.querySelector('#openDuckieDash')?.addEventListener('click',()=>showScreen('dash'));
  document.querySelector('#openHatchery')?.addEventListener('click',()=>showScreen('hatchery'));
  document.querySelector('#dashBack')?.addEventListener('click',()=>showScreen('home'));
  document.querySelector('#hatchBack')?.addEventListener('click',()=>showScreen('home'));
  document.querySelector('#hatchInventoryButton')?.addEventListener('click',()=>openEggInventory(null,false));
  document.querySelector('#closeHatchDetail')?.addEventListener('click',closeHatchDetail);
  document.querySelector('#hatchDetailBackdrop')?.addEventListener('click',closeHatchDetail);
  document.querySelector('#closeEggInventory')?.addEventListener('click',closeEggInventory);
  document.querySelector('#eggInventoryBackdrop')?.addEventListener('click',closeEggInventory);

  window.DUCKIE_DASH_API_V269={
    start:startDash,
    getStatus:()=>( {
      tokens:specialQty('jump-token'),
      freeRuns:Math.max(0,Math.floor(Number(questSave.dash.freeRuns)||0)),
      duration:Number(questSave.dash.runDuration)===60?60:30,
      coins:Math.max(0,Number(hubSave.coins)||0)
    }),
    setDuration:(value)=>{
      questSave.dash.runDuration=Number(value)===60?60:30;
      persistAll();
    },
    refresh:refreshFeatureBadges
  };

  window.DuckieHatchApiV178={
    renderHatchery, openEggInventory, closeEggInventory, closeHatchDetail,
    openHatchDetail, refreshFeatureBadges, hatchAllReadyV343,
    readyEggCount:readyEggs
  };
  window.refreshFeatureBadges=refreshFeatureBadges;
  window.renderDashSelectors=renderDashSelectors;
  refreshFeatureBadges();renderDashSelectors();renderHatchery();
})();


// v24.169 — compact Duck Quest home + one-screen Hatching Area polish
(function(){
  const polish=document.createElement('style');
  polish.textContent=`
    /* Home organization — based on the player's compact mockup. */
    #homeScreen.dq-home-polished{gap:10px;}
    #homeScreen.dq-home-polished .hero-card{grid-template-columns:minmax(118px,30%) minmax(0,1fr);gap:12px;padding:12px;border-radius:18px;}
    #homeScreen.dq-home-polished .hero-sprite-column{gap:6px;}
    #homeScreen.dq-home-polished .hero-sprite-wrap{min-height:132px;border-radius:14px;}
    #homeScreen.dq-home-polished .menu-peep{width:108px;height:108px;}
    #homeScreen.dq-home-polished .hero-info{align-content:start;gap:10px;padding-top:4px;}
    #homeScreen.dq-home-polished .hero-name-row h2{font-size:1.22rem;}
    #homeScreen.dq-home-polished .hero-quick-actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;order:4;}
    #homeScreen.dq-home-polished .hero-info-button{min-height:39px;padding:6px 7px;font-size:.64rem;border-radius:10px;}
    #homeScreen.dq-home-polished .meter-group{gap:4px;}
    #homeScreen.dq-home-polished .happiness-row{align-items:flex-end;}
    #homeScreen.dq-home-polished .hearts{font-size:1.08rem;gap:2px;flex-wrap:nowrap;}
    #homeScreen.dq-home-polished .icon-background-control>span{font-size:.57rem;}
    #homeScreen.dq-home-polished .icon-background-button{min-height:39px;padding:5px 7px;}
    #homeScreen.dq-home-polished .switch-quest-oc-button{min-height:39px;margin-top:1px;}
    .dq-hero-tools{grid-column:1/-1;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.08fr);gap:10px;margin-top:1px;}
    .dq-hero-tools .charm-home-card{margin:0!important;min-height:58px;padding:0!important;border:0!important;background:transparent!important;box-shadow:none!important;display:block!important;}
    .dq-hero-tools .charm-home-copy,.dq-hero-tools .charm-home-slots{display:none!important;}
    .dq-hero-tools #openCharmScreen,.dq-hero-tools #openHatchery{width:100%;min-height:58px;border-radius:14px;font-size:.82rem;display:flex;align-items:center;justify-content:center;gap:8px;}
    .dq-hero-tools #openCharmScreen::before{content:'♡';font-size:1.15rem;color:#cf6788;}
    .dq-hero-tools #openHatchery{background:linear-gradient(180deg,#f4a4c0,#e87fa7);color:#fff;border-color:#9d5b70;text-shadow:1px 1px #99566d;}
    .dq-hero-tools #openHatchery .home-hatch-icon{width:30px;height:30px;object-fit:contain;image-rendering:pixelated;filter:drop-shadow(0 2px 0 rgba(97,61,73,.16));}
    .dq-hero-tools #openHatchery .home-hatch-label{font-size:.88rem;letter-spacing:.01em;}
    .dq-hero-tools #hatchReadyBadge:not(:empty){display:inline-grid;place-items:center;min-width:21px;height:21px;padding:0 5px;border-radius:999px;background:#fff5aa;color:#98661f;text-shadow:none;font-size:.67rem;}

    #homeScreen.dq-home-polished .endless-home-card{padding:12px;border-radius:18px;gap:9px;background:linear-gradient(135deg,rgba(250,244,255,.98),rgba(245,236,255,.96));border-color:#8c78bc;}
    #homeScreen.dq-home-polished .endless-home-heading{align-items:center;}
    #homeScreen.dq-home-polished .endless-home-heading h2{font-size:1.16rem;margin:1px 0 1px;}
    #homeScreen.dq-home-polished .endless-home-heading small{font-size:.66rem;line-height:1.25;}
    #homeScreen.dq-home-polished .endless-symbol{width:42px;height:42px;font-size:1.25rem;display:grid;place-items:center;border:3px solid #8c78bc;border-radius:50%;background:rgba(255,255,255,.72);color:#745db0;}
    #homeScreen.dq-home-polished .endless-record-grid{gap:7px;}
    #homeScreen.dq-home-polished .endless-record-grid>div{padding:8px 9px;min-height:57px;border-radius:12px;background:rgba(255,255,255,.72);}
    #homeScreen.dq-home-polished .endless-record-grid span{font-size:.57rem;}
    #homeScreen.dq-home-polished .endless-record-grid strong{font-size:.82rem;}
    #homeScreen.dq-home-polished .endless-home-actions{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(0,1fr);gap:8px;}
    #homeScreen.dq-home-polished .endless-home-actions .pixel-button{min-height:45px;}
    #homeScreen.dq-home-polished .endless-note{display:none;}

    #homeScreen.dq-home-polished #duckieDashHomeCard{margin-top:0;padding:12px 13px;border-radius:18px;gap:8px;position:relative;overflow:hidden;}
    #homeScreen.dq-home-polished #duckieDashHomeCard::before{content:'♪';position:absolute;left:12px;bottom:12px;color:#ee9ab7;font-size:1.35rem;opacity:.5;pointer-events:none;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head{align-items:center;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head>div{padding-left:34px;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head h2{font-size:1.15rem;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head small{font-size:.67rem;line-height:1.25;max-width:440px;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-token-pill{flex:0 0 auto;padding:5px 9px;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-mini-grid{display:none;}
    .dash-home-cost{margin:0 0 0 auto;font-size:.72rem;font-weight:900;color:#6d4d59;display:flex;align-items:center;gap:5px;}
    .dash-home-cost img{width:20px;height:20px;object-fit:contain;image-rendering:pixelated;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-actions{justify-content:flex-end;}
    #homeScreen.dq-home-polished #duckieDashHomeCard #openDuckieDash{flex:0 1 58%;min-height:44px;}

    #homeScreen.dq-home-polished .area-select-card{padding:12px;border-radius:18px;}
    #homeScreen.dq-home-polished .area-select-title{margin-bottom:8px;}
    #homeScreen.dq-home-polished .area-select-card h2{font-size:1rem;}
    #homeScreen.dq-home-polished .area-picker{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;}
    #homeScreen.dq-home-polished .area-option{min-height:76px;padding:7px 8px;border-radius:13px;grid-template-columns:66px minmax(0,1fr);gap:8px;}
    #homeScreen.dq-home-polished .area-option-image{width:64px;height:58px;border-radius:9px;}
    #homeScreen.dq-home-polished .area-option strong{font-size:.76rem;}
    #homeScreen.dq-home-polished .area-option small{font-size:.55rem;}

    /* Hatching Area: all three nests fit in the available phone viewport. */
    body.hatchery-active{overflow:hidden;}
    #hatcheryScreen.hatchery-fit-screen{min-height:0!important;height:var(--hatch-screen-height,calc(100dvh - 64px))!important;overflow:hidden!important;padding:0!important;}
    #hatcheryScreen.hatchery-fit-screen .hatch-world-shell{height:100%;min-height:0!important;padding:0!important;display:grid;place-items:stretch;}
    #hatcheryScreen.hatchery-fit-screen .hatch-world{height:100%;min-height:0!important;width:100%;max-width:none;aspect-ratio:auto!important;border-radius:18px;}
    #hatcheryScreen.hatchery-fit-screen .hatch-world-title{font-size:.92rem;padding:7px 13px;letter-spacing:.065em;}
    #hatcheryScreen.hatchery-fit-screen .hatch-world-topbar{padding-top:9px;}
    #hatcheryScreen.hatchery-fit-screen .hatch-world-ready{top:13%;font-size:.68rem;padding:4px 8px;}
    #hatcheryScreen.hatchery-fit-screen .hatch-nest-slot{width:42%;height:16.5%;}
    #hatcheryScreen.hatchery-fit-screen .hatch-nest-slot:nth-child(1){top:35.5%;}
    #hatcheryScreen.hatchery-fit-screen .hatch-nest-slot:nth-child(2){top:61%;}
    #hatcheryScreen.hatchery-fit-screen .hatch-nest-slot:nth-child(3){top:83%;}
    #hatcheryScreen.hatchery-fit-screen .hatch-main-egg{width:68%;height:68%;}
    #hatcheryScreen.hatchery-fit-screen .hatch-empty-plus{width:38px;height:38px;font-size:1.25rem;}
    #hatcheryScreen.hatchery-fit-screen .hatch-slot-status{top:80%;font-size:.61rem;padding:3px 7px;}
    #hatcheryScreen.hatchery-fit-screen .hatch-world-tip{display:none!important;}

    @media(max-width:600px){
      #homeScreen.dq-home-polished .hero-card{grid-template-columns:31% minmax(0,1fr);gap:9px;padding:9px;}
      #homeScreen.dq-home-polished .hero-sprite-wrap{min-height:112px;}
      #homeScreen.dq-home-polished .menu-peep{width:94px;height:94px;}
      #homeScreen.dq-home-polished .hero-info{gap:7px;padding-top:1px;}
      #homeScreen.dq-home-polished .hero-name-row h2{font-size:1rem;}
      #homeScreen.dq-home-polished .hero-info-button{min-height:32px;padding:4px 4px;font-size:.52rem;}
      #homeScreen.dq-home-polished .hearts{font-size:.91rem;gap:1px;}
      #homeScreen.dq-home-polished .icon-background-button{font-size:.54rem;min-height:35px;}
      #homeScreen.dq-home-polished .switch-quest-oc-button{font-size:.54rem;min-height:35px;}
      .dq-hero-tools{gap:7px;}
      .dq-hero-tools #openCharmScreen,.dq-hero-tools #openHatchery{min-height:50px;font-size:.68rem;padding:6px 7px;}
      .dq-hero-tools #openHatchery .home-hatch-icon{width:25px;height:25px;}
      .dq-hero-tools #openHatchery .home-hatch-label{font-size:.72rem;}
      #homeScreen.dq-home-polished .endless-home-card{padding:9px;gap:7px;}
      #homeScreen.dq-home-polished .endless-home-heading h2{font-size:.95rem;}
      #homeScreen.dq-home-polished .endless-home-heading small{font-size:.54rem;}
      #homeScreen.dq-home-polished .endless-symbol{width:34px;height:34px;font-size:1rem;border-width:2px;}
      #homeScreen.dq-home-polished .endless-record-grid>div{padding:6px;min-height:48px;}
      #homeScreen.dq-home-polished .endless-record-grid span{font-size:.48rem;}
      #homeScreen.dq-home-polished .endless-record-grid strong{font-size:.68rem;}
      #homeScreen.dq-home-polished .endless-home-actions .pixel-button{min-height:40px;font-size:.64rem;padding:6px;}
      #homeScreen.dq-home-polished #duckieDashHomeCard{padding:9px 10px;gap:6px;}
      #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head>div{padding-left:27px;}
      #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head h2{font-size:.94rem;}
      #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head small{font-size:.54rem;}
      #homeScreen.dq-home-polished #duckieDashHomeCard .dq-token-pill img{width:21px;height:21px;}
      .dash-home-cost{font-size:.58rem;}
      #homeScreen.dq-home-polished #duckieDashHomeCard #openDuckieDash{min-height:39px;font-size:.66rem;flex-basis:62%;}
      #homeScreen.dq-home-polished .area-select-card{padding:9px;}
      #homeScreen.dq-home-polished .area-picker{gap:6px;}
      #homeScreen.dq-home-polished .area-option{min-height:66px;padding:6px;grid-template-columns:54px minmax(0,1fr);gap:6px;}
      #homeScreen.dq-home-polished .area-option-image{width:52px;height:50px;}
      #homeScreen.dq-home-polished .area-option strong{font-size:.64rem;}
      #homeScreen.dq-home-polished .area-option small{font-size:.47rem;}
      #homeScreen.dq-home-polished .area-select-card h2{font-size:.83rem;}
    }
    @media(max-width:390px){
      #homeScreen.dq-home-polished .hero-card{grid-template-columns:108px minmax(0,1fr);}
      #homeScreen.dq-home-polished .hero-quick-actions{grid-template-columns:repeat(3,minmax(0,1fr));gap:4px;}
      #homeScreen.dq-home-polished .hero-info-button{font-size:.48rem;padding:4px 2px;}
      #homeScreen.dq-home-polished .hearts{font-size:.82rem;}
      .dq-hero-tools #openHatchery .home-hatch-label{font-size:.66rem;}
    }
  `;
  document.head.appendChild(polish);

  function organizeHome(){
    const home=document.querySelector('#homeScreen');
    const hero=document.querySelector('.hero-card');
    const charm=document.querySelector('.charm-home-card');
    const dash=document.querySelector('#duckieDashHomeCard');
    const hatch=document.querySelector('#openHatchery');
    if(!home||!hero||!charm||!dash||!hatch) return;
    home.classList.add('dq-home-polished');

    let tools=hero.querySelector('.dq-hero-tools');
    if(!tools){tools=document.createElement('div');tools.className='dq-hero-tools';hero.appendChild(tools);}
    if(charm.parentElement!==tools) tools.appendChild(charm);
    const charmButton=document.querySelector('#openCharmScreen');
    if(charmButton) charmButton.textContent='Equip Charm';

    if(hatch.parentElement!==tools) tools.appendChild(hatch);
    hatch.innerHTML=`<img class="home-hatch-icon" src="assets/eggs/Common-egg.png" alt=""><span class="home-hatch-label">Hatching Area</span><span id="hatchReadyBadge"></span>`;

    let cost=dash.querySelector('.dash-home-cost');
    if(!cost){
      cost=document.createElement('p');
      cost.className='dash-home-cost';
      cost.innerHTML=`Cost: 3 Tokens <img src="assets/dash/Jump-Token.png" alt="">`;
      const actions=dash.querySelector('.dq-expand-actions');
      actions?.before(cost);
    }
  }

  function fitHatcheryToViewport(){
    const screen=document.querySelector('#hatcheryScreen');
    if(!screen || screen.classList.contains('hidden')) return;
    screen.classList.add('hatchery-fit-screen');
    const top=Math.max(0,screen.getBoundingClientRect().top);
    const available=Math.max(420,window.innerHeight-top-6);
    screen.style.setProperty('--hatch-screen-height',`${available}px`);
  }

  organizeHome();
  const previousShowScreen=showScreen;
  showScreen=function(which){
    previousShowScreen(which);
    const active=which==='hatchery';
    document.body.classList.toggle('hatchery-active',active);
    if(active) requestAnimationFrame(fitHatcheryToViewport);
  };
  window.addEventListener('resize',()=>requestAnimationFrame(fitHatcheryToViewport),{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(fitHatcheryToViewport,120));
})();


// v24.171 — mimic chest variants + condensed icon border picker + Duckie Dash polish
(function(){
  const JUMP_TOKEN_ITEM={id:'jump-token',name:'Jump Token',image:'assets/dash/Jump-Token.png'};
  const MIMIC_CHEST_VARIANTS=Object.freeze({
    regular:{id:'regular',label:'Regular Chest',accent:'Pink',description:'Won after battles.',disguiseClosed:'assets/items/chests/treasure/closed.webp',disguiseOpen:'assets/items/chests/treasure/open.webp',mimicIdle:['assets/enemies/mimic/base/open-1.webp','assets/enemies/mimic/base/open-2.webp'],mimicHurt:'assets/items/chests/treasure/closed.webp',mimicName:'Mimic',revealChance:0.25},
    lucky:{id:'lucky',label:'Lucky Chest',accent:'Gold',description:'Random chest with better coin luck.',disguiseClosed:'assets/enemies/mimic/lucky/closed.webp',disguiseOpen:'assets/enemies/mimic/lucky/open.webp',mimicIdle:['assets/enemies/mimic/lucky/idle-1.webp','assets/enemies/mimic/lucky/idle-2.webp'],mimicHurt:'assets/enemies/mimic/lucky/closed.webp',mimicName:'Lucky Mimic',revealChance:0.25},
    healthy:{id:'healthy',label:'Healthy Chest',accent:'Green',description:'Random rare chest that can reward multiple Jump Tokens.',disguiseClosed:'assets/enemies/mimic/healthy/closed.webp',disguiseOpen:'assets/enemies/mimic/healthy/open.webp',mimicIdle:['assets/enemies/mimic/healthy/idle-1.webp','assets/enemies/mimic/healthy/idle-2.webp'],mimicHurt:'assets/enemies/mimic/healthy/closed.webp',mimicName:'Healthy Mimic',revealChance:0.20},
    amethyst:{id:'amethyst',label:'Amethyst Chest',accent:'Purple',description:'Shiny mystery chest. Very rare!',disguiseClosed:'assets/shinies/amethyst-mimic-closed.webp',disguiseOpen:'assets/shinies/amethyst-mimic-open.webp',mimicIdle:['assets/shinies/amethyst-mimic-idle-1.webp','assets/shinies/amethyst-mimic-idle-2.webp'],mimicHurt:'assets/shinies/amethyst-mimic-closed.webp',mimicName:'Amethyst Mimic',revealChance:1}
  });
  window.DUCKIE_DAYS_MIMIC_VARIANT_LIST=[
    'Regular — Pink — won after battles.',
    'Lucky — Gold — random chest.',
    'Healthy — Green — random rare chest with extra Jump Tokens.',
    'Amethyst — Purple — shiny and very rare.'
  ];

  function mimicVariantById(id){ return MIMIC_CHEST_VARIANTS[id] || MIMIC_CHEST_VARIANTS.regular; }
  function chestVariantFor(data={}){
    const explicit=data.mimicChestStyle || data.enemy?.mimicChestStyle;
    if(explicit && MIMIC_CHEST_VARIANTS[explicit]) return MIMIC_CHEST_VARIANTS[explicit];
    if(data.mystery) return MIMIC_CHEST_VARIANTS.amethyst;
    if(data.kind==='healthy') return MIMIC_CHEST_VARIANTS.healthy;
    if(data.kind==='rare') return MIMIC_CHEST_VARIANTS.lucky;
    return MIMIC_CHEST_VARIANTS.regular;
  }

  const patchCss=document.createElement('style');
  patchCss.textContent=`
    #homeScreen .quest-icon-border-color-control{display:none!important;}
    #homeScreen .quest-icon-border-control .icon-background-picker-wrap{position:relative;}
    .quest-border-combo-picker{width:min(100%,284px);padding:10px;display:grid;gap:10px;border-radius:14px;border:2px solid rgba(140,98,93,.18);box-shadow:0 12px 28px rgba(84,58,70,.12);}
    .quest-border-combo-section{display:grid;gap:7px;}
    .quest-border-combo-label{font-size:.63rem;font-weight:900;letter-spacing:.12em;text-transform:uppercase;color:#8a6b77;}
    .quest-border-style-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;}
    .quest-border-color-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:7px;}
    .quest-border-color-grid .icon-background-choice{justify-content:center;min-height:42px;}
    .quest-border-color-grid .icon-background-dot{width:18px;height:18px;}
    .quest-border-style-choice{min-height:48px;}
    .quest-border-style-choice[aria-current="true"], .quest-border-color-grid .icon-background-choice[aria-current="true"]{box-shadow:inset 0 0 0 2px rgba(207,103,136,.28);background:#fff1f6;}

    #charmScreen .charm-book-heading{grid-template-columns:minmax(0,1fr)!important;align-items:start;}
    #charmScreen #backFromCharms,#charmScreen #charmCoinCount{display:none!important;}

    #dashScreen .dq-feature-shell{gap:12px;padding:16px;border-radius:24px;}
    #dashScreen .dq-feature-top{display:grid;gap:10px;align-items:start;}
    #dashScreen .dq-feature-top > div{display:grid;gap:8px;}
    #dashScreen .dq-feature-top small{display:none!important;}
    #dashScreen .dq-feature-top .pixel-button{justify-self:start;}
    .dash-title-actions{display:flex;flex-wrap:wrap;gap:8px;align-items:center;}
    .dash-title-actions .pixel-button{min-height:42px;}
    .dash-title-actions .dash-title-cost{display:inline-flex;align-items:center;gap:7px;padding:8px 12px;border-radius:999px;border:2px solid rgba(140,98,93,.18);background:#fffaf7;font-size:.73rem;font-weight:900;color:#6e4e5a;}
    .dash-title-actions .dash-title-cost img{width:20px;height:20px;object-fit:contain;image-rendering:pixelated;}
    #dashScreen .dq-mini-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;}
    #dashScreen .dq-mini-grid>div{padding:10px;border-radius:14px;background:#fffdfb;}
    #dashScreen .dq-mini-grid>div:last-child{grid-column:1 / -1;}
    .dash-selected-summary{display:grid;gap:8px;grid-template-columns:repeat(2,minmax(0,1fr));}
    .dash-selected-card{padding:11px 12px;border:2px solid rgba(140,98,93,.14);border-radius:16px;background:#fffdfb;display:grid;gap:4px;}
    .dash-selected-card span{font-size:.66rem;letter-spacing:.1em;text-transform:uppercase;color:#8a6d79;}
    .dash-selected-card strong{font-size:1rem;color:#644953;}
    #dashScreen .dash-stage-button{min-height:62px;border-radius:16px;font-size:.92rem;background:#fffdfb;}
    #dashScreen .dash-stage-button.selected{background:#fff0f7;}
    #dashScreen .dash-hud>span{padding:7px 5px;border-radius:12px;background:#fffdfb;}
    #dashScreen .dash-garage-wrap{gap:9px;}
    #dashScreen .dash-garage{gap:9px;}
    #dashScreen .dash-cart-card{border-radius:16px;background:#fffdfb;}
    #dashScreen .dash-overlay-card small{line-height:1.45;}
    .dash-playbox{gap:10px;}
    .dash-compact-note{margin:0;text-align:center;color:#7d6571;font-size:.73rem;line-height:1.35;}
    @media(max-width:560px){
      .quest-border-color-grid{grid-template-columns:repeat(4,minmax(0,1fr));}
      .dash-title-actions{display:grid;grid-template-columns:1fr;align-items:stretch;}
      .dash-selected-summary{grid-template-columns:1fr;}
      #dashScreen .dq-mini-grid{grid-template-columns:repeat(2,minmax(0,1fr));}
      #dashScreen .dq-mini-grid>div:last-child{grid-column:1 / -1;}
    }
  `;
  document.head.appendChild(patchCss);

  function renderCombinedBorderPicker(){
    normalizeIconBorderStyleUnlocks();
    normalizeIconBorderColorUnlocks();
    if(!ui.iconBorderPicker || !ui.heroSpriteWrap) return;
    const hero=activeHeroProgress();
    const unlockedStyles=new Set(questSave.iconBorderStylesUnlocked);
    const unlockedColors=new Set(questSave.iconBorderColorsUnlocked);
    if(!unlockedStyles.has(hero.iconBorderStyle)) hero.iconBorderStyle='none';
    if(!unlockedColors.has(hero.iconBorderColor)) hero.iconBorderColor='white';
    const selectedStyle=iconBorderStyleById(hero.iconBorderStyle);
    const selectedColor=iconBorderColorById(hero.iconBorderColor);
    if(ui.iconBorderCurrent) applyIconBorderPreviewStyle(ui.iconBorderCurrent,selectedStyle,selectedColor);
    if(ui.iconBorderLabel) ui.iconBorderLabel.textContent=`${selectedStyle.label} · ${selectedColor.label}`;
    applyQuestIconBorder(ui.heroSpriteWrap,activeCharacterId);

    ui.iconBorderPicker.classList.add('quest-border-combo-picker');
    ui.iconBorderPicker.innerHTML='';

    const styleSection=document.createElement('div');
    styleSection.className='quest-border-combo-section';
    styleSection.innerHTML='<span class="quest-border-combo-label">Border</span>';
    const styleGrid=document.createElement('div');
    styleGrid.className='quest-border-style-grid';
    for(const style of ICON_BORDER_STYLES){
      const isUnlocked=unlockedStyles.has(style.id);
      const button=document.createElement('button');
      button.type='button';
      button.className=`quest-border-style-choice${isUnlocked?'':' locked'}`;
      button.setAttribute('aria-current',String(hero.iconBorderStyle===style.id));
      button.setAttribute('aria-label',`${style.label}${isUnlocked?'':', locked'}`);
      const preview=document.createElement('span');
      preview.className='quest-border-style-preview';
      applyIconBorderPreviewStyle(preview,style,selectedColor);
      const label=document.createElement('span');
      label.className='quest-border-style-label';
      label.textContent=style.id==='none'?'None':style.label.replace(/\s+Border$/i,'');
      button.append(preview,label);
      if(!isUnlocked){
        const lock=document.createElement('span');
        lock.className='icon-background-lock';
        lock.textContent='🔒';
        button.append(lock);
      }
      button.addEventListener('click',()=>{
        if(!isUnlocked) return;
        setIconBorderStyle(style.id);
      });
      styleGrid.append(button);
    }
    styleSection.append(styleGrid);

    const colorSection=document.createElement('div');
    colorSection.className='quest-border-combo-section';
    colorSection.innerHTML='<span class="quest-border-combo-label">Color</span>';
    const colorGrid=document.createElement('div');
    colorGrid.className='quest-border-color-grid';
    for(const color of ICON_BORDER_COLORS){
      const isUnlocked=unlockedColors.has(color.id);
      const button=document.createElement('button');
      button.type='button';
      button.className=`icon-background-choice${isUnlocked?'':' locked'}`;
      button.setAttribute('aria-current',String(hero.iconBorderColor===color.id));
      button.setAttribute('aria-label',`${color.label}${isUnlocked?'':', locked'}`);
      button.title=color.label;
      const dot=document.createElement('span');
      dot.className='icon-background-dot';
      dot.style.background=color.value;
      button.append(dot);
      if(!isUnlocked){
        const lock=document.createElement('span');
        lock.className='icon-background-lock';
        lock.textContent='🔒';
        button.append(lock);
      }
      button.addEventListener('click',()=>{
        if(!isUnlocked) return;
        setIconBorderColor(color.id);
      });
      colorGrid.append(button);
    }
    colorSection.append(colorGrid);
    ui.iconBorderPicker.append(styleSection,colorSection);
  }
  renderIconBorderPicker=renderCombinedBorderPicker;
  renderIconBorderColorPicker=function(){ renderCombinedBorderPicker(); };

  const originalSetIconBorderStyle=setIconBorderStyle;
  setIconBorderStyle=function(styleId){ originalSetIconBorderStyle(styleId); renderCombinedBorderPicker(); };
  const originalSetIconBorderColor=setIconBorderColor;
  setIconBorderColor=function(colorId){ originalSetIconBorderColor(colorId); renderCombinedBorderPicker(); };
  requestAnimationFrame(renderCombinedBorderPicker);

  function hideCharmHeadingExtras(){
    document.querySelector('#backFromCharms')?.remove();
    document.querySelector('#charmCoinCount')?.remove();
  }
  hideCharmHeadingExtras();

  function activeScreenId(){
    const screens=['homeScreen','charmScreen','buddyScreen','dashScreen','hatcheryScreen','battleScreen','resultScreen'];
    return screens.find(id=>{const el=document.getElementById(id);return el && !el.classList.contains('hidden');}) || 'homeScreen';
  }
  function installContextBackButton(){
    const oldButton=document.querySelector('#backGames');
    if(!oldButton) return;
    const fresh=oldButton.cloneNode(true);
    oldButton.replaceWith(fresh);
    fresh.addEventListener('click',()=>{
      const current=activeScreenId();
      if(current==='homeScreen'){
        window.location.href='../#games';
        return;
      }
      if(['dashScreen','hatcheryScreen','charmScreen','buddyScreen'].includes(current)){
        showScreen('home');
        renderMeta();
        return;
      }
      if(current==='resultScreen' || current==='battleScreen'){
        returnHome();
        return;
      }
      showScreen('home');
    });
  }
  installContextBackButton();

  function prepareChestEncounter(kind, styleId, introText){
    currentEnemy=null;
    ui.enemyCombatant.classList.add('hidden');
    ui.enemyCombatant2?.classList.add('hidden');
    ui.commandGrid.classList.add('hidden');
    closeCommandWindow();
    const variant=mimicVariantById(styleId);
    showChest({kind, revealMimic:Math.random()<variant.revealChance, mimicChestStyle:styleId});
    setMessage(introText);
  }

  const originalBuildEncounterFromPool=buildEncounterFromPool;
  buildEncounterFromPool=function(enemyPool,mode='stage'){
    if(Math.random()<MYSTERY_CHEST_RATE) return {type:'mystery-chest'};
    const roll=Math.random();
    if(mode==='endless'){
      if(roll<.05) return {type:'healthy-chest'};
      if(roll<.13) return {type:'rare-chest'};
      if(roll<.18) return {type:'mimic'};
      if(roll<.28) return {type:'double-enemy',enemyIds:pickEncounterEnemies(ENDLESS_NORMAL_ENEMIES,2),waveIndex:0,defeatedEnemies:[]};
      if(roll<.36) return {type:pickSituationType('endless')};
      return {type:'enemy',enemyId:pickEncounterEnemy(ENDLESS_NORMAL_ENEMIES)};
    }
    if(roll<.04) return {type:'healthy-chest'};
    if(roll<.12) return {type:'rare-chest'};
    if(roll<.17) return {type:'mimic'};
    if(roll<.25) return {type:'double-enemy',enemyIds:pickEncounterEnemies(enemyPool,2),waveIndex:0,defeatedEnemies:[]};
    if(roll<.33) return {type:pickSituationType('stage')};
    return {type:'enemy',enemyId:pickEncounterEnemy(enemyPool)};
  };

  const originalStartEncounter=startEncounter;
  startEncounter=function(){
    const isEndless=currentRun?.mode==='endless';
    const encounter=isEndless ? currentRun?.endlessEncounter : currentRun?.plan?.[currentRun?.index];
    if(encounter?.type==='healthy-chest'){
      // mirror the same prep steps the normal encounter loader uses.
      buddyUsedThisHeroTurn=false;
      activeBattleBuddySlot=firstAssignedBattleBuddySlot();
      buddySwitchUsedThisEncounter=false;
      renderBattleCharmStrip();
      resetDoubleBattleUi();
      hideEventChoices();
      ui.enemyCombatant2?.classList.add('hidden');
      ui.chestLayer.classList.add('hidden');
      ui.postFloorActions?.classList.add('hidden');
      ui.leaveEndlessButton?.classList.add('hidden');
      setPostFloorLayout(false);
      ui.commandGrid.classList.remove('hidden');
      closeCommandWindow();
      ui.enemyCombatant.classList.remove('hidden');
      ui.buddyCombatant?.classList.add('hidden');
      if(isEndless){
        currentRun.rank=endlessEffectiveRank(currentRun.floor);
        if(!currentRun.floorBackground) currentRun.floorBackground=chooseEndlessBackground();
        setQuestSpriteFrame(ui.battleBg,currentRun.floorBackground);
        const oceanish=String(currentRun.floorBackground).includes('/ocean/');
        ui.battlefield.classList.toggle('ocean-peep-raised',oceanish && !String(currentRun.floorBackground).includes('/floor.'));
      }else{
        const cfg=currentAreaConfig();
        setQuestSpriteFrame(ui.battleBg,cfg.backgrounds[currentRun.index]);
        ui.battlefield.classList.toggle('ocean-peep-raised', currentRun.area==='ocean' && (currentRun.index===1 || currentRun.index===2));
      }
      updateEncounterHeader(encounter);
      ui.peepLevelCombat.textContent=`Lv. ${activeHeroProgress().level}`;
      renderPeepHp();
      startPeepIdle();
      prepareChestEncounter('healthy','healthy','A healthy green chest appeared! It may hide extra Jump Tokens.');
      return;
    }
    if(encounter?.type==='rare-chest'){
      buddyUsedThisHeroTurn=false;
      activeBattleBuddySlot=firstAssignedBattleBuddySlot();
      buddySwitchUsedThisEncounter=false;
      renderBattleCharmStrip();
      resetDoubleBattleUi();
      hideEventChoices();
      ui.enemyCombatant2?.classList.add('hidden');
      ui.chestLayer.classList.add('hidden');
      ui.postFloorActions?.classList.add('hidden');
      ui.leaveEndlessButton?.classList.add('hidden');
      setPostFloorLayout(false);
      ui.commandGrid.classList.remove('hidden');
      closeCommandWindow();
      ui.enemyCombatant.classList.remove('hidden');
      ui.buddyCombatant?.classList.add('hidden');
      if(isEndless){
        currentRun.rank=endlessEffectiveRank(currentRun.floor);
        if(!currentRun.floorBackground) currentRun.floorBackground=chooseEndlessBackground();
        setQuestSpriteFrame(ui.battleBg,currentRun.floorBackground);
        const oceanish=String(currentRun.floorBackground).includes('/ocean/');
        ui.battlefield.classList.toggle('ocean-peep-raised',oceanish && !String(currentRun.floorBackground).includes('/floor.'));
      }else{
        const cfg=currentAreaConfig();
        setQuestSpriteFrame(ui.battleBg,cfg.backgrounds[currentRun.index]);
        ui.battlefield.classList.toggle('ocean-peep-raised', currentRun.area==='ocean' && (currentRun.index===1 || currentRun.index===2));
      }
      updateEncounterHeader(encounter);
      ui.peepLevelCombat.textContent=`Lv. ${activeHeroProgress().level}`;
      renderPeepHp();
      startPeepIdle();
      prepareChestEncounter('rare','lucky','A lucky gold chest appeared instead of an enemy!');
      return;
    }
    return originalStartEncounter();
  };

  const originalShowChest=showChest;
  showChest=function(data){
    // v24.199: clear stale Merchant markup directly here. The merchant helper
    // lives in an earlier IIFE and is not in scope in this enhancement block.
    // Calling it here caused a ReferenceError after ordinary enemy defeats,
    // leaving the game stuck on “___ was defeated!” before the chest appeared.
    if(data?.eventType!=='mysterious-merchant'){
      ui.chestLayer?.classList.remove('merchant-active-v197');
      ui.chestLayer?.querySelector('#merchantShopV197')?.remove();
    }
    originalShowChest(data);
    const variant=chestVariantFor(data||{});
    if(!ui?.chestSprite) return;
    if(!(data?.eventType)){
      ui.chestSprite.src=variant.disguiseClosed;
      ui.chestSprite.alt=variant.label;
    }
    if(data?.mystery){
      ui.chestCaption.textContent='A strange purple chest appeared...';
    }else if(data?.kind==='healthy'){
      ui.chestCaption.textContent=data.captionText || 'A healthy chest appeared!';
    }else if(data?.kind==='rare'){
      ui.chestCaption.textContent=data.captionText || 'A lucky gold chest appeared!';
    }
  };

  const originalStartEnemy=startEnemy;
  startEnemy=function(enemyId,options={}){
    originalStartEnemy(enemyId,options);
    if(enemyId!=='mimic' || !currentEnemy || options.forceShiny) return;
    const variant=mimicVariantById(options.mimicChestStyle || currentEnemy.mimicChestStyle || 'regular');
    currentEnemy.name=variant.mimicName || currentEnemy.name;
    currentEnemy.idle=[...variant.mimicIdle];
    currentEnemy.hurt=variant.mimicHurt;
    currentEnemy.mimicChestStyle=variant.id;
    if(variant.id==='lucky'){
      currentEnemy.coinMinNow+=8;
      currentEnemy.coinMaxNow+=14;
      currentEnemy.expNow+=4;
    }else if(variant.id==='healthy'){
      currentEnemy.coinMinNow+=5;
      currentEnemy.coinMaxNow+=8;
      currentEnemy.expNow+=6;
    }
    renderEnemyCombatant(currentEnemy,currentEnemy._doubleSlot||0);
    startEnemyIdle();
    renderEnemyName(currentEnemy);
    setMessage(`${currentEnemy.name} sprang out of the ${variant.accent.toLowerCase()} chest!`);
  };

  const originalGenerateRewards=generateRewards;
  generateRewards=function(chest){
    if(chest?.kind==='healthy'){
      const rank=Math.max(1,Number(currentRun?.rank)||1);
      const items=[];
      addRewardItem(items,JUMP_TOKEN_ITEM,randInt(2,4));
      if(Math.random()<.55) addRewardItem(items,weightedRewardItemByIds(['apple','flower','glitter','mint-paint','aqua-paint']),1);
      const rewards=finalizeCharmRewards({
        coins:randInt(16,28)+Math.max(1,Math.round(rank*0.85)),
        exp:randInt(8,14)+Math.max(1,Math.round(rank*0.6)),
        happiness:3,
        items,
        iconBackground:Math.random()<.12?pickChestIconBackground({kind:'rare'}):null,
        iconBorderStyle:null,
        iconBorderColor:Math.random()<.16?pickChestIconBorderColor({kind:'rare'}):null,
        wallpaper:null
      },chest);
      return rewards;
    }
    const rewards=originalGenerateRewards(chest);
    if(chest?.enemy?.id==='mimic' && chest.enemy.mimicChestStyle==='healthy'){
      addRewardItem(rewards.items,JUMP_TOKEN_ITEM,randInt(1,2));
    }
    if(chest?.enemy?.id==='mimic' && chest.enemy.mimicChestStyle==='lucky'){
      rewards.coins=Math.max(0,Number(rewards.coins)||0)+randInt(10,16);
    }
    return rewards;
  };

  openPendingChest=async function(){
    if(!pendingChest || ui.chestLayer.classList.contains('hidden')) return;

    // v24.185: once a chest has paid out, the same button becomes Continue.
    // Advance exactly once instead of reopening the same chest and rolling rewards again.
    if(pendingChest.opened){
      const finishedChest=pendingChest;
      pendingChest=null;
      ui.openChest.disabled=true;
      ui.openChest.textContent='Open';
      actionLocked=false;
      nextEncounter();
      return;
    }

    if(ui.openChest.disabled) return;
    actionLocked=true;
    ui.openChest.disabled=true;
    ui.chestSprite.classList.remove('opening');
    await sleep(260);
    const chestVariant=chestVariantFor(pendingChest);

    if(pendingChest.eventType){
      if(pendingChest.eventType==='lucky-picnic') ui.chestSprite.src='assets/events/Picnic.png';
      else if(pendingChest.eventType==='wishing-fountain') ui.chestSprite.src='assets/events/Fountain.png';
      await sleep(140);
      const choiceName=eventChoiceLabel(pendingChest.eventType,pendingChest.eventChoice);
      setMessage(pendingChest.eventType==='lucky-picnic'
        ? `${choiceName}! The picnic turned into a lovely little break.`
        : `${choiceName}! The Wishing Fountain sparkles...`);
    } else if(pendingChest.mystery){
      ui.chestSprite.src=MIMIC_CHEST_VARIANTS.amethyst.disguiseOpen;
      await sleep(180);
      const isAmethystMimic=Math.random()<AMETHYST_MIMIC_RATE;
      if(isAmethystMimic){
        ui.chestCaption.textContent='Oh no... it moved!';
        setMessage('The purple chest was an Amethyst Mimic ✨!');
        await sleep(420);
        ui.chestLayer.classList.add('hidden');
        actionLocked=false;
        startEnemy('mimic',{forceShiny:true,mimicChestStyle:'amethyst'});
        return;
      }
      pendingChest={kind:'hidden-treasure',hiddenTreasure:true,revealMimic:false,mimicChestStyle:'amethyst'};
      ui.chestCaption.textContent='Hidden Treasure! JACKPOT!';
      setMessage('Hidden Treasure! You found a huge jackpot!');
    } else if(pendingChest.revealMimic){
      ui.chestSprite.src=chestVariant.disguiseOpen;
      await sleep(140);
      ui.chestLayer.classList.add('hidden');
      actionLocked=false;
      startEnemy('mimic',{mimicChestStyle:pendingChest.mimicChestStyle || chestVariant.id});
      return;
    } else {
      ui.chestSprite.src=chestVariant.disguiseOpen;
    }

    const rewards=generateRewards(pendingChest);
    applyRewards(rewards);

    const textParts=[];
    if(rewards.coins) textParts.push(`+${rewards.coins} Pink Coins`);
    if(rewards.exp) textParts.push(`+${rewards.exp} EXP`);
    if(rewards.happiness) textParts.push(`♡ +${rewards.happiness} Happiness`);
    else if(rewards.happinessMaxed) textParts.push('♡ Happiness MAX');
    if(rewards.unlockedBackgrounds?.length) textParts.push(rewards.unlockedBackgrounds.map(bg=>`${bg.label} Icon`).join(', '));
    if(rewards.iconBorderStyle) textParts.push(`${rewards.iconBorderStyle.label}`);
    if(rewards.iconBorderColor) textParts.push(`${rewards.iconBorderColor.label} Border Color`);
    if(rewards.items.length) textParts.push(rewards.items.map(x=>`${x.name} ×${x.qty}`).join(', '));
    if(rewards.charmTreasureBonus) textParts.push('Treasure Charm bonus!');
    if(rewards.unlockedWallpapers?.length) textParts.push(rewards.unlockedWallpapers.map(x=>`${x.label} Wallpaper`).join(', '));
    if(rewards.unlockedClosetRewards?.length) textParts.push(rewards.unlockedClosetRewards.map(x=>x.name).join(', '));
    if(rewards.unlockedUiThemes?.length) textParts.push(rewards.unlockedUiThemes.map(x=>`${x.label} Theme`).join(', '));
    setMessage(textParts.length ? `Rewards: ${textParts.join(' · ')}` : 'The chest was empty.');
    ui.openChest.textContent='Continue';
    ui.openChest.disabled=false;
    pendingChest.opened=true;
    actionLocked=false;
  };

  function rebindOpenChestButton(){
    const oldButton=document.querySelector('#openChest');
    if(!oldButton) return;
    const fresh=oldButton.cloneNode(true);
    oldButton.replaceWith(fresh);
    if(ui) ui.openChest=fresh;
    fresh.addEventListener('click',openPendingChest);
  }
  rebindOpenChestButton();

  function updateDashSelectedSummary(){
    const cartLabel=document.querySelector('#dashCartLabel');
    const compactCart=document.querySelector('#dashSelectedCartName');
    if(compactCart && cartLabel) compactCart.textContent=cartLabel.textContent || 'Default Cart';
    const oc=document.querySelector('#dashSelectedOcName');
    if(oc) oc.textContent=heroDisplayName();
    const titleCart=document.querySelector('#dashStartInline');
    if(titleCart) titleCart.textContent='Play Duckie Dash';
  }

  function polishDashScreen(){
    const screen=document.querySelector('#dashScreen');
    if(!screen) return;
    const top=screen.querySelector('.dq-feature-top');
    const titleCol=top?.querySelector('div');
    const small=titleCol?.querySelector('small');
    if(small) small.remove();
    if(titleCol && !screen.querySelector('#dashTitleActions')){
      const actions=document.createElement('div');
      actions.id='dashTitleActions';
      actions.className='dash-title-actions';
      actions.innerHTML=`<span class="dash-title-cost">Cost 3 Tokens <img src="assets/dash/Jump-Token.png" alt=""></span><button id="dashStartInline" class="pixel-button primary" type="button">Play Duckie Dash</button>`;
      titleCol.append(actions);
      actions.querySelector('#dashStartInline')?.addEventListener('click',()=>window.DUCKIE_DASH_API_V269?.start?.());
    }
    const mini=screen.querySelector('.dq-mini-grid');
    const cartTile=mini?.querySelector('div:last-child');
    if(cartTile){
      const strong=cartTile.querySelector('strong');
      const span=cartTile.querySelector('span');
      if(span) span.textContent='Selected Cart';
      if(strong) strong.id='dashCartLabel';
    }
    if(mini && !screen.querySelector('#dashSelectedSummary')){
      const summary=document.createElement('div');
      summary.id='dashSelectedSummary';
      summary.className='dash-selected-summary';
      summary.innerHTML=`<div class="dash-selected-card"><span>Selected Cart</span><strong id="dashSelectedCartName">Default Cart</strong></div><div class="dash-selected-card"><span>Selected OC</span><strong id="dashSelectedOcName">Peep</strong></div>`;
      mini.after(summary);
    }
    const playbox=screen.querySelector('.dash-playbox');
    const note=screen.querySelector('.dash-tap-note');
    if(note){
      note.classList.add('dash-compact-note');
      note.textContent='Tap anywhere on the course to jump.';
    }
    const overlaySmall=screen.querySelector('#dashOverlay small');
    if(overlaySmall) overlaySmall.textContent='Use 3 Jump Tokens to run. Free Runs are spent first if you have one.';
    updateDashSelectedSummary();
  }
  polishDashScreen();

  const originalRefreshFeatureBadges=refreshFeatureBadges;
  refreshFeatureBadges=function(){
    originalRefreshFeatureBadges();
    updateDashSelectedSummary();
  };

  const originalRenderDashSelectors=renderDashSelectors;
  renderDashSelectors=function(){
    originalRenderDashSelectors();
    updateDashSelectedSummary();
  };

  const originalShowScreen2=showScreen;
  showScreen=function(which){
    originalShowScreen2(which);
    hideCharmHeadingExtras();
    if(which==='dash'){
      polishDashScreen();
      updateDashSelectedSummary();
    }
    if(which==='home') requestAnimationFrame(renderCombinedBorderPicker);
  };
})();


// v24.172 — robust Hatching Area viewport sizing (mobile/PWA safe)
(function(){
  const hatchFixStyle=document.createElement('style');
  hatchFixStyle.textContent=`
    #hatcheryScreen.hatchery-fit-screen{
      display:block!important;
      box-sizing:border-box!important;
      height:var(--hatch-screen-height,calc(100dvh - 64px))!important;
      min-height:var(--hatch-screen-height,calc(100dvh - 64px))!important;
      max-height:var(--hatch-screen-height,calc(100dvh - 64px))!important;
      overflow:hidden!important;
      padding:0!important;
    }
    #hatcheryScreen.hatchery-fit-screen .hatch-world-shell{
      display:block!important;
      box-sizing:border-box!important;
      width:100%!important;
      height:var(--hatch-world-height,calc(100dvh - 64px))!important;
      min-height:var(--hatch-world-height,calc(100dvh - 64px))!important;
      max-height:var(--hatch-world-height,calc(100dvh - 64px))!important;
      padding:0!important;
      margin:0!important;
    }
    #hatcheryScreen.hatchery-fit-screen .hatch-world{
      display:block!important;
      box-sizing:border-box!important;
      width:100%!important;
      max-width:none!important;
      height:var(--hatch-world-height,calc(100dvh - 64px))!important;
      min-height:var(--hatch-world-height,calc(100dvh - 64px))!important;
      max-height:var(--hatch-world-height,calc(100dvh - 64px))!important;
      aspect-ratio:auto!important;
      margin:0!important;
      background:#9ee78f!important;
    }
    @media(max-width:600px){
      #hatcheryScreen.hatchery-fit-screen .hatch-world{
        border-left:0!important;
        border-right:0!important;
        border-radius:0!important;
      }
    }
  `;
  document.head.appendChild(hatchFixStyle);

  function fitHatcheryRobustly(){
    const screen=document.querySelector('#hatcheryScreen');
    if(!screen || screen.classList.contains('hidden')) return;
    screen.classList.add('hatchery-fit-screen');

    const vv=window.visualViewport;
    const viewportHeight=Math.max(1,Math.floor(vv?.height || document.documentElement.clientHeight || window.innerHeight || 0));
    const rect=screen.getBoundingClientRect();
    const visualTop=Math.max(0,Number(vv?.offsetTop)||0);
    const screenTop=Math.max(0,Math.floor(rect.top-visualTop));
    let available=Math.floor(viewportHeight-screenTop);
    if(!Number.isFinite(available) || available<320) available=viewportHeight;
    available=Math.max(320,available);

    const px=`${available}px`;
    screen.style.setProperty('--hatch-screen-height',px);
    screen.style.setProperty('--hatch-world-height',px);
    const shell=screen.querySelector('.hatch-world-shell');
    const world=screen.querySelector('.hatch-world');
    if(shell){shell.style.height=px;shell.style.minHeight=px;shell.style.maxHeight=px;}
    if(world){world.style.height=px;world.style.minHeight=px;world.style.maxHeight=px;}
  }

  function scheduleHatchFit(){
    requestAnimationFrame(()=>requestAnimationFrame(fitHatcheryRobustly));
    setTimeout(fitHatcheryRobustly,80);
    setTimeout(fitHatcheryRobustly,220);
  }

  const previousShowScreenV172=showScreen;
  showScreen=function(which){
    previousShowScreenV172(which);
    if(which==='hatchery') scheduleHatchFit();
  };

  window.addEventListener('resize',scheduleHatchFit,{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(scheduleHatchFit,120),{passive:true});
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize',scheduleHatchFit,{passive:true});
    window.visualViewport.addEventListener('scroll',scheduleHatchFit,{passive:true});
  }
})();


// v24.173 — final Duck Quest home layout + hatchery hard recovery
(function(){
  function makeHomeCharmIcon(){
    try{
      const def=CHARM_DEFS?.['fortune-gold'];
      if(def) return charmArtMarkup(def,'tiny').replace('charm-art family-','charm-art home-charm-icon family-');
    }catch(error){}
    return '<img class="home-charm-icon" src="assets/charms/Charm-outline.png" alt="">';
  }

  function finalizeQuestHomeLayout(){
    const home=document.querySelector('#homeScreen');
    const heroInfo=home?.querySelector('.hero-info');
    const charmCard=home?.querySelector('.charm-home-card');
    const charmButton=document.querySelector('#openCharmScreen');
    const hatchButton=document.querySelector('#openHatchery');
    if(!home||!heroInfo||!charmCard||!charmButton||!hatchButton) return;
    home.classList.add('dq-home-polished');

    let tools=heroInfo.querySelector(':scope > .dq-hero-tools');
    if(!tools){
      tools=document.querySelector('.dq-hero-tools') || document.createElement('div');
      tools.className='dq-hero-tools';
      heroInfo.appendChild(tools);
    }else if(tools.parentElement!==heroInfo){
      heroInfo.appendChild(tools);
    }

    if(charmCard.parentElement!==tools) tools.appendChild(charmCard);
    if(hatchButton.parentElement!==tools) tools.appendChild(hatchButton);

    charmButton.innerHTML=`${makeHomeCharmIcon()}<span>Equip Charm</span>`;
    hatchButton.classList.remove('primary');
    hatchButton.innerHTML=`<img class="home-hatch-icon" src="assets/eggs/Common-egg.png" alt=""><span class="home-hatch-label">Hatching Area</span><span id="hatchReadyBadge"></span>`;

    // Rebuild the condensed Duckie Dash home line requested earlier.
    const dash=document.querySelector('#duckieDashHomeCard');
    const headCopy=dash?.querySelector('.dq-expand-head > div');
    const play=document.querySelector('#openDuckieDash');
    let cost=dash?.querySelector('.dash-home-cost');
    if(dash&&headCopy&&play){
      dash.querySelector('.dq-expand-head small')?.remove();
      if(!cost){
        cost=document.createElement('span');
        cost.className='dash-home-cost';
        cost.innerHTML=`Cost: 3 Tokens <img src="assets/dash/Jump-Token.png" alt="">`;
      }
      let inline=headCopy.querySelector('.dash-home-inline-actions');
      if(!inline){
        inline=document.createElement('div');
        inline.className='dash-home-inline-actions';
        headCopy.appendChild(inline);
      }
      if(cost.parentElement!==inline) inline.appendChild(cost);
      if(play.parentElement!==inline) inline.appendChild(play);
      const leftover=dash.querySelector('.dq-expand-actions');
      if(leftover && !leftover.children.length) leftover.remove();
    }
  }

  function positionHatcherySolidly(){
    const screen=document.querySelector('#hatcheryScreen');
    if(!screen || screen.classList.contains('hidden')) return;
    screen.classList.add('hatchery-solid-screen');
    const header=document.querySelector('.quest-header');
    const headerRect=header?.getBoundingClientRect();
    const top=Math.max(0,Math.round(headerRect?.bottom || 78));
    screen.style.setProperty('--hatch-fixed-top',`${top}px`);
    // Strip old explicit height values; fixed top+bottom now owns the geometry.
    screen.style.removeProperty('--hatch-screen-height');
    screen.style.removeProperty('--hatch-world-height');
    const shell=screen.querySelector('.hatch-world-shell');
    const world=screen.querySelector('.hatch-world');
    for(const el of [screen,shell,world]){
      if(!el) continue;
      el.style.removeProperty('height');
      el.style.removeProperty('min-height');
      el.style.removeProperty('max-height');
    }
    // Ensure the actual repo background is restored if a stale DOM instance lost it.
    const bg=screen.querySelector('.hatch-world-bg');
    if(bg && !String(bg.getAttribute('src')||'').includes('Hatching-background-new.png')){
      bg.src='assets/eggs/Hatching-background-new.png';
    }
  }

  function scheduleSolidHatch(){
    requestAnimationFrame(()=>requestAnimationFrame(positionHatcherySolidly));
    setTimeout(positionHatcherySolidly,80);
  }

  finalizeQuestHomeLayout();

  const previousShowScreenV173=showScreen;
  showScreen=function(which){
    previousShowScreenV173(which);
    if(which==='home') requestAnimationFrame(finalizeQuestHomeLayout);
    if(which==='hatchery') scheduleSolidHatch();
  };

  window.addEventListener('resize',()=>{
    if(!document.querySelector('#hatcheryScreen')?.classList.contains('hidden')) scheduleSolidHatch();
  },{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(scheduleSolidHatch,120),{passive:true});
})();

// v24.174 — verified recovery installer build marker


// v24.176 — authoritative Duck Quest home tools + hatchery recovery
(function(){
  const finalStyle=document.createElement('style');
  finalStyle.id='duckie-v24-176-final-style';
  finalStyle.textContent=`
    /* Home tools are intentionally a single vertical stack. */
    #homeScreen.dq-home-polished .hero-info > .quest-home-tools,
    #homeScreen .hero-info > .quest-home-tools{
      width:100%!important;
      display:grid!important;
      grid-template-columns:minmax(0,1fr)!important;
      gap:8px!important;
      margin:2px 0 0!important;
      padding:0!important;
      order:10!important;
    }
    #homeScreen .quest-home-tools .quest-home-tool-button{
      width:100%!important;
      min-width:0!important;
      min-height:52px!important;
      margin:0!important;
      padding:7px 12px!important;
      display:flex!important;
      align-items:center!important;
      justify-content:center!important;
      gap:9px!important;
      border:3px solid var(--border,#8c625d)!important;
      border-radius:13px!important;
      background:#fff6df!important;
      color:var(--brown,#6f4a45)!important;
      box-shadow:var(--shadow)!important;
      text-shadow:none!important;
      font-size:.76rem!important;
    }
    #homeScreen .quest-home-tools #openHatchery.primary,
    #homeScreen .quest-home-tools #openCharmScreen.primary{background:#fff6df!important;color:var(--brown,#6f4a45)!important;}
    #homeScreen .quest-home-tools .home-charm-icon{
      width:31px!important;height:34px!important;object-fit:contain!important;image-rendering:pixelated!important;flex:0 0 31px!important;
    }
    #homeScreen .quest-home-tools .home-hatch-icon{
      width:30px!important;height:30px!important;object-fit:contain!important;image-rendering:pixelated!important;flex:0 0 30px!important;
    }
    #homeScreen .quest-home-tools .home-hatch-label{color:inherit!important;font-size:inherit!important;}
    #homeScreen > .charm-home-card,#homeScreen .dq-hero-tools{display:none!important;}

    /* Duckie Dash home: no summary; cost and play sit directly below title. */
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head{align-items:flex-start!important;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head>div{padding-left:0!important;width:100%!important;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head small{display:none!important;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dq-expand-head>.dq-token-pill{align-self:start!important;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dash-home-inline-actions{
      margin-top:7px!important;display:grid!important;grid-template-columns:auto minmax(145px,1fr)!important;gap:9px!important;align-items:center!important;
    }
    #homeScreen.dq-home-polished #duckieDashHomeCard .dash-home-inline-actions .dash-home-cost{margin:0!important;}
    #homeScreen.dq-home-polished #duckieDashHomeCard .dash-home-inline-actions #openDuckieDash{
      width:100%!important;min-height:42px!important;padding:7px 12px!important;flex:none!important;
    }
    #dashScreen #dashBack{display:none!important;}

    /* Hatchery: last-wins rules override all older viewport experiments. */
    body.hatchery-active{overflow:hidden!important;}
    #hatcheryScreen.hatchery-v175:not(.hidden){
      position:fixed!important;
      z-index:1000!important;
      top:var(--hatch-v175-top,70px)!important;
      right:0!important;
      bottom:0!important;
      left:0!important;
      width:100vw!important;
      height:auto!important;
      min-height:0!important;
      max-height:none!important;
      margin:0!important;
      padding:0!important;
      display:block!important;
      overflow:hidden!important;
      transform:none!important;
      background:#d9eef9!important;
    }
    #hatcheryScreen.hatchery-v175 .hatch-world-shell{
      position:absolute!important;inset:0!important;width:100%!important;height:100%!important;min-height:0!important;max-height:none!important;
      margin:0!important;padding:0!important;display:block!important;overflow:hidden!important;
    }
    #hatcheryScreen.hatchery-v175 .hatch-world{
      position:absolute!important;inset:0!important;width:100%!important;height:100%!important;min-height:0!important;max-height:none!important;max-width:none!important;
      margin:0!important;padding:0!important;display:block!important;overflow:hidden!important;aspect-ratio:auto!important;
      border:4px solid var(--border,#8c625d)!important;border-radius:0!important;box-shadow:none!important;
      background-color:#9ee78f!important;
      background-image:url('assets/eggs/Hatching-background-new.png')!important;
      background-position:center center!important;
      background-repeat:no-repeat!important;
      background-size:100% 100%!important;
      isolation:isolate!important;
    }
    #hatcheryScreen.hatchery-v175 .hatch-world-bg{display:none!important;}
    #hatcheryScreen.hatchery-v175 .hatch-world-topbar{z-index:12!important;padding-top:9px!important;}
    #hatcheryScreen.hatchery-v175 .hatch-nest-slots{position:absolute!important;inset:0!important;z-index:4!important;}
    #hatcheryScreen.hatchery-v175 .hatch-nest-slot{width:44%!important;height:18%!important;}
    #hatcheryScreen.hatchery-v175 .hatch-nest-slot:nth-child(1){top:37%!important;}
    #hatcheryScreen.hatchery-v175 .hatch-nest-slot:nth-child(2){top:63%!important;}
    #hatcheryScreen.hatchery-v175 .hatch-nest-slot:nth-child(3){top:88%!important;}
    #hatcheryScreen.hatchery-v175 .hatch-main-egg{width:70%!important;height:70%!important;}
    #hatcheryScreen.hatchery-v175 .hatch-slot-status{top:80%!important;}
    #hatcheryScreen.hatchery-v175 .hatch-world-tip{display:none!important;}

    #charmScreen .charm-book-heading{grid-template-columns:minmax(0,1fr)!important;}
    #charmScreen #backFromCharms,#charmScreen #charmCoinCount{display:none!important;}

    @media(max-width:600px){
      #homeScreen .quest-home-tools{gap:7px!important;}
      #homeScreen .quest-home-tools .quest-home-tool-button{min-height:48px!important;padding:5px 8px!important;font-size:.62rem!important;}
      #homeScreen .quest-home-tools .home-charm-icon{width:28px!important;height:31px!important;flex-basis:28px!important;}
      #homeScreen .quest-home-tools .home-hatch-icon{width:26px!important;height:26px!important;flex-basis:26px!important;}
      #homeScreen.dq-home-polished #duckieDashHomeCard .dash-home-inline-actions{grid-template-columns:1fr!important;gap:6px!important;}
      #homeScreen.dq-home-polished #duckieDashHomeCard .dash-home-inline-actions .dash-home-cost{justify-self:start!important;}
    }
  `;
  document.head.appendChild(finalStyle);

  function enforceQuestHomeV175(){
    const home=document.querySelector('#homeScreen');
    const heroInfo=home?.querySelector('.hero-info');
    const tools=document.querySelector('#questHomeTools');
    const charmButton=document.querySelector('#openCharmScreen');
    const hatchButton=document.querySelector('#openHatchery');
    if(home) home.classList.add('dq-home-polished');
    if(heroInfo&&tools&&tools.parentElement!==heroInfo) heroInfo.appendChild(tools);
    if(tools&&charmButton&&charmButton.parentElement!==tools) tools.appendChild(charmButton);
    if(tools&&hatchButton&&hatchButton.parentElement!==tools) tools.appendChild(hatchButton);
    if(charmButton){
      charmButton.classList.remove('primary');
      charmButton.innerHTML='<img class="home-charm-icon" src="assets/charms/Fortune-green-charm.png" alt=""><span>Equip Charm</span>';
    }
    if(hatchButton){
      hatchButton.classList.remove('primary');
      hatchButton.innerHTML='<img class="home-hatch-icon" src="assets/eggs/Common-egg.png" alt=""><span class="home-hatch-label">Hatching Area</span><span id="hatchReadyBadge"></span>';
    }

    const dash=document.querySelector('#duckieDashHomeCard');
    const titleCol=dash?.querySelector('.dq-expand-head > div');
    const play=document.querySelector('#openDuckieDash');
    if(dash&&titleCol&&play){
      dash.querySelector('.dq-expand-head small')?.remove();
      let cost=dash.querySelector('.dash-home-cost');
      if(!cost){
        cost=document.createElement('span');
        cost.className='dash-home-cost';
        cost.innerHTML='Cost: 3 Tokens <img src="assets/dash/Jump-Token.png" alt="">';
      }
      let row=titleCol.querySelector('.dash-home-inline-actions');
      if(!row){row=document.createElement('div');row.className='dash-home-inline-actions';titleCol.appendChild(row);}
      if(cost.parentElement!==row) row.appendChild(cost);
      if(play.parentElement!==row) row.appendChild(play);
      dash.querySelector('.dq-expand-actions')?.remove();
    }
  }

  function enforceHatcheryV175(){
    const screen=document.querySelector('#hatcheryScreen');
    if(!screen || screen.classList.contains('hidden')) return;
    document.body.classList.add('hatchery-active');
    screen.classList.add('hatchery-v175');
    const header=document.querySelector('.quest-header');
    const bottom=Math.max(0,Math.round(header?.getBoundingClientRect().bottom || 70));
    screen.style.setProperty('--hatch-v175-top',`${bottom}px`);
    screen.style.removeProperty('--hatch-screen-height');
    screen.style.removeProperty('--hatch-world-height');
    for(const el of [screen,screen.querySelector('.hatch-world-shell'),screen.querySelector('.hatch-world')]){
      if(!el) continue;
      el.style.removeProperty('height');
      el.style.removeProperty('min-height');
      el.style.removeProperty('max-height');
    }
    const world=screen.querySelector('.hatch-world');
    if(world) world.style.setProperty('background-image',"url('assets/eggs/Hatching-background-new.png')",'important');
    renderHatchery?.();
  }

  function scheduleV175Hatch(){
    requestAnimationFrame(()=>requestAnimationFrame(enforceHatcheryV175));
    setTimeout(enforceHatcheryV175,60);
    setTimeout(enforceHatcheryV175,180);
  }

  enforceQuestHomeV175();
  const previousShowScreenV175=showScreen;
  showScreen=function(which){
    previousShowScreenV175(which);
    document.body.classList.toggle('hatchery-active',which==='hatchery');
    if(which==='home') requestAnimationFrame(enforceQuestHomeV175);
    if(which==='hatchery') scheduleV175Hatch();
  };
  window.addEventListener('resize',()=>{
    if(!document.querySelector('#hatcheryScreen')?.classList.contains('hidden')) scheduleV175Hatch();
  },{passive:true});
})();


// v24.176 — compact home tools + hard hatchery canvas recovery
(function(){
  const HATCH_BG_V176='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAFACAYAAAAVuVaJAAAAAXNSR0IArs4c6QAAAKJlWElmTU0AKgAAAAgABgEGAAMAAAABAAIAAAENAAIAAAARAAAAVgEaAAUAAAABAAAAaAEbAAUAAAABAAAAcAEoAAMAAAABAAIAAIdpAAQAAAABAAAAeAAAAABVbnRpdGxlZCBBcnR3b3JrAAAAAAu4AAAAAQAAC7gAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAALSgAwAEAAAAAQAAAUAAAAAA3pzFJQAAAAlwSFlzAAHNXgABzV4BuHKTWgAAA/FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIKICAgICAgICAgICAgeG1sbnM6SXB0YzR4bXBFeHQ9Imh0dHA6Ly9pcHRjLm9yZy9zdGQvSXB0YzR4bXBFeHQvMjAwOC0wMi0yOS8iPgogICAgICAgICA8dGlmZjpEb2N1bWVudE5hbWU+VW50aXRsZWQgQXJ0d29yazwvdGlmZjpEb2N1bWVudE5hbWU+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOkNvbXByZXNzaW9uPjU8L3RpZmY6Q29tcHJlc3Npb24+CiAgICAgICAgIDx0aWZmOlhSZXNvbHV0aW9uPjMwMDA8L3RpZmY6WFJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlBob3RvbWV0cmljSW50ZXJwcmV0YXRpb24+MjwvdGlmZjpQaG90b21ldHJpY0ludGVycHJldGF0aW9uPgogICAgICAgICA8dGlmZjpZUmVzb2x1dGlvbj4zMDAwPC90aWZmOllSZXNvbHV0aW9uPgogICAgICAgICA8ZGM6dGl0bGU+CiAgICAgICAgICAgIDxyZGY6QWx0PgogICAgICAgICAgICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPlVudGl0bGVkIEFydHdvcms8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6QWx0PgogICAgICAgICA8L2RjOnRpdGxlPgogICAgICAgICA8SXB0YzR4bXBFeHQ6QXJ0d29ya1RpdGxlPlVudGl0bGVkIEFydHdvcms8L0lwdGM0eG1wRXh0OkFydHdvcmtUaXRsZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cj008gQAABWkSURBVHgB7Z2/jhzHEcZn7/ZInmlZpAIZCgQlCggwceDYMAzrFZQIcOqL/CAK5eSUGlAi6A1oG4YTJw6cECBsJYICwYIgygbkE3nHW2/tsXi1fT0z3TPd01Xd3xLk9L+prv7qN7U9s3vH1UeP/rvp8IIClShwUMk6sAwosFMAQAOEqhQA0FWFE4sB0GCgKgUAdFXhxGIANBioSgEAXVU4sZh1bRKc/Dp+Sad/vKhNhmbXEx99ZVJNAdhdgmsDgLsK2ambBdqFMKXkbBtgp1R1GVvmgGbYlpCH5wLYS6idZg5TN4UMWJqlh1uheUvNHe4lRpICZoDWAJQGH4DtsALqgdaWHQH1MFCle1UDrRUerX6VhknD/Gutm46TX+m+XyWoT/+M59caIJY+qM7Q0lGNZe0XnUbNcvukEmiAkjvs9dpXB7Q1mK35Wy/KVysb3aiGBizFfjJ0rtqDgvVNV8AL9BSw+JwUYE9fTpkzae0trruM2sOzrj760/5PfTOYw6eN98YGONW8457lGxG75lBPYrXJ5UeovyXHvcrQsaKNOU32QoVNPfeYbxb652gizw2NgQVNQnzcPYc++eUrrkPOCR6zg/ovDT2rnXmLnSMODPdpI3FYPd/8L/svmhkSM0cQg6+4DAOH1uqbbun1x/rn81lz28ycEra0pYMW5lX5USV0KTHnkkovAnTfgmoXd2jdJddecu4+TVK1LwZ0zSLKYAytk/qG+qWd3GUtfqRe52JAp3bckj1NIEvdaoR6kZtCKSLflNQoprtOK2vkmEj/rZaRoTNFzgrMmZZfzOziGbrYSjHxoAKnf63j8wJk6MEwt9N58os8H64trSCAXlpxzJdVAQCdVV4YX1oBAL204pgvqwIAOqu8tozXsI8G0LaYg7cjCgDoEYHQbUuBOp7V2NJct7dHut0b8w4Zekwh9JtSAECbCldeZ0//Zv/TQgCdlxFYX1gBAL2w4JgurwIAOq++ZqzXsN0gsQG0GeTgaIgCADpEpcrH1JKdKUx4Dl05rGPLO/379smG8WfPco0AWqqBshkFTn7uR9ffamZZcHSOArvsPMfAguf2Aey6AKBdRRqpW4A5FGIZMgAt1WigXCvIHDoAzUo0cNQO85SM7IYNQLuKVFrXDHMKkDlsAJqVqPSoGWSSPCXMZA9AkwqVvk7/sX3GrDjCJz9L71x6i5XCYWlZO5CVO5wDZloygFYe+Bj3LIBM68kFM9kG0KSC8ZcVkJeQGUAvoXKmOSyCnDM7k8wAOhNsucxahDiXFj67ANqnirK2WiDOnZ0pbABaGbzsTi0Q83qWOgLopZQemef0sfMT1xV9R3lk6Um7AXRSOcON3QA4/FSMHFAAQA+Ik6oL8KZSctzOekzsk4dgfkzGMQ3Hzkd/OgVGac0RLK0XSY61pgsVLIUoMAp0iJHYMQAnVjGMD1UAv8YgVCmMm63AEokMQM8OEwxoUmDdHWpyB77UrsDpk4vu5EG+nS4ydO0EKVwfQZ3rBaBzKQu7gwrkghpAD8qOzpwKENSpwQbQOSMG20EKpIQ63+48aCkYBAWuFJBQz7lpBNAgSp0CEm5yLgZwAK0unHDIVSAG8PXqYOOejzoUUK3Ax/887/UPN4W90qDDogIA2mLU4HOvAgC6Vxp0WFQAQFuMGnzuVQBA90qDDosKAGiLUYPPvQoA6F5p0GFRgTX+L1mLYYPPfQogQ/cpg3aTCgBok2GD030KAOg+ZdBuUgF8OSkgbL/590feUX/46e+87WgspwCAdrTvg9cZlqQ6NBculmkSA+itbkNgDck69bwhmzF9ffO3fDGsfv+v/zT5/dE+GGKA0jy2VairzNC1w6r5QirtWxDQb93/eOfnV09/m9zflLYBcvLwLGIwJQOvHtux0bEV0LjQsSG25Jg5tgGzVHK/zPGS+sry/ujptVQ2pZ2+cp+XuwxNJ8kX1d1s7NbleLfs2qN+Op/bZdk9l+o8TvbFzC/Pa73s01Jqwv1D+soxfWVpc6xMNsYYCLHBY6StNTvInXx02/vq0hidOyQM2/YdXfshY3juqXP65qiljd+xHt2/fWNJPq25jTXlk6Zo69ry2eAxPA8d3TZZ7yu7560+++ZDs085WHw+vvfkmdQHZUeBRw9uwu0MuVFlbd0O2S7L7ril66aBZrEAMisxfpwC9bhVPSOCnnLocXffE4C8r0dIjTWrFWyzQHNgQoI4Nubsi8djQxbpP37n4SLz0CSkX41QmwQ6BcxaIJYEh/iUEvoaoTYFdK0gS6jHyqmhZ01rydavPlgZExL9dSvAYFtfpSmgU2SRlG/Z1oPv+l8D1KaApgAAahfDm/WQbcnNs65aJNRff//VjWHU5mu/MbBQgzmgpeCFNKt+WqmxZnh9gTAFtBTat5iQNspeczJYyBylx6TaVr15963dUixBbeYpRwqYS4O21Px8waYCW/rNkMs2TWWVQHNGIPGo/MGXbyTTjIPMQU9m2LihvnsT7QC7sqsE2nUyR53BJts1wS3XFaMbvQP2QR1jp/RYE3voT97+NqtOBIH8m3WyjManwswu1bCtU5mheavBQl+97ZX9auhcWHgtMUffO0duP6xnapVAU9B578bHT98927Hw/ufHMUxMGpsbmlCnpB8+uEPtxI57evFdd399L/Y0FeNNbDmkUgy2bGuhTHBLwHOumZIGQW3xZQ5oiyJb9Nkq1OaAXmLLYRFA+HylgDmgEbhlFbC29QDQy/JhZjar9yrmgLYqtBWSSV9XY0tZWu1juyEAWHDsp4dUCu9jPcPP0DvSDND0XNTNFDGBAPw3IYzR7+bZOltMbTmsPuzXGfquq/EiNwU0gQGotV4eOvwys+WQcvm2H7LfV5ZvrzVmJt+aU7VZSiImgaZATYGaAyzh5jZ5nAp8n92p9qRPseU+X2LtWBtvFmgSmjOHe7O4VBBCoaFxY1C7tsbG0xrdc5Zat+Z5qvhljSRwaqglUKXBkb4wTEv5xEmD59V+rAZoFjo12Gy3xeOqW3X31q+bWrrpLYdPac4oANunzljbqlt3h936YN2tV+vuaPvX2suex4EKA+wwoQ66gy24Rzt4CWTKypZf1QLNQQHYrMT18XCbhY8OjrpbW5APV4fXHRWUqgeaY8RgU72F7YhcL2vQwrEZoGUwZbD1w73abgq2f1a0GVh1Pz68K5eCsqNAk0BLDSTc1J4TcALyCs6DHZw7RLeg8uv44A4XcZyoQPNAu7q5gLv9fcC7oN49/JF7KuoLKACgI0UeAz7SHIYnVsDEt+3o99vx77vj9fvauA/HdhUwAXS74cHKYxUwATT/9iQ3S8cuFuPrV8DMHpqhliHxtcl+lPMowIlFo/4mMrQvLBrF9PlZexvDrWWdZoHWIiD80KUAgNYVj+LebLrNqA+a3x3N7KFHVcaAyQpcbC66i82L7d+L4I/WGWo+Tp488YkAOrGgFsxddpfd+eVFd74530FMWfnqA6PbFtwf9BFAD8pTT+eLbQZ+vgX4/PK8e7H9I181ffrZJNB8Z85vl1Tnsgx0TWX63vMx/a38C1BNAq0dVNoCXG52/25Lm91PlGj3WYt/TQJN2ZiyMmfqnMG4gpN2rZfdZgvp9l8x3aa748mY9LXSw93XSvEQSogVVGwSaFKGtxhzoCY4L7d7UzoSrLcPbt0Q/QpO+qGn7Y86XX/1+cY4NKRRoFmgWT4Gm+sxR/qa/gH/ZDRgjZEu21i8p2WTFoZLKACgS6iOObMpAKCzSQvDJRQA0CVUx5zZFADQ2aTNa3ipx455V5HeOoBOr2l2i/yocc4TmuxOFpoAQBcSfmhaN/sywHSOLA/ZaLUPQBuJvAsysrM/cADar0vRVobVhZicoj7uL+qk0smb/6RQaVz2oAXA4VFChg7XCiMNKACgDQQJLoYrAKDDtcJIAwqYAdq9QaK622ZAb7iYWQEzQJMOADgzDRPNu3Fx6xPNTjrNFNB9KyQBS4rY51dL7Vr0NwM0P7pyhXPrLUGkba0aYmEG6LHgMfBj49CfXgGpfWmoTX2wIoWT5fQhgsVYBbTEo5oMHRsAjK9TAQBdZ1ybXRWAbjb0dS4cQNcZ12ZXBaCbDX2dCzf1lKPOEFyv6r0nz64rovTogf1fcyuWk7UIoCPl7YOOzOQCzzdnrrki5VA3vEmgfYCkALLPbo6oy7kA97XCq8+++VD+OszrnkpLEoQal9g63E1m6BpB5jWFXLA1Q4+nHExCQ0eCPgR8i5IAaItRS+RzjVAD6ERwwIwOBZrZQ9eYjXQgpMuLqoEGxMOw1XhzWO2WAzAPw0y9pFFtOlWXoWsL0DiW80ewZjVk7KqA5sDMD3GYhbMvHocNzDzq+J2HSWYg/axDXQ3QqWHWAmsIqdLXuXBbh9o80FNAlgCEAGNpDK9tDtisqcVsbfqmkIW3BBx8zauAWaABcz8Yc7IzW7WYncl3k0DPgZnfkjlwtR1bhtkk0HNgrg3eXOuxrLHJDD0nkCky2Jz5c59L70Ap3oWsQt0U0KmCnRtKLfYtQm3usd2n757txfv9z4/36q1XUr8DEdSWbhBNAf304rs9XmNhlsFO8ba850zBilxXQTdUTG0KaKlYLMzyXCoTBFahXhJgS9mZ4moS6Lkw08LpNQSGD/ah8VcW0//r8yP9LPVYNAn0kvKXgFiur9T8r+5VLs66++t70iXVZTNA8/45VXYei0opkMb8WqL/FcwvJyPtrUBt6rHdUjAvAQ3myKOAGaCtZIg8YVrWquXEYQboZUOK2VwFeMvntmurmwLa3dtpExP+lFfAFNAkF0ENsPOCY1lfM085KIS0j+a3Pim65T1fXjTjrEtN487UM9oU0CSbhJpl5EAAbFbk+sjaXLfUXTK35egLB2DuU6atdpNA4xFeW5DGrNbcloMX59t6cF/rx9a2GTLeZoGmRXCmphvF0CCW2Jr0+TbVlz57MrCtlk0DzUGTYHNb33EIhhDA3PPHznHHS7/cvjFb8tyly6zx0vPGzlft/7HCj/diBfFB5YIXa3PueOlTCV8Ou8PuJ+vX5i5jkfOrBdpVbyrgrp226qvttu51U0uuYssRorj7lqkFcNevkLWkGDO0/lW36u5FgPz191/tXHrz7lspXJtloxmgXZV8IA0F2T0/pO6bI+S8JcZM9U0TvD6dmgXaJ8bUIPtstdKmDXCTH6y0AgvWGa8AgI7XrOkz3H0y1d22kgIB6JLqG51bE8CuhADaVQR10woAaNPhg/OuAgDaVQR10woAaNPhg/OuAgDaVQT1RRWg59j8LJsmduuxzjQP9KbbxGqG8QsqEAt480DT9xbwKqcAPwKUWZq98bVxX98RH333KYP2Igow4HJyX5vsl2UALdVAuYgCfcD2tQ852fyWY0gc9NlTwCzQsTcL9kIDj6coYBZod7Eu4G7dHY96nQqYBZr3V3wnzPU6w4RVhSpgFuihBQLyIXXq7jP9lMPNym697tBhdT4FTAPtWxC1Aew+Zepvr3LLUX/YsMI+BQB0nzJoN6kAgDYZNjjdpwCA7lMG7SYVANAmwwan+xQA0H3KGG1v/RNSAG0QXP7gyHW9r90dV3MdQBuNrpuJJcwtP4cH0AaBHgJ2qC92qe5Fw+f3tXN/yWOVnxSWFHSpuV1w3XouP+Q7Ac/BbUv5wPP6jsjQPlXQNqoAw8swj56w0AC1GZqEckXj+kLaND+NT2/ZJmGW7SWFUws0iSKhliJpFFL610pZC8RSb9NbDo2CSnFRXl4BtRl6DNax/uWlxIwaFDCZoQGzBnR0+qA2Q0u5ALBUA+UhBUxm6KEFoa9tBQB02/GvbvUAurqQtr0gAN12/KtbvYmbQg2qv/fkmdeNRw9ue9vRWEYBAO3RvQ9ez9DZTUNz4WKJlxdAv9RsCKwhWaeeN2Qzpq9v/lYvhtVn33zY7P/J0AdDDFCax7YIdbUZunZYNV9IJX2rDmiAXBKn8nNX9dgOMJcHqrQHVQFdWkzMX14BAF0+Btk8oHes1t61qnvK0VoAY6+G2p98VJOhW8xGsTDT+NovePNPOWoP0BRox85hzWrM1qaB5sCMBTCk/+yLxyHDso85fudh9jl4AtKvNqjNAp0CZi0QM2B0DPEpJfS1QW0O6FpBllCPlVNDz5rWkK2ruSkcgwD94wow2OMj9Y4wB3SKLJLyLVtvaKd5Zh1qE0DTb0ri35ZEx0/e/nZatMRZtUMdsi0RcuwVLUNtAmj31xh88OUbewFAJb0CVqE2c1PIUKeAeU72So9OHou1vwP1qWYiQ7PzVrMG+7/kkS7aFi5cV1MzGTolzJy9Wgy4C4Csp7jhlvZKlM0AnUMcBpts1wS3XFeMbpQ0rENt6tt2KbP0WKCtAj4VZqmHZaibztAyiCHlFLCEzCPH+C6s3H5YztSmgKbM8fTiu+79z49lzLOUc0MT6rT0wwd3qJ1Wxpl6ykEw0+vTd89aic/eOgluCfheZ+LK2PbustP52y/MAM0wJ44bzA0oMAT188vnA2eW6zIDtJRoiS2HnA/lmwoA6JuaoMWoAs83592L7R+NL5MZWqOQNfrU9/juhxc/qF2uSaBbvSlciiLSt09j2mpQdr6/vreUO1HzmHpsJ1fGgmM/LVWZXmY9pQW6EZfgbrZPNs4u9WZn8t0s0Cy8LxDc5x4Bv6tI3CPQHy6fdZfbPxLymxbLtqjdcrzY6LzpKBuu9LOPXeT8uJRuBI8P7qiGmdRRC/Th6nAvepqzwp6jlVUOXiJya3VkYmXmtxwxKsvtyVhmirFb89gjIyBzDEwBTVma3wJ5AVOPEm6fjanA99mdas/nW2hbny+h59O42we3YoYXH2sKaFIrJdQp1A+FhsaNQe3aGhtP/rvnpFgT26Ds7G79uE/r0dT3oV0RU2Vr1y7XJVA5weH5ho7SFx6X26efHL42CjT/ND7/zCf7VupoLkNLoUKy9fmzq2/mHd2++sop1bksbfnKuYHxzdnXtrQvt1a3vDBrA9jVyzTQtBj59CN3xnbFq7W+6la7R3QW16f2sd0UMQluCbi0QZmZs7Vs11D2+SZ9leUl/L2zfd58sPKjwVsLytQas7X5DO0L8B7UW8hZeN9YtO0rcLTdatw5CPvvnhnufQtla1UC7UrKwjPYe8C7g1/Wl9y+0J6es7S7v18uO6+2726v96ix38x67rfqqDUBNEsdE4gQ6Nlu7DHkYnHBjp0jbHw4xGH2yo9qCujycl954L1Y+r6O2dMeclHQbN65tAiRwQ8AnUHUJUy2Bmqopv5b2dCzMQ4KKFMAQCsLCNyZpwCAnqcfzlamAIBWFhC4M08BAD1PP5ytTAEArSwgpd2RH2mX9mXK/AB6imqec/hTSE+XuqZYaC2trRqgY4MUQ5kb0JxzxfiVeqy7TrLva0s9b0p7/wc3asud5ikDEAAAAABJRU5ErkJggg==';

  const style=document.createElement('style');
  style.id='duckie-v24-176-final-style';
  style.textContent=`
    /* Compact, equal-size vertical home tools. */
    #homeScreen .hero-info > .quest-home-tools{
      width:min(100%,180px)!important;
      max-width:180px!important;
      justify-self:center!important;
      align-self:start!important;
      display:grid!important;
      grid-template-columns:1fr!important;
      gap:6px!important;
      margin:3px auto 0!important;
      padding:0!important;
    }
    #homeScreen .quest-home-tools .quest-home-tool-button{
      box-sizing:border-box!important;
      width:180px!important;
      max-width:100%!important;
      min-width:0!important;
      height:48px!important;
      min-height:48px!important;
      max-height:48px!important;
      margin:0!important;
      padding:4px 9px!important;
      display:flex!important;
      align-items:center!important;
      justify-content:center!important;
      gap:7px!important;
      border:3px solid var(--border,#8c625d)!important;
      border-radius:11px!important;
      background:#fff6df!important;
      color:var(--brown,#6f4a45)!important;
      box-shadow:0 4px 0 rgba(102,67,61,.20)!important;
      text-shadow:none!important;
      font-size:.61rem!important;
      line-height:1!important;
      white-space:nowrap!important;
    }
    #homeScreen .quest-home-tools .home-charm-icon,
    #homeScreen .quest-home-tools .home-hatch-icon{
      display:block!important;
      width:22px!important;
      height:22px!important;
      min-width:22px!important;
      max-width:22px!important;
      max-height:22px!important;
      flex:0 0 22px!important;
      object-fit:contain!important;
      image-rendering:pixelated!important;
      filter:none!important;
    }
    #homeScreen .quest-home-tools .home-hatch-label{font-size:inherit!important;color:inherit!important;}
    #homeScreen .quest-home-tools #hatchReadyBadge:empty{display:none!important;}

    /* v24.176 hatchery: fixed dimensions + visible art layer. */
    body.hatchery-active{overflow:hidden!important;}
    #hatcheryScreen.hatchery-v176:not(.hidden){
      box-sizing:border-box!important;
      position:fixed!important;
      z-index:1000!important;
      left:0!important;
      right:auto!important;
      bottom:auto!important;
      margin:0!important;
      padding:0!important;
      overflow:hidden!important;
      display:block!important;
      transform:none!important;
      background-position:center!important;
      background-repeat:no-repeat!important;
      background-size:cover!important;
    }
    #hatcheryScreen.hatchery-v176 .hatch-world-shell{
      box-sizing:border-box!important;
      position:absolute!important;
      inset:0!important;
      margin:0!important;
      padding:0!important;
      overflow:hidden!important;
      display:block!important;
    }
    #hatcheryScreen.hatchery-v176 .hatch-world{
      box-sizing:border-box!important;
      position:absolute!important;
      inset:0!important;
      margin:0!important;
      padding:0!important;
      overflow:hidden!important;
      display:block!important;
      max-width:none!important;
      max-height:none!important;
      aspect-ratio:auto!important;
      border:4px solid var(--border,#8c625d)!important;
      border-radius:0!important;
      box-shadow:none!important;
      background-position:center!important;
      background-repeat:no-repeat!important;
      background-size:cover!important;
      isolation:isolate!important;
    }
    #hatcheryScreen.hatchery-v176 .hatch-world-bg{
      display:block!important;
      visibility:visible!important;
      opacity:1!important;
      position:absolute!important;
      inset:0!important;
      z-index:0!important;
      width:100%!important;
      height:100%!important;
      min-width:100%!important;
      min-height:100%!important;
      max-width:none!important;
      max-height:none!important;
      object-fit:cover!important;
      object-position:center center!important;
      image-rendering:pixelated!important;
      pointer-events:none!important;
    }
    #hatcheryScreen.hatchery-v176 .hatch-world-topbar{
      display:grid!important;
      visibility:visible!important;
      opacity:1!important;
      z-index:30!important;
    }
    #hatcheryScreen.hatchery-v176 .hatch-nest-slots{
      display:block!important;
      visibility:visible!important;
      opacity:1!important;
      position:absolute!important;
      inset:0!important;
      z-index:10!important;
    }
    #hatcheryScreen.hatchery-v176 .hatch-nest-slot{width:44%!important;height:19%!important;}
    #hatcheryScreen.hatchery-v176 .hatch-nest-slot:nth-child(1){top:32.5%!important;}
    #hatcheryScreen.hatchery-v176 .hatch-nest-slot:nth-child(2){top:63.5%!important;}
    #hatcheryScreen.hatchery-v176 .hatch-nest-slot:nth-child(3){top:89%!important;}
    #hatcheryScreen.hatchery-v176 .hatch-world-tip{display:none!important;}

    @media(max-width:600px){
      #homeScreen .hero-info > .quest-home-tools{width:min(100%,170px)!important;max-width:170px!important;}
      #homeScreen .quest-home-tools .quest-home-tool-button{width:170px!important;height:46px!important;min-height:46px!important;max-height:46px!important;font-size:.58rem!important;padding:4px 7px!important;}
      #homeScreen .quest-home-tools .home-charm-icon,
      #homeScreen .quest-home-tools .home-hatch-icon{width:21px!important;height:21px!important;min-width:21px!important;max-width:21px!important;max-height:21px!important;flex-basis:21px!important;}
    }
  `;
  document.head.appendChild(style);

  function forceCompactToolsV176(){
    const tools=document.querySelector('#questHomeTools');
    const charm=document.querySelector('#openCharmScreen');
    const hatch=document.querySelector('#openHatchery');
    if(!tools||!charm||!hatch) return;
    const heroInfo=document.querySelector('#homeScreen .hero-info');
    if(heroInfo&&tools.parentElement!==heroInfo) heroInfo.appendChild(tools);
    charm.classList.remove('primary');
    hatch.classList.remove('primary');
    charm.innerHTML='<img class="home-charm-icon" src="assets/charms/Fortune-green-charm.png" alt=""><span>Equip Charm</span>';
    hatch.innerHTML='<img class="home-hatch-icon" src="assets/eggs/Common-egg.png" alt=""><span class="home-hatch-label">Hatching Area</span><span id="hatchReadyBadge"></span>';
  }

  function setImportant(el,name,value){if(el) el.style.setProperty(name,value,'important');}

  function forceHatcheryV176(){
    const screen=document.querySelector('#hatcheryScreen');
    if(!screen||screen.classList.contains('hidden')) return;
    document.body.classList.add('hatchery-active');
    screen.classList.add('hatchery-v176');

    const vv=window.visualViewport;
    const viewportHeight=Math.max(320,Math.round(vv?.height||window.innerHeight||document.documentElement.clientHeight||720));
    const viewportWidth=Math.max(240,Math.round(vv?.width||window.innerWidth||document.documentElement.clientWidth||390));
    const header=document.querySelector('.quest-header');
    const visualTop=Math.max(0,Number(vv?.offsetTop)||0);
    const headerBottom=Math.max(0,Math.round((header?.getBoundingClientRect().bottom||70)-visualTop));
    const height=Math.max(320,viewportHeight-headerBottom);
    const top=Math.max(0,headerBottom);

    const shell=screen.querySelector('.hatch-world-shell');
    const world=screen.querySelector('.hatch-world');
    const bg=screen.querySelector('.hatch-world-bg');
    const topbar=screen.querySelector('.hatch-world-topbar');
    const slots=screen.querySelector('.hatch-nest-slots');

    setImportant(screen,'position','fixed');
    setImportant(screen,'top',`${top}px`);
    setImportant(screen,'left','0px');
    setImportant(screen,'right','auto');
    setImportant(screen,'bottom','auto');
    setImportant(screen,'width',`${viewportWidth}px`);
    setImportant(screen,'height',`${height}px`);
    setImportant(screen,'min-height',`${height}px`);
    setImportant(screen,'max-height',`${height}px`);
    setImportant(screen,'background-image',`url("${HATCH_BG_V176}")`);
    setImportant(screen,'background-size','cover');
    setImportant(screen,'background-position','center center');

    for(const el of [shell,world]){
      setImportant(el,'width',`${viewportWidth}px`);
      setImportant(el,'height',`${height}px`);
      setImportant(el,'min-height',`${height}px`);
      setImportant(el,'max-height',`${height}px`);
    }
    setImportant(world,'background-image',`url("${HATCH_BG_V176}")`);
    setImportant(world,'background-size','cover');
    setImportant(world,'background-position','center center');

    if(bg){
      bg.src=HATCH_BG_V176;
      setImportant(bg,'display','block');
      setImportant(bg,'visibility','visible');
      setImportant(bg,'opacity','1');
      setImportant(bg,'width','100%');
      setImportant(bg,'height','100%');
      setImportant(bg,'object-fit','cover');
    }
    setImportant(topbar,'display','grid');
    setImportant(topbar,'visibility','visible');
    setImportant(topbar,'opacity','1');
    setImportant(slots,'display','block');
    setImportant(slots,'visibility','visible');
    setImportant(slots,'opacity','1');

    try{ renderHatchery?.(); }catch(error){ console.warn('v24.176 hatch render retry',error); }
  }

  function scheduleHatchV176(){
    requestAnimationFrame(()=>requestAnimationFrame(forceHatcheryV176));
    for(const delay of [40,100,180,280,500]) setTimeout(forceHatcheryV176,delay);
  }

  forceCompactToolsV176();
  const previousShowScreenV176=showScreen;
  showScreen=function(which){
    previousShowScreenV176(which);
    document.body.classList.toggle('hatchery-active',which==='hatchery');
    if(which==='home') requestAnimationFrame(forceCompactToolsV176);
    if(which==='hatchery') scheduleHatchV176();
  };

  const reflow=()=>{if(!document.querySelector('#hatcheryScreen')?.classList.contains('hidden')) scheduleHatchV176();};
  window.addEventListener('resize',reflow,{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(reflow,120),{passive:true});
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize',reflow,{passive:true});
    window.visualViewport.addEventListener('scroll',reflow,{passive:true});
  }
})();



// v24.177 — authoritative clean hatchery surface; no legacy geometry dependency
(function(){
  const HATCH_BG_V177='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAFACAYAAAAVuVaJAAAAAXNSR0IArs4c6QAAAKJlWElmTU0AKgAAAAgABgEGAAMAAAABAAIAAAENAAIAAAARAAAAVgEaAAUAAAABAAAAaAEbAAUAAAABAAAAcAEoAAMAAAABAAIAAIdpAAQAAAABAAAAeAAAAABVbnRpdGxlZCBBcnR3b3JrAAAAAAu4AAAAAQAAC7gAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAALSgAwAEAAAAAQAAAUAAAAAA3pzFJQAAAAlwSFlzAAHNXgABzV4BuHKTWgAAA/FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIKICAgICAgICAgICAgeG1sbnM6SXB0YzR4bXBFeHQ9Imh0dHA6Ly9pcHRjLm9yZy9zdGQvSXB0YzR4bXBFeHQvMjAwOC0wMi0yOS8iPgogICAgICAgICA8dGlmZjpEb2N1bWVudE5hbWU+VW50aXRsZWQgQXJ0d29yazwvdGlmZjpEb2N1bWVudE5hbWU+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOkNvbXByZXNzaW9uPjU8L3RpZmY6Q29tcHJlc3Npb24+CiAgICAgICAgIDx0aWZmOlhSZXNvbHV0aW9uPjMwMDA8L3RpZmY6WFJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlBob3RvbWV0cmljSW50ZXJwcmV0YXRpb24+MjwvdGlmZjpQaG90b21ldHJpY0ludGVycHJldGF0aW9uPgogICAgICAgICA8dGlmZjpZUmVzb2x1dGlvbj4zMDAwPC90aWZmOllSZXNvbHV0aW9uPgogICAgICAgICA8ZGM6dGl0bGU+CiAgICAgICAgICAgIDxyZGY6QWx0PgogICAgICAgICAgICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPlVudGl0bGVkIEFydHdvcms8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6QWx0PgogICAgICAgICA8L2RjOnRpdGxlPgogICAgICAgICA8SXB0YzR4bXBFeHQ6QXJ0d29ya1RpdGxlPlVudGl0bGVkIEFydHdvcms8L0lwdGM0eG1wRXh0OkFydHdvcmtUaXRsZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cj008gQAABWkSURBVHgB7Z2/jhzHEcZn7/ZInmlZpAIZCgQlCggwceDYMAzrFZQIcOqL/CAK5eSUGlAi6A1oG4YTJw6cECBsJYICwYIgygbkE3nHW2/tsXi1fT0z3TPd01Xd3xLk9L+prv7qN7U9s3vH1UeP/rvp8IIClShwUMk6sAwosFMAQAOEqhQA0FWFE4sB0GCgKgUAdFXhxGIANBioSgEAXVU4sZh1bRKc/Dp+Sad/vKhNhmbXEx99ZVJNAdhdgmsDgLsK2ambBdqFMKXkbBtgp1R1GVvmgGbYlpCH5wLYS6idZg5TN4UMWJqlh1uheUvNHe4lRpICZoDWAJQGH4DtsALqgdaWHQH1MFCle1UDrRUerX6VhknD/Gutm46TX+m+XyWoT/+M59caIJY+qM7Q0lGNZe0XnUbNcvukEmiAkjvs9dpXB7Q1mK35Wy/KVysb3aiGBizFfjJ0rtqDgvVNV8AL9BSw+JwUYE9fTpkzae0trruM2sOzrj760/5PfTOYw6eN98YGONW8457lGxG75lBPYrXJ5UeovyXHvcrQsaKNOU32QoVNPfeYbxb652gizw2NgQVNQnzcPYc++eUrrkPOCR6zg/ovDT2rnXmLnSMODPdpI3FYPd/8L/svmhkSM0cQg6+4DAOH1uqbbun1x/rn81lz28ycEra0pYMW5lX5USV0KTHnkkovAnTfgmoXd2jdJddecu4+TVK1LwZ0zSLKYAytk/qG+qWd3GUtfqRe52JAp3bckj1NIEvdaoR6kZtCKSLflNQoprtOK2vkmEj/rZaRoTNFzgrMmZZfzOziGbrYSjHxoAKnf63j8wJk6MEwt9N58os8H64trSCAXlpxzJdVAQCdVV4YX1oBAL204pgvqwIAOqu8tozXsI8G0LaYg7cjCgDoEYHQbUuBOp7V2NJct7dHut0b8w4Zekwh9JtSAECbCldeZ0//Zv/TQgCdlxFYX1gBAL2w4JgurwIAOq++ZqzXsN0gsQG0GeTgaIgCADpEpcrH1JKdKUx4Dl05rGPLO/379smG8WfPco0AWqqBshkFTn7uR9ffamZZcHSOArvsPMfAguf2Aey6AKBdRRqpW4A5FGIZMgAt1WigXCvIHDoAzUo0cNQO85SM7IYNQLuKVFrXDHMKkDlsAJqVqPSoGWSSPCXMZA9AkwqVvk7/sX3GrDjCJz9L71x6i5XCYWlZO5CVO5wDZloygFYe+Bj3LIBM68kFM9kG0KSC8ZcVkJeQGUAvoXKmOSyCnDM7k8wAOhNsucxahDiXFj67ANqnirK2WiDOnZ0pbABaGbzsTi0Q83qWOgLopZQemef0sfMT1xV9R3lk6Um7AXRSOcON3QA4/FSMHFAAQA+Ik6oL8KZSctzOekzsk4dgfkzGMQ3Hzkd/OgVGac0RLK0XSY61pgsVLIUoMAp0iJHYMQAnVjGMD1UAv8YgVCmMm63AEokMQM8OEwxoUmDdHWpyB77UrsDpk4vu5EG+nS4ydO0EKVwfQZ3rBaBzKQu7gwrkghpAD8qOzpwKENSpwQbQOSMG20EKpIQ63+48aCkYBAWuFJBQz7lpBNAgSp0CEm5yLgZwAK0unHDIVSAG8PXqYOOejzoUUK3Ax/887/UPN4W90qDDogIA2mLU4HOvAgC6Vxp0WFQAQFuMGnzuVQBA90qDDosKAGiLUYPPvQoA6F5p0GFRgTX+L1mLYYPPfQogQ/cpg3aTCgBok2GD030KAOg+ZdBuUgF8OSkgbL/590feUX/46e+87WgspwCAdrTvg9cZlqQ6NBculmkSA+itbkNgDck69bwhmzF9ffO3fDGsfv+v/zT5/dE+GGKA0jy2VairzNC1w6r5QirtWxDQb93/eOfnV09/m9zflLYBcvLwLGIwJQOvHtux0bEV0LjQsSG25Jg5tgGzVHK/zPGS+sry/ujptVQ2pZ2+cp+XuwxNJ8kX1d1s7NbleLfs2qN+Op/bZdk9l+o8TvbFzC/Pa73s01Jqwv1D+soxfWVpc6xMNsYYCLHBY6StNTvInXx02/vq0hidOyQM2/YdXfshY3juqXP65qiljd+xHt2/fWNJPq25jTXlk6Zo69ry2eAxPA8d3TZZ7yu7560+++ZDs085WHw+vvfkmdQHZUeBRw9uwu0MuVFlbd0O2S7L7ril66aBZrEAMisxfpwC9bhVPSOCnnLocXffE4C8r0dIjTWrFWyzQHNgQoI4Nubsi8djQxbpP37n4SLz0CSkX41QmwQ6BcxaIJYEh/iUEvoaoTYFdK0gS6jHyqmhZ01rydavPlgZExL9dSvAYFtfpSmgU2SRlG/Z1oPv+l8D1KaApgAAahfDm/WQbcnNs65aJNRff//VjWHU5mu/MbBQgzmgpeCFNKt+WqmxZnh9gTAFtBTat5iQNspeczJYyBylx6TaVr15963dUixBbeYpRwqYS4O21Px8waYCW/rNkMs2TWWVQHNGIPGo/MGXbyTTjIPMQU9m2LihvnsT7QC7sqsE2nUyR53BJts1wS3XFaMbvQP2QR1jp/RYE3voT97+NqtOBIH8m3WyjManwswu1bCtU5mheavBQl+97ZX9auhcWHgtMUffO0duP6xnapVAU9B578bHT98927Hw/ufHMUxMGpsbmlCnpB8+uEPtxI57evFdd399L/Y0FeNNbDmkUgy2bGuhTHBLwHOumZIGQW3xZQ5oiyJb9Nkq1OaAXmLLYRFA+HylgDmgEbhlFbC29QDQy/JhZjar9yrmgLYqtBWSSV9XY0tZWu1juyEAWHDsp4dUCu9jPcPP0DvSDND0XNTNFDGBAPw3IYzR7+bZOltMbTmsPuzXGfquq/EiNwU0gQGotV4eOvwys+WQcvm2H7LfV5ZvrzVmJt+aU7VZSiImgaZATYGaAyzh5jZ5nAp8n92p9qRPseU+X2LtWBtvFmgSmjOHe7O4VBBCoaFxY1C7tsbG0xrdc5Zat+Z5qvhljSRwaqglUKXBkb4wTEv5xEmD59V+rAZoFjo12Gy3xeOqW3X31q+bWrrpLYdPac4oANunzljbqlt3h936YN2tV+vuaPvX2suex4EKA+wwoQ66gy24Rzt4CWTKypZf1QLNQQHYrMT18XCbhY8OjrpbW5APV4fXHRWUqgeaY8RgU72F7YhcL2vQwrEZoGUwZbD1w73abgq2f1a0GVh1Pz68K5eCsqNAk0BLDSTc1J4TcALyCs6DHZw7RLeg8uv44A4XcZyoQPNAu7q5gLv9fcC7oN49/JF7KuoLKACgI0UeAz7SHIYnVsDEt+3o99vx77vj9fvauA/HdhUwAXS74cHKYxUwATT/9iQ3S8cuFuPrV8DMHpqhliHxtcl+lPMowIlFo/4mMrQvLBrF9PlZexvDrWWdZoHWIiD80KUAgNYVj+LebLrNqA+a3x3N7KFHVcaAyQpcbC66i82L7d+L4I/WGWo+Tp488YkAOrGgFsxddpfd+eVFd74530FMWfnqA6PbFtwf9BFAD8pTT+eLbQZ+vgX4/PK8e7H9I181ffrZJNB8Z85vl1Tnsgx0TWX63vMx/a38C1BNAq0dVNoCXG52/25Lm91PlGj3WYt/TQJN2ZiyMmfqnMG4gpN2rZfdZgvp9l8x3aa748mY9LXSw93XSvEQSogVVGwSaFKGtxhzoCY4L7d7UzoSrLcPbt0Q/QpO+qGn7Y86XX/1+cY4NKRRoFmgWT4Gm+sxR/qa/gH/ZDRgjZEu21i8p2WTFoZLKACgS6iOObMpAKCzSQvDJRQA0CVUx5zZFADQ2aTNa3ipx455V5HeOoBOr2l2i/yocc4TmuxOFpoAQBcSfmhaN/sywHSOLA/ZaLUPQBuJvAsysrM/cADar0vRVobVhZicoj7uL+qk0smb/6RQaVz2oAXA4VFChg7XCiMNKACgDQQJLoYrAKDDtcJIAwqYAdq9QaK622ZAb7iYWQEzQJMOADgzDRPNu3Fx6xPNTjrNFNB9KyQBS4rY51dL7Vr0NwM0P7pyhXPrLUGkba0aYmEG6LHgMfBj49CfXgGpfWmoTX2wIoWT5fQhgsVYBbTEo5oMHRsAjK9TAQBdZ1ybXRWAbjb0dS4cQNcZ12ZXBaCbDX2dCzf1lKPOEFyv6r0nz64rovTogf1fcyuWk7UIoCPl7YOOzOQCzzdnrrki5VA3vEmgfYCkALLPbo6oy7kA97XCq8+++VD+OszrnkpLEoQal9g63E1m6BpB5jWFXLA1Q4+nHExCQ0eCPgR8i5IAaItRS+RzjVAD6ERwwIwOBZrZQ9eYjXQgpMuLqoEGxMOw1XhzWO2WAzAPw0y9pFFtOlWXoWsL0DiW80ewZjVk7KqA5sDMD3GYhbMvHocNzDzq+J2HSWYg/axDXQ3QqWHWAmsIqdLXuXBbh9o80FNAlgCEAGNpDK9tDtisqcVsbfqmkIW3BBx8zauAWaABcz8Yc7IzW7WYncl3k0DPgZnfkjlwtR1bhtkk0HNgrg3eXOuxrLHJDD0nkCky2Jz5c59L70Ap3oWsQt0U0KmCnRtKLfYtQm3usd2n757txfv9z4/36q1XUr8DEdSWbhBNAf304rs9XmNhlsFO8ba850zBilxXQTdUTG0KaKlYLMzyXCoTBFahXhJgS9mZ4moS6Lkw08LpNQSGD/ah8VcW0//r8yP9LPVYNAn0kvKXgFiur9T8r+5VLs66++t70iXVZTNA8/45VXYei0opkMb8WqL/FcwvJyPtrUBt6rHdUjAvAQ3myKOAGaCtZIg8YVrWquXEYQboZUOK2VwFeMvntmurmwLa3dtpExP+lFfAFNAkF0ENsPOCY1lfM085KIS0j+a3Pim65T1fXjTjrEtN487UM9oU0CSbhJpl5EAAbFbk+sjaXLfUXTK35egLB2DuU6atdpNA4xFeW5DGrNbcloMX59t6cF/rx9a2GTLeZoGmRXCmphvF0CCW2Jr0+TbVlz57MrCtlk0DzUGTYHNb33EIhhDA3PPHznHHS7/cvjFb8tyly6zx0vPGzlft/7HCj/diBfFB5YIXa3PueOlTCV8Ou8PuJ+vX5i5jkfOrBdpVbyrgrp226qvttu51U0uuYssRorj7lqkFcNevkLWkGDO0/lW36u5FgPz191/tXHrz7lspXJtloxmgXZV8IA0F2T0/pO6bI+S8JcZM9U0TvD6dmgXaJ8bUIPtstdKmDXCTH6y0AgvWGa8AgI7XrOkz3H0y1d22kgIB6JLqG51bE8CuhADaVQR10woAaNPhg/OuAgDaVQR10woAaNPhg/OuAgDaVQT1RRWg59j8LJsmduuxzjQP9KbbxGqG8QsqEAt480DT9xbwKqcAPwKUWZq98bVxX98RH333KYP2Igow4HJyX5vsl2UALdVAuYgCfcD2tQ852fyWY0gc9NlTwCzQsTcL9kIDj6coYBZod7Eu4G7dHY96nQqYBZr3V3wnzPU6w4RVhSpgFuihBQLyIXXq7jP9lMPNym697tBhdT4FTAPtWxC1Aew+Zepvr3LLUX/YsMI+BQB0nzJoN6kAgDYZNjjdpwCA7lMG7SYVANAmwwan+xQA0H3KGG1v/RNSAG0QXP7gyHW9r90dV3MdQBuNrpuJJcwtP4cH0AaBHgJ2qC92qe5Fw+f3tXN/yWOVnxSWFHSpuV1w3XouP+Q7Ac/BbUv5wPP6jsjQPlXQNqoAw8swj56w0AC1GZqEckXj+kLaND+NT2/ZJmGW7SWFUws0iSKhliJpFFL610pZC8RSb9NbDo2CSnFRXl4BtRl6DNax/uWlxIwaFDCZoQGzBnR0+qA2Q0u5ALBUA+UhBUxm6KEFoa9tBQB02/GvbvUAurqQtr0gAN12/KtbvYmbQg2qv/fkmdeNRw9ue9vRWEYBAO3RvQ9ez9DZTUNz4WKJlxdAv9RsCKwhWaeeN2Qzpq9v/lYvhtVn33zY7P/J0AdDDFCax7YIdbUZunZYNV9IJX2rDmiAXBKn8nNX9dgOMJcHqrQHVQFdWkzMX14BAF0+Btk8oHes1t61qnvK0VoAY6+G2p98VJOhW8xGsTDT+NovePNPOWoP0BRox85hzWrM1qaB5sCMBTCk/+yLxyHDso85fudh9jl4AtKvNqjNAp0CZi0QM2B0DPEpJfS1QW0O6FpBllCPlVNDz5rWkK2ruSkcgwD94wow2OMj9Y4wB3SKLJLyLVtvaKd5Zh1qE0DTb0ri35ZEx0/e/nZatMRZtUMdsi0RcuwVLUNtAmj31xh88OUbewFAJb0CVqE2c1PIUKeAeU72So9OHou1vwP1qWYiQ7PzVrMG+7/kkS7aFi5cV1MzGTolzJy9Wgy4C4Csp7jhlvZKlM0AnUMcBpts1wS3XFeMbpQ0rENt6tt2KbP0WKCtAj4VZqmHZaibztAyiCHlFLCEzCPH+C6s3H5YztSmgKbM8fTiu+79z49lzLOUc0MT6rT0wwd3qJ1Wxpl6ykEw0+vTd89aic/eOgluCfheZ+LK2PbustP52y/MAM0wJ44bzA0oMAT188vnA2eW6zIDtJRoiS2HnA/lmwoA6JuaoMWoAs83592L7R+NL5MZWqOQNfrU9/juhxc/qF2uSaBbvSlciiLSt09j2mpQdr6/vreUO1HzmHpsJ1fGgmM/LVWZXmY9pQW6EZfgbrZPNs4u9WZn8t0s0Cy8LxDc5x4Bv6tI3CPQHy6fdZfbPxLymxbLtqjdcrzY6LzpKBuu9LOPXeT8uJRuBI8P7qiGmdRRC/Th6nAvepqzwp6jlVUOXiJya3VkYmXmtxwxKsvtyVhmirFb89gjIyBzDEwBTVma3wJ5AVOPEm6fjanA99mdas/nW2hbny+h59O42we3YoYXH2sKaFIrJdQp1A+FhsaNQe3aGhtP/rvnpFgT26Ds7G79uE/r0dT3oV0RU2Vr1y7XJVA5weH5ho7SFx6X26efHL42CjT/ND7/zCf7VupoLkNLoUKy9fmzq2/mHd2++sop1bksbfnKuYHxzdnXtrQvt1a3vDBrA9jVyzTQtBj59CN3xnbFq7W+6la7R3QW16f2sd0UMQluCbi0QZmZs7Vs11D2+SZ9leUl/L2zfd58sPKjwVsLytQas7X5DO0L8B7UW8hZeN9YtO0rcLTdatw5CPvvnhnufQtla1UC7UrKwjPYe8C7g1/Wl9y+0J6es7S7v18uO6+2726v96ix38x67rfqqDUBNEsdE4gQ6Nlu7DHkYnHBjp0jbHw4xGH2yo9qCujycl954L1Y+r6O2dMeclHQbN65tAiRwQ8AnUHUJUy2Bmqopv5b2dCzMQ4KKFMAQCsLCNyZpwCAnqcfzlamAIBWFhC4M08BAD1PP5ytTAEArSwgpd2RH2mX9mXK/AB6imqec/hTSE+XuqZYaC2trRqgY4MUQ5kb0JxzxfiVeqy7TrLva0s9b0p7/wc3asud5ikDEAAAAABJRU5ErkJggg==';
  const LEGACY_HATCH_CLASSES=['hatchery-fit-screen','hatchery-solid-screen','hatchery-v175','hatchery-v176'];
  let hatchV177Timer=0;
  let hatchV177Raf=0;

  function imp(el,name,value){ if(el) el.style.setProperty(name,value,'important'); }

  function enforceHatcheryV177(){
    const screen=document.getElementById('hatcheryScreen');
    if(!screen || screen.classList.contains('hidden')) return;

    // Detach from the quest grid entirely. Older patches were fighting over
    // percentage/grid heights; body-level fixed positioning removes that chain.
    if(screen.parentElement!==document.body) document.body.appendChild(screen);
    for(const cls of LEGACY_HATCH_CLASSES) screen.classList.remove(cls);
    screen.classList.add('hatchery-v177');
    document.body.classList.add('hatchery-active');

    const header=document.querySelector('.quest-header');
    const headerBottom=Math.max(0,Math.round(header?.getBoundingClientRect().bottom||72));
    const vv=window.visualViewport;
    const viewportHeight=Math.max(360,Math.round(vv?.height||window.innerHeight||document.documentElement.clientHeight||720));
    const viewportWidth=Math.max(240,Math.round(vv?.width||window.innerWidth||document.documentElement.clientWidth||390));
    const available=Math.max(320,viewportHeight-headerBottom);

    imp(screen,'position','fixed');
    imp(screen,'z-index','10000');
    imp(screen,'top',headerBottom+'px');
    imp(screen,'left','0px');
    imp(screen,'right','auto');
    imp(screen,'bottom','auto');
    imp(screen,'width',viewportWidth+'px');
    imp(screen,'height',available+'px');
    imp(screen,'min-width',viewportWidth+'px');
    imp(screen,'max-width',viewportWidth+'px');
    imp(screen,'min-height',available+'px');
    imp(screen,'max-height',available+'px');
    imp(screen,'margin','0');
    imp(screen,'padding','0');
    imp(screen,'display','block');
    imp(screen,'overflow','hidden');
    imp(screen,'transform','none');
    imp(screen,'background-color','#d9eef9');
    imp(screen,'background-image','url("'+HATCH_BG_V177+'")');
    imp(screen,'background-position','center center');
    imp(screen,'background-repeat','no-repeat');
    imp(screen,'background-size','cover');

    const shell=screen.querySelector('.hatch-world-shell');
    const world=screen.querySelector('.hatch-world');
    for(const el of [shell,world]){
      imp(el,'position','absolute');
      imp(el,'top','0'); imp(el,'right','0'); imp(el,'bottom','0'); imp(el,'left','0');
      imp(el,'width','100%'); imp(el,'height','100%');
      imp(el,'min-width','0'); imp(el,'min-height','0');
      imp(el,'max-width','none'); imp(el,'max-height','none');
      imp(el,'margin','0'); imp(el,'padding','0');
      imp(el,'display','block'); imp(el,'overflow','hidden');
      imp(el,'aspect-ratio','auto');
      imp(el,'background','transparent');
      imp(el,'border','0'); imp(el,'border-radius','0'); imp(el,'box-shadow','none');
      imp(el,'transform','none');
    }

    // Screen owns the art now; the old image layer is deliberately removed
    // from layout so a failed inner-world size can never hide the scene.
    const bg=screen.querySelector('.hatch-world-bg');
    imp(bg,'display','none');

    const topbar=screen.querySelector('.hatch-world-topbar');
    imp(topbar,'display','grid'); imp(topbar,'visibility','visible'); imp(topbar,'opacity','1');
    imp(topbar,'position','absolute'); imp(topbar,'top','0'); imp(topbar,'left','0'); imp(topbar,'right','0'); imp(topbar,'z-index','30');

    const slots=screen.querySelector('.hatch-nest-slots');
    imp(slots,'display','block'); imp(slots,'visibility','visible'); imp(slots,'opacity','1');
    imp(slots,'position','absolute'); imp(slots,'top','0'); imp(slots,'right','0'); imp(slots,'bottom','0'); imp(slots,'left','0'); imp(slots,'z-index','10');
  }

  function startHatchV177(){
    stopHatchV177();
    enforceHatcheryV177();
    hatchV177Raf=requestAnimationFrame(()=>requestAnimationFrame(enforceHatcheryV177));
    // Keep one tiny enforcer while the hatchery is open. This neutralizes the
    // older delayed resize callbacks still present for save compatibility.
    hatchV177Timer=window.setInterval(enforceHatcheryV177,120);
    for(const delay of [30,80,160,320,650,1100]) window.setTimeout(enforceHatcheryV177,delay);
  }

  function stopHatchV177(){
    if(hatchV177Timer){clearInterval(hatchV177Timer);hatchV177Timer=0;}
    if(hatchV177Raf){cancelAnimationFrame(hatchV177Raf);hatchV177Raf=0;}
    document.body.classList.remove('hatchery-active');
  }

  const previousShowScreenV177=showScreen;
  showScreen=function(which){
    previousShowScreenV177(which);
    if(which==='hatchery') startHatchV177();
    else stopHatchV177();
  };

  const resizeHatchV177=()=>{
    const screen=document.getElementById('hatcheryScreen');
    if(screen && !screen.classList.contains('hidden')) enforceHatcheryV177();
  };
  window.addEventListener('resize',resizeHatchV177,{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(resizeHatchV177,100),{passive:true});
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize',resizeHatchV177,{passive:true});
    window.visualViewport.addEventListener('scroll',resizeHatchV177,{passive:true});
  }
})();



// v24.178 — isolated hatchery screen. The old #hatcheryScreen is retired entirely
// so no legacy hatchery CSS, timers, or geometry callbacks can affect this surface.
(function(){
  const api=window.DuckieHatchApiV178;
  const old=document.getElementById('hatcheryScreen');
  if(old) old.remove();

  const screen=document.createElement('section');
  screen.id='hatcheryScreenV178';
  screen.className='screen hidden hatchery-clean-v178';
  screen.setAttribute('aria-label','Hatching Area');
  screen.innerHTML=`
    <div class="hatchery-v178-scene">
      <img class="hatchery-v178-bg" src="assets/eggs/Hatching-background-new.png?v=24-178" alt="">
      <div class="hatchery-v178-topbar">
        <div class="hatchery-v178-title">Hatching Area</div>
        <button id="hatchInventoryButton" class="hatch-inventory-button" type="button">Inventory <span id="hatchInventoryCount" class="count">0</span></button>
      </div>
      <div id="hatchWorldReady" class="hatch-world-ready hidden">An egg is ready! ✨</div>
      <div id="hatchNestSlots" class="hatch-nest-slots hatch-nest-slots-v178" aria-label="Incubating eggs"></div>
    </div>
    <div id="hatchDetailModal" class="hatch-modal hidden" aria-hidden="true">
      <button id="hatchDetailBackdrop" class="hatch-modal-backdrop" type="button" aria-label="Close egg window"></button>
      <section class="hatch-modal-card" role="dialog" aria-modal="true" aria-labelledby="hatchDetailTitle">
        <button id="closeHatchDetail" class="hatch-modal-close" type="button" aria-label="Close">×</button>
        <div class="hatch-modal-heading"><span id="hatchDetailKicker" class="mini-label">INCUBATOR</span><h2 id="hatchDetailTitle">Lil Guy Egg</h2><small id="hatchDetailSubtitle">Warm and cozy.</small></div>
        <div class="hatch-window">
          <div id="hatchGlow" class="hatch-window-glow" aria-hidden="true"></div>
          <img class="hatch-window-nest" src="assets/eggs/Hatch-nest.png" alt="">
          <img id="hatchDetailEgg" class="hatch-window-egg" src="assets/eggs/Common-egg.png" alt="Lil Guy egg">
          <div id="hatchResult" class="hatch-result hidden" aria-live="polite"></div>
        </div>
        <div id="hatchDetailStatus" class="hatch-detail-status">Incubating...</div>
        <div id="hatchDetailActions" class="hatch-detail-actions"></div>
      </section>
    </div>
    <div id="eggInventoryModal" class="hatch-modal hidden" aria-hidden="true">
      <button id="eggInventoryBackdrop" class="hatch-modal-backdrop" type="button" aria-label="Close egg inventory"></button>
      <section class="hatch-modal-card" role="dialog" aria-modal="true" aria-labelledby="eggInventoryTitle">
        <button id="closeEggInventory" class="hatch-modal-close" type="button" aria-label="Close">×</button>
        <div class="hatch-modal-heading"><span class="mini-label">EGG INVENTORY</span><h2 id="eggInventoryTitle">Choose an Egg</h2><small>You can keep as many eggs as you find.</small></div>
        <div id="eggInventoryGrid" class="egg-inventory-summary"></div>
        <p id="eggInventoryNote" class="egg-inventory-note">Up to six eggs can incubate at once.</p>
      </section>
    </div>`;
  document.body.appendChild(screen);

  // Rebind controls because the old dynamically-generated hatchery node was removed.
  document.getElementById('hatchInventoryButton')?.addEventListener('click',()=>api?.openEggInventory?.(null,false));
  document.getElementById('closeHatchDetail')?.addEventListener('click',()=>api?.closeHatchDetail?.());
  document.getElementById('hatchDetailBackdrop')?.addEventListener('click',()=>api?.closeHatchDetail?.());
  document.getElementById('closeEggInventory')?.addEventListener('click',()=>api?.closeEggInventory?.());
  document.getElementById('eggInventoryBackdrop')?.addEventListener('click',()=>api?.closeEggInventory?.());

  function setV178Top(){
    const header=document.querySelector('.quest-header');
    const bottom=Math.max(0,Math.round(header?.getBoundingClientRect().bottom||72));
    screen.style.setProperty('--hatch-v178-top',`${bottom}px`);
  }
  function openV178(){
    setV178Top();
    window.scrollTo?.(0,0);
    screen.classList.remove('hidden');
    document.body.classList.add('hatchery-v178-active');
    try{api?.renderHatchery?.();}catch(error){console.warn('v24.178 hatchery render',error);}
  }
  function closeV178(){
    screen.classList.add('hidden');
    document.body.classList.remove('hatchery-v178-active');
  }

  const previousShowScreenV178=showScreen;
  showScreen=function(which){
    if(which!=='hatchery') closeV178();
    previousShowScreenV178(which);
    if(which==='hatchery') openV178();
  };

  // Reinstall the global back button so Hatching Area returns to Duck Quest home,
  // not out to the Games hub.
  const oldBack=document.getElementById('backGames');
  if(oldBack){
    const fresh=oldBack.cloneNode(true);
    oldBack.replaceWith(fresh);
    fresh.addEventListener('click',()=>{
      if(!screen.classList.contains('hidden')){
        showScreen('home');
        try{renderMeta?.();}catch(error){}
        return;
      }
      const visible=(id)=>{const el=document.getElementById(id);return !!el&&!el.classList.contains('hidden');};
      if(visible('homeScreen')){window.location.href='../#games';return;}
      if(visible('dashScreen')||visible('charmScreen')||visible('buddyScreen')){showScreen('home');try{renderMeta?.();}catch(error){};return;}
      if(visible('battleScreen')||visible('resultScreen')){try{returnHome();}catch(error){showScreen('home');}return;}
      showScreen('home');
    });
  }

  window.addEventListener('resize',()=>{if(!screen.classList.contains('hidden'))setV178Top();},{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(()=>{if(!screen.classList.contains('hidden'))setV178Top();},100),{passive:true});
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize',()=>{if(!screen.classList.contains('hidden'))setV178Top();},{passive:true});
  }
  setInterval(()=>{if(!screen.classList.contains('hidden')){try{api?.renderHatchery?.();}catch(error){}}},1000);
})();

window.DUCKIE_DAYS_BUILD='24.203';



/* v24.202 — Wishing Fountain recovery: smaller fountain art, shorter caption,
   and restore the hidden Continue button after choosing a fountain wish. */
(function(){
  const styleId='duckie-fountain-v202-style';
  if(!document.getElementById(styleId)){
    const style=document.createElement('style');
    style.id=styleId;
    style.textContent=`
      #chestSprite.fountain-scene-art-v202{
        width:min(146px,38vw)!important;
        height:min(146px,38vw)!important;
        object-fit:contain!important;
      }
    `;
    document.head.appendChild(style);
  }

  function applyFountainUiV202(){
    if(!ui?.chestSprite) return;
    ui.chestSprite.classList.remove('fountain-scene-art-v202');
    if(pendingChest?.eventType==='wishing-fountain'){
      ui.chestSprite.src='assets/events/Fountain.png';
      ui.chestSprite.classList.add('event-scene-art','fountain-scene-art-v202');
      if(ui.chestCaption) ui.chestCaption.textContent='Wishing Fountain';
    }
  }

  const prevShowChestV202=showChest;
  showChest=function(data){
    if(data?.eventType==='wishing-fountain'){
      data={...data, captionText:'Wishing Fountain'};
    }
    prevShowChestV202(data);
    applyFountainUiV202();
  };

  const prevShowEventChoicesV202=showEventChoices;
  showEventChoices=function(type){
    prevShowEventChoicesV202(type);
    if(type==='wishing-fountain'){
      applyFountainUiV202();
      ui?.openChest?.classList.add('hidden');
    }
  };

  const prevOpenPendingChestV202=openPendingChest;
  openPendingChest=async function(){
    if(pendingChest?.eventType){
      ui?.openChest?.classList.remove('hidden');
    }
    const result=await prevOpenPendingChestV202();
    if(pendingChest?.eventType==='wishing-fountain'){
      applyFountainUiV202();
    }
    if(pendingChest?.eventType && pendingChest?.opened && ui?.openChest){
      ui.openChest.classList.remove('hidden');
      ui.openChest.disabled=false;
      ui.openChest.textContent='Continue';
    }
    return result;
  };

  // Rebind in case the button had an older listener closure.
  setTimeout(()=>{
    const btn=document.getElementById('openChest');
    if(!btn) return;
    const fresh=btn.cloneNode(true);
    btn.replaceWith(fresh);
    ui.openChest=fresh;
    fresh.addEventListener('click',openPendingChest);
    if(pendingChest?.eventType && pendingChest?.opened){
      fresh.classList.remove('hidden');
      fresh.disabled=false;
      fresh.textContent='Continue';
    }
  },0);
})();


/* v24.203 — Mimic buddy key recovery.
   Lucky/Healthy Mimics are separate Lil Guy variants instead of overwriting the regular pink Mimic.
   This intentionally does not alter the chest -> Open -> Mimic reveal -> battlefield sequence. */
(function(){
  function restoreOverwrittenMimicBuddyV203(){
    try{
      ensureBuddySave();
      const collection=hubSave?.buddies?.collection;
      if(!collection) return;
      const base=collection['mimic:base'];
      if(!base) return;
      const name=String(base.name||'').toLowerCase();
      const image=String(base.image||'').toLowerCase();
      const isLucky=name.includes('lucky mimic') || image.includes('/mimic/lucky/');
      const isHealthy=name.includes('healthy mimic') || image.includes('/mimic/healthy/');
      if(!isLucky && !isHealthy) return;

      const variantId=isLucky?'lucky':'healthy';
      const variantKey=`mimic:${variantId}`;
      const total=Math.max(1,Math.floor(Number(base.quantity)||1));
      const variantCatalog=BUDDY_CATALOG_BY_KEY.get(variantKey);
      const baseCatalog=BUDDY_CATALOG_BY_KEY.get('mimic:base');

      if(!collection[variantKey]){
        collection[variantKey]={
          ...base,
          ...variantCatalog,
          key:variantKey,
          enemyId:'mimic',
          variantId,
          quantity:1,
          capturedAt:Number(base.capturedAt)||Date.now()
        };
      }else{
        collection[variantKey].quantity=Math.max(1,Number(collection[variantKey].quantity)||1)+1;
      }

      collection['mimic:base']={
        ...base,
        ...baseCatalog,
        key:'mimic:base',
        enemyId:'mimic',
        variantId:'base',
        quantity:Math.max(1,total-1),
        shiny:false,
        boss:false,
        capturedAt:Number(base.capturedAt)||Date.now()
      };

      persistAll();
      try{ renderBattleBuddy?.(); }catch(error){}
      try{ renderBuddyBook?.(); }catch(error){}
    }catch(error){
      console.warn('v24.203 Mimic buddy recovery skipped:',error);
    }
  }

  restoreOverwrittenMimicBuddyV203();
})();

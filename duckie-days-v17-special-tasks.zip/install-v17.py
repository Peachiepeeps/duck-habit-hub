#!/usr/bin/env python3
"""Idempotent Duckie Days Special Tasks v17 patch for the current checked-out repo."""
from pathlib import Path
import re, shutil
root=Path.cwd()
src=Path(__file__).resolve().parent

def require(condition,message):
    if not condition:raise RuntimeError(message)

def once(text,old,new,label):
    require(old in text, f'Missing source pattern ({label}); refusing unsafe modification')
    return text.replace(old,new,1)

app=root/'app.js'
s=app.read_text(encoding='utf-8')
# Persist task metadata when the normal task loader re-normalizes saves.
old='''    completions: Number(task.completions) || 0,
    pinned: Boolean(task.pinned)
'''
new='''    completions: Number(task.completions) || 0,
    pinned: Boolean(task.pinned),
    special: Boolean(task.special),
    specialRewards: window.DuckieSpecialTasksV17?.sanitize?.(task.specialRewards) || (Array.isArray(task.specialRewards) ? task.specialRewards : [])
'''
if 'special: Boolean(task.special)' not in s:s=once(s,old,new,'normalizeTask')
# Grant bonus rewards before core persistence, alongside regular completion rewards.
old='''  recordTaskCompletion(task, reward);

  if (task.repeat?.type === "once"'''
new='''  recordTaskCompletion(task, reward);
  const specialBonuses = window.DuckieSpecialTasksV17?.award?.(task) || '';

  if (task.repeat?.type === "once"'''
if 'const specialBonuses = window.DuckieSpecialTasksV17' not in s:s=once(s,old,new,'completion reward')
old='''  showToast(`Task complete! +${reward} Pink Coins${happinessGained > 0 ? ` · +${happinessGained} Happiness` : ""} ♡`);'''
new='''  showToast(`Task complete! +${reward} Pink Coins${happinessGained > 0 ? ` · +${happinessGained} Happiness` : ""}${specialBonuses ? ` · ✨ ${specialBonuses}` : ''} ♡`);'''
if 'specialBonuses ? ` · ✨' not in s:s=once(s,old,new,'special completion toast')
old='''  card.className = `task-card${isTaskReady(task) ? " ready" : " upcoming"}`;
'''
new='''  card.className = `task-card${isTaskReady(task) ? " ready" : " upcoming"}`;
  if (task.special) card.classList.add('special-task-v17');
'''
if "card.classList.add('special-task-v17')" not in s:s=once(s,old,new,'task card class')
old='''  titleWrap.append(title, createCoinInline(task.reward));
'''
new='''  titleWrap.append(title, createCoinInline(task.reward));
  if(task.special){
    const specialLabel=document.createElement('small');
    specialLabel.className='special-task-rewards-label-v17';
    specialLabel.textContent='🎁 '+(window.DuckieSpecialTasksV17?.summary?.(task.specialRewards)||'Special rewards');
    titleWrap.append(specialLabel);
  }
'''
if "specialLabel.className='special-task-rewards-label-v17'" not in s:s=once(s,old,new,'reward preview task card')
old='''    completions: 0,
    pinned: false
  });

  save.tasks.push(task);'''
new='''    completions: 0,
    pinned: false,
    special: usingSaved ? Boolean(template.special) : Boolean(window.DuckieSpecialTasksV17?.isSpecial?.()),
    specialRewards: usingSaved ? (template.specialRewards || []) : (window.DuckieSpecialTasksV17?.formRewards?.() || [])
  });

  save.tasks.push(task);'''
if 'special: usingSaved ? Boolean(template.special)' not in s:s=once(s,old,new,'create task special metadata')
if "showToast('Add at least one Special Task reward. ♡')" not in s:s=once(s,'''  const reward = getTaskReward();
  if (!reward) {''','''  if(!usingSaved && window.DuckieSpecialTasksV17?.isSpecial?.() && !(window.DuckieSpecialTasksV17?.formRewards?.().length)){
    showToast('Add at least one Special Task reward. ♡');
    return;
  }

  const reward = getTaskReward();
  if (!reward) {''','special task reward validation')
old='''      reward: task.reward,
      repeat: structuredClone(task.repeat)
'''
new='''      reward: task.reward,
      repeat: structuredClone(task.repeat),
      special: task.special,
      specialRewards: structuredClone(task.specialRewards)
'''
if 'specialRewards: structuredClone(task.specialRewards)' not in s:s=once(s,old,new,'saved task template rewards')
app.write_text(s,encoding='utf-8')

index=root/'index.html'
h=index.read_text(encoding='utf-8')
css='<link rel="stylesheet" href="special-tasks-v17.css?v=17">'
script='<script src="special-tasks-v17.js?v=17"></script>'
if css not in h:
    h=once(h,'</head>',f'  {css}\n</head>','special css tag')
if script not in h:
    h=once(h,'<script src="tasks.js?',f'{script}\n  <script src="tasks.js?','special js tag')
index.write_text(h,encoding='utf-8')
for name in ('special-tasks-v17.js','special-tasks-v17.css'):
    shutil.copyfile(src/name,root/name)

# Retain, but deactivate, known obsolete one-off installer workflows.
w=root/'.github/workflows';archive=root/'.github/workflow-archive';archive.mkdir(parents=True,exist_ok=True)
old_installers={
'duckie-days-v10-installer-fresh.yml','duckie-days-v11-installer-REUPLOAD.yml',
'fix-task-buddy-native-proportions-v14.yml','fix-task-buddy-natural-sprite-sizes-v13.yml',
'fix_mimic_card_gallery_v9.yml','install-duckie-task-buddy-v12-room-height.yml',
'install-task-buddy-beta-from-zip.yml','install-task-buddy-v7-shared-economy.yml',
'normalize-mimics-v8-reupload.yml','repair-task-buddy-v4-zip-name.yml',
'update-task-buddy-room-v2.yml','update-task-buddy-room-v3.yml',
'update-task-buddy-room-v4.yml','update-task-buddy-v5-opacity-mimics.yml'
}
moved=[]
for filename in sorted(old_installers):
    p=w/filename
    if p.is_file():
        p.rename(archive/filename)
        moved.append(filename)
print('Special Tasks v17 installed. Archived',len(moved),'old installer workflows. Kept current v16 and all unspecified workflows.')

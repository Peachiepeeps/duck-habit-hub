#!/usr/bin/env python3
"""Ducky Days v24.356 incremental patch, always runs against HEAD checkout.
No save or user-generated files are modified. Fail fast on unexpected source layouts.
"""
import sys,re,json,runpy
from pathlib import Path
root=Path(sys.argv[1]).resolve()

def file(rel):return root/rel
def read(rel):return file(rel).read_text(encoding='utf-8')
def put(rel,txt):file(rel).parent.mkdir(parents=True,exist_ok=True);file(rel).write_text(txt,encoding='utf-8')
def swap(s,a,b,label,expected=1):
 ct=s.count(a)
 if ct!=expected:raise RuntimeError(f'{label}: expected {expected} matches, found {ct}: {a[:90]}')
 return s.replace(a,b,expected)

def insert_after(s,needle,added,label):return swap(s,needle,needle+added,label)

# 1) Run the tested cafe patch first: existing ingredients, 3 customers, soda masks.
# It temporarily sets Midori to opened/opened, then this release uses the new frame.
artzip=root/'.github/workflows/cafe-customer-v356.zip'
cafe_script=root/'.github/workflows/prepare_bao_cafe_patch.py'
if not artzip.exists() or not cafe_script.exists():raise RuntimeError('Missing Bao Cafe installer support files')
saved_argv=sys.argv
try:
 sys.argv=[str(cafe_script),str(root),str(artzip)]
 runpy.run_path(str(cafe_script),run_name='__main__')
finally:sys.argv=saved_argv

# 2) New fabled art, three shared-species cards, Annika LI cards, Quackers.
card='trading-cards-base.js';s=read(card)
raw=json.loads((root/'.github/workflows/extra-cards-v356.json').read_text(encoding='utf-8'))
fabled=[]
for entry in raw:
 label=entry['label'];slug=entry['slug']
 fabled.append(f'    ["{slug}",{json.dumps(label)},"trading-cards/fabled/F-{slug}.png","Fabled"],')
fabled.append('    ["quackers","Quackers","gimmicks/quackers/Quackers-idle-1.png","Fabled"],')
needle='  ];\n  const cards=[];'
# insert before closing of the Fabled array, not before other arrays
start=s.index('  const fabled=[');i=s.index(needle,start)
s=s[:i]+ '\n' + '\n'.join(fabled) + '\n' + s[i:]
# Append new enemy cards with existing registration mechanism (stable legacy card IDs)
needle='  additionalCardFamilies.forEach(([enemyId,name,area,boss],index)=>{'
extra='''  additionalCardFamilies.push(
    ['strawbunny','Strawbunny','Meadow / Candyland',false],
    ['pudding-snatcher','Pudding Snatcher','City Streets / Candyland',false],
    ['pancake-ray','Pancake Ray','Ocean / Candyland',true]
  );
'''
s=swap(s,needle,extra+needle,'shared creature cards')
# Existing new-family card artwork uses PNG (correct for new WebP images only if special-cased)
s=swap(s,"const art=`${folder}/${enemyId}/base/idle-1.${area==='Spooky Forest'?'webp':'png'}`;",
           "const art=`${folder}/${enemyId}/base/idle-1.${area==='Spooky Forest'||['strawbunny','pudding-snatcher','pancake-ray'].includes(enemyId)?'webp':'png'}`;",'shared art format')
needle='  // City Streets and newly introduced boss/enemy cards.'
rare='''  cards.push({id:'r-love-shin',characterId:'shin',name:'Shin',art:'love-interests/shin/Shin-idle-1.png',rarity:'rare',number:'R-058',category:'Annika Love Interest',hint:'Meet Shin while playing Duck Quest as Annika.'});
  cards.push({id:'r-love-bubble',characterId:'bubble',name:'Bubble',art:'love-interests/bubble/Bubble-idle-1.png',rarity:'rare',number:'R-059',category:'Annika Love Interest',hint:'Meet Bubble while playing Duck Quest as Annika.'});
'''
s=swap(s,needle,rare+needle,'Annika rare cards')
put(card,s)

# 3) Hub ducks + Annika's fully equipable wardrobe pieces.
app='app.js';s=read(app)
needle='const DUCKS = {\n'
extra='''  "shin-duck": {name:"Shin Duck",file:"duck-quest/assets/love-interests/shin/Shin-duck.png",acquisition:"love-interest-shin"},
  "bubble-duck": {name:"Bubble Duck",file:"duck-quest/assets/love-interests/bubble/Bubble-duck.png",acquisition:"love-interest-bubble"},
'''
s=insert_after(s,needle,extra,'Hub duck definitions')
s=swap(s,'"moriko-duck", "jenson-duck"]','"moriko-duck", "jenson-duck", "shin-duck", "bubble-duck"]','prevent gacha giving love interest ducks')
# Annika asset catalog. These point to lossless WebP variants of provided 1080x1920 pixel layers.
needle='const ANNIKA_ASSETS = {\n'
parts=[
 ('annika-lingerie-stockings','Annika Lingerie Stockings','Annika-lingerie-stockings.webp',23),
 ('annika-lingerie-bottoms','Annika Lingerie Bottoms','Annika-lingerie-bottoms.webp',29),
 ('annika-lingerie-babydoll','Annika Lingerie Babydoll','Annika-lingerie-babydoll.webp',30),
 ('annika-date-pigtails','Annika Date Pigtails','Annika-date-pigtails.webp',10),
 ('annika-date-stockings','Annika Date Stockings','Annika-date-Stockings.webp',24),
 ('annika-date-heels','Annika Date Heels','Annika-date-heels.webp',25),
 ('annika-date-skirt','Annika Date Skirt','Annika-date-skirt.webp',28),
 ('annika-date-sweater','Annika Date Sweater','Annika-date-Sweater.webp',31),
 ('annika-date-necklace','Annika Date Necklace','Annika-date-necklace.webp',33),
]
extra=''.join(f'  "{id}": {{label:{json.dumps(label)},file:"{fn}",z:{z}}},\n' for id,label,fn,z in parts)
s=insert_after(s,needle,extra,'Annika new asset definitions')
s=swap(s,'options: ["hair-long", "hair-ponytail"]','options: ["hair-long", "hair-ponytail", "annika-date-pigtails"]','Annika hair closet')
s=swap(s,'options: ["outer-sweater", "outer-bow-sweater"]','options: ["outer-sweater", "outer-bow-sweater", "annika-date-sweater"]','Annika outer closet')
s=swap(s,'{ id: "bottom", label: "Bottoms", type: "single", allowNone: true, options: ["bottom-shorts"] }','{ id: "bottom", label: "Bottoms", type: "single", allowNone: true, options: ["bottom-shorts", "annika-date-skirt", "annika-lingerie-bottoms"] }','Annika bottom closet')
s=swap(s,'options: ["dress-leotard"]','options: ["dress-leotard", "annika-lingerie-babydoll"]','Annika dress closet')
s=swap(s,'options: ["legwear-black", "legwear-circus"]','options: ["legwear-black", "legwear-circus", "annika-lingerie-stockings", "annika-date-stockings"]','Annika legwear closet')
s=swap(s,'options: ["shoes-sneakers", "shoes-booties", "shoes-folded-booties"]','options: ["shoes-sneakers", "shoes-booties", "shoes-folded-booties", "annika-date-heels"]','Annika shoes closet')
s=swap(s,'"candy-hairclip", "city-crown"] }\n];\n\nconst MIKO_CLOSET', '"candy-hairclip", "city-crown", "annika-date-necklace"] }\n];\n\nconst MIKO_CLOSET','Annika extras closet')
# Outfits need explicit normalization acceptance or newly equipped items vanish on save/load.
s=swap(s,'["hair-long", "hair-ponytail"].includes(normalized.hair)','["hair-long", "hair-ponytail", "annika-date-pigtails"].includes(normalized.hair)','Annika hair normalize')
s=swap(s,'[null, "outer-sweater", "outer-bow-sweater"].includes(normalized.outer)','[null, "outer-sweater", "outer-bow-sweater", "annika-date-sweater"].includes(normalized.outer)','Annika outer normalize')
s=swap(s,'[null, "bottom-shorts"].includes(normalized.bottom)','[null, "bottom-shorts", "annika-date-skirt", "annika-lingerie-bottoms"].includes(normalized.bottom)','Annika bottom normalize')
s=swap(s,'[null, "dress-leotard"].includes(normalized.dress)','[null, "dress-leotard", "annika-lingerie-babydoll"].includes(normalized.dress)','Annika dress normalize')
s=swap(s,'"legwear-bow-both", "legwear-circus"].includes(normalized.legwear)','"legwear-bow-both", "legwear-circus", "annika-date-stockings", "annika-lingerie-stockings"].includes(normalized.legwear)','Annika legwear normalize')
s=swap(s,'"shoes-booties", "shoes-folded-booties"].includes(normalized.shoes)','"shoes-booties", "shoes-folded-booties", "annika-date-heels"].includes(normalized.shoes)','Annika shoes normalize')
s=swap(s,'"candy-hairclip", "city-crown"].includes(id))\n    : [...DEFAULT_ANNIKA_OUTFIT.extras];', '"candy-hairclip", "city-crown", "annika-date-necklace"].includes(id))\n    : [...DEFAULT_ANNIKA_OUTFIT.extras];','Annika extras normalize')
# The Annika renderer has an explicit order; list layers there too.
s=swap(s,'"hair-long", "hair-ponytail",\n      "back-bow-circus"','"hair-long", "hair-ponytail", "annika-date-pigtails",\n      "back-bow-circus"','Annika draw order hair')
s=swap(s,'"legwear-black", "legwear-bow-left", "legwear-bow-right", "legwear-bow-both", "legwear-circus",\n      "shoes-sneakers", "shoes-booties", "shoes-folded-booties",\n      "bottom-shorts",','"legwear-black", "legwear-bow-left", "legwear-bow-right", "legwear-bow-both", "legwear-circus", "annika-lingerie-stockings", "annika-date-stockings",\n      "shoes-sneakers", "shoes-booties", "shoes-folded-booties", "annika-date-heels",\n      "bottom-shorts", "annika-lingerie-bottoms", "annika-date-skirt",','Annika draw order wear')
s=swap(s,'"dress-leotard",\n      "outer-sweater", "outer-bow-sweater",\n      "scarf", "neck-bow",','"dress-leotard", "annika-lingerie-babydoll",\n      "outer-sweater", "outer-bow-sweater", "annika-date-sweater",\n      "scarf", "neck-bow", "annika-date-necklace",','Annika draw order dress')
put(app,s)

# 4) Quest save merge: preserve Annika unlocks from separate scene runtime.
quest='duck-quest/js/game-v96.js';s=read(quest)
needle='''    hubSave.characterUnlockedItems.miko=[...new Set([...currentMiko,...incomingMiko])];'''
extra='''
    const currentAnnika=Array.isArray(hubSave.characterUnlockedItems.annika)?hubSave.characterUnlockedItems.annika:[];
    const incomingAnnika=Array.isArray(incoming.characterUnlockedItems?.annika)?incoming.characterUnlockedItems.annika:[];
    hubSave.characterUnlockedItems.annika=[...new Set([...currentAnnika,...incomingAnnika])];'''
s=insert_after(s,needle,extra,'Annika quest reward save sync')
put(quest,s)

# 5) Annika love interest scenes: keep Miko's existing story logic untouched.
li='duck-quest/js/love-interests-v326.js';s=read(li)
s=swap(s,'idle2: "assets/love-interests/midori/Midori-opened.png",', 'idle2: "assets/love-interests/midori/Midori-idle-2.png",','Midori new idle2 in Quest')
needle='  const CHARACTERS = {\n'
extra='''    annika:{name:'Annika',sprites:{idle1:'assets/characters/annika/base/idle-1.webp',idle2:'assets/characters/annika/base/idle-2.webp'}},
    shin:{name:'Shin',duckId:'shin-duck',cardId:'r-love-shin',sprites:{idle1:'assets/love-interests/shin/Shin-idle-1.png',idle2:'assets/love-interests/shin/Shin-idle-2.png',blush:'assets/love-interests/shin/Shin-hurt.png'},outfitIds:['annika-lingerie-stockings','annika-lingerie-bottoms','annika-lingerie-babydoll']},
    bubble:{name:'Bubble',duckId:'bubble-duck',cardId:'r-love-bubble',sprites:{idle1:'assets/love-interests/bubble/Bubble-idle-1.png',idle2:'assets/love-interests/bubble/Bubble-idle-2.png',happy:'assets/love-interests/bubble/Bubble-happy.png'},outfitIds:['annika-date-pigtails','annika-date-stockings','annika-date-heels','annika-date-skirt','annika-date-sweater','annika-date-necklace']},
'''
s=insert_after(s,needle,extra,'Annika love-interest character definitions')
needle='  const SCENES = {\n'
scenes='''    shin:{id:'shin',title:'Shin',kicker:'ANNIKA LOVE INTEREST',leftId:'annika',rightId:'shin',dialogue:[
      {speaker:'Annika',text:'Oh, hello, Shin!',rightPose:'idle'},
      {speaker:'Shin',text:'Ah! There you are. Uh, Tamao wanted me to give this to you.',rightPose:'idle'},
      {speaker:'Annika',text:'Me? Oh, thank you.',rightPose:'idle'},
      {speaker:'Narrator',text:'Annika opens the box.',rightPose:'idle'},
      {speaker:'Annika',text:'Oh my!',rightPose:'idle'},
      {speaker:'Shin',text:'What is it…?',rightPose:'idle'},
      {speaker:'Narrator',text:'He peeks over her shoulder.',rightPose:'blush'},
      {speaker:'Shin',text:'DAMN IT, TAMAO!',rightPose:'blush'},
      {speaker:'Annika',text:'I… uh, I like it.',rightPose:'blush'},
      {speaker:'Shin',text:'I mean… It’s… It’s not bad… S-Should we head home?',rightPose:'blush'},
      {speaker:'Annika',text:'Yes, please!',rightPose:'blush'}
    ],reward(){const data=load();unlockCharacter(data,'shin',{grantCard:false,grantDuck:true,grantOutfit:true});save(data);notifyUnlock('shin');}},
    bubble:{id:'bubble',title:'Bubble',kicker:'ANNIKA LOVE INTEREST',leftId:'annika',rightId:'bubble',dialogue:[
      {speaker:'Annika',text:'Oh, Bubble, hello!',rightPose:'idle'},
      {speaker:'Bubble',text:'Hello, my queen. It’s dangerous being out alone. Would you like me to escort you home?',rightPose:'idle'},
      {speaker:'Annika',text:'How sweet of you. Sure, I wouldn’t mind that.',rightPose:'idle'},
      {speaker:'Bubble',text:'My pleasure. I couldn’t possibly let you get hurt here.',rightPose:'idle'},
      {speaker:'Annika',text:'I appreciate it. What were you doing out here?',rightPose:'idle'},
      {speaker:'Bubble',text:'Oh, I was just… on a walk. That’s all.',rightPose:'idle'},
      {speaker:'Annika',text:'Best not to dig further…',rightPose:'idle'},
      {speaker:'Annika',text:'I see. Ahh, I ripped my sweater a bit…',rightPose:'idle'},
      {speaker:'Bubble',text:'Oh, I can fix that. I know, I’ll get you a cute new outfit! We can go on a date!',rightPose:'happy'},
      {speaker:'Annika',text:'You’re too sweet, Bubble. Sure, I won’t say no to that.',rightPose:'happy'},
      {speaker:'Bubble',text:'Okay, let’s go!',rightPose:'happy'}
    ],reward(){const data=load();unlockCharacter(data,'bubble',{grantCard:false,grantDuck:true,grantOutfit:true});save(data);notifyUnlock('bubble');}},
'''
s=insert_after(s,needle,scenes,'Annika new scenes')
s=swap(s,'if (!Array.isArray(data.characterUnlockedItems.miko)) data.characterUnlockedItems.miko = [];','if (!Array.isArray(data.characterUnlockedItems.miko)) data.characterUnlockedItems.miko = [];\n    if (!Array.isArray(data.characterUnlockedItems.annika)) data.characterUnlockedItems.annika = [];','Annika scene save initialization')
s=swap(s,'"moriko", "jenson"]) {\n      data.loveInterests[key]', '"moriko", "jenson", "shin", "bubble"]) {\n      data.loveInterests[key]','Annika encounter state')
s=swap(s,'if (!data.characterUnlockedItems.miko.includes(piece)) data.characterUnlockedItems.miko.push(piece);','const target=key===\'shin\'||key===\'bubble\'?data.characterUnlockedItems.annika:data.characterUnlockedItems.miko;\n        if (!target.includes(piece)) target.push(piece);','Annika wardrobe reward')
s=swap(s,"const items=[`${scene.title} Duck`, `Miko's ${scene.title} Outfit`];", "const outfit=scene.id==='shin'?'Annika’s Lingerie Outfit':scene.id==='bubble'?'Annika’s Date Outfit':`Miko’s ${scene.title} Outfit`;\n    const items=[`${scene.title} Duck`,outfit];",'Annika reward screen')
s=swap(s,'"moriko", "jenson"]) {\n      if (!root.loveInterests[key]?.encountered)', '"moriko", "jenson", "shin", "bubble"]) {\n      if (!root.loveInterests[key]?.encountered)','Annika reward migration')
needle='''    const ids = [];

    if (!root.loveInterests.lukio.encountered)'''
repl='''    const ids = [];
    if(activeCharacterId()==='annika'){
      for(const name of ['shin','bubble'])if(!root.loveInterests[name].encountered)ids.push(name);
      return ids.length?ids:['shin','bubble']; // Repeat encounters: duck + card, never reaward outfit.
    }

    if (!root.loveInterests.lukio.encountered)'''
s=swap(s,needle,repl,'Annika eligible scenes')
s=swap(s,'if (open || !isMiko()) return false;',"if (open || !(isMiko() || activeCharacterId()==='annika')) return false;",'Annika natural scene rolls')
s=swap(s,'window.triggerLukioEncounter = function()',"window.triggerShinEncounter = function(){return showScene('shin');};\n  window.triggerBubbleEncounter = function(){return showScene('bubble');};\n  window.triggerLukioEncounter = function()",'Annika manual scene triggers')
put(li,s)

# 6) Quackers' mobile no-scroll pond integrated with special gimmick encounters.
gimmick='duck-quest/js/gimmick-encounters-v288.js';s=read(gimmick)
s=swap(s,'"sock-gremlin","ufono"];','"sock-gremlin","ufono","quackers"];','add Quackers to random encounters')
needle='  function show(encounter){'
new='''  function quackersPond(){
    animateScene(['assets/gimmicks/quackers/Quackers-idle-1.png','assets/gimmicks/quackers/Quackers-idle-2.png'],470);
    ui.chestCaption.textContent='Quackers · Lucky Duck Pond';
    setMessage('Quackers: Quack quack! Feeling lucky today? Pick a duck! Any duck!');
    const m=menu('Lucky Duck Pond','Pick ONE floating duck to reveal a surprise! Every duck holds a prize.');
    const controls=m.querySelector('.gimmick-actions-v288');controls.innerHTML='';
    const style=document.createElement('style');style.textContent=`
      #gimmickMenuV288.quackers-v356{max-height:min(54dvh,400px);overflow:hidden;display:flex;flex-direction:column;align-items:center;gap:3px}
      .quackers-v356 .quack-pond-v356{width:min(100%,390px);height:clamp(96px,18dvh,150px);border:3px solid #7db6b1;border-radius:50% 50% 45% 45%;background:radial-gradient(ellipse,#b3eee5 15%,#70c7d3 70%,#5aafc7 100%);display:flex;justify-content:space-around;align-items:center;box-shadow:inset 0 9px #ffffff55;margin:0 auto}
      .quackers-v356 .quack-pond-v356 button{width:31%;height:80%;display:grid;place-items:center;background:transparent;border:0;padding:0;cursor:pointer;transition:transform .15s;touch-action:manipulation}
      .quackers-v356 .quack-pond-v356 button:focus-visible{outline:3px solid #ad6890;border-radius:25px}
      .quackers-v356 .quack-pond-v356 img{width:clamp(43px,10vh,73px);height:clamp(43px,10vh,73px);object-fit:contain;image-rendering:pixelated;animation:quackFloatV356 1.2s ease-in-out infinite alternate}
      .quackers-v356 .quack-pond-v356 button:nth-child(2) img{animation-delay:.2s}
      .quackers-v356 .quack-pond-v356 button:nth-child(3) img{animation-delay:.5s}
      .quackers-v356 .quack-result-v356{font-size:clamp(12px,2vh,16px);min-height:1.5em;font-weight:700;text-align:center}
      .quackers-v356 .gimmick-actions-v288{display:flex;flex-direction:column;align-items:center;gap:4px;width:100%}
      @keyframes quackFloatV356{to{transform:translateY(-6px) rotate(3deg)}}
      @media(max-height:600px){#gimmickMenuV288.quackers-v356{max-height:48dvh;padding:4px}.quackers-v356 .quack-pond-v356{height:85px}.quackers-v356 .quack-pond-v356 img{width:48px;height:48px}}
    `;m.classList.add('quackers-v356');m.prepend(style);
    const pond=document.createElement('div');pond.className='quack-pond-v356';
    const summary=document.createElement('div');summary.className='quack-result-v356';summary.setAttribute('aria-live','polite');
    const golden=Math.random()<.03?randInt(0,2):-1;
    const ducks=['../assets/ducks/Standard-duck.webp','../assets/ducks/Pink-duck.webp','../assets/ducks/Blue-duck.webp'];
    if(golden!==-1)ducks[golden]='../assets/ducks/Golden-duck.webp';
    let picked=false;
    const win=()=>{
      const r=Math.random(),tier=r<.50?'common':r<.85?'lucky':'rare';
      const choices=tier==='common'?[
        ()=>{const n=randInt(75,125);addCoins(n);return `${n} Pink Coins`;},
        ()=>{addInventory('exp-candy-small',3);return '3 Small EXP Candies';},
        ()=>{addInventory('buddy-pon',3);return '3 Lil Pons';}
      ]:tier==='lucky'?[
        ()=>{const n=randInt(200,300);addCoins(n);return `${n} Pink Coins`;},
        ()=>{addInventory('exp-candy-large',2);return '2 Large EXP Candies';},
        ()=>{addInventory('jump-token',2);return '2 Jump Tokens';},
        ()=>{hubSave.taskProgression??={};hubSave.taskProgression.duckBucks=Math.max(0,Number(hubSave.taskProgression.duckBucks)||0)+5;return '5 Duck Bucks';}
      ]:[
        ()=>{const t=TC?.ensureState?.(hubSave);if(t){t.unopenedPacks=Math.max(0,Number(t.unopenedPacks)||0)+1;return '1 Card Pack';}addCoins(200);return '200 Pink Coins';},
        ()=>{addInventory('exp-candy-large',5);return '5 Large EXP Candies';},
        ()=>{addInventory('buddy-pon',10);return '10 Lil Pons';},
        ()=>{hubSave.taskProgression??={};hubSave.taskProgression.duckBucks=Math.max(0,Number(hubSave.taskProgression.duckBucks)||0)+15;return '15 Duck Bucks';}
      ];
      return pick(choices)();
    };
    ducks.forEach((src,i)=>{
      const b=document.createElement('button');b.type='button';b.setAttribute('aria-label',i===golden?'Pick the golden duck':`Pick duck ${i+1}`);
      const img=document.createElement('img');img.src=src;img.alt=i===golden?'Golden duck':'Floating duck';b.append(img);
      b.addEventListener('click',()=>{
        if(picked)return;picked=true;pond.querySelectorAll('button').forEach(x=>x.disabled=true);
        let reward='';
        if(i===golden){
          const owned=Math.max(0,Number(TC?.ensureState?.(hubSave)?.owned?.['f-quackers']||0));
          addCoins(150);
          if(!owned&&TC?.byId?.['f-quackers']){TC.grantCard(hubSave,'f-quackers',1);reward='NEW Quackers Fabled Card + 150 Pink Coins';}
          else{const t=TC?.ensureState?.(hubSave);if(t)t.unopenedPacks=Math.max(0,Number(t.unopenedPacks)||0)+1;reward='1 Card Pack + 150 Pink Coins';}
        }else reward=win();
        summary.textContent=`✨ ${reward}!`;
        const next=document.createElement('button');next.type='button';next.className='pixel-button primary';next.textContent='Continue';
        next.addEventListener('click',()=>finish(`Quackers: A lucky duck indeed! You won ${reward}!`),{once:true});
        controls.append(next);persistAll();
      },{once:true});pond.append(b);
    });
    controls.append(pond,summary);
    // Explicitly one free pick, no replay until the next independent encounter.
  }
'''
s=s.replace(needle,new+needle,1)
s=swap(s,"else if(kind==='ufono')window.DuckieUFONOV298?.show?.({animateScene,menu,button,finish});else angyDuck();",
  "else if(kind==='ufono')window.DuckieUFONOV298?.show?.({animateScene,menu,button,finish});else if(kind==='quackers')quackersPond();else angyDuck();",'Quackers gimmick dispatcher')
put(gimmick,s)

# 7) Midori's actual idle-2 for Bao Cafe, retaining special closed story pose.
cafe='bao-cafe/index.html';s=read(cafe)
old='"name":"Midori","idle1":"../duck-quest/assets/love-interests/midori/Midori-opened.png","idle2":"../duck-quest/assets/love-interests/midori/Midori-opened.png"'
new='"name":"Midori","idle1":"../duck-quest/assets/love-interests/midori/Midori-opened.png","idle2":"../duck-quest/assets/love-interests/midori/Midori-idle-2.png"'
s=swap(s,old,new,'Midori new cafe bounce')
put(cafe,s)

# 8) Version bump, robust new service worker media cache to refresh recently
# replaced art (including F-io.png); never overwrite prior artwork file.
for rel in ['index.html','duck-quest/index.html','bao-cafe/index.html']:
 s=read(rel)
 s=s.replace('24.355','24.356').replace('24-355','24-356')
 if rel=='duck-quest/index.html':
  # Force fresh scripts even if a phone retained the earlier URL in its HTTP cache.
  for name in ['love-interests-v326.js','gimmick-encounters-v288.js']:
   s,n=re.subn(r'('+re.escape(name)+r'\?v=)[^" ]+',r'\g<1>24.356',s)
   if n!=1:raise RuntimeError('Expected versioned '+name+' script in Quest')
  s,n=re.subn(r'(\.\./trading-cards-base\.js\?v=)[^" ]+',r'\g<1>24.356',s)
  if n!=1:raise RuntimeError('Quest trading cards script query missing')
  s=swap(s,'</body>', '  <script src="js/shared-families-v356.js?v=24.356"></script>\n</body>','register shared species')
 if rel=='index.html':
  s,n=re.subn(r'(trading-cards-base\.js\?v=)[^" ]+',r'\g<1>24.356',s)
  if n!=1:raise RuntimeError('Hub trading cards script query missing')
 put(rel,s)
# main page references the updated service-worker cache and code with new revision
s=read('index.html')
s=re.sub(r'(navigator\.serviceWorker\.register\("\./sw\.js\?v=)[^"\n]+',r'\g<1>24-356-big-update',s)
put('index.html',s)
s=read('sw.js')
s=re.sub(r"(duck-habit-hub-(?:media|app)-v24-)(?:\d+)[^']*",lambda m:m.group(1)+'356',s)
s=s.replace('24.355','24.356').replace('24-355','24-356')
put('sw.js',s)
put('version.json',json.dumps({'version':'24.356'},indent=2)+'\n')
print('Ducky Days v24.356 source patch complete')

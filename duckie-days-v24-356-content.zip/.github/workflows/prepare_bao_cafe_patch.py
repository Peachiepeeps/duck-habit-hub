#!/usr/bin/env python3
"""Idempotent, in-repository patch for upcoming Ducky Days big update.

Run: python prepare_bao_cafe_patch.py PATH_TO_GAME_ROOT PATH_TO_NEW_ART_ZIP
Does not change save files, version metadata or live deployment.
"""
import json,re,sys,zipfile
from pathlib import Path

if len(sys.argv)!=3: raise SystemExit('Usage: prepare_bao_cafe_patch.py ROOT ART_ZIP')
root=Path(sys.argv[1]); art_zip=Path(sys.argv[2]); html_path=root/'bao-cafe/index.html'; li_path=root/'duck-quest/js/love-interests-v326.js'
html=html_path.read_text(encoding='utf-8')

def obj(name):
 m=re.search(r'(?m)^(const '+re.escape(name)+r'\s*=\s*)([^\n]*)(;\s*)$',html)
 if not m: raise RuntimeError(f'Missing object {name}')
 return m,json.loads(m.group(2))

def update_obj(name, transform):
 global html
 m,v=obj(name);transform(v)
 encoded=json.dumps(v,ensure_ascii=True,separators=(',',':'))
 if name=='STATIONS_RAW': encoded=encoded.replace('<',r'\u003c').replace('>',r'\u003e').replace('&',r'\u0026')
 html=html[:m.start(2)]+encoded+html[m.end(2):]

color_names=obj('FINISH_COLOR_NAMES')[1]
by_color={name:key for key,name in color_names.items()}

def hexes(names):
 missing=[n for n in names if n not in by_color]
 if missing: raise RuntimeError(f'Missing color swatches: {missing}')
 return list(dict.fromkeys(by_color[n] for n in names))

pink=['Strawberry Milk','Bubblegum','Pink','Rose','Sakura','Rose Gold','Cotton Candy']
blue=['Sky Blue','Ocean','Blueberry','Periwinkle','Twilight']
black=['Charcoal','Midnight Black']
green=['Pistachio','Matcha','Mint','Seafoam','Jade']
red=['Scarlet','Cherry Red','Crimson','Burgundy']
yellow=['Buttercream','Lemon Drop']

prefs={
 'Bubble':dict(bases=['milkTea','milkshake','smoothie'],flavors=['Strawberry','Cherry','Blue-raspberry'],toppings=['raspberry','crystal','whipped'],colors=hexes(pink+blue+black)),
 'Shin':dict(bases=['blackTea','greenTea','soda'],flavors=['Apple','Blue-raspberry','Matcha','Peppermint'],toppings=['aloe','coconut','cheese'],colors=hexes(blue+green+red)),
 'Quackers':dict(bases=['milkshake','greenTea','lemonade'],flavors=['Lemon','Banana','Vanilla','Honey'],toppings=['whipped','pudding','honey'],colors=hexes(yellow+blue+['Marshmallow']))
}

bases=obj('BASE_NAMES')[1];flavors=obj('FLAVOR_NAMES')[1];toppings=obj('TOPPING_NAMES')[1]
for name,cfg in prefs.items():
 for key,allowed in [('bases',bases),('flavors',flavors),('toppings',toppings)]:
  assert set(cfg[key]).issubset(allowed), (name,key,set(cfg[key])-set(allowed))

update_obj('CAFE_FAVORITES',lambda d:d.update(prefs))
new_customers=[
 dict(name='Bubble',idle1='../duck-quest/assets/love-interests/bubble/Bubble-idle-1.png',idle2='../duck-quest/assets/love-interests/bubble/Bubble-idle-2.png'),
 dict(name='Shin',idle1='../duck-quest/assets/love-interests/shin/Shin-idle-1.png',idle2='../duck-quest/assets/love-interests/shin/Shin-idle-2.png'),
 dict(name='Quackers',idle1='../duck-quest/assets/gimmicks/quackers/Quackers-idle-1.png',idle2='../duck-quest/assets/gimmicks/quackers/Quackers-idle-2.png')
]
def update_customers(items):
 for item in items:
  if item['name']=='Midori':
   item['idle1']='../duck-quest/assets/love-interests/midori/Midori-opened.png'
   item['idle2']=item['idle1']
 for c in new_customers:
  if not any(x['name']==c['name'] for x in items):items.append(c)
update_obj('CAFE_EXTRA_CUSTOMERS',update_customers)

# Preview/results: synchronize soda effect's bounds and alpha mask with the
# actual liquid fill; clipping solely to the cup leaves bubbles above liquid.
needle="if(liquid){const mask=getComputedStyle(liquid).webkitMaskImage || getComputedStyle(liquid).maskImage; if(mask && mask!=='none'){effect.style.webkitMaskImage=mask;effect.style.maskImage=mask;effect.style.webkitMaskSize='100% 100%';effect.style.maskSize='100% 100%';effect.style.webkitMaskRepeat='no-repeat';effect.style.maskRepeat='no-repeat';}}"
repl="""if(liquid){
    const style=getComputedStyle(liquid);
    for(const prop of ['left','right','top','bottom','transform','clipPath']){
      effect.style[prop]=style[prop];
    }
    const shape=style.webkitMaskImage!=='none'?style.webkitMaskImage:style.maskImage;
    effect.style.webkitMaskImage=shape||'none';effect.style.maskImage=shape||'none';
    effect.style.webkitMaskSize=style.webkitMaskSize||'100% 100%';
    effect.style.maskSize=style.maskSize||'100% 100%';
    effect.style.webkitMaskPosition=style.webkitMaskPosition||'center';
    effect.style.maskPosition=style.maskPosition||'center';
    effect.style.webkitMaskRepeat='no-repeat';effect.style.maskRepeat='no-repeat';
    effect.style.overflow='hidden';
  }"""
if needle in html:html=html.replace(needle,repl,1)
elif 'const style=getComputedStyle(liquid);' not in html:raise RuntimeError('Could not locate root soda effect geometry code')

# Four animated station templates are inline in STATIONS_RAW.
# Their previous soda layers were positioned over the full cup. Match the
# real liquid's bounding box AND its alpha/clip mask instead.
station_marker='const shape=liquid.tagName===\'IMG\'?`url("${liquid.src}")`:(getComputedStyle(liquid).webkitMaskImage||getComputedStyle(liquid).maskImage);\n    if(shape&&shape!==\'none\'){fizz.style.webkitMaskImage=shape;fizz.style.maskImage=shape;}'
st_replacement="""const style=getComputedStyle(liquid);
    const r=liquid.getBoundingClientRect(), p=fizz.parentElement.getBoundingClientRect();
    fizz.style.left=(r.left-p.left)+'px';fizz.style.top=(r.top-p.top)+'px';
    fizz.style.width=r.width+'px';fizz.style.height=r.height+'px';
    fizz.style.right='auto';fizz.style.bottom='auto';fizz.style.transform='none';
    fizz.style.clipPath=style.clipPath;
    const shape=liquid.tagName==='IMG'?`url("${liquid.currentSrc||liquid.src}")`:
       (style.webkitMaskImage!=='none'?style.webkitMaskImage:style.maskImage);
    fizz.style.webkitMaskImage=shape&&shape!=='none'?shape:'none';
    fizz.style.maskImage=shape&&shape!=='none'?shape:'none';
    fizz.style.webkitMaskSize='100% 100%';fizz.style.maskSize='100% 100%';
    fizz.style.webkitMaskPosition='center';fizz.style.maskPosition='center';
    fizz.style.webkitMaskRepeat='no-repeat';fizz.style.maskRepeat='no-repeat';
    fizz.style.overflow='hidden';"""

def update_stations(d):
 for name in ('sweetness','flavor','ice','toppings'):
  stage=d[name]
  if station_marker in stage:
   d[name]=stage.replace(station_marker,st_replacement,1)
  elif "const r=liquid.getBoundingClientRect()" not in stage:
   raise RuntimeError(f'Could not locate soda layer in {name}')
update_obj('STATIONS_RAW',update_stations)

html_path.write_text(html,encoding='utf-8')

# Midori opens once and then remains in open pose for all idle animation.
li=li_path.read_text(encoding='utf-8')
needle='idle2: "assets/love-interests/midori/Midori-closed.png",'
replacement='idle2: "assets/love-interests/midori/Midori-opened.png",'
if needle in li:li=li.replace(needle,replacement,1)
elif replacement not in li:raise RuntimeError('Missing Midori sprite definition')
li_path.write_text(li,encoding='utf-8')

# Art shipped with this user's new-creature upload. Other new enemy/card files
# remain for the forthcoming combined installer.
art_files={
 'Bubble-idle-1.png':'duck-quest/assets/love-interests/bubble/Bubble-idle-1.png',
 'Bubble-idle-2.png':'duck-quest/assets/love-interests/bubble/Bubble-idle-2.png',
 'Shin-idle-1.png':'duck-quest/assets/love-interests/shin/Shin-idle-1.png',
 'Shin-idle-2.png':'duck-quest/assets/love-interests/shin/Shin-idle-2.png',
 'Quackers-idle-1.png':'duck-quest/assets/gimmicks/quackers/Quackers-idle-1.png',
 'Quackers-idle-2.png':'duck-quest/assets/gimmicks/quackers/Quackers-idle-2.png'
}
with zipfile.ZipFile(art_zip) as z:
 for filename,dest in art_files.items():
  path=root/dest
  path.parent.mkdir(parents=True,exist_ok=True)
  path.write_bytes(z.read(filename))

print('Prepared Bao Cafe: 3 new customers, 3 preference tables, Midori opened pose, soda effect geometry.')

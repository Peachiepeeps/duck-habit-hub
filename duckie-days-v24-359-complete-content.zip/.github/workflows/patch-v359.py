#!/usr/bin/env python3
"""Incremental Ducky Days v24.359 update from v24.358, no save resets."""
from pathlib import Path
import sys,json,re
R=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def read(p):return (R/p).read_text(encoding='utf8')
def put(p,s):
 q=R/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s,encoding='utf8')
def rep(s,b,a,where,number=1):
 found=s.count(b)
 if found!=number:raise RuntimeError(f'{where}: expected {number} matches for {b[:100]!r}, found {found}')
 return s.replace(b,a,number)
def add(s,needle,more,where):return rep(s,needle,needle+more,where)
version=json.loads(read('version.json')).get('version')
if version!='24.358':raise RuntimeError(f'Expected version 24.358, got {version!r}')

# 1. Annika, Lain, Tamao Hub assets/outfits
p='app.js';s=read(p)
s=add(s,'const DUCKS = {\n', '''  "lain-duck": {name:"Lain Duck",file:"duck-quest/assets/love-interests/lain/Lain-duck.png",acquisition:"love-interest-lain"},
  "tamao-duck": {name:"Tamao Duck",file:"duck-quest/assets/love-interests/tamao/Tamao-Duck.png",acquisition:"love-interest-tamao"},
''',p)
s=rep(s,'"shin-duck", "bubble-duck"]','"shin-duck", "bubble-duck", "lain-duck", "tamao-duck"]',p)
new_assets=[
 ('annika-casual-bow','Casual Cute Bow','Annika-Casual-Cute-Bow.webp',7,None),
 ('annika-casual-dress','Casual Cute Dress','Annika-Casual-Cute-Dress.webp',32,None),
 ('annika-casual-shoes','Casual Cute Shoes','Annika-Casual-Cute-shoes.webp',25,None),
 ('annika-school-buns','School Buns','Annika-School-buns.webp',8,None),
 ('annika-school-socks','School Socks','Annika-School-Socks.webp',24,None),
 ('annika-school-sneakers','School Sneakers','Annika-School-Sneakers.webp',25,None),
 ('annika-school-uniform','School Uniform','Annika-School-Uniform.webp',31,None),
 ('annika-school-hoodie','School Hoodie','Annika-School-Hoodie.webp',33,'Annika-School-Hoodie-shop.webp')]
assets=''.join('  '+json.dumps(i)+': {label:'+json.dumps(name)+',file:'+json.dumps(fn)+',z:'+str(z)+((',previewFile:'+json.dumps(preview)) if preview else '')+'},\n' for i,name,fn,z,preview in new_assets)
s=add(s,'const ANNIKA_ASSETS = {\n',assets,p)
# Date pigtails must coexist with long hair (behind it), including old saves.
s=rep(s,'{ id: "hair", label: "Hair", type: "hair", options: ["hair-long", "hair-ponytail", "annika-date-pigtails"] },',
    '{ id: "hair", label: "Hair", type: "hair", options: ["hair-long", "hair-ponytail"] },\n  { id: "backPigtails", label: "Back Pigtails", type: "single", allowNone: true, options: ["annika-date-pigtails"] },\n  { id: "schoolBuns", label: "School Buns", type: "single", allowNone: true, options: ["annika-school-buns"] },',p)
s=rep(s,'options: ["back-hair-ribbon"]','options: ["back-hair-ribbon", "annika-casual-bow"]',p)
s=rep(s,'options: ["outer-sweater", "outer-bow-sweater", "annika-date-sweater"]','options: ["outer-sweater", "outer-bow-sweater", "annika-date-sweater", "annika-school-hoodie"]',p)
s=rep(s,'options: ["dress-leotard", "annika-lingerie-babydoll"]','options: ["dress-leotard", "annika-lingerie-babydoll", "annika-casual-dress", "annika-school-uniform"]',p)
s=rep(s,'"annika-lingerie-stockings", "annika-date-stockings"]','"annika-lingerie-stockings", "annika-date-stockings", "annika-school-socks"]',p)
s=rep(s,'"shoes-folded-booties", "annika-date-heels"]','"shoes-folded-booties", "annika-date-heels", "annika-casual-shoes", "annika-school-sneakers"]',p,number=2)
s=rep(s,'  if (!["hair-long", "hair-ponytail", "annika-date-pigtails"].includes(normalized.hair)) normalized.hair = "hair-long";',
'''  // Carry forward saves where Date Pigtails were previously the hair choice.
  if (normalized.hair === "annika-date-pigtails") {
    normalized.hair="hair-long";
    normalized.backPigtails="annika-date-pigtails";
  }
  if (!["hair-long", "hair-ponytail"].includes(normalized.hair)) normalized.hair = "hair-long";
  if (![null, "annika-date-pigtails"].includes(normalized.backPigtails)) normalized.backPigtails=null;
  if (![null, "annika-school-buns"].includes(normalized.schoolBuns)) normalized.schoolBuns=null;''',p)
s=rep(s,'[null, "back-hair-ribbon"].includes(incoming.backHairBow)', '[null, "back-hair-ribbon", "annika-casual-bow"].includes(incoming.backHairBow)',p)
s=rep(s,'[null, "outer-sweater", "outer-bow-sweater", "annika-date-sweater"].includes(normalized.outer)','[null, "outer-sweater", "outer-bow-sweater", "annika-date-sweater", "annika-school-hoodie"].includes(normalized.outer)',p)
s=rep(s,'[null, "dress-leotard", "annika-lingerie-babydoll"].includes(normalized.dress)','[null, "dress-leotard", "annika-lingerie-babydoll", "annika-casual-dress", "annika-school-uniform"].includes(normalized.dress)',p)
s=rep(s,'"annika-date-stockings", "annika-lingerie-stockings"].includes(normalized.legwear)','"annika-date-stockings", "annika-lingerie-stockings", "annika-school-socks"].includes(normalized.legwear)',p)
s=rep(s,'"hair-long", "hair-ponytail", "annika-date-pigtails",','"annika-date-pigtails", "annika-school-buns", "hair-long", "hair-ponytail",',p)
s=rep(s,'"back-hair-ribbon",\n      "annika-date-pigtails"','"back-hair-ribbon",\n      "annika-date-pigtails"',p,number=0) if False else s
s=rep(s,'"back-hair-ribbon",\n      "annika-date-pigtails",', '"back-hair-ribbon",\n      "annika-date-pigtails",',p,number=0) if False else s
# Move bow behind hair (while still supporting existing bow layering).
s=rep(s,'"back-hair-ribbon",\n      "annika-date-pigtails", "annika-school-buns", "hair-long", "hair-ponytail",',
        '"back-hair-ribbon", "annika-casual-bow",\n      "annika-date-pigtails", "annika-school-buns", "hair-long", "hair-ponytail",',p)
s=rep(s,'"annika-lingerie-stockings", "annika-date-stockings",\n      "shoes-sneakers",','"annika-lingerie-stockings", "annika-date-stockings", "annika-school-socks",\n      "shoes-sneakers",',p)
s=rep(s,'"shoes-folded-booties", "annika-date-heels",\n      "bottom-shorts", "annika-lingerie-bottoms", "annika-date-skirt",','"shoes-folded-booties", "annika-date-heels", "annika-casual-shoes", "annika-school-sneakers",\n      "bottom-shorts", "annika-lingerie-bottoms",',p)
s=rep(s,'"dress-leotard", "annika-lingerie-babydoll",\n      "outer-sweater", "outer-bow-sweater", "annika-date-sweater",','"dress-leotard", "annika-lingerie-babydoll", "annika-casual-dress", "annika-school-uniform",\n      "outer-sweater", "outer-bow-sweater", "annika-date-sweater", "annika-school-hoodie",\n      "annika-date-skirt",',p)
# Include special back hair layers in the Hub compositing function.
s=rep(s,'  if (outfit.backHairBow) ids.push(outfit.backHairBow);\n  ids.push(outfit.hair);',
        '  if (outfit.backHairBow) ids.push(outfit.backHairBow);\n  if (outfit.backPigtails) ids.push(outfit.backPigtails);\n  if (outfit.schoolBuns) ids.push(outfit.schoolBuns);\n  ids.push(outfit.hair);',p)
# Actual pixel bounds from supplied transparent RGBA artwork, computed at packaging time.
bounds=json.loads((R/'.github/workflows/v359-annika-bounds.json').read_text())
preview_bounds=''.join('  '+json.dumps(k)+': '+json.dumps(v)+',\n' for k,v in bounds.items())
s=add(s,'const ANNIKA_THUMB_BOUNDS = {\n',preview_bounds,p)
# Crop all new wardrobe icons to the alpha bounds, not full 1080x1920 transparent canvas.
put(p,s)

# 2. Trading cards: two new rare Annika LI cards, rare Bownny, and common enemy cards.
p='trading-cards-base.js';s=read(p)
rare='''  cards.push({id:'r-love-lain',characterId:'lain',name:'Lain',art:'love-interests/lain/Lain-idle-1.png',rarity:'rare',number:'R-060',category:'Annika Love Interest',hint:'Meet Lain as Annika.'});
  cards.push({id:'r-love-tamao',characterId:'tamao',name:'Tamao',art:'love-interests/tamao/Tamao-idle-1.png',rarity:'rare',number:'R-061',category:'Annika Love Interest',hint:'Meet Tamao as Annika.'});
  cards.push({id:'r-bownny',name:'Bownny',art:'gimmicks/bownny/base/idle-1.png',rarity:'rare',number:'R-062',category:'Gimmick Encounter',hint:'Meet Bownny in Duck Quest.'});
'''
s=rep(s,'  // City Streets and newly introduced boss/enemy cards.',rare+'  // City Streets and newly introduced boss/enemy cards.',p)
needle='  additionalCardFamilies.forEach(([enemyId,name,area,boss],index)=>{'
s=rep(s,needle,"  additionalCardFamilies.push(['trashcat','Trashcat','City Streets',false],['jellybeanie','Jellybeanie','Candyland',false],['whispurr','Whispurr','Cloud Garden',false],['flame-spirit','Flame Spirit','Spooky Forest',false]);\n"+needle,p)
s=rep(s,"['strawbunny','pudding-snatcher','pancake-ray'].includes(enemyId)","['strawbunny','pudding-snatcher','pancake-ray','trashcat','jellybeanie','whispurr','flame-spirit'].includes(enemyId)",p,number=2)
put(p,s)

# 3. Lain/Tamao scenes and NPC-NPC interactions, with Miko-style pair card reward logic.
p='duck-quest/js/love-interests-v326.js';s=read(p)
chars='''    lain:{name:'Lain',duckId:'lain-duck',cardId:'r-love-lain',sprites:{idle1:'assets/love-interests/lain/Lain-idle-1.png',idle2:'assets/love-interests/lain/Lain-idle-2.png',sigh:'assets/love-interests/lain/Lain-sigh.png'},outfitIds:['annika-casual-bow','annika-casual-dress','annika-casual-shoes']},
    tamao:{name:'Tamao',duckId:'tamao-duck',cardId:'r-love-tamao',sprites:{idle1:'assets/love-interests/tamao/Tamao-idle-1.png',idle2:'assets/love-interests/tamao/Tamao-idle-2.png',sigh:'assets/love-interests/tamao/Tamao-sigh.png'},outfitIds:['annika-school-buns','annika-school-socks','annika-school-sneakers','annika-school-uniform','annika-school-hoodie']},
'''
s=add(s,'  const CHARACTERS = {\n',chars,p)
scenes=r'''    lain:{id:'lain',title:'Lain',kicker:'ANNIKA LOVE INTEREST',leftId:'annika',rightId:'lain',kitties:true,dialogue:[
      {speaker:'Annika',text:'L-Lain, are you okay?'},
      {speaker:'Lain',text:'Oh. Yeah. I just met some little kitties… I think they need a home.',rightPose:'idle'},
      {speaker:'Annika',text:'Awww, they really like you! That’s so sweet.'},
      {speaker:'Lain',text:'You’re not bothered when I bring home animals?',rightPose:'sigh'},
      {speaker:'Annika',text:'Not at all. I mean, you make enough to house them, and you do get them to loving homes. I think it’s sweet.'},
      {speaker:'Lain',text:'Thank you. That makes me feel much better.',rightPose:'idle'},
      {speaker:'Annika',text:'Not a problem at all! Can I help name them?'},
      {speaker:'Lain',text:'Sure, let’s head home and we can name them there. Oh, here… for you.'},
      {speaker:'Annika',text:'Oh! Thank you!!'}
    ],reward(){const data=load();unlockCharacter(data,'lain',{grantCard:false,grantDuck:true,grantOutfit:true});save(data);notifyUnlock('lain');}},
    tamao:{id:'tamao',title:'Tamao',kicker:'ANNIKA LOVE INTEREST',leftId:'annika',rightId:'tamao',dialogue:[
      {speaker:'Tamao',text:'Oh, there you are. Hello.'},
      {speaker:'Annika',text:'Tamao! What was with the gift you gave Shin to give me?!'},
      {speaker:'Tamao',text:'I thought it’d look good on you.'},
      {speaker:'Annika',text:'And why didn’t you just give it to me yourself?'},
      {speaker:'Tamao',text:'Because he irritated me, so I knew it would get him to react. Besides, I assume you used it soooo, what’s the issue?'},
      {speaker:'Annika',text:'Jeez, Tamao, you need to stop fighting with him. I nearly had a panic attack!'},
      {speaker:'Tamao',text:'Sorry, sorry. It’s fine, it’s fine! I just can’t stand that jerk…',rightPose:'sigh'},
      {speaker:'Annika',text:'You two…'},
      {speaker:'Tamao',text:'Here, a nicer gift. I promise it’s not the same as the other.',rightPose:'idle'},
      {speaker:'Annika',text:'Oh? Thank you… Oh, thank goodness, it’s actually cute and sweet… I appreciate this, Tamao.'},
      {speaker:'Tamao',text:'No problem. Let’s go home.'},
      {speaker:'Annika',text:'Alright!'}
    ],reward(){const data=load();unlockCharacter(data,'tamao',{grantCard:false,grantDuck:true,grantOutfit:true});save(data);notifyUnlock('tamao');}},
    'shin-tamao':{id:'shin-tamao',title:'Shin + Tamao',kicker:'LOVERS REUNITE',leftId:'shin',rightId:'tamao',dialogue:[
      {speaker:'Shin',text:'YOU!',leftPose:'blush'},
      {speaker:'Tamao',text:'Oho, someone looks angry…'},
      {speaker:'Shin',text:'I swear to god, Tamao, you did that on purpose!',leftPose:'blush'},
      {speaker:'Tamao',text:'I don’t know what you’re talking about.',rightPose:'idle'},
      {speaker:'Shin',text:'You know what you did! That… That gift you gave me to give to Annika!'},
      {speaker:'Tamao',text:'Did you not like it?'},
      {speaker:'Shin',text:'I… That’s beside the point! You KNEW that would fluster me!',leftPose:'blush'},
      {speaker:'Tamao',text:'I did, I never said otherwise.'},
      {speaker:'Shin',text:'You… You are horrible.'},
      {speaker:'Tamao',text:'Good. Suffer.'},
      {speaker:'Shin',text:'UGH. Let’s just go home.'},
      {speaker:'Tamao',text:'Oh, okay, buy me a drink on the way back.'},
      {speaker:'Shin',text:'Jeez, fine.'}
    ],reward(){const data=load(),root=ensureAll(data);unlockCardsOnly(data,['shin','tamao']);root.pairScenes.shinTamao={seen:true,cardsGranted:true};save(data);notifyUnlock('shin-tamao');}},
    'bubble-lain':{id:'bubble-lain',title:'Bubble + Lain',kicker:'LOVERS REUNITE',leftId:'bubble',rightId:'lain',dialogue:[
      {speaker:'Bubble',text:'Laiiinnn! Hello, my love.',leftPose:'happy'},
      {speaker:'Lain',text:'Oh, hello Bubble… Were you looking for me?'},
      {speaker:'Bubble',text:'Yeah, I missed you.'},
      {speaker:'Lain',text:'Oh, I’m sorry. I was busy at work…',rightPose:'sigh'},
      {speaker:'Bubble',text:'It’s okay! It’s time to take a break though.'},
      {speaker:'Lain',text:'I suppose…'},
      {speaker:'Bubble',text:'Yes, I insist! You overwork yourself if not!'},
      {speaker:'Lain',text:'Thank you. You always worry so much for me, I feel bad.'},
      {speaker:'Bubble',text:'Please don’t. I love taking care of you. You’re my soulmate. It is never an inconvenience.',leftPose:'happy'},
      {speaker:'Lain',text:'I appreciate it… I love you.',rightPose:'idle'},
      {speaker:'Bubble',text:'I love you too, hun!',leftPose:'happy'},
      {speaker:'Lain',text:'Let’s go home… I want a nap.',rightPose:'sigh'},
      {speaker:'Bubble',text:'Yes, sir! Hehe…',leftPose:'happy'}
    ],reward(){const data=load(),root=ensureAll(data);unlockCardsOnly(data,['bubble','lain']);root.pairScenes.bubbleLain={seen:true,cardsGranted:true};save(data);notifyUnlock('bubble-lain');}},
'''
s=add(s,'  const SCENES = {\n',scenes,p)
# Pair state and save migration; never erase previous states.
s=add(s,'    data.loveInterestPairs = data.loveInterestPairs && typeof data.loveInterestPairs === "object" ? data.loveInterestPairs : {};\n',
'''    data.loveInterestPairs.shinTamao = data.loveInterestPairs.shinTamao && typeof data.loveInterestPairs.shinTamao === "object" ? data.loveInterestPairs.shinTamao : {};
    data.loveInterestPairs.bubbleLain = data.loveInterestPairs.bubbleLain && typeof data.loveInterestPairs.bubbleLain === "object" ? data.loveInterestPairs.bubbleLain : {};
''',p)
s=rep(s,'"jenson", "shin", "bubble"]','"jenson", "shin", "bubble", "lain", "tamao"]',p,number=2)
s=rep(s,"const target=key==='shin'||key==='bubble'?data.characterUnlockedItems.annika:data.characterUnlockedItems.miko;", "const target=['shin','bubble','lain','tamao'].includes(key)?data.characterUnlockedItems.annika:data.characterUnlockedItems.miko;",p)
s=rep(s,"const outfit=scene.id==='shin'?'Annika’s Lingerie Outfit':scene.id==='bubble'?'Annika’s Date Outfit':`Miko’s ${scene.title} Outfit`;", "const outfit=scene.id==='shin'?'Annika’s Lingerie Outfit':scene.id==='bubble'?'Annika’s Date Outfit':scene.id==='lain'?'Annika’s Casual Cute Outfit':scene.id==='tamao'?'Annika’s School Outfit':`Miko’s ${scene.title} Outfit`;",p)
s=rep(s,"for(const name of ['shin','bubble'])if(!root.loveInterests[name].encountered)ids.push(name);\n      return ids.length?ids:['shin','bubble']; // Repeat encounters: duck + card, never reaward outfit.",
'''for(const name of ['shin','bubble','lain','tamao'])if(!root.loveInterests[name].encountered)ids.push(name);
      if(root.loveInterests.shin.encountered&&root.loveInterests.tamao.encountered&&!root.pairScenes.shinTamao.cardsGranted)ids.push('shin-tamao');
      if(root.loveInterests.bubble.encountered&&root.loveInterests.lain.encountered&&!root.pairScenes.bubbleLain.cardsGranted)ids.push('bubble-lain');
      return ids.length?ids:['shin','bubble','lain','tamao']; // Repeat encounters: duck + card, never reaward outfit.''',p)
s=rep(s,'      ["morikoJenson", ["moriko", "jenson"]]', '      ["morikoJenson", ["moriko", "jenson"]],\n      ["shinTamao", ["shin", "tamao"]],\n      ["bubbleLain", ["bubble", "lain"]]',p)
s=rep(s,"  window.triggerShinEncounter = function(){return showScene('shin');};",'''  window.triggerLainEncounter = function(){return showScene('lain');};
  window.triggerTamaoEncounter = function(){return showScene('tamao');};
  window.triggerShinTamaoCutscene = function(){return showScene('shin-tamao');};
  window.triggerBubbleLainCutscene = function(){return showScene('bubble-lain');};
  window.triggerShinEncounter = function(){return showScene('shin');};''',p)
# Lain background kitty trio: based on current world, variants randomized and layered BEHIND Lain.
kitty_fx=r'''  function sceneKitties(state){
    state.el.querySelectorAll('.lain-rescue-kitty-v359').forEach(node=>node.remove());
    if(!state.scene.kitties)return;
    const area=String((typeof currentRun!=='undefined'&&currentRun?.area)|| (typeof selectedArea!=='undefined'?selectedArea:'meadow'));
    const pool={
      meadow:['assets/enemies/cat-slime/base/idle-1-neutral.webp','assets/enemies/cat-slime/base/Green-idle-1-neutral.webp','assets/enemies/cat-slime/base/Strawberry-idle-1-neutral.webp'],
      ocean:['assets/enemies/catfish/base/idle-1.webp','assets/enemies/catfish/base/Orange-idle-1.webp','assets/enemies/catfish/base/Brown-idle-1.webp'],
      spooky:['assets/enemies/pumpkitty/base/idle-1.webp','assets/enemies/pumpkitty/base/pink-idle-1.webp','assets/enemies/pumpkitty/base/gold-idle-1.webp'],
      city:['assets/enemies/trashcat/base/idle-1.webp','assets/enemies/trashcat/base/blue-idle-1.webp','assets/enemies/trashcat/base/orange-idle-1.webp'],
      candy:['assets/enemies/jellybeanie/base/idle-1.webp','assets/enemies/jellybeanie/base/lime-idle-1.webp','assets/enemies/jellybeanie/base/grape-idle-1.webp'],
      cloud:['assets/enemies/whispurr/base/idle-1.webp','assets/enemies/whispurr/base/pink-idle-1.webp','assets/enemies/whispurr/base/purple-idle-1.webp']
    };
    const options=[...(pool[area]||pool.meadow)].sort(()=>Math.random()-.5);
    if(Math.random()<.16)options[Math.floor(Math.random()*3)]='assets/enemies/mimic/base/open-1.webp';
    options.slice(0,3).forEach((src,i)=>{
      const img=document.createElement('img');img.className='lain-rescue-kitty-v359';img.alt='One of Lain’s rescued kittens';img.src=src;
      img.style.setProperty('--kitty-index',i);img.style.left=`${33+i*9}%`;
      state.el.insertBefore(img,state.right);
    });
  }

'''
s=rep(s,'  function showScene(sceneId, onFinished){',kitty_fx+'  function showScene(sceneId, onFinished){',p)
s=rep(s,'    state.right.onload = () => sizeSceneSprite(state.right);','    state.right.onload = () => sizeSceneSprite(state.right);\n    sceneKitties(state);',p)
s=rep(s,'          state.heart.classList.add("hidden");\n          el.classList.add("hidden");','          state.heart.classList.add("hidden");\n          el.querySelectorAll(".lain-rescue-kitty-v359").forEach(node=>node.remove());\n          el.classList.add("hidden");',p)
put(p,s)

# 4. Bownny: share Sock Gremlin's actual fashion-challenge save and return path.
p='duck-quest/js/sock-gremlin-v297.js';s=read(p)
s=rep(s,'function sprite(variant,frame=1){return `assets/gimmicks/sock-gremlin/${variant}/idle-${frame}.png`;}','function sprite(variant,frame=1,source="sock-gremlin"){return `assets/gimmicks/${source}/${variant}/idle-${frame}.png`;} ',p)
s=rep(s,"function chooseVariant(){const shiny=Math.random()<currentShinyRate(),id=shiny?\"shiny\":pick(NORMAL_VARIANTS),names={base:\"Sock Gremlin\",blue:\"Blue Sock Gremlin\",pink:\"Pink Sock Gremlin\",black:\"Black Sock Gremlin\",gold:\"Gold Sock Gremlin\",shiny:\"Shiny Sock Gremlin ✨\"};return{id,shiny,name:names[id]||\"Sock Gremlin\"};}",
'''function chooseVariant(source="sock-gremlin"){
    const variants=source==='bownny'?['base','blue','purple','yellow','mint']:NORMAL_VARIANTS;
    const shiny=Math.random()<currentShinyRate(),id=shiny?'shiny':pick(variants);
    const family=source==='bownny'?'Bownny':'Sock Gremlin';
    return {id,shiny,name:id==='base'?family:id==='shiny'?`Shiny ${family} ✨`:`${id[0].toUpperCase()+id.slice(1)} ${family}`};
  }''',p)
s=rep(s,'function beginFashionChallenge(variant){','function beginFashionChallenge(variant,source="sock-gremlin"){',p)
s=rep(s,'previousHubCharacter:hubSave.selectedCharacter||"peep",variant:variant.id,', 'previousHubCharacter:hubSave.selectedCharacter||"peep",source,variant:variant.id,',p)
s=rep(s,'    const variant=chooseVariant();api.animateScene([sprite(variant.id,1),sprite(variant.id,2)],390);','    const source=api.bownny?"bownny":"sock-gremlin";\n    const variant=chooseVariant(source);api.animateScene([sprite(variant.id,1,source),sprite(variant.id,2,source)],390);',p)
s=rep(s,'Sock Gremlin demands that Miko prove his fashion sense.', '${source===\'bownny\'?\'Bownny\':\'Sock Gremlin\'} demands that Miko prove his fashion sense.',p)
s=rep(s,'()=>beginFashionChallenge(variant)','()=>beginFashionChallenge(variant,source)',p)
s=rep(s,'api.finish("Sock Gremlin stuffs a sock into its bag and scampers away.")','api.finish(`${variant.name} waves and hops away.`)',p)
s=rep(s,'function startReturnIdle(variant){','function startReturnIdle(variant,source="sock-gremlin"){',p)
s=rep(s,'setQuestSpriteFrame(ui.chestSprite,sprite(variant,1));','setQuestSpriteFrame(ui.chestSprite,sprite(variant,1,source));',p)
s=rep(s,'setQuestSpriteFrame(ui.chestSprite,sprite(variant,frame));','setQuestSpriteFrame(ui.chestSprite,sprite(variant,frame,source));',p)
s=rep(s,'if(TC?.byId?.["r-sock-gremlin"]&&Math.random()<cardChance){cardResult=TC.grantCard(hubSave,"r-sock-gremlin",1);if(cardResult)bonus.push(`${cardResult.isNew?"NEW ":""}Sock Gremlin Trading Card`);}',
'''const cardId=c.source==='bownny'?'r-bownny':'r-sock-gremlin';
    if(TC?.byId?.[cardId]&&Math.random()<cardChance){cardResult=TC.grantCard(hubSave,cardId,1);if(cardResult)bonus.push(`${cardResult.isNew?"NEW ":""}${c.source==='bownny'?'Bownny':'Sock Gremlin'} Trading Card`);}''',p)
a=s.index('  function catchEnemy(c){');b=s.index('\n  function clearJudgeUi()',a)
s=s[:a]+'''  function catchEnemy(c){
    const v=c.variant||'base',source=c.source==='bownny'?'bownny':'sock-gremlin';
    const family=source==='bownny'?'Bownny':'Sock Gremlin';
    return {id:source,name:v==='base'?family:v==='shiny'?`Shiny ${family} ✨`:`${v[0].toUpperCase()+v.slice(1)} ${family}`,
      idle:[sprite(v,1,source),sprite(v,2,source)],hurt:`assets/gimmicks/${source}/${v}/hurt.png`,shiny:Boolean(c.shiny),boss:false,gimmickVariant:v,maxHp:1,hpNow:1};
  }'''+s[b:]
s=rep(s,'startReturnIdle(c.variant||"base");','startReturnIdle(c.variant||"base",c.source||"sock-gremlin");',p)
s=rep(s,'setMessage(`Sock Gremlin judges Miko\'s outfit… ${rating} ${hearts}`);','setMessage(`${c.source===\'bownny\'?\'Bownny\':\'Sock Gremlin\'} judges Miko\'s outfit… ${rating} ${hearts}`);',p)
put(p,s)
p='duck-quest/js/gimmick-encounters-v288.js';s=read(p)
s=rep(s,'"sock-gremlin","ufono","quackers"]','"sock-gremlin","bownny","ufono","quackers"]',p)
s=rep(s,"else if(kind==='sock-gremlin')window.DuckieSockGremlinV297?.show?.({animateScene,menu,button,finish});", "else if(kind==='sock-gremlin'||kind==='bownny')window.DuckieSockGremlinV297?.show?.({animateScene,menu,button,finish,bownny:kind==='bownny'});",p)
s=rep(s,"GIMMICKS.filter(id=>id!=='sock-gremlin')", "GIMMICKS.filter(id=>id!=='sock-gremlin'&&id!=='bownny')",p)
put(p,s)

# Bownny uses the same Hub fashion challenge, with the right character as judge.
p='sock-gremlin-fashion-v297.js';s=read(p)
s=rep(s,'  function addChallengeUi(c){',
       '  function addChallengeUi(c){\n    const judge=c.source===\'bownny\'?\'Bownny\':\'Sock Gremlin\';',p)
s=rep(s,'banner.setAttribute("aria-label","Sock Gremlin fashion challenge");',
        'banner.setAttribute("aria-label",`${judge} fashion challenge`);',p)
s=rep(s,'eyebrow.textContent="SOCK GREMLIN FASHION BATTLE";',
        'eyebrow.textContent=`${judge.toUpperCase()} FASHION BATTLE`;',p)
s=rep(s,'done.textContent="Back to Sock Gremlin…";',
        'done.textContent=`Back to ${state.source===\'bownny\'?\'Bownny\':\'Sock Gremlin\'}…`;',p)
put(p,s)
p='index.html';s=read(p)
s,n=re.subn(r'(sock-gremlin-fashion-v297\.js\?v=)[^"\']+',r'\g<1>24.359',s)
if n!=1:raise RuntimeError(f'{p}: missing Hub fashion script version ({n})')
s=rep(s,'app.js?v=24.356','app.js?v=24.359',p)
s=rep(s,'trading-cards-base.js?v=24.357','trading-cards-base.js?v=24.359',p)
s=rep(s,'sw.js?v=24-357-card-cafe-fix','sw.js?v=24-359-content',p)
put(p,s)

# 5. Spooky Forest Miss Wick: one nonpersistent flame-spirit summon attack animation per fight.
p='duck-quest/js/game-v96.js';s=read(p)
old='''  const refs=activeEnemyUi();
  refs.sprite?.classList.add("attack-pop"); await sleep(300);'''
new='''  const refs=activeEnemyUi();
  if(currentEnemy.id==='miss-wick'&&!currentEnemy._summonedFlameV359){
    currentEnemy._summonedFlameV359=true;
    const field=ui.battlefield||document.querySelector('#battlefield');
    if(field){
      const spirit=document.createElement('img');spirit.className='flame-spirit-summon-v359';
      const colors=['','blue-','green-','purple-','grey-'];
      spirit.src='assets/enemies/flame-spirit/base/'+colors[Math.floor(Math.random()*colors.length)]+'idle-1.webp';
      spirit.alt='Miss Wick’s summoned Flame Spirit';field.append(spirit);
      setMessage('Miss Wick summons a tiny Flame Spirit! ✨');
      await sleep(700);spirit.remove();
      if(!currentRun||currentRun.hp<=0)return 0;
    }
    setMessage(label||`${currentEnemy.name} attacks!`);
  }
  refs.sprite?.classList.add("attack-pop"); await sleep(300);'''
s=rep(s,old,new,p)
put(p,s)

# 6. City before Spooky, enemy flips, animated rescue kitties, load extra enemy module.
p='duck-quest/index.html';s=read(p)
city='''          <button class="area-option city-area-option" data-area="city" type="button">
            <img class="area-option-image pixel-background" src="assets/backgrounds/city/stage-1.png" alt="City Streets preview" loading="lazy" decoding="async" />
            <span class="area-option-copy"><strong>City Streets</strong><small>Levels 1–200</small></span>
          </button>'''
spooky='''          <button class="area-option spooky-area-option" data-area="spooky" type="button">
            <img class="area-option-image pixel-background" src="assets/backgrounds/spooky/stage-1.webp" alt="Spooky Forest preview" loading="lazy" decoding="async" />
            <span class="area-option-copy"><strong>Spooky Forest</strong><small>Levels 1–240</small></span>
          </button>'''
s=rep(s,spooky+'\n'+city,city+'\n'+spooky,p)
# Also switch Duckipedia filter ordering.
s=rep(s,'<button class="buddy-filter" data-buddy-filter="spooky" type="button">Spooky Forest</button>\n          <button class="buddy-filter" data-buddy-filter="city" type="button">City Streets</button>',
        '<button class="buddy-filter" data-buddy-filter="city" type="button">City Streets</button>\n          <button class="buddy-filter" data-buddy-filter="spooky" type="button">Spooky Forest</button>',p)
styles='''<style id="v24359-enemy-facing-kitty-summon">
img[src*="enemies/puffer/"],img[src*="enemies/star-glider/"],img[src*="enemies/asterfox/"]{scale:-1 1}
.love-interest-battle-scene .lain-rescue-kitty-v359{position:absolute;z-index:0;width:13%;max-width:77px;bottom:5%;height:auto;object-fit:contain;image-rendering:pixelated;animation:lainKittyBobV359 1s ease-in-out infinite alternate;animation-delay:calc(var(--kitty-index)*-.2s);pointer-events:none}
.love-interest-battle-scene .love-interest-battle-sprite{z-index:2}
@keyframes lainKittyBobV359{to{translate:0 -8px}}
.flame-spirit-summon-v359{position:absolute;z-index:75;width:clamp(42px,12%,80px);height:auto;object-fit:contain;image-rendering:pixelated;right:25%;top:28%;pointer-events:none;animation:wickFlameV359 .7s ease-in forwards}
@keyframes wickFlameV359{0%{opacity:0;transform:translate(15px,18px) scale(.35)}30%{opacity:1;transform:translate(0,0) scale(1)}70%{opacity:1;transform:translate(-50px,20px) scale(1.15)}100%{opacity:0;transform:translate(-170px,75px) scale(.4)}}
</style>\n'''
s=rep(s,'</head>',styles+'</head>',p)
s=rep(s,'<script src="js/shared-families-v356.js?v=24.356"></script>', '<script src="js/shared-families-v356.js?v=24.356"></script>\n  <script src="js/extra-content-v359.js?v=24.359"></script>',p)
s=rep(s,'js/love-interests-v326.js?v=24.356','js/love-interests-v326.js?v=24.359',p)
s=rep(s,'js/sock-gremlin-v297.js?v=24.356','js/sock-gremlin-v297.js?v=24.359',p)
s=rep(s,'js/gimmick-encounters-v288.js?v=24.356','js/gimmick-encounters-v288.js?v=24.359',p)
s=rep(s,'js/game-v96.js?v=24.356','js/game-v96.js?v=24.359',p)
s=rep(s,'trading-cards-base.js?v=24.357','trading-cards-base.js?v=24.359',p)
put(p,s)

p='crane-game/play-v24-40.html';s=read(p)
s=rep(s,'trading-cards-base.js?v=24.287','trading-cards-base.js?v=24.359',p)
put(p,s)

# 7. Bao cafe existing customer favorites and animated sprite list.
p='bao-cafe/index.html';s=read(p)
m=re.search(r'(?m)^(const CAFE_FAVORITES = )([^\n]+)(;)$',s)
if not m:raise RuntimeError('Missing CAFE_FAVORITES')
favs=json.loads(m.group(2))
favs['Lain']={'bases':['greenTea','icedCoffee'],'flavors':['Matcha','Apple','Lime'],'toppings':['aloe','cheese','grass'],'colors':[]}
favs['Tamao']={'bases':['milkTea','icedCoffee'],'flavors':['Taro','Lavender','Cherry'],'toppings':['boba','cookie','whipped','coffee'],'colors':[]}
# Colors unspecified for these two; no restriction, not an impossible favorite.
s=s[:m.start(2)]+json.dumps(favs,ensure_ascii=True,separators=(',',':'))+s[m.end(2):]
m=re.search(r'(?m)^(const CAFE_EXTRA_CUSTOMERS = )([^\n]+)(;)$',s)
if not m:raise RuntimeError('Missing CAFE_EXTRA_CUSTOMERS')
customers=json.loads(m.group(2))
for name in ('Lain','Tamao'):
 customers.append({'name':name,'idle1':f'../duck-quest/assets/love-interests/{name.lower()}/{name}-idle-1.png','idle2':f'../duck-quest/assets/love-interests/{name.lower()}/{name}-idle-2.png'})
s=s[:m.start(2)]+json.dumps(customers,ensure_ascii=True,separators=(',',':'))+s[m.end(2):]
s=rep(s,"const favoriteStraw=f.colors.includes(String(detail.strawColor||'').toLowerCase());","const favoriteStraw=!f.colors.length||f.colors.includes(String(detail.strawColor||'').toLowerCase());",p)
s=rep(s,"const favoriteLid=dome||f.colors.includes(String(detail.lidColor||'').toLowerCase());","const favoriteLid=dome||!f.colors.length||f.colors.includes(String(detail.lidColor||'').toLowerCase());",p)
put(p,s)

# 8. Refresh cached script references, preserve previous saved progress.
p='sw.js';s=read(p)
s=rep(s,"const APP_CACHE='duck-habit-hub-app-v24-358';", "const APP_CACHE='duck-habit-hub-app-v24-359';",p)
# Keep previous preload paths; add new script and version changes where already cached.
s,n=re.subn(r"(\./app\.js\?v=)[^']+",r'\g<1>24.359',s)
if n!=1: raise RuntimeError(f'{p}: missing Hub app cache entry')
s,n=re.subn(r"(\./trading-cards-base\.js\?v=)[^']+",r'\g<1>24.359',s)
if n!=1: raise RuntimeError(f'{p}: missing trading card cache entry')
s,n=re.subn(r"(\./sock-gremlin-fashion-v297\.js\?v=)[^']+",r'\g<1>24.359',s)
if n!=1: raise RuntimeError(f'{p}: missing Hub fashion cache script')
# Both older and performance-service-worker layouts are supported; update exact script paths.
for script in ['game-v96.js','love-interests-v326.js','gimmick-encounters-v288.js','sock-gremlin-v297.js']:
    pattern=r"'\./duck-quest/js/"+re.escape(script)+r"\?v=[^']+'"
    updated,n=re.subn(pattern,"'./duck-quest/js/"+script+"?v=24.359'",s)
    if n!=1: raise RuntimeError(f'{p}: expected one cached script {script}, found {n}')
    s=updated
# The new enemy runtime must be cached with the quest shell.
needle="'./duck-quest/js/ufono-v298.js?v="
pos=s.find(needle)
if pos<0:raise RuntimeError('Missing UFONO cache entry to follow')
endline=s.index('\n',pos)
s=s[:endline+1]+" './duck-quest/js/extra-content-v359.js?v=24.359',\n"+s[endline+1:]
put(p,s)
p='version.json';put(p,json.dumps({'version':'24.359'},indent=2)+'\n')
print('v24.359 complete: outfits, scenes, cats, Bownny, Flame Spirit, café favorites, UI and caching')

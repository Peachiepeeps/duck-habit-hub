from pathlib import Path
import json,subprocess,re,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
for f in ['app.js','trading-cards-base.js','duck-quest/js/game-v96.js','duck-quest/js/love-interests-v326.js','duck-quest/js/gimmick-encounters-v288.js','duck-quest/js/sock-gremlin-v297.js','duck-quest/js/extra-content-v359.js','sw.js']:
 subprocess.run(['node','--check',str(root/f)],check=True,stdout=subprocess.DEVNULL)
# Every new enemy variant: base, four recolors, shiny; 2 idle + hurt.
variants={
 'trashcat':['base','blue','red','brown','orange','shiny'],
 'jellybeanie':['base','orange','lemon','lime','grape','shiny'],
 'whispurr':['base','pink','yellow','purple','green','shiny'],
 'flame-spirit':['base','blue','grey','purple','green','shiny']}
for id,colors in variants.items():
 for c in colors:
  for f in ['idle-1','idle-2','hurt']:
   filename=('' if c=='base' else c+'-')+f+'.webp'
   p=root/'duck-quest/assets/enemies'/id/'base'/filename
   assert p.exists() and p.stat().st_size, p
for c in ['base','blue','purple','yellow','mint','shiny']:
 for f in ['idle-1.png','idle-2.png','hurt.png']:
  p=root/'duck-quest/assets/gimmicks/bownny'/c/f
  assert p.is_file(),p
for person in ['Lain','Tamao']:
 paths=[person+'-idle-1.png',person+'-idle-2.png',person+'-sigh.png',person+('-Duck.png' if person=='Tamao' else '-duck.png')]
 for file in paths:assert (root/'duck-quest/assets/love-interests'/person.lower()/file).is_file()
for extra in ['Annika-School-Hoodie-shop.webp','Annika-Casual-Cute-Dress.webp','Annika-School-Uniform.webp']:
 assert (root/'assets/annika'/extra).exists()
li=(root/'duck-quest/js/love-interests-v326.js').read_text()
for id in ['lain','tamao','shin-tamao','bubble-lain']:
 assert f"{id}:{{" in li or f"'{id}':{{" in li,id
assert 'sceneKitties(state)' in li
assert "['shin','bubble','lain','tamao']" in li
hub=(root/'app.js').read_text()
assert 'if (outfit.backPigtails) ids.push(outfit.backPigtails)' in hub
assert hub.index('"annika-date-sweater", "annika-school-hoodie"')<hub.index('"annika-date-skirt",',hub.index('const annikaBackToFront'))
assert '"Annika-School-Hoodie-shop.webp"' in hub
cafe=(root/'bao-cafe/index.html').read_text()
for key in ['CAFE_FAVORITES','CAFE_EXTRA_CUSTOMERS']:
 m=re.search(r'(?m)^const '+key+r' = ([^\n]+);',cafe)
 assert m,key
 data=json.loads(m.group(1))
 if key=='CAFE_FAVORITES':
  assert data['Lain']['bases']==['greenTea','icedCoffee']
  assert data['Tamao']['toppings']==['boba','cookie','whipped','coffee']
 else: assert {'Lain','Tamao'}<=set(x['name'] for x in data)
assert "!f.colors.length||f.colors.includes" in cafe
quest=(root/'duck-quest/index.html').read_text()
assert quest.index('class="area-option city-area-option"')<quest.index('class="area-option spooky-area-option"')
assert 'extra-content-v359.js?v=24.359' in quest
assert 'flame-spirit-summon-v359' in quest
assert "const APP_CACHE='duck-habit-hub-app-v24-359'" in (root/'sw.js').read_text()
assert json.loads((root/'version.json').read_text())['version']=='24.359'
print('All v24.359 integration, sprites, apparel, scene, customer and cache checks passed.')
